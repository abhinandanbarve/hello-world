/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers

 Description:    Contains the Abstract Handler Interface

 ===============================================================================*/

#ifndef ABSTRACTHANDLER_HXX_
#define ABSTRACTHANDLER_HXX_
#include <vector>
#include <tccore/method.h>
#include <epm/epm.h>

namespace handlers {

typedef std::vector<tag_t>::iterator tagIterator;
/*
 * This is a Abstract handler class. It provides common methods and arguments.
 * This class is designed to handle rule handlers and action handlers.
 * The messageType handler argument should be EPM_rule_message_t for rule handlers
 * and EPM_action_message_t for action handlers. the handlerReturnType should be
 * int for action handlers and EPM_decision_t for rule handlers.
 *
 */
template <class messageType, class handlerReturnType>
class AbstractHandler {
public:
	//Constructor with messsageType, defining if it is a rule or action handler.
	explicit
	AbstractHandler(messageType localMsg);
	// Destructor
	virtual ~AbstractHandler();
	/*
	 * Basic perform method which should be overridden by each custom handler.
	 * The actual handler logic should be implemented in here.
	 */
	virtual handlerReturnType perform(std::vector<tag_t> attachments) = 0;

	/*
	 * This function should be used to collect all the attachments and
	 * trigger the perform method
	 */
	virtual handlerReturnType startHandler() = 0;
	/*
	 * returns the root task of the current workflow process
	 */
	tag_t getRootTask();
	/*
	 * Common method to retrieve handler arguments.
	 *
	 * @param name: Name of the handler parameter to retrieve
	 * @param value_cpp: Output parameter, where the value of the parameter will be stored in.
	 * @param argument_Exists: output parameter, indicating whether the parameter is set in the workflow.
	 * @param maxSize, defining maximum sting length of the result value.
	 * @return int, the error code.
	 */
	int ask_handler_arg(const char* name,std::string* value_cpp,bool * argumentExists, int maxSize);
protected:
	messageType msg;
	/*
	 * Retrieves the value, which is defined by the from_attach handler argument.
	 * currently there are the following possibilities:
	 *
	 * TARGET_ATTACHMENT
	 * REFERENCE_ATTACHMENT
	 * SCHEDULE_TASK_ATTACHMENT
	 *
	 * @param userError, output parameter indicating misconfiguration of the from_attach parameter
	 * @param parameter, from_attach handler parameter name.
	 */
	int getFromAttachValue(int * userError, const char* parameter);

	/*
	 * Follows a path of attributes to retrieve a certain object.
	 *
	 * @param objtag: Starting point of the search path
	 * @param searchPath: vector of attriutes and objectTypes defining the search path.
	 * @param pos: current position in the searchPath vector for recursive calls
	 * @param result: output parameter, result objects
	 */
	void collectObjectfromSearchPath(tag_t objtag, std::vector<std::string> searchpath, int pos, char*template_name , std::vector<tag_t> &result);

	/*
	 * retrieves workflow attachments
	 *
	 * @param attachment_type: type of attachment to be retrieved
	 * @param task: task to use for retrieving
	 * @return vector of attachment tags
	 */
	std::vector<tag_t> get_attachments(tag_t task, int attachment_type);

	/*
	 * validates whether the name of t types are existing TC types.
	 * ANY and NONE are also considered to be valid.
	 *
	 * @param types: types to be validated
	 * @return int: indicating whether or not all types are valid types
	 */
	int validateTypes(std::vector<std::string> &types);
};

} /* namespace handlers */
#endif /* ABSTRACTHANDLER_HXX_ */
