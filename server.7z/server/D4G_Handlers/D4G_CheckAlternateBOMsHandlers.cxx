/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_CheckAlternateBOMs
/*  Program ID:         D4G_CheckAlternateBOMsHandlers.cxx
/*  Description:        Gets the participants  present in the  sign off team  who are assigned by the manager
/*  Input Parameters:   EPM_action_message_t msg -- Workflow task
/*  Return Value:       int ifail -- return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 29-08-2017	         Jayant 		     2944               Initial Creation
* 10-06-2017	         Jayant 		     2944               Added lock and set application bypass so that job can be modified
*
*************************************************************************************************************************/
#include <D4G_Handlers/D4G_CheckAlternateBOMsHandlers.hxx>

EPM_decision_t D4G_CheckAlternateBOMs( EPM_rule_message_t msg ){
	int status = ITK_ok;
	int userError = ITK_ok;
	int attachmentsCount =0;
	tag_t rootTask = NULLTAG;
	tag_t job = NULLTAG;
	tag_t *attachment_tags = NULL;
	char * object_type = NULL;
	char * cpSolutionItemObjectType = NULL;

	ITK_LOG(EPM_ask_root_task(msg.task, &rootTask));
	if(status != ITK_ok)return EPM_nogo;

	ITK_LOG(EPM_ask_job(msg.task, &job));
	if(status != ITK_ok)return EPM_nogo;

	ITK_LOG(EPM_ask_attachments(rootTask,EPM_target_attachment,&attachmentsCount,&attachment_tags));
	if(status != ITK_ok)return EPM_nogo;

	for(int i=0;i<attachmentsCount;i++){
		std::vector<tag_t> vBomItems;
		int iSolutionIRCount = 0;
		tag_t object = attachment_tags[i];
		tag_t tRelType = NULLTAG;
		tag_t* ptSolutionItems;

		ITK_LOG(AOM_ask_value_string(object,OBJECT_TYPE.c_str(), &object_type));

		if(tc_strcmp(object_type , CHANGE_MASTER_REVISiON.c_str())==0)
		{
			ITK_LOG(GRM_find_relation_type(CM_HAS_SOLUTION_ITEM,&tRelType));
			ITK_LOG(GRM_list_secondary_objects_only(object, tRelType, &iSolutionIRCount, & ptSolutionItems));

			if(iSolutionIRCount > 0)
			{
				for(int j=0; j< iSolutionIRCount; j++)
				{
					ITK_LOG(AOM_ask_value_string(ptSolutionItems[j],OBJECT_TYPE.c_str(), &cpSolutionItemObjectType));
					if(tc_strcmp(cpSolutionItemObjectType , BOM_ITEM_REVISON.c_str())==0)
					{
						vBomItems.push_back(ptSolutionItems[j]);
					}
				}
				for (std::vector<tag_t>::iterator it = vBomItems.begin() ; it != vBomItems.end(); ++it)
				{
					char* cpCurrentPartID = NULL;
					char* cpCurrentPlantID = NULL;
					ITK_LOG(AOM_ask_value_string(*it,PART_ATTRIBUTE.c_str(),&cpCurrentPartID));
					ITK_LOG(AOM_ask_value_string(*it,PLANT_ATTRIBUTE.c_str(),&cpCurrentPlantID));

					for(std::vector<tag_t>::iterator itr = vBomItems.begin() ; itr != vBomItems.end(); ++itr)
					{
						if(*it != *itr && cpCurrentPartID!= NULL && cpCurrentPlantID != NULL){
							char* cpPartID = NULL;
							char* cpPlantID = NULL;

							ITK_LOG(AOM_ask_value_string(*itr,PART_ATTRIBUTE.c_str(),&cpPartID));
							ITK_LOG(AOM_ask_value_string(*itr,PLANT_ATTRIBUTE.c_str(),&cpPlantID));

							if(cpPartID != NULL &&  cpPlantID!= NULL &&(tc_strcmp(cpPartID , cpCurrentPartID)==0 && tc_strcmp(cpPlantID , cpCurrentPlantID)==0))
							{
								//Updated below for access related with Test Interface system.
								//Set am bypass so that access issue ignored.
								bool current = set_bypass(true);
								ITK_LOG(AOM_refresh(job, true));
								ITK_LOG(AOM_set_value_string(job, OBJECT_DESC,"There is an alternative BOM(s) in this CM. The start date will be used for all alternative BOM. If you want to provide specific start date to an alternative BOM, abort this workflow and create a new CM for that alternative BOM."));
								ITK_LOG(AOM_save(job));
								ITK_LOG(AOM_refresh(job, false));
								set_bypass(current);
								SAFE_SM_FREE(cpPartID);
								SAFE_SM_FREE(cpPlantID);
								SAFE_SM_FREE(cpCurrentPartID);
								SAFE_SM_FREE(cpCurrentPlantID);
								SAFE_SM_FREE(cpSolutionItemObjectType);
								SAFE_SM_FREE(ptSolutionItems);
								SAFE_SM_FREE(object_type);
								SAFE_SM_FREE(attachment_tags);
								EMH_store_error(EMH_severity_error, ALT_BOM_EXIST);
								return EPM_nogo;
							}

							SAFE_SM_FREE(cpPartID);
							SAFE_SM_FREE(cpPlantID);
						}
					}
					SAFE_SM_FREE(cpCurrentPartID);
					SAFE_SM_FREE(cpCurrentPlantID);
				}
				SAFE_SM_FREE(cpSolutionItemObjectType);
			}
			SAFE_SM_FREE(ptSolutionItems);
		}
		SAFE_SM_FREE(object_type);
	}
	SAFE_SM_FREE(attachment_tags);
	return EPM_go;
}
