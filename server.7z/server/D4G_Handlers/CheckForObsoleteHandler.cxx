/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions

 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers
 Author  : Birger Nielsen

 Description:    Contains the Abstract Handler Interface

 ===============================================================================*/
#include <D4G_Handlers/CheckForObsoleteHandler.hxx>
#include <itkCallHeader.hxx>
#include <cfm/cfm.h>
#include <bom/bom.h>
#include <ps/ps.h>
#include <D4G_ErrorCodes.hxx>
#include <constants.hxx>
#include <bomWindow.hxx>
#include <ITKtools.hxx>
#include <algorithm>
#include <tccore/aom_prop.h>
#include <constants.hxx>

namespace handlers {

CheckForObsoleteHandler::CheckForObsoleteHandler(EPM_rule_message_t msg) : RuleHandler(msg) {
}
/*
 *@see header file for explanation
 */
EPM_decision_t CheckForObsoleteHandler::perform(std::vector<tag_t> attachments){
	using namespace std;
	readParameter();
	// collect parts and BOMs contained in the solution item folders
	// initialize ChangeMaster objects and build changeMasterMap
	collectPlantsAndBomItems(attachments);
	EPM_decision_t decision = EPM_go;
	// do validations for each ChangeMaster
	for(std::map<tag_t,ChangeMaster>::iterator it=changeMasterMap.begin();it!=changeMasterMap.end();++it){
		// do the validation for parts
		if(handlePlants(it->second)==EPM_nogo){
			decision = EPM_nogo;
		// do the validation for bomItems
		} else if(handleBomItems(it->second) == EPM_nogo){
			decision = EPM_nogo;
		}
	}
	return decision;
}

/*
 *@see header file for explanation
 */
void CheckForObsoleteHandler::collectPlantsAndBomItems(std::vector<tag_t> attachments){
	using std::vector;
	using std::string;
	// create a chagneMaster object for each attachment
	for(tagIterator it=attachments.begin();it!=attachments.end();++it){
		ChangeMaster changeMaster(*it);
		string statusToSet(getStatusToSet(*it));
		// analyze changeType to retrieve the status to set in the workflow
		changeMaster.statusToSet=getStatusToSet(*it);
		vector<tag_t> solutionItems=get_tags_property(*it,CM_HAS_SOLUTION_ITEM);
		// plant value of the changeMaster
		string changePlant(get_string_property(*it,PLANT_ATTRIBUTE));
		for(tagIterator jt=solutionItems.begin(); jt!=solutionItems.end();++jt){
			// remember bomItem having a matching plant
			if(is_of_type(*jt,bomItemType)){
				string bomItemPlant(get_string_property(*jt,PLANT_ATTRIBUTE));
				if(bomItemPlant==changePlant){
					changeMaster.bomItems.push_back(*jt);
				}
			// remember parts having a matching plant
			} else if(is_of_type(*jt,partType)){
				vector<tag_t> plants=get_tags_property(*jt,PART_PLANT_RELATION);
				for(tagIterator kt=plants.begin();kt!=plants.end();++kt){
					string partPlant(get_string_property(*kt,OBJECT_NAME));
					if(partPlant==changePlant){
						// Fill the partPlant map: key="plant tag" value="part Revision tag"
						changeMaster.plantPartMap.insert(std::map<tag_t, tag_t>::value_type(*kt,*jt));changeMaster.plantPartMap.insert(std::pair<tag_t, tag_t>(*kt,*jt));
					}
				}
			}
		}
		// fill the changeMasterMap: key="tag of the ChangeMaster" value="ChangeMaster object"
		changeMasterMap.insert(std::map<tag_t,ChangeMaster>::value_type(*it,changeMaster));
	}
}

/*
 *@see header file for explanation
 */
//TODO rename method to handleParts
EPM_decision_t CheckForObsoleteHandler::handlePlants(ChangeMaster changeMaster){
	using std::vector;
	using std::string;
	// iterate through all parts of this change master
	for(std::map<tag_t,tag_t>::iterator it=changeMaster.plantPartMap.begin();it!=changeMaster.plantPartMap.end();++it){
		tag_t part=it->second;
		tag_t plant=it->first;
		// compute bomItems where the part is used(Initializes BOMItemHelper objects)
		vector<BOMItemHelper> localBomItems(whereUsed(plant, part, bomItemType));
		if(changeMaster.statusToSet==STATUS_OBSOLETE){
			for(vector<BOMItemHelper>::iterator jt=localBomItems.begin();jt!=localBomItems.end();++jt){
				// basically computing latest Revision containing the part and having status service or released
				tag_t bomRev(jt->checkStatusForObsolete());
				if(bomRev!=NULLTAG && !containsVector(changeMaster.bomItems,bomRev)){
					return returnWithError(PART_CONTAINED_IN_BOM, part, bomRev);
				}
			}
		} else if(changeMaster.statusToSet==STATUS_SERVICE){
			for(vector<BOMItemHelper>::iterator jt=localBomItems.begin();jt!=localBomItems.end();++jt){
				// basically computing latest Revision containing the part and having status released
				tag_t bomRev=jt->checkStatusForService();
				if(bomRev!=NULLTAG){
					// iterate through bom
					bomWindow window(bomRev,DEFUALT_BOM_VIEW_TYPE);
					vector<tag_t> childLines(get_child_lines(window.getTopLine()));
					for(tagIterator kt=childLines.begin();kt!=childLines.end();++kt){
						// TODO comparing item would be more correct, because no revision rule is used and needed here.
						tag_t itemRevision=get_bomLine_object(*kt);
						if(itemRevision==part){
							// check if the part is marked as production relevant
							string productionRelevant(get_string_property(*kt,PRODUCTION_RELEVANT));
							if(productionRelevant==PRODUCTION_RELEVANT_TRUE && !containsVector(changeMaster.bomItems,bomRev)){
								return returnWithError(PART_IS_PRODUCTION_REVELEVANT_IN_BOM, part, bomRev);
							}
						}
					}
				}
			}
		}
	}
	return EPM_go;
}

/*
 *@see header file for explanation
 */
EPM_decision_t CheckForObsoleteHandler::handleBomItems(ChangeMaster changeMaster){
	using std::vector;
	using std::string;
	std::string changePlant(get_string_property(changeMaster.getTag(),PLANT_ATTRIBUTE));
	// iterate over all BOMItems on the changeMaster
	for(vector<tag_t>::iterator it=changeMaster.bomItems.begin(); it!=changeMaster.bomItems.end();++it){
		if((changeMaster.statusToSet==STATUS_SERVICE) || (changeMaster.statusToSet==STATUS_RELEASED)){
			// open BOMWindow with revision rule.
			bomWindow window(*it,DEFUALT_BOM_VIEW_TYPE);
			window.setRevisionRule(revisionRule);
			// iterate through bom.
			vector<tag_t> childLines(get_child_lines(window.getTopLine()));
			for(tagIterator jt=childLines.begin();jt!=childLines.end();++jt){
				tag_t itemRevision=get_bomLine_object(*jt);
				if(itemRevision!=NULLTAG && (is_of_type(itemRevision,DAN_PART_REVISON) || is_of_type(itemRevision,VENDOR_PART_REVISION))){
					// the matching plant on the Part Revision must not have status obsolete
					if(hasPlantStatus(itemRevision,changePlant,STATUS_OBSOLETE) && !mapContainsValue(changeMaster.plantPartMap,itemRevision)){
						return returnWithError(BOM_CONTAINS_OBSOLETE, *it, itemRevision);
					}
					if(changeMaster.statusToSet==STATUS_RELEASED && hasPlantStatus(itemRevision,changePlant,STATUS_SERVICE)){
						// the Part must not be marked as production relevant
						string productionRelevant(get_string_property(*jt,PRODUCTION_RELEVANT));
						if((productionRelevant==PRODUCTION_RELEVANT_TRUE) && !mapContainsValue(changeMaster.plantPartMap,itemRevision)){
							return returnWithError(BOM_CONTAINS_PRODUCTION_RELEVANT, *it,itemRevision);
						}
					}
				}
			}
		}
	}
	return EPM_go;
}

/*
 *@see header file for explanation
 */
bool hasPlantStatus(tag_t revision, std::string plant, std::string status){
	// retrieve plant objects
	std::vector<tag_t> plants(get_tags_property(revision,PART_PLANT_RELATION));
	// search for the matching plant
	for(tagIterator it=plants.begin(); it!=plants.end(); ++it){
		std::string localPlantName(get_string_property(*it,OBJECT_NAME));
		if(localPlantName==plant){
			// check matching plant for status
			if(hasStatus(*it,status)){
				return true;
			}
		}
	}
	return false;
}

/*
 *@see header file for explanation
 */
void CheckForObsoleteHandler::readParameter(){
		// Part Revision type real name to use
		bool partTypeExists;
		this->ask_handler_arg(PART_TYPE_ARG,&partType,&partTypeExists,-1);
		// BOMItemRevision type real name to use
		bool bomItemTypeExists;
		this->ask_handler_arg(BOM_ITEM_TYPE_ARG,&bomItemType,&bomItemTypeExists,-1);
		// Revision rule to use
		bool revisionRuleExists;
		this->ask_handler_arg(REVISION_RULE_ARG,&revisionRule,&revisionRuleExists,-1);
}

/*
 *@see header file for explanation
 */
bool CheckForObsoleteHandler::containsVector(std::vector<tag_t> collection,tag_t object){
	return std::find(collection.begin(),collection.end(),object)!=collection.end();
}

/*
 *@see header file for explanation
 */
bool CheckForObsoleteHandler::mapContainsValue(std::map<tag_t,tag_t> map, tag_t object){
	for(std::map<tag_t,tag_t>::iterator it=map.begin();it!=map.end();++it){
		if(it->second==object){
			return true;
		}
	}
	return false;
}

/*
 *@see header file for explanation
 */
std::vector<BOMItemHelper> CheckForObsoleteHandler::whereUsed(tag_t plant, tag_t part, std::string type){
	// use ps_parents attribute to compute the BOMItems using this part
	std::vector<tag_t> parents=get_tags_property(part,PS_PARENTS.c_str());
	int status;
	std::vector<BOMItemHelper> result;
	// retrieve plant value
	std::string plantValue(get_string_property(plant,OBJECT_NAME));
	// iterate through all parents
	for(tagIterator it=parents.begin(); it!=parents.end();++it){
		// only BOMItemRevisions are considered
		if(is_of_type(*it,type)){
			// compare plant values
			std::string bomPlant(get_string_property(*it,PLANT_ATTRIBUTE));
			if(plantValue==bomPlant){
				// retrieve item from Item Revision
				tag_t item;
				ITK_LOG(AOM_ask_value_tag(*it,ITEM_ATTTRIBUTE.c_str(),&item));
				// create BOMItemHelper and mark revision for containing this part in the bom.
				BOMItemHelper bomItemHelper(item);
				std::vector<BOMItemHelper>::iterator bomIt=std::find(result.begin(),result.end(),bomItemHelper);
				if(bomIt!=result.end()){
					// mark this revision as containing the part in the bom
					bomIt->setContainsPart(*it,true);
				} else {
					// initialize BOMItemHelper
					bomItemHelper.addAllRevisions();
					// mark this revision as containing the part in the bom
					bomItemHelper.setContainsPart(*it,true);
					result.push_back(bomItemHelper);
				}
			}
		}
	}
	return result;
}

/*
 *@see header file for explanation
 */
EPM_decision_t CheckForObsoleteHandler::returnWithError(int errorCode, tag_t object1, tag_t object2){
	int status;
	using std::string;
	string object1Display(get_string_property(object1, OBJECT_STRING));
	string object2Display(get_string_property(object2, OBJECT_STRING));
	ITK_LOG(EMH_store_error_s2(EMH_severity_error, errorCode, object1Display.c_str(), object2Display.c_str()));
	return EPM_nogo;
}

/*
 *@see header file for explanation
 */
std::string CheckForObsoleteHandler::getStatusToSet(tag_t change){
	std::string changeType(get_string_property(change,CHANGE_TYPE));
	if(changeType=="Obsolete"){
		return STATUS_OBSOLETE;
	} else if(changeType=="Service"){
		return STATUS_SERVICE;
	} else {
		return STATUS_RELEASED;
	}
}

ChangeMaster::ChangeMaster(tag_t object) : BusinessObject(object){
}

BOMItemHelper::BOMItemHelper(tag_t object) : BusinessObject(object) {
}

/*
 *@see header file for explanation
 */
void BOMItemHelper::addRevision(tag_t revision){
	RevisionHelper revisionHelper(revision);
	if(std::find(bomRevisions.begin(),bomRevisions.end(),revisionHelper)==bomRevisions.end()){
		// add a new revision respecting the numeric order of the Item Revision Id.
		bomRevisions.insert(std::upper_bound(bomRevisions.begin(),bomRevisions.end(),revisionHelper),revisionHelper);
	}
}

/*
 *@see header file for explanation
 */
void BOMItemHelper::addAllRevisions(){
	// get all revisions of BOMItem
	std::vector<tag_t> revisions(get_tags_property(object_tag_,"displayable_revisions"));
	for(tagIterator it=revisions.begin(); it!=revisions.end(); ++it){
		this->addRevision(*it);
	}
}

/*
 *@see header file for explanation
 */
tag_t BOMItemHelper::checkStatusForObsolete(){
	// iterate through the revisions of the BOMItem in reverse order using the Item Revision ID attribute
	for(std::vector<RevisionHelper>::reverse_iterator it=bomRevisions.rbegin();it!=bomRevisions.rend();++it){
		tag_t bomRevision=it->getTag();
		// Retrieve all status strings on this revision.
		std::vector<std::string> statusVector(get_status_vector(bomRevision));
		// check whether there is an obsolete status on this revision
		bool hasObsolete = std::find(statusVector.begin(),statusVector.end(),STATUS_OBSOLETE)!=statusVector.end();
		// check whether there is an service status on this revision
		bool hasService = std::find(statusVector.begin(),statusVector.end(),STATUS_SERVICE)!=statusVector.end();
		// check whether there is an release status on this revision
		bool hasReleased = std::find(statusVector.begin(),statusVector.end(),STATUS_RELEASED)!=statusVector.end();
		if(hasObsolete){
			return NULLTAG;
		}
		if(it->containsPart()){
			if(hasService){
				return bomRevision;
			}
			if(hasReleased){
				return bomRevision;
			}
		} else {
			if(hasReleased){
				return NULLTAG;
			}
			if(hasService){
				return NULLTAG;
			}
		}
	}
	return NULLTAG;
}

/*
 *@see header file for explanation
 */
tag_t BOMItemHelper::checkStatusForService(){
	// iterate through the revisions of the BOMItem in reverse order using the Item Revision ID attribute
	for(std::vector<RevisionHelper>::reverse_iterator it=bomRevisions.rbegin();it!=bomRevisions.rend();++it){
		tag_t bomRevision=it->getTag();
		// Retrieve all status strings on this revision.
		std::vector<std::string> statusVector(get_status_vector(bomRevision));
		// check whether there is an obsolete status on this revision
		bool hasObsolete = std::find(statusVector.begin(),statusVector.end(),STATUS_OBSOLETE)!=statusVector.end();
		// check whether there is an service status on this revision
		bool hasService = std::find(statusVector.begin(),statusVector.end(),STATUS_SERVICE)!=statusVector.end();
		// check whether there is an released status on this revision
		bool hasReleased = std::find(statusVector.begin(),statusVector.end(),STATUS_RELEASED)!=statusVector.end();

		if(hasService){
			return NULLTAG;
		}
		if(hasObsolete){
			return NULLTAG;
		}
		if(it->containsPart()){
			if(hasReleased){
				return bomRevision;
			}

		} else {
			if(hasReleased){
				return NULLTAG;
			}
		}
	}
	return NULLTAG;
}

/*
 *@see header file for explanation
 */
void  BOMItemHelper::setContainsPart(tag_t revision, bool value){
	for(std::vector<RevisionHelper>::iterator it = bomRevisions.begin(); it != bomRevisions.end(); ++it){
		if(it->getTag() == revision){
			it->setContainsPart(value);
			break;
		}
	}
}

RevisionHelper::RevisionHelper(tag_t object) : BusinessObject(object), containsPartFlag(false){
}

/*
 *@see header file for explanation
 */
bool RevisionHelper::operator<(RevisionHelper const& object) const{
	std::string::size_type sz;
	tag_t tag=object.getTag();
	// convert revision Id to int for numerical comparison
	int _objRevId(std::stoi(get_string_property(object_tag_,ITEM_REVISION_ID),&sz));
	int objectRevId(std::stoi(get_string_property(tag,ITEM_REVISION_ID),&sz));
	return _objRevId<objectRevId;
}


BusinessObject::BusinessObject(tag_t object) : object_tag_(object){
}
tag_t BusinessObject::getTag() const{
	return object_tag_;
}

} /* namespace handlers */

