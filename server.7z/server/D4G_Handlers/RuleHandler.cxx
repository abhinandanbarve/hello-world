/*
 * RuleHandler.cxx
 *
 *  Created on: Feb 23, 2016
 *      Author: infodba
 */

#include <D4G_Handlers/RuleHandler.hxx>
#include <D4G_Handlers/AbstractHandler.hxx>
#include <itkCallHeader.hxx>
#include <tccore/method.h>
#include <D4G_ErrorCodes.hxx>
#include <constants.hxx>
#include <ITKtools.hxx>
#include <cToolbox.hxx>

namespace handlers {

//Constructor
RuleHandler::RuleHandler(EPM_rule_message_t msg) : AbstractHandler<EPM_rule_message_t, EPM_decision_t>(msg) {
}

// Destructor
RuleHandler::~RuleHandler(){
}

/*
 *@see header file for explanation
 */
EPM_decision_t RuleHandler::startHandler() {
	int userError=ITK_ok;
	int status;
	// Get attachment type to work with
	int fromattach = getFromAttachValue(&userError, TO_ATTACH);

	// Get the type whitelist
	std::string includeType;
	bool includeTypeExists=false;
	ask_handler_arg(INCLUDE_TYPE,&includeType,&includeTypeExists,0);

	// Get the type blacklist
	std::string excludeType;
	bool excludeTypeExists=false;
	ask_handler_arg(EXCLUDE_TYPE,&excludeType,&excludeTypeExists,0);
	std::vector<tag_t> filteredAttachments;

	std::vector<std::string> includetypes(split_and_trim_to_vector_nonempty(includeType,",", " \t"));
	ITK_LOG(validateTypes(includetypes));
	std::vector<std::string> excludetypes(split_and_trim_to_vector_nonempty(excludeType,",", " \t"));
	ITK_LOG(validateTypes(excludetypes));
	std::vector<tag_t> attachments=get_attachments(getRootTask(),fromattach);

	// filter attachments with object types according to the type whitelist and blacklist.
	for(std::vector<tag_t>::iterator it=attachments.begin();it!=attachments.end();++it){
		if((!includeTypeExists || is_of_type(*it,includetypes)) && (!is_of_type(*it,excludetypes) || !excludeTypeExists)){
			filteredAttachments.push_back(*it);
		}
	}

	// get search string parameter
	bool searchPathExists = false;
	std::string search_string("");
	ITK_LOG(ask_handler_arg("search_string",&search_string,&searchPathExists,0));
	EPM_decision_t decision = EPM_go;
	if(searchPathExists){
		// parse and validate search_String parameter
		std::vector<std::string> searchpath =split_and_trim_to_vector_nonempty(search_string,",.", " ");
		if(searchpath.size() %2!=0){
			ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE,
					"search_string", "an even number of dot separated values"));
			userError--;
		}
		// trigger the perfom method on every object resulting from the search_string
		std::vector<tag_t> result;
		for(std::vector<tag_t>::iterator it=filteredAttachments.begin();it!=filteredAttachments.end();++it){
			///Issue 3448
			//There is additional parameter introduced in the the function call collectObjectfromSearchPath for the workflow template name
			//Here it is passed a blank string as there is additional logic in collectObjectfromSearchPath which
			// is only meant for if the workflow is Release Prototype or SAP transfer with BOM
			collectObjectfromSearchPath(*it,searchpath,0,"",result);
			if(perform(result) == EPM_nogo){
				decision = EPM_nogo;
			}
		}
	} else {
		// if search string is not available trigger perform method on the filtered attachments
		if(perform(filteredAttachments) == EPM_nogo){
			decision = EPM_nogo;
		}
	}

	if(userError != ITK_ok){
		return EPM_nogo;
	} else{
		return decision;
	}
}

}  /* namespace handlers */


