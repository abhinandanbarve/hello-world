/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers
 Author  : Birger Nielsen

 Description:    Contains the Abstract Handler Interface

 ===============================================================================*/

#include "D4G_Handlers/AbstractHandler.hxx"
#include <itkCallHeader.hxx>
#include <epm/epm.h>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <iostream>
#include <vector>
#include <memory>
#include <D4G_ErrorCodes.hxx>
#include <constants.hxx>
#include <tccore/aom.h>

namespace handlers {

/*
 *@see header file for explanation
 */
template<class messageType, class handlerReturnType>
AbstractHandler<messageType, handlerReturnType>::~AbstractHandler() {
	// TODO Auto-generated destructor stub
}

/*
 *@see header file for explanation
 */
template<class messageType, class handlerReturnType>
AbstractHandler<messageType, handlerReturnType>::AbstractHandler(messageType localMsg) : msg(localMsg){
}

/*
 *@see header file for explanation
 */
template<class messageType, class handlerReturnType>
int AbstractHandler<messageType, handlerReturnType>::getFromAttachValue(int * userError, const char* parameter){
	std::string from_attach(TARGET_ATTACHMENT); //If argument not specified default to TARGET
	int fromattach = EPM_target_attachment;
	bool frommattachExists = false;
	// retrieve from_attach handler parameter
	ask_handler_arg(parameter, &from_attach, &frommattachExists, 0);
	if(frommattachExists){
		from_attach= StrCaps(from_attach);
		if(from_attach==TARGET_ATTACHMENT){fromattach = EPM_target_attachment;
		} else if(from_attach==REFERENCE_ATTACHMENT){fromattach = EPM_reference_attachment;
		} else if(from_attach==SCHEDULE_TASK_ATTACHMENT){fromattach = EPM_schedule_task_attachment;
		} else if(!from_attach.empty()){
			userError--;
			int status;
			ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, FROM_ATTACH, "TARGET, REFERENCE or SCHEDULE_TASK"));
		}
	}
	return fromattach;
}

/*
 *@see header file for explanation
 */
template<class messageType, class handlerReturnType>
int AbstractHandler<messageType, handlerReturnType>::validateTypes(std::vector<std::string> &types){
	int userError = ITK_ok;
	for(std::vector<std::string>::iterator it=types.begin();it!=types.end();++it){
		if(validate_type(*it)){
			ITK_LR(EMH_store_error_s1(EMH_severity_error, UE_WRONG_TYPE,it->c_str()));
			userError--;
		}
	}
	return userError;
}

/*
 *@see header file for explanation
 */
template<class messageType, class handlerReturnType>
void AbstractHandler<messageType, handlerReturnType>::collectObjectfromSearchPath(tag_t objtag, std::vector<std::string> searchpath, int pos,char* template_name, std::vector<tag_t> &result){
	//If we have not yet reached the end of the searchpath
	if(pos<searchpath.size()){
		//we call recursively on all items that fit the next step of the searchpath
		std::string property = searchpath[pos];
		std::string type = searchpath[pos+1];
		int found = ask_prop_exists(objtag, (char*) property.c_str());
		if(found){
			AOM_refresh(objtag, false);
			std::vector<tag_t> targets = get_tags_property(objtag, (char*) property.c_str());
			for(auto itTargets = targets.begin(); itTargets!=targets.end(); itTargets++){
				if(is_of_type(*itTargets, type) ){
					//Set answer to outcome of recursive request
          ///Issue 3448
				  //There is additional parameter introduced in the the function call collectObjectfromSearchPath for the workflow template name
				  //Here it is passed a blank string as there is additional logic in collectObjectfromSearchPath which
				  // is only meant for if the workflow is Release Prototype or SAP transfer with BOM
					collectObjectfromSearchPath(*itTargets, searchpath, pos+2,"", result);
				}
			}
		}
	} else{
		AOM_refresh(objtag, false);
		result.push_back(objtag);
	}
}

/*
 *@see header file for explanation
 */
template<class messageType, class handlerReturnType>
std::vector<tag_t> AbstractHandler<messageType, handlerReturnType>::get_attachments(tag_t task, int attachment_type){
	int status=ITK_ok; //only needed for the ITK_LOG macro;
	(void)attachment_type; // only needed for the C4100 error
	std::vector<tag_t> attachments;
	tag_t rootTask=NULLTAG;
	ITK_LOG(EPM_ask_root_task(task, &rootTask));
	int attachmentsCount=0;
	tag_t *attachment_tags=NULL;
	ITK_LOG(EPM_ask_attachments(rootTask,attachment_type,&attachmentsCount,&attachment_tags));
	for(int i=0;i<attachmentsCount;++i){
		attachments.push_back(attachment_tags[i]);
	}
	SAFE_SM_FREE(attachment_tags);
	return attachments;
}

/*
 *@see header file for explanation
 */
template<class messageType, class handlerReturnType>
tag_t AbstractHandler<messageType, handlerReturnType>::getRootTask() {
	tag_t root;
	ITK_LR(EPM_ask_root_task((this->msg).task, &root));
	return root;
}

/*
 * gets a handler argument value form TC
 *
 * @param arguments, the TC argument list
 * @param name, name of the argument to be retrieved
 * @param value_cpp, value which will be set as output in this function
 *
 * @return int, success of this operation.
 */
template<class messageType, class handlerReturnType>
int
AbstractHandler<messageType, handlerReturnType>::ask_handler_arg(const char* name,std::string* value_cpp,bool * argumentExists, int maxSize) {
	// reset value
	char *value=NULL;
	value=NULL;
	*argumentExists=false;
	// iterate through all arguments
	if (this->msg.arguments) {
		TC_init_argument_list(this->msg.arguments);
		int numArgs=TC_number_of_arguments(this->msg.arguments);
		for (int i=0;i<numArgs;i++) {
			// get arg name & value
			char* argName=NULL;
			char* argValue=NULL;
			ITK_LR(ITK_ask_argument_named_value(TC_next_argument(this->msg.arguments),&argName,&argValue));
			char* substValue=NULL;
			ITK_LR(EPM_substitute_keyword(argValue,&substValue));
			// check size of value
			if ((maxSize<=0)||((maxSize>0)&&(tc_strlen(substValue)<=maxSize))) {
				// check name
				if (tc_strcmp(name,argName)==0) {
					*value_cpp=substValue?std::string(const_cast<const char *>(substValue)):"";
					*argumentExists=true;
				}
			}
			SAFE_SM_FREE(argName);
			SAFE_SM_FREE(argValue);
			SAFE_SM_FREE(substValue);
		}
	}
	return ITK_ok;
}
/*
 * The following template instantiations are needed, to prevent linker errors.
 * To get the compiler to instantiate the required code we can use explicit instantiation.
 */
template class AbstractHandler<EPM_rule_message_t, EPM_decision_t>;
template class AbstractHandler<EPM_action_message_t, int>;
}
