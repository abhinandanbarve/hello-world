/*
 * MMOAfterValidationHandler.hxx
 *
 *  Created on: Feb 28, 2017
 *      Author: infodba
 */

#ifndef MASSOBSOLETEPREPARATIONHANDLER_HXX_
#define MASSOBSOLETEPREPARATIONHANDLER_HXX_


#include <fclasses/tc_stdlib.h>
#include <tc/emh.h>
#include <tc/preferences.h>
#include <tc/tc_util.h>
#include <sa/user.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/project.h>

#include <tcinit/tcinit.h>

#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <set>
#include <sstream>
#include <vector>
#include <algorithm>

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>
#include <D4G_ErrorCodes.hxx>
#include <D4G_Core/D4G_EPM_Handlers.hxx>
#include <epm/epm_toolkit_tc_utils.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>

#define  FORMAT_TEXT                         "TEXT"
#define  REF_TEXT                            "Text"
#define  DATASET                             "Dataset"
#define  REFERENCE_ITEMS_REL                 "CMReferences"
#define  SOLUTION_ITEM_REL                   "CMHasSolutionItem"
#define  DANFOSS_BOMITEMREV                  "D4G_BOMItemRevision"
#define  TEMP_DIR                            "TC_SHARED_MEMORY_DIR"
#define  PREF_FROM_TO_CSV                    "D4G_Mass_Update_From_To_File_Column"
#define  CMIMPLEMENTS                        "CMImplements"
#define  CHANGE_REQ_REV                      "D4G_ChangeReqRevision"
#define  REMOVE_STATUS                       "Remove status"
#define  READY_FOR_MMU                       "D4G_ReadyForMMU"

int D4G_Mass_Obsolete_Preparation( EPM_action_message_t msg );

#endif /* MASSOBSOLETEPREPARATIONHANDLER_HXX_ */
