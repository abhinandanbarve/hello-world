/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers

 Description:    contains the implementation of the D4G-check-properties handler.


 Date            Name      Task Id      Description of Change
 -------------------------------------------------------------------------------------------------------------------------
 06-Jun-2017    Amruta      2388        Implemented changes for checking first level child for BOM and Design revision
                                        for Prototype Release workflow
 23-Jun-2017    Amruta      3448        Implement changes for checking staus of first level child of BOM item for SAP transfer with BOM workflow
 7-Aug-2017     Amruta      3448,2388   Regression issue fix for issue TesTC11_012,TestTC11_027,TestTC11_028
 9-Aug-2017     Amruta      3448        Regression issue fix TestTC11_047
 14-Sep-2017    Amruta      3448        Addressed empty solution item folder issue for TestTc11_093
 ========================================================================================================================*/

#include <epm/epm.h>

#include <tc/emh.h>
#include <tc/preferences.h>
#include <bom/bom.h>
#include <epm/epm_toolkit_tc_utils.h>

#include <sa/user.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/project.h>

#include <tcinit/tcinit.h>

#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <set>
#include <sstream>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>
#include <D4G_ErrorCodes.hxx>
#include <D4G_Core/D4G_EPM_Handlers.hxx>
#include <bomWindow.hxx>
#include <constants.hxx>
#include <D4G_Handlers/AbstractHandler.hxx>
#include <D4G_Handlers/SetPropertiesHandler.hxx>

map<tag_t,vector<checktarget>> convertToItemItemRevMap(vector<checktarget> objects){
	int status=ITK_ok; //only needed for the ITK_LOG macro;
	map<tag_t,vector<checktarget>> result;
	for(int i=0; i<objects.size();i++){
		if(is_of_type(objects[i].objtag,"ItemRevision")){
			tag_t item=NULLTAG;
			ITK_LOG(AOM_ask_value_tag(objects[i].objtag,"items_tag",&item));
			map<tag_t,vector<checktarget>>::iterator itMap =result.find(item);
			if(itMap!=result.end()){
				(itMap->second).push_back(objects[i]);
			} else {
				vector<checktarget> values;
				values.push_back(objects[i]);
				result.insert(make_pair(item,values));
			}
		}
	}
	return result;
}


/******************************************************************************************************************
Function Name    : collectObjectfromSearchPath
Description      : This method based on the searchpath traverse the relation to identify the target object.There additional logic
                 : to identify the first level child items for BOM and Design Rev ,and add them to target object list
nput Parameters  :tag_t objtag              -- Target business Object on which workflow invoked
                  vector<string> searchpath -- searchpath argument read from D4G-check-properties handler
                  int pos                   -- position of the searchstring
                  char* template_name       -- workflow name,
                  vector<checktarget> result -- object tags for which status needs to be checked
Return Value     :int status -- ITK_ok
NOTES            :
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date              Name        Task Id       Description of Change
* 05-Jun-2017       Amruta      2388          Implemented changes for checking first level child for BOM and Design revision
* 23-Jun-2017       Amruta      3448          Implemented first level check for BOM iten for SAP transfer wih BOM
* 09-Aug-2017        Amruta      3448          Regression issue fix
* 14-Sep-2017       Amruta      3448          Addressed empty solution items folder issue
*---------------------------------------------------------------------------------------------------------------------------------
*
************************************************************************************************************************/

int  collectObjectfromSearchPath(tag_t objtag, vector<string> searchpath,
	                           	 int pos, char* template_name , vector<checktarget> &result)
{

	int    status      = ITK_ok;
    int    count =0;
    char*  prefValue = NULL;

    std::string workflow_template_name (template_name);

	//If we have not yet reached the end of the searchpath
	if(pos<searchpath.size()){
		vector<tag_t> targets;
		if(searchpath[pos].compare(0, 1, "<")==0){
			// Looking for a backwards relation
			string relation = searchpath[pos].substr(1, searchpath[pos].length());
			string type = searchpath[pos+1];
			ITK_LOG(get_primary_for_relation(objtag, relation, type, targets));

		} else if(searchpath[pos].compare(0, 1, ">")==0){
			// Looking for a forwards relation
			string relation = searchpath[pos].substr(1, searchpath[pos].length());
			string type = searchpath[pos+1];
			ITK_LOG(get_secondary_for_relation(objtag, relation, type, targets));

		} else{
			// We call recursively on all items that fit the next step of the searchpath
			string property = searchpath[pos];
			string type = searchpath[pos+1];
			int found = ask_prop_exists(objtag, (char*) property.c_str());
			if(found){
				AOM_refresh(objtag, false);
				targets = get_tags_property(objtag, (char*) property.c_str());
				for(auto itTargets = targets.begin(); itTargets!=targets.end(); ){
					if(is_of_type(*itTargets, type) ){//filter for types
						itTargets++;
					} else{
						itTargets = targets.erase(itTargets);
					}
				}
			}
		}
		for (auto itTargets = targets.begin(); itTargets!=targets.end()&& status==ITK_ok; itTargets++){
			//Set answer to outcome of recursive request
			status = collectObjectfromSearchPath(*itTargets, searchpath, pos+2,template_name, result);
		}
	} else{

		//3448  Regression issue fix
		if(workflow_template_name.compare(SAP_TRANSFER_WITH_BOM)==0 ||
				workflow_template_name.compare(PROTOTYPE_RELEASE)==0){
		if(!is_of_type(objtag, CHANGE_MASTER_REVISiON))
	    {

				result.push_back(checktarget(objtag));
			}
		}
		else
		{
			result.push_back(checktarget(objtag));
	    }
	}

	//Issue 2388
	//Check if the BOM Item rev and the Design Rev object have children and check the status
	vector<tag_t> objTags;


//Regression issue fix for TesTC11_012
if(workflow_template_name.compare(SAP_TRANSFER_WITH_BOM)==0 ||
		workflow_template_name.compare(PROTOTYPE_RELEASE)==0){

	   if (is_of_type(objtag, DESIGN_REVISION)
			|| is_of_type(objtag, BOM_ITEM_REVISON)
			|| is_of_type(objtag, CUS_APP_DESIGN)
			|| is_of_type(objtag, CHANGE_MASTER_REVISiON))

	    {

		//Check for all the item under the CM solution Item ,Parts ,Bom Item,Drawing ,Design

		if (is_of_type(objtag, CHANGE_MASTER_REVISiON)) {

			vector<tag_t> solutionItems = get_tags_property(objtag,
					CM_HAS_SOLUTION_ITEM);
			if (solutionItems.size() != 0) {
				for (std::vector<tag_t>::iterator it = solutionItems.begin();
						it != solutionItems.end(); ++it) {
					if (is_of_type(*it, PART_REVISION) ) {

                        //Issue 3448
						//IF workflow is SAP tranfer with BOM then only BOM items needs to be  considered
						if(workflow_template_name.compare(SAP_TRANSFER_WITH_BOM)!=0){

							objTags.push_back(*it);

                       }

					} else if (is_of_type(*it, BOM_ITEM_REVISON)) {
						objTags.push_back(*it);


					} else if (is_of_type(*it, DESIGN_REVISION)) {

						//Issue 3448
						//If workflow is SAP tranfer with BOM then only BOM items needs to be  considered
						if(workflow_template_name.compare(SAP_TRANSFER_WITH_BOM)!=0){
						  objTags.push_back(*it);


						 }
					} else if (is_of_type(*it, D4G_DRAWING_REVISION)) {

						//Issue 3448
						//If workflow is SAP tranfer with BOM then only BOM items needs to be  considered
						 if(workflow_template_name.compare(SAP_TRANSFER_WITH_BOM)!=0){

							 objTags.push_back(*it);

						 }
					}

				} //for
			} //if
			else{
				//no Items under Solution items
				result.push_back(checktarget(objtag));
			}
		} else if (is_of_type(objtag, BOM_ITEM_REVISON) ||
				   is_of_type(objtag, DESIGN_REVISION) ||
				   is_of_type(objtag, CUS_APP_DESIGN) ){

			      objTags.push_back(objtag);

		}

		for (std::vector<tag_t>::iterator it = objTags.begin();
				it != objTags.end(); ++it) {
            //Regression Issue fix
			//Check the Solution Item status if it anything below Approved
			//Status or Obsolete
           if (is_of_type(objtag, CHANGE_MASTER_REVISiON)){
			std::vector<tag_t> statusRev = get_tags_property_vector(*it,
														"release_status_list");
			//no Status hence in Working state
			if (statusRev.size()==0)
			{
				result.push_back(checktarget(*it));
			}

			for (std::vector<tag_t>::iterator itr =	statusRev.begin();itr != statusRev.end(); ++itr)
			{
				char *status_type_rev;
				ITK_LR (RELSTAT_ask_release_status_type(*itr,&status_type_rev));

				std::string typeName(status_type_rev);

			    if (typeName == STATUS_INREVIEW || typeName ==STATUS_OBSOLETE)
				{
						result.push_back(checktarget(*it));
				}
			}
           }

			//Check if the Design/Bom Rev has BVR attached
			vector<tag_t> bvrs = get_tags_property(*it, "structure_revisions");
			if (bvrs.size() != 0) {

				bomWindow window(*it, DEFUALT_BOM_VIEW_TYPE);

				 ITK_LOG(PREF_ask_char_value ( REVISON_PREFERENCE.c_str(), count, &prefValue));

		         window.setRevisionRule(prefValue);


				vector<tag_t> childLines(get_child_lines(window.getTopLine()));
				for (std::vector<tag_t>::iterator kt = childLines.begin();
						kt != childLines.end(); ++kt) {

					//Get Latest Rev
					tag_t itemRevision = get_bomLine_object(*kt);

					if (itemRevision != NULLTAG ) {

						vector<tag_t> revisions = get_tags_property_vector(
								itemRevision, "revision_list");

						//If only one revision check the status
						if (revisions.size() == 1) {

							std::vector<tag_t> statusLatestRev =
									get_tags_property_vector(itemRevision,
											"release_status_list");
							//Latest working rev no status hence in working status
							if (statusLatestRev.size() == 0) {


								result.push_back(checktarget(itemRevision));
							}
							for (std::vector<tag_t>::iterator itr =
									statusLatestRev.begin();
									itr != statusLatestRev.end(); ++itr) {

								char *status_type_latest_rev;
								ITK_LR(
										RELSTAT_ask_release_status_type(*itr,&status_type_latest_rev));
								std::string typeName(status_type_latest_rev);

								//Latest working rev In Review status
								if (typeName == STATUS_INREVIEW) {

									result.push_back(checktarget(itemRevision));
									break;
								}
								//Regression issue fox TestTC11_027,TestTC11_028
								if(typeName == STATUS_OBSOLETE)
								{
									result.push_back(checktarget(itemRevision));
									break;
								}

							}
						}
						//If more than one revision then check the  rest of the revision status
						if (revisions.size() > 1) {

							//Get Latest rev status

							std::vector<tag_t> statusLatestRev =
									get_tags_property_vector(itemRevision,
											"release_status_list");
							//If Latest revision in working status
							if (statusLatestRev.size() == 0) {
								result.push_back(checktarget(itemRevision));

							}
							for (std::vector<tag_t>::iterator itr =
									statusLatestRev.begin();
									itr != statusLatestRev.end(); ++itr) {

								char *status_type_latest_rev;
								ITK_LR(
										RELSTAT_ask_release_status_type(*itr,&status_type_latest_rev));
								std::string latestStatus(
										status_type_latest_rev);

								//If Latest revision in Review status
								if (status_type_latest_rev == STATUS_INREVIEW) {
									result.push_back(checktarget(itemRevision));
								}

							}

							for (int k = 0; k < revisions.size(); k++) {

								//Latest revision status check with previous has been already done so break

								if (revisions[k] == itemRevision) {

									break;
								}
								//Get prev release status
								std::vector<tag_t> status =
										get_tags_property_vector(revisions[k],
												"release_status_list");

								//Check status for previous revisions and compare with latest revision status
								for (std::vector<tag_t>::iterator it =
										status.begin(); it != status.end();
										++it) {

									char *status_type;
									ITK_LR(
											RELSTAT_ask_release_status_type(*it,&status_type));
									std::string typeName(status_type);

									//Previous revision status is Released
									if (typeName == STATUS_RELEASED) {

										if (statusLatestRev.size() == 0) {
											result.pop_back();
										}

										for (std::vector<tag_t>::iterator itr =
												statusLatestRev.begin();
												itr != statusLatestRev.end();
												++itr) {

											char *status_type_latest_rev;
											ITK_LR(
													RELSTAT_ask_release_status_type(*itr,&status_type_latest_rev));
											std::string latestStatus(
													status_type_latest_rev);
											//Previous revision status is Obsolete
											if (latestStatus
													== STATUS_OBSOLETE) {

												result.push_back(
														checktarget(
																itemRevision));
												break;
											}
											if (latestStatus
													== STATUS_INREVIEW) {
												result.pop_back();
											}
										}

									} //for

								}   //for
							} // If rev size >1
						} //if

					}
				}
				// for

			}//If

		} //for
	} //IF
} //If work flow template name
	SAFE_SM_FREE(prefValue);

	return status;
}

void checkPropertyAtomic(const vector<string>& toproperties,
		checktarget &target, const vector<string>& fromvalues,
		const vector<string>& properties, const vector<string>& values,
		const set<string>& allowedstati, const set<string>& disallowedstati,
		const vector<string>& relationpath ,bool& checkstatusfail,char* template_name) {

	AOM_refresh(target.objtag, false);
	target.passed=true;
	for (int i = 0; i < toproperties.size(); i++) {
		string propvalue = get_display_property(target.objtag, toproperties[i]);
		if (fromvalues[i] != propvalue) {
			target.passed = false;
			string args[3] = {get_display_property(target.objtag, "object_string") , properties[i], values[i]};
			target.errors.push_back(TCerror(EMH_severity_error, CHECK_PROPERTY));
			target.errors.back().args = vector<string>(args, args+sizeof(args)/sizeof(string));
		}
	}
	for (int i = 0; (i < properties.size()); i++) {
		string propvalue = get_display_property(target.objtag, properties[i]);
		if (values[i] == "$TODAY" ) {
			
			date_t dtCurrentDate = NULLDATE;
			date_t pcValueDate = NULLDATE;
			int iDateCompare = 0;

            //get Current time
            get_current_time( &dtCurrentDate );						
			
			ITK_string_to_date( propvalue.c_str(), &pcValueDate );
								
			POM_compare_dates (dtCurrentDate, pcValueDate, &iDateCompare);
				
			if(iDateCompare == -1 && properties[i] == "d4g_CommonStartDate" )
			{
				target.passed = false;
				string args[2] = {get_display_property(target.objtag, "object_string") };
				target.errors.push_back(TCerror(EMH_severity_error, CHECK_COMMON_START_DATE));
				target.errors.back().args = vector<string>(args, args+sizeof(args)/sizeof(string));
			}
		} else if (values[i] != propvalue) {
			target.passed = false;
			string args[3] = {get_display_property(target.objtag, "object_string") , properties[i], values[i]};
			target.errors.push_back(TCerror(EMH_severity_error, CHECK_PROPERTY));
			target.errors.back().args = vector<string>(args, args+sizeof(args)/sizeof(string));
		}
	}
	if (!allowedstati.empty() || !disallowedstati.empty()) {
		bool statusOK=true;
		vector<tag_t> stati = get_tags_property_vector(target.objtag, "release_status_list");
		if (stati.size() == 0
				&& ((!allowedstati.empty() && !allowedstati.count("NONE")) || disallowedstati.count("NONE"))) {

			statusOK=false;
		}
		if (stati.size()>0 && disallowedstati.count("ANY")) {
			statusOK=false;
		}
		if (!allowedstati.count("ANY")) {
			for (int i = 0; i < stati.size(); i++) {
				string name = get_string_property(stati[i], "object_name");
				if (!allowedstati.empty() && !allowedstati.count(name)) {
					statusOK=false;
				}
				if (disallowedstati.count(name)) {
					statusOK=false;
				}
			}
		}
		if (!statusOK) {

			checkstatusfail = true;
			target.passed = false;

			//Issue 2388
			//Following lines were commented as all the object strings for which the
			//status has failed would be collected and reported in string.

			//****string args[1] = {get_display_property(target.objtag, "object_string")};
			//****target.errors.push_back(TCerror(EMH_severity_error, CHECK_STATUS));
			//***target.errors.back().args = vector<string>(args, args+sizeof(args)/sizeof(string));
		}
	}
	if (!relationpath.empty()){
		vector<checktarget> relatedObjs;

		collectObjectfromSearchPath(target.objtag, relationpath, 0,
				                     template_name, relatedObjs);

		if (relatedObjs.empty()) {
			target.passed = false;
			string args[2] = {get_display_property(target.objtag, "object_string"), relationpath.back()};
			target.errors.push_back(TCerror(EMH_severity_error, CHECK_RELATION));
			target.errors.back().args = vector<string>(args, args+sizeof(args)/sizeof(string));
		}
	}
}

string writeCheckDescription(const vector<string>& toproperties, const vector<string>& fromvalues,
		const vector<string>& properties, const vector<string>& values,
		const set<string>& allowedstati, const set<string>& disallowedstati) {
	string check_desc;
	for(int j=0; j<properties.size(); j++){
		if(check_desc.empty()){
			check_desc.append("["+properties[j]+"="+values[j]);
		} else {
			check_desc.append(", "+properties[j]+"="+values[j]);
		}
	}
	for(int j=0; j<toproperties.size(); j++){
		if(check_desc.empty()){
			check_desc.append("["+toproperties[j]+"="+fromvalues[j]);
		} else {
			check_desc.append(", "+toproperties[j]+"="+fromvalues[j]);
		}
	}
	if(!allowedstati.empty()){
		vector<string> allowed(allowedstati.begin(), allowedstati.end());
		if(check_desc.empty()){
			check_desc.append("[-allowed_status=("+allowed[0]);
		} else {
			check_desc.append(", -allowed_status=("+allowed[0]);
		}
		for(int j=1; j<allowed.size(); j++){
			check_desc.append(", "+allowed[j]);
		}
		check_desc.append(")");
	}
	if(!disallowedstati.empty()){
		vector<string> disallowed(disallowedstati.begin(), disallowedstati.end());
		if(check_desc.empty()){
			check_desc.append("[-disallowed_status=("+disallowed[0]);
		} else {
			check_desc.append(", -disallowed_status=("+disallowed[0]);
		}
		for(int j=1; j<disallowed.size(); j++){
			check_desc.append(", "+disallowed[j]);
		}
		check_desc.append(")");
	}
	check_desc.append("]");
	return check_desc;
}

/*
 * Rule Handler that follows a searchpath and checks if specified types at
 * the end of this path have the specified values on the specified properties.
 * If match_one is not set every object at the end of the searchpath must match.
 * If match_one is set at least one (per included attachment) must match.
 * Handler arguments:
 *  -to_attach, -include_type, -search_string
 *  -from_property, -to_property, -property, -value
 *  -allowed_status, -disallowed_status, -has_relation
 *  -match_exists, -group_revisions,-not
 */
EPM_decision_t D4G_CheckPropertiesDeepSearch( EPM_rule_message_t msg )
{
	int status = ITK_ok; //failure status, if this is ever not ITK_ok we MEM_FREE and abort
	int userError = ITK_ok;
	EPM_decision_t decision = EPM_nogo;

	string failedObject;
	string soltionItemMissingErr;
	char* template_name=NULL;
	bool checkstatus = false;

	//get all arguments from the msg
	string to_attach("TARGET"); //If argument not specified default to TARGET
	int toattach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"to_attach",&to_attach,0));
	to_attach= StrCaps(to_attach);
	if(to_attach=="TARGET"){toattach = EPM_target_attachment;
	} else if(to_attach=="REFERENCE"){toattach = EPM_reference_attachment;
	} else if(to_attach=="SCHEDULE_TASK"){toattach = EPM_schedule_task_attachment;
	} else if(!to_attach.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "to_attach", "TARGET, REFERENCE or SCHEDULE_TASK"));
	}
  
  
  //***Issue 3448******
  //Get the process template name for the root task
  //The process template name would be verified is it is SAP tranfer with BOM
  //This issue would only address if the process template is SAP tranfer with BOM

	tag_t root;
	ITK_LOG(EPM_ask_root_task(msg.task, &root));
	ITK_LOG(EPM_ask_name2(root,&template_name));
	//cout <<"****3448 Root task template name******" <<template_name;


	string include_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"include_type",&include_type,0));
	vector<string> includetypes =split_and_trim_to_vector_nonempty(include_type,",", " \t");
	if (includetypes.empty()){
		includetypes.push_back("ANY");
	}
	if(validate_type(includetypes)){userError--;}

	string exclude_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"exclude_type",&exclude_type,0));
	vector<string> excludetypes =split_and_trim_to_vector_nonempty(exclude_type,",", " \t");
	if(validate_type(excludetypes)){userError--;}

	string search_string("");
	ITK_LOG(ask_handler_arg(msg.arguments,"search_string",&search_string,0));
	vector<string> searchpath =split_and_trim_to_vector_nonempty(search_string,",.", " ");
	if(searchpath.size() %2!=0){
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE,
				"search_string", "an even number of dot separated values"));
		userError--;
	}


	//Pairs of compare values. Have to match in number. If a pair is not set we ignore it.
	vector<string> fromproperties;
	ITK_LOG(ask_handler_arg_as_vector(msg.arguments,"from_property",&fromproperties));

	vector<string> toproperties;
	ITK_LOG(ask_handler_arg_as_vector(msg.arguments,"to_property",&toproperties));


	if(fromproperties.size()!=toproperties.size()){
		userError--;
		ITK_LOG(EMH_store_error(EMH_severity_error, UE_TO_FROM_NR));
	}

	vector<string> properties;
	ITK_LOG(ask_handler_arg_as_vector(msg.arguments,"property",&properties));

	vector<string> values;
	ITK_LOG(ask_handler_arg_as_vector(msg.arguments,"value",&values));

	if(properties.size()!=values.size()){
		userError--;
		ITK_LOG(EMH_store_error(EMH_severity_error, UE_PROP_VALUE_NR));
	}

	//Status checking is mutually exclusive
	string allowedstatus("");
	ITK_LOG(ask_handler_arg(msg.arguments,"allowed_status",&allowedstatus,0));
	set<string> allowedstati =split_and_trim_to_set(allowedstatus,",", " ");

	string disallowedstatus("");
	ITK_LOG(ask_handler_arg(msg.arguments,"disallowed_status",&disallowedstatus,0));
	set<string> disallowedstati =split_and_trim_to_set(disallowedstatus,",", " ");

	if(!allowedstati.empty()&& !disallowedstati.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_EXCLUSIVE_ARGS,
				"allowed_status", "disallowed_status"));
	}

	string has_relation("");
	ITK_LOG(ask_handler_arg(msg.arguments,"has_relation",&has_relation,0));
	vector<string> relationpath =split_and_trim_to_vector_nonempty(has_relation,",.", " ");
	if(relationpath.size() %2!=0){
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE,
				"has_relation", "an even number of dot separated values"));
		userError--;
	}

	bool matchone;
	ITK_LOG(ask_handler_arg(msg.arguments,"match_exists",&matchone));

	// Check for deprecated argument -match_all=FALSE
	if(!matchone){
		string match_all("");
		ITK_LOG(ask_handler_arg(msg.arguments,"match_all",&match_all,0));
		match_all=StrCaps(match_all);
		if(match_all=="FALSE"){matchone=TRUE;}
	}

	bool negate;
	ITK_LOG(ask_handler_arg(msg.arguments,"not",&negate));

	bool groupRevisions;
	ITK_LOG(ask_handler_arg(msg.arguments,"group_revisions",&groupRevisions));


	if(status==ITK_ok && userError==ITK_ok){
		vector<string> fromvalues;
		//Found no mismatches yet
		decision = EPM_go;
		//get the attachments
		vector<tag_t> attachments = get_attachments_vector(msg.task, toattach);

		//Issue 3448 and 2388
		//If multiple Change manager/BOM/Design objects are selected then status check for
		//each is performed for approved status ,else status check error reported

		for (int i = 0; /*decision == EPM_go &&*/ i < attachments.size(); i++) {

			if (is_of_type(attachments[i], includetypes)
					&& !is_of_type(attachments[i], excludetypes)) {
				ITK_LOG(AOM_refresh(attachments[i], false));
				fromvalues.clear();
				for(int j=0; j<fromproperties.size();j++){
					fromvalues.push_back(get_display_property(attachments[i], fromproperties[j]));
				}
				vector<checktarget> objectsToCheck;
				status = collectObjectfromSearchPath(attachments[i], searchpath,
						0, template_name, objectsToCheck);
				if (status != ITK_ok) {
					return EPM_nogo;
				}

				for (int j = 0; j < objectsToCheck.size(); j++) {
                     //3448 Check if the Change MAster Revision has empty Solution item folder
					if(is_of_type(objectsToCheck[j].objtag ,CHANGE_MASTER_REVISiON))
					{
						vector<tag_t> solutionItems = get_tags_property(objectsToCheck[j].objtag,
											CM_HAS_SOLUTION_ITEM);
						if(solutionItems.size()==0){
						if (soltionItemMissingErr.empty()) {
						soltionItemMissingErr.append(get_string_property(objectsToCheck[j].objtag,
											"object_string"));
						}
						else {
							soltionItemMissingErr.append("," + get_string_property(objectsToCheck[j].objtag,
																		"object_string"));
						}
						string args[] = { soltionItemMissingErr };
						objectsToCheck[j].errors.push_back(
						TCerror(EMH_severity_error, CMHASSOLUTIONITEM_MISSING));
						objectsToCheck[j].errors.back().args = vector<string>(
						args, args + sizeof(args) / sizeof(string));
                        break;

					}
				  }

					checkPropertyAtomic(toproperties, objectsToCheck[j],
							fromvalues, properties, values, allowedstati,
							disallowedstati, relationpath, checkstatus ,template_name);

					//Issue 2388 ,collect all the failed object including first level child
					if (objectsToCheck[j].passed == false
							&& checkstatus == true) {
						if (failedObject.empty()) {
							failedObject.append(
									get_string_property(
											objectsToCheck[j].objtag,
											"object_string"));
						} else {
							failedObject.append(
									", "
											+ get_string_property(
													objectsToCheck[j].objtag,
													"object_string"));
						}

					}
				}
				//Issue 3448 and 2388
				//If multiple Change master revision is selected for workflow (Prototype release or SAP transfer
				// BOM ) then each of the change master revision and all the objects under solution item would be
				// checked for status approved ,hence we loop over all the objects and report the status error for each of
				// failed objects.and first child objects for Design and BOM items would be reported.

				if (i==(attachments.size()-1))
				{
				for (int j = 0; j < objectsToCheck.size(); j++) {
					if (objectsToCheck[j].passed == false && checkstatus == true) {

						string args[] = { failedObject };
						objectsToCheck[j].errors.push_back(
								TCerror(EMH_severity_error, CHECK_STATUS));
						objectsToCheck[j].errors.back().args = vector<string>(
								args, args + sizeof(args) / sizeof(string));

					}
				}//for
			 }//If

				bool answer;
				if(!groupRevisions){
					if(!matchone){
						answer =true;
						for(int j=0; j<objectsToCheck.size();j++){
							if(!objectsToCheck[j].passed){
								answer=false;
							}
						}
						if(answer!=negate){
							decision = EPM_go;
						} else{
							decision = EPM_nogo;
							if(negate){
								string passed_items;
								for(int j=0; j<objectsToCheck.size();j++){
									if(passed_items.empty()){
										passed_items.append("["+get_string_property(objectsToCheck[j].objtag, "object_string"));
									} else {
										passed_items.append(", "+get_string_property(objectsToCheck[j].objtag, "object_string"));
									}
								}
								passed_items.append("]");
								string check_desc = writeCheckDescription(
										toproperties,fromvalues,properties,values,allowedstati,disallowedstati);
								ITK_LOG(EMH_store_error_s2(
										EMH_severity_error, CHECK_NOTMATCHALL, passed_items.c_str(), check_desc.c_str()));
							} else{
								for(int j=0; j<objectsToCheck.size();j++){
									store_errors(objectsToCheck[j].errors);
								}
							}
						}
					} else if(matchone){
						answer =false;
						for(int j=0; j<objectsToCheck.size();j++){
							if(objectsToCheck[j].passed){
								answer=true;
							}
						}
						if(answer!=negate){
							decision = EPM_go;
						} else{
							decision = EPM_nogo;
							if(negate){
								string passed_items;
								for(int j=0; j<objectsToCheck.size();j++){
									if(objectsToCheck[j].passed){
										if(passed_items.empty()){
											passed_items.append("["+get_string_property(objectsToCheck[j].objtag, "object_string"));
										} else {
											passed_items.append(", "+get_string_property(objectsToCheck[j].objtag, "object_string"));
										}
									}
								}
								passed_items.append("]");
								string check_desc = writeCheckDescription(
										toproperties,fromvalues,properties,values,allowedstati,disallowedstati);
								ITK_LOG(EMH_store_error_s2(
										EMH_severity_error, CHECK_MATCHNONE, passed_items.c_str(), check_desc.c_str()));
							} else if(!negate){
								string failed_items;
								for(int j=0; j<objectsToCheck.size();j++){
									if(failed_items.empty()){
										failed_items.append("["+get_string_property(objectsToCheck[j].objtag, "object_string"));
									} else {
										failed_items.append(", "+get_string_property(objectsToCheck[j].objtag, "object_string"));
									}
									store_errors(objectsToCheck[j].errors);
								}
								failed_items.append("]");
								ITK_LOG(EMH_store_error_s1(EMH_severity_error, CHECK_MATCHONE, failed_items.c_str()));
							}
						}
					}

				} else if(groupRevisions){
					bool answer = !matchone;
					map<tag_t,vector<checktarget>> itemItemRevMap=convertToItemItemRevMap(objectsToCheck);
					map<tag_t, bool> itemResult;
					for(auto itItemRevs=itemItemRevMap.begin();itItemRevs!=itemItemRevMap.end();++itItemRevs){
						vector<checktarget> revs=itItemRevs->second;
						bool isOneRevOk=false;
						for(auto itRev=revs.begin();itRev!=revs.end();++itRev){
							if((*itRev).passed){
								isOneRevOk=true;
							}
						}
						itemResult.insert(make_pair(itItemRevs->first, isOneRevOk));
						//For !matchone the first failed item means failure, for matchone the first passed means passed
						if (isOneRevOk==matchone){
							answer=isOneRevOk;
						}
					}
					if(answer!=negate){
						decision = EPM_go;
					} else {
						decision = EPM_nogo;
						string problem_items;
						string check_desc = writeCheckDescription(
								toproperties,fromvalues,properties,values,allowedstati,disallowedstati);
						if(!matchone&&!negate){
							for(auto itemEnt=itemResult.begin();itemEnt!=itemResult.end();++itemEnt){
								if(!itemEnt->second){
									if(problem_items.empty()){
										problem_items.append("["+get_string_property(itemEnt->first, "object_string"));
									} else {
										problem_items.append(", "+get_string_property(itemEnt->first, "object_string"));
									}
								}
							}
							problem_items.append("]");
							ITK_LOG(EMH_store_error_s2(EMH_severity_error, CHECK_REVGROUP, problem_items.c_str(), check_desc.c_str()));
						} else if (matchone&&!negate){
							for(auto itemEnt=itemResult.begin();itemEnt!=itemResult.end();++itemEnt){
								if(problem_items.empty()){
									problem_items.append("["+get_string_property(itemEnt->first, "object_string"));
								} else {
									problem_items.append(", "+get_string_property(itemEnt->first, "object_string"));
								}
							}
							problem_items.append("]");
							ITK_LOG(EMH_store_error_s2(EMH_severity_error, CHECK_ONEREVGROUP, problem_items.c_str(), check_desc.c_str()))
						} else if (matchone&&negate){
							for(auto itemEnt=itemResult.begin();itemEnt!=itemResult.end();++itemEnt){
								if(problem_items.empty()){
									problem_items.append("["+get_string_property(itemEnt->first, "object_string"));
								} else {
									problem_items.append(", "+get_string_property(itemEnt->first, "object_string"));
								}
							}
							problem_items.append("]");
							ITK_LOG(EMH_store_error_s2(
									EMH_severity_error, CHECK_ALLBUTONEREVGROUP, problem_items.c_str(), check_desc.c_str()))
						} else if (matchone&&negate){
							for(auto itemEnt=itemResult.begin();itemEnt!=itemResult.end();++itemEnt){
								if(itemEnt->second){
									if(problem_items.empty()){
										problem_items.append("["+get_string_property(itemEnt->first, "object_string"));
									} else {
										problem_items.append(", "+get_string_property(itemEnt->first, "object_string"));
									}
								}
							}
							problem_items.append("]");
							ITK_LOG(EMH_store_error_s2(EMH_severity_error, CHECK_NOREVGROUP, problem_items.c_str(), check_desc.c_str()))
						}
					}
				}
			}
		}
	}
	SAFE_SM_FREE(template_name);
	return decision;
}

