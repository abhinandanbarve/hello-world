
/***************************************************************************************
 * Function Name    : D4G_Mass_Update_Preparation
 * Description      : This workflow handler gets input as selected CR's and user group and call massmassupdate_prepare_utility that runs in background.

 *
 * REQUIRED HEADERS : MassUpdatePreparationHandler.hxx
 * INPUT PARAMS     : msg   -- Input argument from Workflow Handler
 *
 * RETURN VALUE     :int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :   1) Read input Arguments
 *                    	2) call Utility
 *
 *
 *
 * NOTES            :
 *
 *
 * History
 *--------------------------------------------------------------------------------------------------------------------------------
 * Date             Name              Company      Description of Change
 * 15-03-16    		Rohit Ghundiyal   Siemens      Initial Code for massmassupdate_prepare_utility
 *
 *---------------------------------------------------------------------------------------------------------------------------------
 *
 ***************************************************************************************/

using namespace std;
#include <D4G_Handlers/MassUpdatePreparationHandler.hxx>
#include <D4G_Handlers/SetPropertiesHandler.hxx>



/*
 * Action Handler that follows a searchpath and checks if specified types at
 * the end of this path have the specified values on the specified properties.
 * Handler arguments:
 *  -to_attach, -include_type, -from_path, -to_path
 *  -from_property, -to_property, -property, -value, -bypass
 */
int D4G_Mass_Update_Preparation( EPM_action_message_t msg )
{
	int status                  = ITK_ok; //failure status, if this is ever not ITK_ok we MEM_FREE and abort
	int iTargetCount            = 0;
	tag_t tagRootTask           = NULLTAG;
	tag_t* list_target_objects  = NULLTAG;
	tag_t  tSelectedCR          = NULLTAG;
	string strInputToUtil;
	string strUtilPath;



	if( msg.task != NULLTAG )
	{
		//get the root task
		char* pTcRootEnv = const_cast<char*>( TC_getenv( "TC_ROOT" ) );
		if(pTcRootEnv != NULL)
		{
			strUtilPath.assign(pTcRootEnv);
		}

		strUtilPath.append("\\bin\\massmassupdate_prepare_utility.exe");

		char cInputArgs[3000];
		//get the root task
		ITK_LOG(EPM_ask_root_task( msg.task, &tagRootTask ) ) ;

		if( status == ITK_ok && tagRootTask != NULLTAG )
		{
			//ask for attachments. (Target/Reference/Signoff )
			ITK_LOG(EPM_ask_attachments( tagRootTask, EPM_target_attachment,
					&iTargetCount, &list_target_objects ) ) ;
			strInputToUtil.assign("");
			for( int index = 0; index < iTargetCount; index++ )
			{
				tSelectedCR = list_target_objects[index];
				char*  pcCRUId = NULL;
				ITK__convert_tag_to_uid( tSelectedCR, &pcCRUId );
				strInputToUtil.append(pcCRUId);
				strInputToUtil.append(",");
				
			}

			char* group_full_name = NULL;
			tag_t  current_groupmember_tag  = NULLTAG;
			tag_t  group_tag  = NULLTAG;
			ITK_LR(SA_ask_current_groupmember( &current_groupmember_tag ) );
			ITK_LR(SA_ask_groupmember_group( current_groupmember_tag,   &group_tag ) );
			ITK_LR(SA_ask_group_full_name( group_tag, &group_full_name ) );
			strInputToUtil.append(group_full_name);
			strInputToUtil.append(",");
			

			char* pUserName = NULL;
			tag_t tUserTag = NULL;
			char* cpPerson_uid = NULL;

			ITK_LR(POM_get_user( &pUserName, &tUserTag ) ) ;
			ITK__convert_tag_to_uid( tUserTag, &cpPerson_uid );
			strInputToUtil.append(cpPerson_uid);
			
			sprintf(cInputArgs,"%s",strInputToUtil.c_str());

			PROCESS_INFORMATION ProcessInfo; //This is what we get as an [out] parameter
			STARTUPINFO StartupInfo; //This is an [in] parameter
			ZeroMemory(&StartupInfo, sizeof(StartupInfo));
			StartupInfo.cb = sizeof StartupInfo ; //Only compulsory field

			if(CreateProcess(strUtilPath.c_str(), cInputArgs,
					NULL,NULL,FALSE,0,NULL,
					NULL,&StartupInfo,&ProcessInfo))
			{
				CloseHandle(ProcessInfo.hThread);
				CloseHandle(ProcessInfo.hProcess);
			}


		}

	}

	return status;
}

