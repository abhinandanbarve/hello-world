/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers
 Author  : Birger Nielsen

 Description:    contains the implementation of the D4G-delete-related-object handler.

 ===============================================================================*/

#ifndef DELETEDATASETHANDLER_HXX_
#define DELETEDATASETHANDLER_HXX_

#include <D4G_Handlers/ActionHandler.hxx>

namespace handlers {
/*
 * This class is represents a workflow handler deleting objects related to the workflow attachment with a predefined
 * relation or attribute. if an object is referenced in other relations or attributes then those defined in the handler parameters,
 * the object will not be deleted. In this case only the reference attribute will be updated or the relation will be deleted.
 * At least one of the handler parameters "relation" or reference must be set. 
 *
 * handler arguments:
 *
 * -related_type : "," or "." seperated list of object_types which shall be considered for deletion. Real object type names are expected.
 * -relation(optional): "," or "." separated list of ImanRelation types defining the relation types the objects are related to the workflow attachment.
 * -reference(optional): "," or "." separated list of real attribute names to be for getting objects to delete
 * -from_attach(optional):
 * 		Attachment type from which the attachments will be retrieved.
 * 		possible values are
 * 		TARGET, REFERENCE, SCHEDULE_TASK
 * 		if this parameter is not set it will be defaulted to TARGET
 * -include_type(optional):
 * 		Komma/Whitespace separated list of types to be used
 * 		to perform the action handler on. Other Types will not be considered.
 * -exclude_type(optional):
 * 		Komma/Whitespace separated list of types, which will
 * 		be excluded when performing the action handler.
 * -search_string(optional):
 *		"," or "." seperated string defining a search path.
 *		For each attachment the search path points to an object,
 *		on which the action handler will be performed.
 *
 *		search_string can look like this:
 *		<Attribute>.<type>.<attribute2>.<type2> ...
 */
class deleteObjectHandler : public ActionHandler{
	public:
		// Constructor
		explicit deleteObjectHandler(EPM_action_message_t msg);
		// Destructor
		virtual ~deleteObjectHandler();
		/*
		 * actual method where the deletion is performed
		 */
		virtual int perform(std::vector<tag_t> attachments);

};

} /* namespace handlers */
#endif /* DELETEDATASETHANDLER_HXX_ */
