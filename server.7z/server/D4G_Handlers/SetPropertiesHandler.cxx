/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers

 Description:    contains the implementation of the D4G-set-properties handler.

 ===============================================================================*/

#include <epm/epm.h>

#include <tc/emh.h>
#include <tc/preferences.h>
#include <bom/bom.h>
#include <epm/epm_toolkit_tc_utils.h>

#include <sa/user.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/project.h>

#include <tcinit/tcinit.h>

#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <set>
#include <sstream>
#include <vector>
#include <algorithm>
#include <map>

#include <time.h>

using namespace std;

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>
#include <D4G_Handlers/CheckPropertiesHandler.hxx>
#include <D4G_ErrorCodes.hxx>
#include <D4G_Core/D4G_EPM_Handlers.hxx>


int get_current_time( date_t* theTime )
{
    time_t tt;
    struct tm* ptm;
    time( &tt );
    ptm = localtime( &tt );
    theTime->year = (short)ptm->tm_year + 1900;
    theTime->month = (byte)ptm->tm_mon;
    theTime->day = (byte)ptm->tm_mday;
    theTime->hour = (byte)ptm->tm_hour;
    theTime->minute = (byte)ptm->tm_min;
    theTime->second = (byte)ptm->tm_sec;
    return ITK_ok;
}

void setPropertyAtomic(	checktarget &target, bool overwrite,
		const vector<string>& toproperties, const vector<string>& fromvalues,
		const vector<string>& properties, const vector<string>& values) {
	int status = ITK_ok;
	ITK_LOG(AOM_refresh(target.objtag, true));
	for (int i = 0; i < toproperties.size(); i++) {
		if(overwrite||""==get_string_property(target.objtag, toproperties[i].c_str())){
			ITK_LOG(AOM_UIF_set_value(target.objtag, toproperties[i].c_str(), fromvalues[i].c_str()));
			if (status!=ITK_ok) {
				target.errors.push_back(TCerror(EMH_severity_error, status));
				status=ITK_ok;
			}
		}
	}
	for (int i = 0; (i < properties.size()); i++) {
		if(overwrite||""==get_string_property(target.objtag, properties[i].c_str())){
			if (tc_strcmp(values[i].c_str(), "$CURRENT_DATE") == 0)
			{
				date_t dtCurrentDate = NULLDATE;

                //get Current time
                status=get_current_time( &dtCurrentDate );

				if (status==ITK_ok)
				{
					ITK_LOG(AOM_set_value_date(target.objtag, properties[i].c_str(), dtCurrentDate));
				}
				else
				{
					target.errors.push_back(TCerror(EMH_severity_error, status));
					status=ITK_ok;
				}
			}
			else
			{
				ITK_LOG(AOM_UIF_set_value(target.objtag, properties[i].c_str(), values[i].c_str()));
			}
			if (status!=ITK_ok) {
				target.errors.push_back(TCerror(EMH_severity_error, status));
				status=ITK_ok;
			}
		}
	}
	//10-5-2017 : Robert : deprecated API "AOM_save" replaced with "AOM_save_with_extensions"
	//ITK_LOG(AOM_save(target.objtag));
	ITK_LOG(AOM_save_with_extensions(target.objtag));

}

/*
 * Action Handler that follows a searchpath and checks if specified types at
 * the end of this path have the specified values on the specified properties.
 * Handler arguments:
 *  -to_attach, -include_type, -from_path, -to_path
 *  -from_property, -to_property, -property, -value, -bypass
 */
int D4G_SetProperties( EPM_action_message_t msg )
{
	int status = ITK_ok; //failure status, if this is ever not ITK_ok we MEM_FREE and abort
	int userError = ITK_ok;

	//get all arguments from the msg
	string to_attach("TARGET"); //If argument not specified default to TARGET
	int toattach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"to_attach",&to_attach,0));
	to_attach= StrCaps(to_attach);
	if(to_attach=="TARGET"){toattach = EPM_target_attachment;
	} else if(to_attach=="REFERENCE"){toattach = EPM_reference_attachment;
	} else if(to_attach=="SCHEDULE_TASK"){toattach = EPM_schedule_task_attachment;
	} else if(!to_attach.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "to_attach", "TARGET, REFERENCE or SCHEDULE_TASK"));
	}

	string include_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"include_type",&include_type,0));
	vector<string> includetypes =split_and_trim_to_vector_nonempty(include_type,",", " \t");
	if (includetypes.empty()){
		includetypes.push_back("ANY");
	}
	if(validate_type(includetypes)){userError--;}

	string exclude_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"exclude_type",&exclude_type,0));
	vector<string> excludetypes =split_and_trim_to_vector_nonempty(exclude_type,",", " \t");
	if(validate_type(excludetypes)){userError--;}

	string to_path("");
	ITK_LOG(ask_handler_arg(msg.arguments,"to_path",&to_path,0));
	vector<string> topath =split_and_trim_to_vector_nonempty(to_path,",.", " ");
	if(topath.size() %2!=0){
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE,
				"to_path", "an even number of dot separated values"));
		userError--;
	}

	string from_path("");
	ITK_LOG(ask_handler_arg(msg.arguments,"from_path",&from_path,0));
	vector<string> frompath =split_and_trim_to_vector_nonempty(from_path,",.", " ");
	if(frompath.size() %2!=0){
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE,
				"from_path", "an even number of dot separated values"));
		userError--;
	}

	//Pairs of set values. Have to match in number. If a pair is not set we ignore it.
	string fromproperty("");
	ITK_LOG(ask_handler_arg(msg.arguments,"from_property",&fromproperty,0));
	vector<string> fromproperties =split_and_trim_to_vector_nonempty(fromproperty,",", " ");

	string toproperty("");
	ITK_LOG(ask_handler_arg(msg.arguments,"to_property",&toproperty,0));
	vector<string> toproperties =split_and_trim_to_vector_nonempty(toproperty,",", " ");

	if(fromproperties.size()!=toproperties.size()){
		userError--;
		ITK_LOG(EMH_store_error(EMH_severity_error, UE_TO_FROM_NR));
	}

	string property("");
	ITK_LOG(ask_handler_arg(msg.arguments,"property",&property,0));
	vector<string> properties =split_and_trim_to_vector_nonempty(property,",", " ");

	string value("");
	ITK_LOG(ask_handler_arg(msg.arguments,"value",&value,0));
	vector<string> values =split_and_trim_to_vector_nonempty(value,",", " ");

	if(properties.size()!=values.size()){
		userError--;
		ITK_LOG(EMH_store_error(EMH_severity_error, UE_PROP_VALUE_NR));
	}

	string bypass_arg("FALSE"); //If argument set to TRUE set bypass for handler
	bool bypass = FALSE;
	ITK_LOG(ask_handler_arg(msg.arguments,"bypass",&bypass_arg,0));
	bypass_arg = StrCaps(bypass_arg);
	if (bypass_arg=="TRUE"){
		bypass=TRUE;
	} else if (bypass_arg=="FALSE"){
		bypass=FALSE;
	} else if (!bypass_arg.empty()){
		userError--;
		EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "bypass", "TRUE or FALSE");
	}

	string overwrite_arg("TRUE"); //If argument set to FALSE only set value if NULL
	bool overwrite = FALSE;
	ITK_LOG(ask_handler_arg(msg.arguments,"overwrite",&overwrite_arg,0));
	overwrite_arg = StrCaps(overwrite_arg);
	if (overwrite_arg=="TRUE"){
		overwrite=TRUE;
	} else if (overwrite_arg=="FALSE"){
		overwrite=FALSE;
	} else if (!overwrite_arg.empty()){
		userError--;
		EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "overwrite", "TRUE or FALSE");
	}

	//user input done

	if(status==ITK_ok && userError==ITK_ok){
		logical current = false;
		if(bypass){
			current = set_bypass(true);}
		vector<string> fromvalues;
		//get the attachments
		vector<tag_t> attachments = get_attachments_vector(msg.task,toattach);
		for(int i=0;status==ITK_ok && i<attachments.size();i++){
			if(is_of_type(attachments[i], includetypes)&&!is_of_type(attachments[i], excludetypes) ){
				ITK_LOG(AOM_refresh(attachments[i], false));
				fromvalues.clear();
				if(fromproperties.size()>0){
					vector<checktarget> objectsToGet;
					///Issue 3448
					//There is additional parameter introduced in the the function call for the workflow template name
					//Here it is passed a blank string as there is additional logic in collectObjectfromSearchPath which
					// is only meant for if the workflow is Release Prototype or SAP transfer with BOM
					collectObjectfromSearchPath(attachments[i], frompath, 0, " ",objectsToGet);
					if(objectsToGet.size()<1){
						string message("Found no objects at end of from_path: "+from_path+". At least one object is required.");
						ITK_LOG(EMH_store_error_s1(EMH_severity_error,-1,message.c_str()));
						status =-1;;
					} else if(objectsToGet.size()==1){
						for(int k=0; k<fromproperties.size();k++){
							fromvalues.push_back(get_display_property(objectsToGet[0].objtag, fromproperties[k]));
						}
					} else if(objectsToGet.size()>1){
						for(int k=0; k<fromproperties.size();k++){
							string valuelist("[");
							valuelist.append(get_display_property(objectsToGet[0].objtag, fromproperties[k]));
							for(int j=1; j<objectsToGet.size();j++){
								valuelist.append(", ");
								valuelist.append(get_display_property(objectsToGet[j].objtag, fromproperties[k]));
							}
							valuelist.append("]");
							fromvalues.push_back(valuelist);
						}
					}
				}
				vector<checktarget> objectsToSet;
				///Issue 3448
				//There is additional parameter introduced in the the function call collectObjectfromSearchPath for the workflow template name
				//Here it is passed a blank string as there is additional logic in collectObjectfromSearchPath which
				// is only meant for if the workflow is Release Prototype or SAP transfer with BOM
				collectObjectfromSearchPath(attachments[i], topath, 0," ", objectsToSet);

				for(int j=0; status==ITK_ok && j<objectsToSet.size();j++){
					setPropertyAtomic(objectsToSet[j], overwrite,toproperties,fromvalues,properties,values);
				}
				for(int j=0; j<objectsToSet.size();j++){
					store_errors(objectsToSet[j].errors);
				}
			}
		}
		if(bypass){set_bypass(current);}
	}

	return status;
}
