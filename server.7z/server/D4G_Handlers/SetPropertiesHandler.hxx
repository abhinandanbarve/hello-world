/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers

 Description:    contains the implementation of the D4G-set-properties handler.

 ===============================================================================*/

#ifndef SETPROPERTIESHANDLER_HXX_
#define SETPROPERTIESHANDLER_HXX_

/*
 * Action Handler that follows a searchpath and sets, on specified types at
 * the end of this path, the specified values on the specified properties.
 * Handler arguments:
 *  -to_attach, -include_type, -search_string,
 *  -from_property, -to_property, -property, -value
 */
int D4G_SetProperties( EPM_action_message_t msg );

int get_current_time( date_t* theTime );




#endif /* SETPROPERTIESHANDLER_HXX_ */
