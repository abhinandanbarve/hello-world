/*==============================================================================
 Copyright (c) 2014 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handler

 Description:    contains the implementation of the Danfoss Global PLM
 	 	 	 	 Project relevant handlers.

 ===============================================================================*/

#ifndef D4G_PROJECTHANDLERS_HXX_
#define D4G_PROJECTHANDLERS_HXX_

/*
 * Action Handler that assigns data to a project.
 * Handler arguments: -to_attach, -include_type, project, include_item
 */

int D4G_AssignToProject( EPM_action_message_t msg );

/*
 * Action Handler that removes data from a project.
 * Handler arguments: -to_attach, -include_type, project, include_item
 */

int D4G_RemoveFromProject( EPM_action_message_t msg );

#endif /* D4G_PROJECTHANDLERS_HXX_ */
