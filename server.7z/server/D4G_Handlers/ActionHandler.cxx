/*
 * ActionHandler.cxx
 *
 *  Created on: Feb 23, 2016
 *      Author: infodba
 */
#include <D4G_Handlers/ActionHandler.hxx>
#include <itkCallHeader.hxx>
#include <tccore/method.h>
#include <D4G_ErrorCodes.hxx>
#include <ITKtools.hxx>
#include <cToolbox.hxx>
#include <constants.hxx>

namespace handlers{
/*
 *@see header file for explanation
 */
ActionHandler::ActionHandler(EPM_action_message_t msg) : AbstractHandler<EPM_action_message_t, int>(msg) {
}
/*
 *@see header file for explanation
 */
ActionHandler::~ActionHandler(){
}
/*
 *@see header file for explanation
 */
int ActionHandler::startHandler() {
	// get from_attach handler argument
	int userError=ITK_ok;
	int fromattach = getFromAttachValue(&userError, FROM_ATTACH);

	// get include_type handler argument
	std::string includeType;
	bool includeTypeExists=false;
	ask_handler_arg(INCLUDE_TYPE,&includeType,&includeTypeExists,0);
	// get exclude type handler argument
	std::string excludeType;
	bool excludeTypeExists=false;
	ask_handler_arg(EXCLUDE_TYPE,&excludeType,&excludeTypeExists,0);
	std::vector<tag_t> filteredAttachments;

	// split include_type and exclude_type handler arguments into vector<string>
	std::vector<std::string> includetypes(split_and_trim_to_vector_nonempty(includeType,",", " \t"));
	ITK_LR(validateTypes(includetypes));
	std::vector<std::string> excludetypes(split_and_trim_to_vector_nonempty(excludeType,",", " \t"));
	ITK_LR(validateTypes(excludetypes));

	// retrieve attachment given the attachment type
	std::vector<tag_t> attachments=get_attachments(getRootTask(),fromattach);

	// filter the attachments according to the include_type and exclude_type handler arguments
	for(std::vector<tag_t>::iterator it=attachments.begin();it!=attachments.end();++it){
		if(is_of_type(*it,includetypes) && !is_of_type(*it,excludetypes)){
			filteredAttachments.push_back(*it);
		}
	}

	// retrieve the search_string handler argument
	bool searchPathExists = false;
	std::string search_string("");
	ITK_LR(ask_handler_arg("search_string",&search_string,&searchPathExists,0));
	if(searchPathExists){
		// parse the search_string handler argument.
		std::vector<std::string> searchpath =split_and_trim_to_vector_nonempty(search_string,",.", " ");
		if(searchpath.size() %2!=0){
			ITK_LR(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE,
					"search_string", "an even number of dot separated values"));
			userError--;
		}

		//retrieve the objects along the defined search_string and trigger the perform method on them
		std::vector<tag_t> result;
		for(std::vector<tag_t>::iterator it=filteredAttachments.begin();it!=filteredAttachments.end();++it){

			///Issue 3448
			//There is additional parameter introduced in the the function call collectObjectfromSearchPath for the workflow template name
			//Here it is passed a blank string as there is additional logic in collectObjectfromSearchPath which
			// is only meant for if the worflow is Release Prototype or SAP transfer with BOM
			collectObjectfromSearchPath(*it,searchpath,0,"", result);
			perform(result);
		}
	} else {
		perform(filteredAttachments);
	}

	return userError;
}

} /* namespace handlers */
