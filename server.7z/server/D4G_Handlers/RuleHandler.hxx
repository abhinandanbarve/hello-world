/*
 * RuleHandler.hxx
 *
 *  Created on: Feb 23, 2016
 *      Author: infodba
 */

#ifndef RULEHANDLER_HXX_
#define RULEHANDLER_HXX_

#include <D4G_Handlers/AbstractHandler.hxx>

namespace handlers {

/*
 *Basic abstract handler for rule handlers
 */
class RuleHandler : public AbstractHandler<EPM_rule_message_t, EPM_decision_t>{
public:
	//Constructor
	explicit RuleHandler(EPM_rule_message_t msg);
	//Destructor
	virtual ~RuleHandler();
	virtual EPM_decision_t perform(std::vector<tag_t> attachments) = 0;

	/*
	 * Retrieves the attachments and triggers the perform method.
	 * The attachments are retrieved/filtered using the following handler arguments:
	 *
	 * include_type(optional):
	 * 		Komma/Whitespace separated list of types to be used
	 * 		to perform the rule handler on. Other Types will not be considered.
	 *
	 * exclude_type(optional):
	 * 		Komma/Whitespace separated list of types, which will
	 * 		be excluded when performing the rule handler.
	 *
	 * to_attach(optional):
	 * 		Attachment type from which the attachments will be retrieved.
	 * 		possible values are
	 * 		TARGET, REFERENCE, SCHEDULE_TASK
	 * 		if this parameter is not set it will be defaulted to TARGET
	 * search_string(optional):
	 *		Komma or dot seperated string defining a search path.
	 *		For each attachment the search path points to an object,
	 *		on which the rule handler will be performed.
	 *
	 *		search_string can look like this:
	 *		<Attribute>.<type>.<attribute2>.<type2> ...
	 *
	 *	@return
	 *		The decision of the rule handler.
	 *		The decision will be EPM_go if the validations of all relevant attachments
	 *		return EPM_go, otherwise EPM_nogo will be returned
	 */
	virtual EPM_decision_t startHandler();
};

} /* namespace handlers */
#endif /* RULEHANDLER_HXX_ */
