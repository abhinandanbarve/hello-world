/*
 * MassUpdateRepalceItems.hxx
 *
 *  Created on: Feb 28, 2017
 *      Author: infodba
 */

#ifndef MASSUPDATEREPALCEITEMSHANDLER_HXX_
#define MASSUPDATEREPALCEITEMSHANDLER_HXX_


#include <fclasses/tc_stdlib.h>
#include <tc/emh.h>
#include <tc/preferences.h>
#include <tc/tc_util.h>
#include <sa/user.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/project.h>

#include <tcinit/tcinit.h>

#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <set>
#include <sstream>
#include <vector>
#include <algorithm>

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>
#include <D4G_ErrorCodes.hxx>
#include <D4G_Core/D4G_EPM_Handlers.hxx>
#include <epm/epm_toolkit_tc_utils.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>

#define  FORMAT_TEXT                         "TEXT"
#define  REF_TEXT                            "Text"
#define  DATASET                             "Dataset"
#define  REFERENCE_ITEMS_REL                 "CMReferences"
#define  SOLUTION_ITEM_REL                   "CMHasSolutionItem"
#define  DANFOSS_BOMITEMREV                  "D4G_BOMItemRevision"
#define  TEMP_DIR                            "TC_SHARED_MEMORY_DIR"
#define  PREF_FROM_TO_CSV                    "D4G_Mass_Update_From_To_File_Column"
#define  CMIMPLEMENTS                        "CMImplements"
#define  CHANGE_REQ_REV                      "D4G_ChangeReqRevision"
#define  REMOVE_STATUS                       "Remove status"
#define  READY_FOR_MMU                       "D4G_ReadyForMMU"
#define  MASS_UPDATE_FILE_DESC               "Mass Update Log File"

int D4G_Mass_Update_Replace_Items( EPM_action_message_t msg );
int getFromToPartFromCsv(tag_t selectedCN,vector<tag_t>& vecFromPart,vector<tag_t>& vecToPart);
int replaceBomItems(tag_t tBomItemRev,tag_t tFromPartRev,tag_t tToPartRev,bool& bReplaceFail,int& iSuccReplaceCount,int& iFailReplaceCount);
int removeMMUStatus(tag_t tSelectedCN);
int check_MMU_Status(tag_t tSelectedCN);
int attach_mass_log_dataset( char*  cDatasetName,char*  cDatasetDesc,char*  cDatasetType,char*  cFormatName,char*  cDatasetRefName,char*  cReferenceName,char*  cRelationTypeName,
		AE_reference_type_t ref_type,tag_t  tagRevTag,tag_t* tagNew_dataset,FILE *logfileptr);

#endif /* MASSUPDATEREPALCEITEMS_HXX_ */
