/*==============================================================================
 Copyright (c) 2014 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_CheckAlternateBOMsHandlers.hxx
 Author  : Jayant Patel

 Description:    contains the implementation of the D4G-check-alternate-BOMs
 	             Check whether Change Master Revision contains alternate BOMs

 ===============================================================================*/

#ifndef D4G_CHECKALTERNATEBOMSHANDLERS_HXX
#define D4G_CHECKALTERNATEBOMSHANDLERS_HXX

#include <D4G_Core/D4G_EPM_Handlers.hxx>
#include <epm/epm.h>
#include <user_exits/epm_rule_handlers.h>

#include <tc/emh.h>
#include <tc/preferences.h>
#include <bom/bom.h>
#include <epm/epm_toolkit_tc_utils.h>

#include <sa/user.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/grm.h>

#include <tcinit/tcinit.h>
#include <constants.hxx>

using namespace std;

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ItkCallHeader.hxx>
#include <D4G_ErrorCodes.hxx>
#include <D4G_Core\D4G_Mail.hxx>
#ifdef __cplusplus
         extern "C"{
#endif

extern  EPM_decision_t D4G_CheckAlternateBOMs( EPM_rule_message_t msg );


#ifdef __cplusplus
                   }
#endif

#endif
