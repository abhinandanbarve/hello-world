/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers
 Author  : Birger Nielsen

 Description:    Contains the Abstract Handler Interface

 ===============================================================================*/

#ifndef CHECKFOROBSOLETEHANDLER_HXX_
#define CHECKFOROBSOLETEHANDLER_HXX_

#include <iostream>
#include <unidefs.h>
#include <epm/epm.h>
#include <D4G_Handlers/RuleHandler.hxx>
#include <map>


namespace handlers {


/*
 * Helper method to check, whether a related plant has a certain status.
 *
 * @param revision: Item Revision to check
 * @param plant: plant name to check
 * @param status: status to check
 */
bool hasPlantStatus(tag_t revision, std::string plant, std::string status);

/*
 * this class represents a BusinessObject in the TC Datamodel.
 */
class BusinessObject {
public:
	// Constructor
	explicit BusinessObject(tag_t object);
	// Destructor
	virtual ~BusinessObject(){};
	/*
	 *  Operator needed for containers like sets
	 */
	virtual bool operator<(BusinessObject const& object) const{
		return object_tag_<object.getTag();
	}
	/*
	 *  Operator needed for containers like sets
	 */
	virtual bool operator==(BusinessObject const& object) const{
		return object_tag_==object.getTag();
	}
	/*
	 *  Operator needed for containers like sets
	 */
	virtual bool operator>(BusinessObject const& object) const{
		return !(*this<object) && !(*this==object);
	}
	/*
	 *  Operator needed for containers like sets
	 */
	virtual bool operator!=(BusinessObject const& object) const{
		return !(*this==object);
	}
	/*
	 * returns the tag representing this object
	 */
	tag_t getTag() const;
protected:
	tag_t object_tag_;
};

/*
 * Helper class for sorting the Item Revisions of an Item in
 * Item Revision Id order. This class represents an Item Revision
 */
class RevisionHelper : public BusinessObject {
public:
	// Constructor
	explicit RevisionHelper(tag_t object);
	// Destructor
	virtual ~RevisionHelper(){};
	/*
	 * Overloaded Operator: Defined by the numerical order with the
	 * Item Revision Id attribute
	 */
	virtual bool operator<(RevisionHelper const& object) const;
	/*
	 * @return bool : whether or not this revision is marked for containing a part
	 * in the bom.
	 */
	inline virtual bool containsPart() { return containsPartFlag;}
	/*
	 * marks this revision cotaining a part in the bom.
	 */
	inline virtual void setContainsPart(bool value) { containsPartFlag = value;}
private:
	bool containsPartFlag;
};

/*
 * Helper class representing a BOMITem. It contains all revisions of the BOMITem
 * in the numerical order of the Item Revision Id.
 */
class BOMItemHelper : public BusinessObject {
public:
	// Constructor
	explicit BOMItemHelper(tag_t item);
	// Destructor
	virtual ~BOMItemHelper(){};
	/*
	 * Computes the last revision of this BOMItem containing the part and
	 * having Service or released status. A newer revision with higher revision ID
	 * not containing the part and having obsolete, released, or service state it returns
	 * NULLTAG. Furthermore if there is a newer revision with higher revision ID containing the part
	 * and having obsolete state it returns NULTAG.
	 */
	tag_t checkStatusForObsolete();
	/*
	 * Computes the last revision of this BOMItem containing the part and
	 * having released status. A newer revision with higher revision ID
	 * not containing the part and having obsolete or released, or service state it returns
	 * NULLTAG. Furthermore if there is a newer revision with higher revision ID containing the part
	 * and having obsolete or service state it returns NULTAG.
	 */

	tag_t checkStatusForService();
	/*
	 * Initializes the BOMItem by adding all revisions of the BOMItem to
	 * the internal vector. The revisions are sorted in the
	 * numerical order using the Item Revision ID Attribute
	 */
	void addAllRevisions();
	/*
	 * Marks a special revision of the BOMITem for containing a part.
	 *
	 * @param revision : BOMItemRevision tag to mark.
	 * @param value : boolean value to set.
	 */
	void setContainsPart(tag_t revision, bool value);
private:
	/*
	 * Adds a revision to the internal vector containing all
	 * BOMItemRevision of this BOMItem. The revisions are sorted in the
	 * numerical order using the Item Revision ID Attribute
	 */
	void addRevision(tag_t revision);
	std::vector<RevisionHelper> bomRevisions;
};

/*
 * This class represents a ChangeMasterRevision in the TC data model.
 */
class ChangeMaster : public BusinessObject {
public:
	// Construcor
	explicit ChangeMaster(tag_t object);
	// Destructor
	virtual ~ChangeMaster(){};
	/*
	 *	 maps a plant to a part.
	 */
	std::map<tag_t, tag_t> plantPartMap;
	/*
	 * all bomItem to be checked with this changeMaster
	 */
	std::vector<tag_t> bomItems;
	/*
	 * Status, for which the objects shall be validated
	 */
	std::string statusToSet;
};

/*
 * Concrete rule handler for validating when Obsolete, Service or Release status shall be set.
 *
 * handler arguments :
 *
 * -part_type :
 *		Technical name of the PartRevision type to be used.
 * -bom_item_type :
 *		Technical name of the BOMItemRevision type to be used.
 * -revision_rule :
 *		revision rule to be used when opening structures.
 * -include_type(optional):
 * 		Komma/Whitespace separated list of types to be used
 * 		to perform the rule handler on. Other Types will not be considered.
 *
 * -exclude_type(optional):
 * 		Komma/Whitespace separated list of types, which will
 * 		be excluded when performing the rule handler.
 *
 * -to_attach(optional):
 * 		Attachment type from which the attachments will be retrieved.
 * 		possible values are:
 * 		TARGET, REFERENCE, SCHEDULE_TASK
 *      if this parameter is not set it will be defaulted to TARGET
 *
 * -search_string(optional):
 *		Komma or dot seperated string defining a search path.
 *		For each attachment the search path points to an object,
 *		on which the rule handler will be performed.
 *
 *		search_string can look like this:
 *		<Attribute>.<type>.<attribute2>.<type2> ...
 *
 */
class CheckForObsoleteHandler : public RuleHandler{
	public:
		// Constructor
		explicit CheckForObsoleteHandler(EPM_rule_message_t msg);
		// Destructor
		virtual ~CheckForObsoleteHandler(){};
		/*
		 * Perform method containing the validation logic.
		 */
		virtual EPM_decision_t perform(std::vector<tag_t> attachments);
	private:
		/*
		 *  This method computes all BOMItems where a part with given plant is used.
		 *  BOMItems with wrong plant will not be considered.
		 *
		 *  @param plant : The plant to be used to retrieve the BOMItems
		 *  @param part: The part, which is contained in BomItem BOM-structures.
		 *  @param type: The technical name of the BOMItemRevision
		 */
		std::vector<BOMItemHelper> whereUsed(tag_t plant, tag_t part, std::string type);

		/*
		 * Helper method to store and error on the error stack and return the EMP_nogo decision.
		 *
		 * @param errorCode: Error code to be used for the error
		 * @param object1: object1: tag of the first object, which will be contained in the error message.
		 * @param object2: object1: tag of the first object, which will be contained in the error message.
		 */
		EPM_decision_t returnWithError(int errorCode, tag_t object1, tag_t object2);

		/*
		 * contains implementation for a vector.
		 *
		 * @param collection : the vector, to be searched for an object.
		 * @param object : object to be searched for.
		 */
		bool containsVector(std::vector<tag_t> collection,tag_t object);

		/*
		 * checks whether a map contains a certain value.
		 *
		 * @param collection: the map, to be searched for an object.
		 * @param object : object to be searched for.
		 */
		bool mapContainsValue(std::map<tag_t,tag_t> collection, tag_t object);

		/*
		 * Attachments are expected to be ChangeMasterRevisions.
		 * This method collects BOM items and Parts contained in the solutionItem folder of the ChangeMasterRevision.
		 * A BOM item or Part is relevant for collecting, if their plant match the plant defined on the change Master.
		 *
		 * @param attachments : Vector of ChangeMasterRevision tags
		 */
		void collectPlantsAndBomItems(std::vector<tag_t> attachments);

		/*
		 * The status which will be set in this workflow is defined by the changeType attribute on the Change Master.
		 * This method will retrieve the status to set.
		 *
		 * @param change : the ChangeMasterRevision tag.
		 */
		std::string getStatusToSet(tag_t change);
		/*
		 * This method retrieves addtional workflow handler parameters:
		 *
		 * part_type :
		 *		Technical name of the PartRevision type to be used.
		 * bom_item_type :
		 *		Technical name of the BOMItemRevision type to be used.
		 * revision_rule :
		 *		revision rule to be used when opening structures.
		 *
		 */
		void readParameter();

		/*
		 * This method performs all necessary checks on the relevant parts
		 * contained in the solutionItem folder of the given change master.
		 *
		 * If the changeType leads to a obsolete status, it will be validated, that the
		 * Part is not used in BOMItem with status service or release. For this decision
		 * the latest released or service state is the important one.
		 *
		 * If the changeType leads to a service status, it will be validated, that the
		 * Part is not Production relevant in a BOMItem with released status. For this decision
		 * the latest released or service state is the important one.
		 *
		 * @param changeMaster : The Change Master to be used.
		 */
		// TODO this function should be called handleParts instead
		EPM_decision_t handlePlants(ChangeMaster changeMaster);

		/*
		 * This method performs all necessary checks on the relevant BOMitems
		 * contained in the solutionItem folder of the given Change Master.
		 *
		 * If the changeType leads to status service or released: for each ItemRevision in the BOM of
		 * the BOMItem the relevant plant must not have status obsolete. the relevant plant is
		 * the plant matching the plant on the changeMaster.
		 *
		 * If the changeType leads to status released: for each itemRevision in the bom having a matching plant
		 * with status service must not be marked as production relevant.
		 *
		 * @param changeMaster : The Change Master to be used.
		 */
		EPM_decision_t handleBomItems(ChangeMaster changeMaster);
		/*
		 * maps the tag of a changeMaster TC object to an instance of the local ChangeMaster class
		 */
		std::map<tag_t,ChangeMaster> changeMasterMap;
		/*
		 * the Part Revision type to use
		 */
		std::string partType;
		/**
		 * the BOMItem type to use
		 */
		std::string bomItemType;
		/*
		 * name of the revision rule to use
		 */
		std::string revisionRule;
};

} /* namespace handlers */
#endif /* CHECKFOROBSOLETEHANDLER_HXX_ */
