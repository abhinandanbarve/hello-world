/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers

 Description:    contains the implementation of the D4G-check-properties handler.

 ===============================================================================*/

#ifndef CHECKPROPERTIESHANDLER_HXX_
#define CHECKPROPERTIESHANDLER_HXX_

/*
 * Rule Handler that follows a searchpath and checks if specified types at
 * the end of this path have the specified values on the specified properties.
 * If match_all=TRUE every object at the end of the searchpath must match.
 * If match_all=FALSE at least one (per included attachment) must match.
 * Handler arguments:
 *  -to_attach, -include_type, -search_string
 *  -from_property, -to_property, -property, -value
 *  -match_exists, -group_revisions,-not
 */
EPM_decision_t D4G_CheckPropertiesDeepSearch( EPM_rule_message_t msg );

int collectObjectfromSearchPath(tag_t objtag, std::vector<std::string> searchpath, int pos, char* template_name ,std::vector<checktarget> &result);


#endif /* CHECKPROPERTIESHANDLER_HXX_ */
