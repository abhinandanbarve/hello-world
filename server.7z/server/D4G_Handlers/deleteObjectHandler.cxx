/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers
 Author  : Birger Nielsen

 Description:    contains the implementation of the D4G-delete-related-object handler.

 ===============================================================================*/

#include "deleteObjectHandler.hxx"
#include <vector>
#include "cToolbox.hxx"
#include <ITKtools.hxx>
#include <epm/epm.h>
#include <itkCallHeader.hxx>
#include <D4G_ErrorCodes.hxx>
#include <tccore/grm.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <constants.hxx>

namespace handlers {

deleteObjectHandler::deleteObjectHandler(EPM_action_message_t msg) : ActionHandler(msg) {
}

int deleteObjectHandler::perform(std::vector<tag_t> attachments){
	// get related_type argument(list of types for secondary relation objects)
	int userError=ITK_ok;
	std::string typesArg;
	bool typesExists = false;
	ask_handler_arg(RELATED_TYPE,&typesArg,&typesExists,0);
	std::vector<std::string> types = split_and_trim_to_vector_nonempty(typesArg,",.", " ");
	validateTypes(types);;

	// get relation argument(list of relation types)
	std::string relation;
	bool relationExists = false;
	ask_handler_arg(RELATION,&relation,&relationExists,0);
	std::vector<std::string> relationTypes = split_and_trim_to_vector_nonempty(relation,",.", " ");
	if(relationExists){
		ITK_LR(validateTypes(relationTypes));
	}

	// get reference argument
	std::string reference; //If argument not specified default to TARGET
	bool referenceExists = false;
	ask_handler_arg(REFERENCE,&reference,&referenceExists,0);
	std::vector<std::string> references = split_and_trim_to_vector_nonempty(reference,",.", " ");

	if(!relationExists && !referenceExists){
		std::string errorText("At least one of the parameters  '"+std::string(REFERENCE)+"' or '"+std::string(RELATION)+"' has to be set");
		ITK_LR(EMH_store_error_s1(EMH_severity_error, -1,errorText.c_str()));
		userError--;
	}
	if(userError==ITK_ok){
		logical current = set_bypass(TRUE);
		// iterate through attachments
		for(tagIterator it=attachments.begin();it!=attachments.end();++it){
			if(relationExists){
				// iterate through defined relation types
				for(std::vector<std::string>::iterator jt=relationTypes.begin();jt!=relationTypes.end();++jt){
					// find relationtype tag in TC
					tag_t relationTypeTag;
					ITK_LR(GRM_find_relation_type(jt->c_str(),&relationTypeTag));
					// list all relations of the given relation type with primary object the current attachment
					int count;
					tag_t * relations;
					ITK_LR(GRM_list_relations(*it,NULLTAG,relationTypeTag,NULLTAG,&count,&relations));
					// iterate through found relations
					for(int i=0;i<count;i++){
						// check secondary _object type
						tag_t secondary=NULLTAG;
						ITK_LR(AOM_ask_value_tag(relations[i],"secondary_object",&secondary));
						if(is_of_type(secondary,types)){
							// delete relation
							ITK_LR(GRM_delete_relation(relations[i]));
							// check if secondary_object is referenced somewhere
							int n_referencers;
							int * levels;
							tag_t *referencers;
							char **relations;
							ITK_LR(WSOM_where_referenced (secondary,1,&n_referencers,&levels,&referencers,&relations));
							SAFE_SM_FREE(levels);
							SAFE_SM_FREE(referencers);
							SAFE_SM_FREE(relations);
							if(n_referencers == 0){
								//delete secondary_object if it is not referenced
								ITK_LR(AOM_delete(secondary));
							}
						}
					}
				}
			}
			if(referenceExists){
				// iterate through reference attributes
				for(std::vector<std::string>::iterator jt=references.begin();jt!=references.end();++jt){
					// get referenced objects
					std::vector<tag_t> referenceObjects = get_tags_property_vector(*it,*jt);
					// remove object from reference considering the type
					std::vector<tag_t> removedObjects;
					std::vector<tag_t> keptObjects;
					for(std::vector<tag_t>::iterator kt=referenceObjects.begin();kt!=referenceObjects.end();++kt){
						if(is_of_type(*kt,types)){
							removedObjects.push_back(*kt);
						} else {
							keptObjects.push_back(*kt);
						}
					}
					if(keptObjects.size() == 0){
						keptObjects.push_back(NULLTAG); // just to be sure AOM_assign_tags can handle this vector
					}
					// save the new list of references(without the objects, which shall be deleted)
					ITK_LR(AOM_lock(*it));
					ITK_LR(AOM_assign_tags(*it,jt->c_str(),keptObjects.size(),&keptObjects[0]));
					//10-5-2017 : Robert : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
					//ITK_LR(AOM_save(*it));
					ITK_LR(AOM_save_with_extensions(*it));
					if(removedObjects.size()>0){
						//delete removed objects
						for(std::vector<tag_t>::iterator kt=removedObjects.begin();kt!=removedObjects.end();++kt){
							// Check whether this object is still referenced somewhere
							int n_referencers;
							int * levels;
							tag_t *referencers;
							char **relations;
							ITK_LR(WSOM_where_referenced (*kt,1,&n_referencers,&levels,&referencers,&relations));
							SAFE_SM_FREE(levels);
							SAFE_SM_FREE(referencers);
							SAFE_SM_FREE(relations);
							if(n_referencers == 0){
								ITK_LR(AOM_delete(*kt));
							}
						}
					}
				}
			}
		}
		set_bypass(current);
	}

	return userError;
}

deleteObjectHandler::~deleteObjectHandler(){
}

} /* namespace handlers */
