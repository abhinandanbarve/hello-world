/*
 * ActionHandler.hxx
 *
 *  Created on: Feb 23, 2016
 *      Author: infodba
 */

#ifndef ACTIONHANDLER_HXX_
#define ACTIONHANDLER_HXX_

#include <D4G_Handlers/AbstractHandler.hxx>

namespace handlers {
/*
 *Basic abstract handler for action handlers
 */
class ActionHandler : public AbstractHandler<EPM_action_message_t, int>{
public:
	//constructor
	explicit ActionHandler(EPM_action_message_t msg);
	// destructor
	virtual ~ActionHandler();

	/*
	 * Retrieves the attachments and triggers the perform method.
	 * The attachments are retrieved/filtered using the following handler arguments:
	 *
	 * include_type(optional):
	 * 		Komma/Whitespace separated list of types to be used
	 * 		to perform the action handler on. Other Types will not be considered.
	 *
	 * exclude_type(optional):
	 * 		Komma/Whitespace separated list of types, which will
	 * 		be excluded when performing the action handler.
	 *
	 * from_attach(optional):
	 * 		Attachment type from which the attachments will be retrieved.
	 * 		possible values are
	 * 		TARGET, REFERENCE, SCHEDULE_TASK
	 * 		if this parameter is not set it will be defaulted to TARGET
	 *
	 * search_string(optional):
	 *		"," or "." separated string defining a search path.
	 *		For each attachment the search path points to an object,
	 *		on which the action handler will be performed.
	 *
	 *		search_string can look like this:
	 *		<Attribute>.<type>.<attribute2>.<type2> ...
	 *
	 *	@return int: error code indicating an error.
	 */
	virtual int startHandler();
};

}


#endif /* ACTIONHANDLER_HXX_ */
