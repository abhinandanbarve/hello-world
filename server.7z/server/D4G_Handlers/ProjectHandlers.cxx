/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handler

 Description:    contains the implementation of the Danfoss Global PLM
 	 	 	 	 Project relevant handlers.

 ===============================================================================*/

#include <epm/epm.h>

#include <tc/emh.h>
#include <tc/preferences.h>
#include <bom/bom.h>
#include <epm/epm_toolkit_tc_utils.h>

#include <sa/user.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/project.h>

#include <tcinit/tcinit.h>

#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <set>
#include <sstream>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>
#include <D4G_ErrorCodes.hxx>
#include <D4G_Core/D4G_EPM_Handlers.hxx>


/*
 * Action Handler that assigns data to a project.
 * Handler arguments: -to_attach, -include_type, -project, include_item
 */

int D4G_AssignToProject( EPM_action_message_t msg ){
	int status = ITK_ok; //failure status, if this is ever not 0 we MEM_FREE and abort
	int userError = ITK_ok;

	//get all arguments from the msg
	string to_attach("TARGET"); //If argument not specified default to TARGET
	int toattach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"to_attach",&to_attach,0));
	to_attach= StrCaps(to_attach);
	if(to_attach=="TARGET"){toattach = EPM_target_attachment;
	} else if(to_attach=="REFERENCE"){toattach = EPM_reference_attachment;
	} else if(!to_attach.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "to_attach", "TARGET or REFERENCE"));
	}

	string include_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"include_type",&include_type,0));
	set<string> includetypes =*split(include_type,", \t");

	string project("PDP::");
	ITK_LOG(ask_handler_arg(msg.arguments,"project",&project,0));
	vector<string> projects =split_and_trim_to_vector_nonempty(project,",", " ");

	string include_item("FALSE");
	bool includeitem = FALSE;
	ITK_LOG(ask_handler_arg(msg.arguments,"include_item",&include_item,0));
	include_item=StrCaps(include_item);
	if(include_item=="TRUE"){includeitem=TRUE;
	} else if(include_item=="FALSE"){includeitem=FALSE;
	} else{
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "include_item", "TRUE or FALSE"));
	}

	//get the root task
	tag_t root;
	ITK_LOG(EPM_ask_root_task(msg.task, &root));


	//Collect the project tags for the entered project ids
	vector<tag_t> projtags;
	bool collectPDPfromRel = false;
	if(status==ITK_ok && userError==ITK_ok){
		for(int i=0; i<projects.size() && status==ITK_ok; i++){
			//If user specified PDP:: collect project list from the related PDP_ItemRevision
			if(projects[i]=="PDP::"){
				tag_t pdptag=NULLTAG;
				vector<tag_t> pdpprojects;
				//Get schedule task attachments (should only be one)
				vector<tag_t> taskattaches = get_attachments_vector(root, EPM_schedule_task_attachment);
				auto it = taskattaches.begin();
				if (it != taskattaches.end()){
					tag_t changetag;
					//get change item revision from csi0parentChange property
					ITK_LOG(AOM_ask_value_tag(*it, "csi0parentChange", &changetag));
					//check if it is the right type of change
					if (changetag && is_of_type(changetag, "D4G_PDPItemRevision")){
						pdptag=changetag;
					}
				}
				//If pdp item found on schedule task add its projects to project list
				if (pdptag!=NULLTAG){
					ITK_LOG(AOM_refresh(pdptag, false));
					pdpprojects = get_tags_property_vector(pdptag, "project_list");
					projtags.insert(projtags.end(), pdpprojects.begin(), pdpprojects.end());
					//If not wait to collect pdp projects per target by relation
				} else {
					collectPDPfromRel = true;
				}
			} else{
				tag_t projtag;
				ITK_LOG(PROJ_find(projects[i].c_str(), &projtag));
				projtags.push_back(projtag);
			}
		}
	}

	//Collect the objtags for target objects
	vector<tag_t> objtags;
	if(status==ITK_ok && userError==ITK_ok){
		//get the attachments
		vector<tag_t> attachments = get_attachments_vector(root,toattach);
		for(auto itAttach=attachments.begin(); status==ITK_ok && itAttach!=attachments.end(); itAttach++){
			string type = get_string_property(*itAttach, "object_type");
			if(includetypes.empty() || (includetypes.find(type) != includetypes.end()) ){
				objtags.push_back(*itAttach);
			}
			//If PDP mode is target based collect and assign to project locally
			if(collectPDPfromRel){
				vector<tag_t> pdptags;
				vector<string> relations;
				relations.push_back("D4G_PDPConcRel");
				relations.push_back("D4G_PDPEngRel");
				relations.push_back("D4G_PDPMarkeRel");
				relations.push_back("D4G_PDPOperRel");
				relations.push_back("D4G_PDPProjManRel");
				relations.push_back("D4G_PDPQualiRel");
				ITK_LOG(get_primary_for_relations(*itAttach, relations, "D4G_PDPItemRevision", pdptags));

				if(pdptags.empty()){
					userError--;
					EMH_store_error_s1(EMH_severity_error, -1,
							"Project value set to 'PDP::', but no PDP_Item found related to Schedule task or target.");
				} else{
					vector<tag_t> localprojects;
					for (int i=0; i<pdptags.size();i++){
						ITK_LOG(AOM_refresh(pdptags[i], false));
						vector<tag_t> pdpprojects = get_tags_property_vector(pdptags[i], "project_list");
						localprojects.insert(localprojects.end(), pdpprojects.begin(), pdpprojects.end());
					}
					if(!localprojects.empty()){
						if(!includeitem || !is_of_type(*itAttach, "ItemRevision")){
							ITK_LOG(PROJ_assign_objects(localprojects.size(), &localprojects[0], 1, &((tag_t) *itAttach)));
						} else{
							tag_t revanditemtags[2];
							revanditemtags[0]=*itAttach;
							ITK_LOG(AOM_ask_value_tag(revanditemtags[0], "items_tag", &revanditemtags[1]));
							ITK_LOG(PROJ_assign_objects(localprojects.size(), &localprojects[0], 2, revanditemtags));
						}
					}
				}
			}
		}
	}

	//Assign objtags to projtags
	if(status==ITK_ok && userError==ITK_ok){
		if(objtags.size()>0 && projtags.size()>0){
			if(!includeitem){
				ITK_LOG(PROJ_assign_objects(projtags.size(), &projtags[0], objtags.size(), &objtags[0]));
			} else{
				vector<tag_t> itemtags;
				for(int i=0; i<objtags.size(); i++){
					if(is_of_type(objtags[i], "ItemRevision")){
						tag_t itemtag;
						ITK_LOG(AOM_ask_value_tag(objtags[i], "items_tag", &itemtag));
						itemtags.push_back(itemtag);
					} else{
						itemtags.push_back(objtags[i]);
					}
				}
				ITK_LOG(PROJ_assign_objects(projtags.size(), &projtags[0], itemtags.size(), &itemtags[0]));
			}
		}
	}
	return status;
}

/*
 * Action Handler that removes data from a project.
 * Handler arguments: -to_attach, -include_type, -project, -pref_related_objects, -remove_item
 */

int D4G_RemoveFromProject( EPM_action_message_t msg ){
	int status = ITK_ok; //failure status, if this is ever not 0 we MEM_FREE and abort
	int userError = ITK_ok;

	//get all arguments from the msg
	string to_attach("TARGET"); //If argument not specified default to TARGET
	int toattach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"to_attach",&to_attach,0));
	to_attach= StrCaps(to_attach);
	if(to_attach=="TARGET"){toattach = EPM_target_attachment;
	} else if(to_attach=="REFERENCE"){toattach = EPM_reference_attachment;
	} else if(!to_attach.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "to_attach", "TARGET or REFERENCE"));
	}

	string include_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"include_type",&include_type,0));
	set<string> includetypes =*split(include_type,", \t");

	string project("PDP::");
	ITK_LOG(ask_handler_arg(msg.arguments,"project",&project,0));
	vector<string> projects =split_and_trim_to_vector_nonempty(project,",", " ");

	string pref_related_objects("");
	ITK_LOG(ask_handler_arg(msg.arguments,"pref_related_objects",&pref_related_objects,0));
	vector<string> relations;
	if(pref_related_objects!=""){
		//Read from pref into relations vector
		int relcount =0;
		char** rels;
		PREF_ask_char_values(pref_related_objects.c_str(), &relcount, &rels);
		for(int i=0; i<relcount; i++){
			relations.push_back(rels[i]);
		}
		SAFE_SM_FREE(rels);
	}

	string remove_item("FALSE");
	bool removeitem = FALSE;
	ITK_LOG(ask_handler_arg(msg.arguments,"remove_item",&remove_item,0));
	remove_item=StrCaps(remove_item);
	if(remove_item=="TRUE"){removeitem=TRUE;
	} else if(remove_item=="FALSE"){removeitem=FALSE;
	} else{
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "remove_item", "TRUE or FALSE"));
	}

	//get the root task
	tag_t root;
	ITK_LOG(EPM_ask_root_task(msg.task, &root));

	//Collect the project tags for the entered project ids
	vector<tag_t> projtags;
	if(status==ITK_ok && userError==ITK_ok){
		for(int i=0; i<projects.size() && status==ITK_ok; i++){
			//If user specified PDP:: collect project list from the related PDP_ItemRevision
			if(projects[i]=="PDP::"){
				vector<tag_t> pdpprojects;
				//Get schedule task attachments (should only be one)
				vector<tag_t> taskattaches = get_attachments_vector(root, EPM_schedule_task_attachment);
				auto it = taskattaches.begin();
				if (it != taskattaches.end()){
					tag_t pdptag;
					//get change item revision from csi0parentChange property
					ITK_LOG(AOM_ask_value_tag(*it, "csi0parentChange", &pdptag));
					//check if it is the right type of change
					if (pdptag && get_string_property(pdptag, "object_type")=="D4G_PDPItemRevision"){
						ITK_LOG(AOM_refresh(pdptag, false));
						pdpprojects = get_tags_property_vector(pdptag, "project_list");
						projtags.insert(projtags.end(), pdpprojects.begin(), pdpprojects.end());
					}
				}
				if (pdpprojects.empty()){
					userError--;
					ITK_LOG(EMH_store_error_s1(EMH_severity_error, -1,
							"Project value set to 'PDP::', but no PDP_Item found related to Schedule task."));
				}
			} else{
				tag_t projtag;
				ITK_LOG(PROJ_find(projects[i].c_str(), &projtag));
				projtags.push_back(projtag);
			}
		}
	}

	//Collect the objtags for target objects
	vector<tag_t> objtags;
	if(status==ITK_ok && userError==ITK_ok){
		//get the attachments
		vector<tag_t> attachments = get_attachments_vector(root,toattach);
		vector<tag_t> relatedtags;
		for(auto itAttach=attachments.begin(); status==ITK_ok && itAttach!=attachments.end(); itAttach++){
			string type = get_string_property(*itAttach, "object_type");
			cout<<"Attaches!\n";
			if(includetypes.empty() || (includetypes.find(type) != includetypes.end()) ){
				objtags.push_back(*itAttach);
				for(int i=0; i<relations.size(); i++){
					ITK_LOG(AOM_refresh(*itAttach, false));
					relatedtags = get_tags_property_vector(*itAttach, relations[i]);
					cout<<"Found "<<relatedtags.size()<<" related tags.\n";
					//					objtags.insert(objtags.end(), relatedtags.begin(), relatedtags.end());
				}
			}
		}
	}
	if(status==ITK_ok && userError==ITK_ok){
		if(objtags.size()>0 && projtags.size()>0){
			if(!removeitem){
				cout<<"Removing revs.\n";
				ITK_LOG(PROJ_remove_objects(projtags.size(), &projtags[0], objtags.size(), &objtags[0]));
			} else{
				vector<tag_t> itemtags;
				for(int i=0; i<objtags.size(); i++){
					if(is_of_type(objtags[i], "ItemRevision")){
						tag_t itemtag;
						ITK_LOG(AOM_ask_value_tag(objtags[i], "items_tag", &itemtag));
						itemtags.push_back(itemtag);
					} else{
						itemtags.push_back(objtags[i]);
					}
				}
				cout<<"Removing items.\n";
				ITK_LOG(PROJ_remove_objects(projtags.size(), &projtags[0], itemtags.size(), &itemtags[0]));
			}
		}
	}
	cout<<"Status is "<<status<<".\n";
	return status;
}
