/*==============================================================================
 Copyright (c) 2015 KGU Consulting
 Unpublished - All Rights Reserved
 ===============================================================================

 Description:    commonly used tool functions for C++

 ===============================================================================*/

#ifndef ITKTOOLS_HXX_
#define ITKTOOLS_HXX_

#include <string>
#include <set>
#include <vector>
#include <epm/epm_toolkit_tc_utils.h>

#ifdef __cplusplus
extern "C"{
#endif

extern int AM__set_application_bypass(logical bypass);
extern int AM__ask_application_bypass(logical* bypass);

#ifdef __cplusplus
}
#endif

struct TCerror {
	int severity;
	int errorid;
	std::vector<std::string> args;
	TCerror(int level, int id) : severity(level), errorid(id) {}
};

struct checktarget{
	tag_t objtag;
	bool passed;
	std::vector<TCerror> errors;
	checktarget(tag_t tag) : objtag(tag), passed(false) {}
};
int ask_prop_exists(tag_t objecttag, char* propname);

/*
 * gets a handler argument value from TC
 *
 * @param arguments, the TC argument list
 * @param name, name of the argument to be retrieved
 * @param value_cpp, value which will be set as output in this function
 * @param isNull, indicates if output was found
 * @param maxSize, maximum length of the string
 *
 * @return int, success of this operation.
 */
int ask_handler_arg(TC_argument_list_t* arguments,const char* name,std::string* value_cpp,bool* isNull, int maxSize);

int ask_handler_arg(TC_argument_list_t* arguments,const char* name,
		std::string* value_cpp, bool* isNull);

int ask_handler_arg(TC_argument_list_t* arguments,const char* name,
		std::string* value_cpp, int maxSize);

int ask_handler_arg(TC_argument_list_t* arguments,const char* name,
		std::string* value_cpp);

int ask_handler_arg(TC_argument_list_t* arguments,const char* name,
		bool* argExists);

/*
 * gets a handler argument value from TC and converts it to vector
 * interprets string as comma separated list and trims away spaces
 *
 * @param arguments, the TC argument list
 * @param name, name of the argument to be retrieved
 * @param values, value vector which will be set as output in this function
 * @param maxSize, maximum length of the string
 *
 * @return int, success of this operation.
 */
int ask_handler_arg_as_vector(TC_argument_list_t* arguments,const char* name,
		std::vector<std::string>* values, int maxSize);

int ask_handler_arg_as_vector(TC_argument_list_t* arguments,const char* name,
		std::vector<std::string>* values);


//std::set<tag_t> *get_attachments(tag_t task, int attachment_type);

std::vector<tag_t> get_attachments_vector(tag_t task, int attachment_type);


/*
 * @param tag of the business object to get the type name for.
 * @return the type name of this Business object.
 */
std::string
get_type_name(tag_t object);

/*
 * @return the value of a given bool property
 * @param attribute name.
 */
bool get_bool_property(tag_t object, std::string name);

/*
 * @return the value of a given string property
 * @param attribute name.
 */
std::string get_string_property(tag_t object, std::string name);

/*
 * @return the display value of a given property
 * @param attribute name.
 */
std::string get_display_property(tag_t object, std::string name);

/*
 * @return the display name of a given property
 * @param object tag, property name.
 */
std::string get_property_display_name(tag_t object, std::string name);

/*
 * return vector of tag or tags from a given property
 * @param object tag, property name
 */
std::vector<tag_t> get_tags_property(tag_t object, std::string name);

std::vector<tag_t> get_tags_property_vector(tag_t object, std::string name);

/*
 * return preference value at index (0 for single value pref)
 * @param preference name, index
 * @outparam preference value
 */
std::string get_pref(std::string prefname, int index);

//get_pref for single valued pref
std::string get_pref(std::string prefname);

/*
 * return vector of preference values of a named preference
 * @param preference name
 * @outparam vector of preference values
 */
std::vector<std::string> get_prefs(std::string prefname);

/*
 * Validate that all types in typelist exist, returns errorcode if not.
 * @param object_type
 */
int validate_type(std::string type);
int validate_type(std::vector<std::string> types);

/*
 * check if user is in group::role combination specified by preference
 * Accepts following format for preference entries:
 *  group::role where group is valid group name and role is a valid role name.
 */
bool check_user_against_pref(std::string prefname);

/*
 * Checks if supplied object is type or subtype of supplied object type or types
 * @param object tag, object_type
 */
bool is_of_type(tag_t objtag, std::string type);

bool is_of_type(tag_t objtag, std::vector<std::string> types);

/*
 * Gets status type as string from a release status tag.
 * @param statustag
 */
std::string get_status_type(tag_t statustag);

/*
 * Gets vector of release status types from an object tag.
 * @param objtag
 */
std::vector<std::string> get_status_vector(tag_t objtag);

/*
 * Answers if an obj has a given status (defined by type string).
 * @param objtag, statusname
 */
bool hasStatus(tag_t objtag, std::string statusname);

logical set_bypass(logical bypass);

/*
 * Starts a subprocess of the given name with the given object as target.
 * @param object tag, process name, attach point
 */
tag_t start_sub_process(tag_t objtag, std::string process_name, int toattach);

/*
 * Collects primary items from named relation with specified item as secondary.
 * @param object tag, relation name, include type
 * @outparam vector of primary tags
 */
int get_primary_for_relation(tag_t objtag, std::string relation_name, std::string include_type,
		std::vector<tag_t>& primaries);

int get_primary_for_relations(tag_t objtag, std::vector<std::string> relation_names, std::string include_type,
		std::vector<tag_t>& primaries);

/*
 * Collects secondary items from named relation with specified item as primary.
 * @param object tag, relation name, include type
 * @outparam vector of secondary tags
 */
int get_secondary_for_relation(tag_t objtag, std::string relation_name, std::string include_type,
		std::vector<tag_t>& secondaries);

int get_secondary_for_relations(tag_t objtag, std::vector<std::string> relation_names, std::string include_type,
		std::vector<tag_t>& secondaries);

int store_error(TCerror error);

int store_errors(std::vector<TCerror> errors);

/*
 * Changes object_name on all attachments following specified relation
 * @param object tag, relation name, include type name, new object name
 * @outparam error code
 */
int rename_attachments(tag_t objtag, std::string relation_name, std::string include_type, std::string newname);

/*
 * After an Revision ID change this function updates object_name on all datasets attached via specified relation.
 * Dataset names are only updated if they follow naming rule specified in XYZ_saveas_pattern.
 * New names are created following the same naming rule.
 * @param object tag, relation name, old revision ID
 * @outparam error code
 */
int update_dataset_names(tag_t objtag, std::string relation_name, std::string oldRevId);

tag_t get_bvr_from_revision(tag_t revision, std::string bvName);

int create_bom_window(tag_t bvr,tag_t *window,tag_t * topBomLine);

int set_revision_rule(tag_t window, std::string revisionRule);

std::vector<tag_t> get_child_lines(tag_t bomLine);

tag_t get_bomLine_object(tag_t bomLine);

/* This function is used to compare revision Id strings */
bool compareRevisionIds( tag_t &revisionObj1, tag_t &revisionObj2 );

/* This function is used to sort revision Ids of the Revision business objects */
void sortRevisionIds( tag_t *tRev_tags , int numberOfRevisions );

#endif /* ITKTOOLS_HXX_ */
