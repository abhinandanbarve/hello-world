/******************************************************************************
* Filename         :  D4G_Mass_Utilities_Functions.cxx
* Description      :
*
*
* ENVIRONMENT      :   C, C++, ITK
* FUNCTION LIST    :

*
* History
*------------------------------------------------------------------------------
* Date             Name           Description of Change
* 28-Jun-2017      Rohit          Initial Creation
* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <D4G_Mass_Utilities_Functions.hxx>

/***************************************************************************************
* Function Name    : createRelationChangeObjects
* Description      : 

*
* REQUIRED HEADERS : D4G_Mass_Utilities_Functions.hxx
* INPUT PARAMS     : 
*                    
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        : 
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date              Name              Company      Description of Change
* 15-03-16    		Rahul Yadav       Siemens      Initial Code for Common Methods in Both Utilities
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

__declspec(dllexport) int createRelationChangeObjects(tag_t tChangeObject,tag_t tsecObject,tag_t tRelation,vector<string>& vecStoreLogs,int& iErrorCount)
{
	int status               = ITK_ok;
	tag_t tagNewRelation      = NULLTAG;
	string strAddLog;
	char* pcObjectString			       = NULL;
	char* pcChangeObjectString			   = NULL;

	try
	{
		if(tChangeObject != NULLTAG && tsecObject != NULLTAG && tRelation != NULLTAG )
		{
			ITK_LR(AOM_ask_value_string( tChangeObject, OBJECT_STRING, &pcChangeObjectString ) );
			ITK_LR(AOM_ask_value_string( tsecObject, OBJECT_STRING, &pcObjectString ) );
			ITK_LR( GRM_create_relation( tChangeObject, tsecObject,
				tRelation, NULLTAG, &tagNewRelation ) );
			ITK_LR( GRM_save_relation( tagNewRelation ) );


			if (status != ITK_ok)
			{
				iErrorCount++;
				strAddLog.clear();
				strAddLog.assign(" Error in creating Relation between ");
				strAddLog.append(pcObjectString);
				strAddLog.append(" and ");
				strAddLog.append(pcChangeObjectString);
				vecStoreLogs.push_back(strAddLog);
			}else
			{
				strAddLog.clear();
				strAddLog.assign(" Created relation with :");
				strAddLog.append(pcObjectString);
				vecStoreLogs.push_back(strAddLog);

			}

		}

	}catch( ... )
	{

	}

	return status;

}


/***************************************************************************************
* Function Name    : createRelation
* Description      : This function create relation with Change Objects and parts from CSV.
*
* REQUIRED HEADERS : soamassobsolete1406impl.hxx
* INPUT PARAMS     : vecsolutionItemLists             -- Vector of parts
*                    iReviseIndex                     -- index for Parts to create relation
*                    tagChangeReqRev                  -- Newly created Chnage Objetcs
*					  strNewObjecttype                 -- object type
*
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :   1) Check for Item or Revision instance.
*                    	2) Create relation to change objects.
*
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date              Name              Company      Description of Change
* 29-11-16    		Rahul Yadav       Siemens      Initial Code for Common Methods in Both Utilities
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

__declspec(dllexport) int createRelation(vector<tag_t> vecsolutionItemLists,int iReviseIndex,tag_t tagChangeReqRev,std::string strNewObjecttype,vector<string>& vecStoreLogs,int& iErrorCount)
{
	int status                            = ITK_ok;
	tag_t tRelationTag               = NULLTAG;
	tag_t latestRevtag = NULLTAG;
	char* pcObjectName			= NULL;
	char* pcChangeObjectString			= NULL;
	string strAddLog;
	try
	{
		//get relation tag for specified relation name
		ITK_LR( GRM_find_relation_type( strNewObjecttype.c_str(), &tRelationTag ) ) ;

		if(tRelationTag != NULLTAG)
		{
			AM__set_application_bypass(true);

			//ATTACH PRIMARY OBJECT TO SECONDARY OBJECT USING GIVEN RELATION....
			tag_t tempObj = vecsolutionItemLists.at(iReviseIndex);
			tag_t tempItem = NULLTAG;

			bool bInstance      = false;
			ITK_LR(isInstanceOfClass( ITEM_REV, tempObj, bInstance ) );

			if(bInstance)
			{
				ITK_LR(ITEM_ask_item_of_rev(tempObj,&tempItem));
				ITK_LR(ITEM_ask_latest_rev(tempItem,&latestRevtag));
			}else
			{
				ITK_LR(ITEM_ask_latest_rev(tempObj,&latestRevtag));
			}

			ITK_LR(AOM_ask_value_string( latestRevtag, OBJECT_STRING, &pcObjectName ) );
			ITK_LR(AOM_ask_value_string( tagChangeReqRev, OBJECT_STRING, &pcChangeObjectString ) );

			if(latestRevtag != NULLTAG && tagChangeReqRev !=NULLTAG)
			{
				createRelationChangeObjects(tagChangeReqRev,latestRevtag,tRelationTag,vecStoreLogs,iErrorCount);
			}

			AM__set_application_bypass(false);
		}
	}
	catch( ... )
	{
		strAddLog.clear();
		strAddLog.assign(" Failed to create relation :");
		strAddLog.append(pcObjectName);
		vecStoreLogs.push_back(strAddLog);
		AM__set_application_bypass(false);
	}

	return status;
}


/***************************************************************************************
* Function Name    : getCurrentTime
* Description      : This function output Current date and time in day-month-year-hr-min-sec.
*
* REQUIRED HEADERS : time.hxx
* INPUT PARAMS     : theTime             -- output current date
*
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :   1) return current time and date.
*
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date              Name              Company      Description of Change
* 15-03-16    		Rahul Yadav       Siemens      Initial Code for Common Methods in Both Utilities
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/


__declspec(dllexport) int getCurrentTime( date_t* theTime )
{
	time_t tt;
	struct tm* ptm;
	time( &tt );
	ptm = localtime( &tt );
	theTime->year = (short)ptm->tm_year + 1900;
	theTime->month = (byte)ptm->tm_mon;
	theTime->day = (byte)ptm->tm_mday;
	theTime->hour = (byte)ptm->tm_hour;
	theTime->minute = (byte)ptm->tm_min;
	theTime->second = (byte)ptm->tm_sec;
	return ITK_ok;
}

/***************************************************************************************
* Function Name    : isInstanceOfClass
* Description      : check if selected objected is instance of Item or Revision

*
* REQUIRED HEADERS : soamassobsolete1406impl.hxx
* INPUT PARAMS     : argv[]   -- Input argument from Workflow Handler
*                    
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :   
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date              Name              Company      Description of Change
* 15-03-16    		Rahul Yadav       Siemens      Initial Code for Common Methods in Both Utilities
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

__declspec(dllexport) int isInstanceOfClass( std::string szClassName, const tag_t& tInstance, bool& bInstance )
{
	int iStatus = ITK_ok;
	bInstance = false;

	try
	{
		tag_t tClass = NULLTAG;
		ITK_LR(POM_class_id_of_class( szClassName.c_str(), &tClass ) );

		tag_t tRefClass = NULLTAG;
		ITK_LR(POM_class_of_instance( tInstance, &tRefClass ) );

		ITK_LR(POM_is_descendant( tClass, tRefClass, &bInstance ) );
	}
	catch( ... )
	{

	}


	return iStatus;
}


/***************************************************************************************
* Function Name    : setParticipants
* Description      : This function sets participants of selected CR.

*
* REQUIRED HEADERS : soamassobsolete1406impl.hxx
* INPUT PARAMS     : 
*                    
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :  
*
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date              Name              Company      Description of Change
* 15-03-16    		Rahul Yadav       Siemens      Initial Code for Common Methods in Both Utilities
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

__declspec(dllexport) int setParticipants(tag_t selectedCR,tag_t& tParticipant)
{
	int    status               = ITK_ok;
	tag_t  tCurrentGroupMember  = NULLTAG;
	int iNumOfParticip          = 0;
	tag_t* ptParticipants       = NULL;
	tag_t tParticipantType      = NULLTAG;

	try{


		AM__set_application_bypass(true);

		ITK_LOG(AOM_refresh( selectedCR, true ) );
		ITK_LOG(SA_ask_current_groupmember( &tCurrentGroupMember ) );

		if( tCurrentGroupMember != NULLTAG && selectedCR != NULLTAG )
		{
			ITK_LOG(EPM_get_participanttype( CHANGE_SPECIALIST_2, &tParticipantType ) );

			ITK_LOG(ITEM_rev_ask_participants( selectedCR, tParticipantType, &iNumOfParticip, &ptParticipants ));

			if( iNumOfParticip > 0 )
			{
				ITK_LOG(ITEM_rev_remove_participant(selectedCR, ptParticipants[0] ) );
				ITK_LOG(AOM_save( selectedCR ) );

				if( tParticipantType != NULLTAG )
				{
					ITK_LOG(EPM_create_participant( tCurrentGroupMember, tParticipantType, &tParticipant ) );
				}
				if( tParticipant != NULLTAG )
				{
					ITK_LOG(ITEM_rev_add_participant( selectedCR, tParticipant ) );
					ITK_LOG(AOM_save( selectedCR ) );
				}

			}else
			{
				if( tParticipantType != NULLTAG )
				{
					ITK_LOG(EPM_create_participant( tCurrentGroupMember, tParticipantType, &tParticipant ) );
				}
				if( tParticipant != NULLTAG )
				{
					ITK_LOG(ITEM_rev_add_participant( selectedCR, tParticipant ) );
					ITK_LOG(AOM_save( selectedCR ) );
				}
			}
		}
		ITK_LOG(AOM_refresh( selectedCR, false ) );
		AM__set_application_bypass(false);



	}catch( ... )
	{

	}
	return status;
}


/***************************************************************************************
* Function Name    : createChangeMasterforParts
* Description      : This function prepare map to create CM. Create Chnage master as per Plant and attach parts to CM with Solution Items relation. Each
CM will have maximum solution items mentioned in mass_obsolete_no_of_objects_in_CSV_Pref.
*
* REQUIRED HEADERS : soamassobsolete1406impl.hxx
* INPUT PARAMS     : selectedCR       -- Selected CR from Teamcenter
*                    vecPartFoundList -- Complete Part List
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :   1) Get Plant information from Part and Bom Item.
*                    	2) preparing Map to create data for CM Map<Plant,<Part vector that matches plant> >
*                   	3) Traverse map_Plant_Part to create CM and create relation and attach parts in Solution Item Folder.
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date             Name              Company      Description of Change
* 29-11-16    		Rahul Yadav       Siemens      Initial Code for Common Methods in Both Utilities
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/


__declspec(dllexport) int createChangeMasterforParts(tag_t tselectedCR,vector<tag_t> vecChangeNoticeLists,vector<tag_t>& vecChangeMasterLists,vector<string>& vecStoreLogs,int& iErrorCount,int& iPlantCount,std::string strOperation,string strMaxPrefName)
{
	int    status                            = ITK_ok;
	float  iobjectsPerCN                      = 0;
	int    iPrefValCount                      = 0;
	int    noOfCM                             = 0;
	char** pPrefValArry                       = NULL;
	char*  pcCMObjectName                     = NULL;
	char*  pcCnItemId                         = NULL;
	std::string strPlantName;
	tag_t  tlatestRevtag 					  = NULLTAG;
	tag_t  tPlantRelation                     = NULLTAG;
	vector<string> vecUniquePlants;
	std::vector<int> vecCMSeq;
	std::map<string, std::vector<tag_t> > map_Plant_Part;
	map_Plant_Part.clear();
	try
	{

		vecUniquePlants.clear();
		ITK_LR( PREF_ask_char_values( strMaxPrefName.c_str(), &iPrefValCount, &pPrefValArry ) );
		if( iPrefValCount == 1 )
		{
			iobjectsPerCN = (float)atoi(pPrefValArry[0]);
		}

		ITK_LR(AOM_ask_value_string( tselectedCR, OBJECT_NAME, &pcCMObjectName ) );
		ITK_LR( GRM_find_relation_type( PLANT_REL, &tPlantRelation ) ) ;

		for( int iCount = 0; iCount < vecChangeNoticeLists.size(); iCount++ )
		{
			std::string strCnPlant;
			int iCountSecoObjs  = 0;
			tag_t* tListSecObjTags    = NULL;
			tag_t  tRelationTag = NULL;

			tag_t tChangeNotice = vecChangeNoticeLists.at( iCount );

			ITK_LR(AOM_ask_value_string( tChangeNotice, ITEM_ID.c_str(), &pcCnItemId ) );
			ITK_LOG(GRM_find_relation_type(SOLUTION_ITEM_REL,&tRelationTag));
			ITK_LOG(GRM_list_secondary_objects_only( tChangeNotice, tRelationTag, &iCountSecoObjs, &tListSecObjTags));

			for( int iIndex = 0; iIndex < iCountSecoObjs; iIndex++ )
			{
				//printf("no of other : %d", iCountSecoObjs);
				tag_t typeTag = NULLTAG;
				char typeName[TCTYPE_name_size_c + 1] = "";
				ITK_LOG(TCTYPE_ask_object_type( tListSecObjTags[iIndex], &typeTag ) );
				ITK_LOG(TCTYPE_ask_name( typeTag, typeName ) );

				if(tc_strcmp( typeName, DANFOSS_PARTREV) == 0 || tc_strcmp( typeName, DANFOSS_BOMITEMREV) == 0)
				{
					tag_t tTempCNPartRev = NULLTAG;

					tTempCNPartRev = tListSecObjTags[iIndex];
					tag_t tempItem = NULLTAG;
					bool bInstance      = false;

					ITK_LR(isInstanceOfClass( ITEM_REV, tTempCNPartRev, bInstance ) );
					if(bInstance)
					{
						ITK_LR(ITEM_ask_item_of_rev(tTempCNPartRev,&tempItem));
						ITK_LR(ITEM_ask_latest_rev(tempItem,&tlatestRevtag));
					}

					int iCountSecondaryObjects =0;
					tag_t* tListSecondaryObjectTags = NULLTAG;
					char   cItemType[ITEM_type_size_c + 1] = "";

					ITK_LR( WSOM_ask_object_type( tlatestRevtag, cItemType ) );

					if(tc_strcmp( strOperation.c_str(), OBSOLETE ) !=0 && tc_strcmp( cItemType, DANFOSS_BOMITEMREV ) ==0)
					{
						tag_t tTempBomItemRev = NULLTAG;

						tTempBomItemRev = tListSecObjTags[iIndex];
						tag_t tempItem = NULLTAG;
						bool bInstance      = false;

						ITK_LR(isInstanceOfClass( ITEM_REV, tTempBomItemRev, bInstance ) );
						if(bInstance)
						{
							ITK_LR(ITEM_ask_item_of_rev(tTempBomItemRev,&tempItem));
							ITK_LR(ITEM_ask_latest_rev(tempItem,&tlatestRevtag));
						}
						char   cItemType[ITEM_type_size_c + 1] = "";

						ITK_LR( WSOM_ask_object_type( tlatestRevtag, cItemType ) );

						if( tc_strcmp( cItemType, DANFOSS_BOMITEMREV ) ==0)
						{
							strCnPlant.clear();
							strCnPlant.assign(pcCnItemId);
							strCnPlant.append("#");

							char* pcPlantName =NULL;
							ITK_LR(AOM_ask_value_string( tlatestRevtag, PLANT_ATT, &pcPlantName ) );

							std::vector<tag_t> innerVector;
							innerVector.push_back( tlatestRevtag );
							strCnPlant.append(pcPlantName);

							if(!vecUniquePlants.empty())
							{
								if(!(std::find(vecUniquePlants.begin(), vecUniquePlants.end(), pcPlantName) != vecUniquePlants.end()))
								{
									vecUniquePlants.push_back(pcPlantName);
								}
							}else
							{
								vecUniquePlants.push_back(pcPlantName);
							}

							if(!map_Plant_Part.empty() )
							{

								std::map<string, std::vector<tag_t> > ::iterator it_PP = map_Plant_Part.find(strCnPlant);

								if(it_PP != map_Plant_Part.end() )
								{

									std::vector<tag_t> innerVector = it_PP->second;
									if(!(std::find(innerVector.begin(), innerVector.end(), tlatestRevtag) != innerVector.end()))
									{
										innerVector.push_back(tlatestRevtag);
										map_Plant_Part[strCnPlant] = innerVector;
									}

								} else
								{
									std::vector<tag_t> innerVector;
									innerVector.push_back( tlatestRevtag );
									map_Plant_Part.insert( make_pair( strCnPlant, innerVector ) );
								}

							}else
							{
								std::vector<tag_t> innerVector;
								innerVector.push_back( tlatestRevtag );
								map_Plant_Part.insert( make_pair( strCnPlant, innerVector ) );
							}

						}



					}else
					{
						if(tPlantRelation != NULLTAG)
						{
							ITK_LR(GRM_list_secondary_objects_only( tlatestRevtag, tPlantRelation, &iCountSecondaryObjects, &tListSecondaryObjectTags));

							for( int iSecIndex = 0; iSecIndex < iCountSecondaryObjects; iSecIndex++ )
							{
								strCnPlant.clear();
								strCnPlant.assign(pcCnItemId);
								strCnPlant.append("#");

								char* pcPlantObjName =NULL;
								ITK_LR(AOM_ask_value_string( tListSecondaryObjectTags[iSecIndex], OBJECT_NAME, &pcPlantObjName ) );
								strCnPlant.append(pcPlantObjName);

								if(!vecUniquePlants.empty())
								{
									if(!(std::find(vecUniquePlants.begin(), vecUniquePlants.end(), pcPlantObjName) != vecUniquePlants.end()))
									{
										vecUniquePlants.push_back(pcPlantObjName);
									}
								}else
								{
									vecUniquePlants.push_back(pcPlantObjName);
								}

								if(!map_Plant_Part.empty() )
								{
									std::map<string, std::vector<tag_t> > ::iterator it_PP = map_Plant_Part.find(strCnPlant);

									if(it_PP != map_Plant_Part.end() )
									{
										std::vector<tag_t> innerVector = it_PP->second;
										if(!(std::find(innerVector.begin(), innerVector.end(), tlatestRevtag) != innerVector.end()))
										{
											innerVector.push_back(tlatestRevtag);
											map_Plant_Part[strCnPlant] = innerVector;
										}

									} else
									{
										std::vector<tag_t> innerVector;
										innerVector.push_back( tlatestRevtag );
										map_Plant_Part.insert( make_pair( strCnPlant, innerVector ) );
									}

								}else
								{
									std::vector<tag_t> innerVector;
									innerVector.push_back( tlatestRevtag );
									map_Plant_Part.insert( make_pair( strCnPlant, innerVector ) );
								}
							}
						}
					}
					D4G_FREE(tListSecondaryObjectTags);

				}

			}
			D4G_FREE(tListSecObjTags);
		}



		if( !map_Plant_Part.empty() )
		{
			std::string strPlantName;
			std::string strTempPlantName;
			std::map<string, std::vector<tag_t> >::iterator mapIter;
			for( mapIter = map_Plant_Part.begin(); mapIter != map_Plant_Part.end(); mapIter++ )
			{
				strTempPlantName = mapIter->first;
				std::size_t pos = strTempPlantName.find_first_of("#");
				if( pos != std::string::npos )
				{
					strPlantName = strTempPlantName.substr (pos+1,strTempPlantName.length());
				}

				std::vector<tag_t> innerVector = mapIter->second;
				float itotalSolutionItems = (float)innerVector.size();

				if(itotalSolutionItems>iobjectsPerCN)
				{
					double fractpart, intpart;
					float quotient;
					quotient = itotalSolutionItems / iobjectsPerCN;
					fractpart = modf (quotient , &intpart);

					if(fractpart>0)
					{
						noOfCM = (int)intpart+1;
					}else
					{
						noOfCM = (int)quotient;
					}

				}else
				{
					noOfCM = 1;
				}


				int istartIndex = 1;
				int iLastIndex  = (int)iobjectsPerCN;
				int iLoopStart = 1;
				int iLoopLast = 0;

				for(int index =1;index <= noOfCM;index++)
				{
					tag_t tagChangeMasRev       = NULLTAG;
					std::string strNewObjectName;
					strNewObjectName.append(pcCMObjectName);
					strNewObjectName.append("-");
					strNewObjectName.append(strPlantName);
					strNewObjectName.append("-");
					stringstream ss;
					ss << index;
					ss.str();
					strNewObjectName.append(ss.str());

					createChangeObject(tselectedCR,strPlantName,strNewObjectName,CHANGE_MASTER,tagChangeMasRev,vecStoreLogs,iErrorCount,strOperation);

					vecChangeMasterLists.push_back(tagChangeMasRev);

					if(index ==1)
					{
						iLoopStart=istartIndex;
						iLoopLast =iLastIndex;
						for(int index=iLoopStart ; index <= iLoopLast; index++)
						{
							int iReviseIndex =index-1;
							if(iReviseIndex < innerVector.size() )
							{
								createRelation(innerVector,iReviseIndex,tagChangeMasRev,SOLUTION_ITEM_REL,vecStoreLogs,iErrorCount);
							}
						}
					}else
					{
						iLoopStart =iLoopStart+iLastIndex;
						iLoopLast =iLoopLast+iLastIndex;
						for(int index=iLoopStart ; index <= iLoopLast; index++)
						{
							if(index <= innerVector.size())
							{
								int iReviseIndex =index-1;
								if(iReviseIndex < innerVector.size() )
								{
									createRelation(innerVector,iReviseIndex,tagChangeMasRev,SOLUTION_ITEM_REL,vecStoreLogs,iErrorCount);
								}
							}
						}
					}

				}

			}
		}

		if(!vecUniquePlants.empty())
		{
			iPlantCount = vecUniquePlants.size();
		}
		D4G_FREE(pPrefValArry);

	}catch(...)
	{

	}

	return status;

}


/***************************************************************************************
* Function Name    : createRelationChangeNoticeMaster
* Description      : This function traverse through vecChangeMasterLists and match solution items with vecChangeNoticeLists . If matches then create relation between
*					  CN and CM with CMImplements relation.
* REQUIRED HEADERS : soamassobsolete1406impl.hxx
* INPUT PARAMS     : vecChangeMasterLists  -- List of CM's
*					  vecChangeNoticeLists  -- List of CN's
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :   1) Traverse through vecChangeMasterLists get solution Items parts.
*                    	2) Traverse through vecChangeNoticeLists get solution Items parts.
*                   	3) match tag of solution items attached to CN and CM.
*                   	4) If match then create relation between CN and CM with CMImplements relation.
*
*
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date             Name              Company      Description of Change
* 29-11-16    		Rahul Yadav       Siemens      Initial Code for Common Methods in Both Utilities
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

__declspec(dllexport) int createRelationChangeNoticeMaster(vector<tag_t> vecChangeNoticeLists,vector<tag_t> vecChangeMasterLists,vector<string>& vecStoreLogs ,int& iErrorCount)
{
	int   status                      = ITK_ok;
	int iCountSecondaryObjects         = 0;
	tag_t* tListSecondaryObjectTags    = NULL;
	tag_t  tRelationTag                = NULL;
	string strAddLog;

	try
	{
		ITK_set_bypass(true);
		ITK_LOG(GRM_find_relation_type(SOLUTION_ITEM_REL,&tRelationTag));
		for( int iCount = 0; iCount < vecChangeMasterLists.size(); iCount++ )
		{
			tag_t tChangeMaster = vecChangeMasterLists.at( iCount );

			ITK_LOG(GRM_list_secondary_objects_only( tChangeMaster, tRelationTag, &iCountSecondaryObjects, &tListSecondaryObjectTags));
			logical lisRelationCreated = false;

			for( int iSecIndex = 0; iSecIndex < iCountSecondaryObjects; iSecIndex++ )
			{
				tag_t typeTag = NULLTAG;
				char typeName[TCTYPE_name_size_c + 1] = "";
				ITK_LOG(TCTYPE_ask_object_type( tListSecondaryObjectTags[iSecIndex], &typeTag ) );
				ITK_LOG(TCTYPE_ask_name( typeTag, typeName ) );

				if(tc_strcmp( typeName, DANFOSS_PARTREV) == 0 || tc_strcmp( typeName, DANFOSS_BOMITEMREV) == 0)
				{
					tag_t tTempCMPartRev = NULLTAG;
					tTempCMPartRev = tListSecondaryObjectTags[iSecIndex];

					for( int iCount = 0; iCount < vecChangeNoticeLists.size(); iCount++ )
					{
						int iCountSecoObjs  = 0;
						tag_t* tListSecObjTags    = NULL;
						tag_t tChangeNotice = vecChangeNoticeLists.at( iCount );

						char* pcCnName =NULL;
						ITK_LR(AOM_ask_value_string( tChangeNotice, OBJECT_STRING, &pcCnName ) );

						ITK_LOG(GRM_list_secondary_objects_only( tChangeNotice, tRelationTag, &iCountSecoObjs, &tListSecObjTags));

						for( int iIndex = 0; iIndex < iCountSecoObjs; iIndex++ )
						{
							tag_t typeTag = NULLTAG;
							char typeName[TCTYPE_name_size_c + 1] = "";
							ITK_LOG(TCTYPE_ask_object_type( tListSecObjTags[iIndex], &typeTag ) );
							ITK_LOG(TCTYPE_ask_name( typeTag, typeName ) );

							if(tc_strcmp( typeName, DANFOSS_PARTREV) == 0 || tc_strcmp( typeName, DANFOSS_BOMITEMREV) == 0)
							{
								tag_t tTempCNPartRev = NULLTAG;
								tTempCNPartRev = tListSecObjTags[iIndex];

								if(tTempCMPartRev == tTempCNPartRev)
								{
									// create relation
									tag_t newRelation = NULLTAG;
									tag_t tRelationType = NULLTAG;
									char* pcCMName =NULL;
									char* pcCNName =NULL;

									ITK_LR(AOM_ask_value_string( tChangeMaster, OBJECT_STRING, &pcCMName ) );
									ITK_LR(AOM_ask_value_string( tChangeNotice, OBJECT_STRING, &pcCNName ) );

									status = GRM_find_relation_type( CMIMPLEMENTS,&tRelationType );

									// create tagRelation between  Item Revisions & newly created  dataset  for avaliable Items
									status =GRM_create_relation( tChangeMaster, tChangeNotice, tRelationType, NULLTAG, &newRelation );
									status = GRM_save_relation( newRelation );
									if (status != ITK_ok)
									{
										iErrorCount++;
										strAddLog.clear();
										strAddLog.assign(" Error in creating relation between CN  ");
										strAddLog.append(pcCNName);
										strAddLog.append(" and CM  ");
										strAddLog.append(pcCMName);
										vecStoreLogs.push_back(strAddLog);


									}else
									{
										lisRelationCreated = true;
										break;
										strAddLog.clear();
										strAddLog.assign(" Relation created between CN ");
										strAddLog.append(pcCNName);
										strAddLog.append(" and CM  ");
										strAddLog.append(pcCMName);
										vecStoreLogs.push_back(strAddLog);

									}
								}
							}
						}
						if(lisRelationCreated)
						{
							D4G_FREE(tListSecObjTags);
							break;
						}else
						{
							D4G_FREE(tListSecObjTags);
						}

					}
				}
				if(lisRelationCreated)
				{
					break;
				}
			}
			D4G_FREE(tListSecondaryObjectTags);
		}
		ITK_set_bypass(false);


	}catch( ... )
	{
		ITK_set_bypass(false);
		D4G_FREE(tListSecondaryObjectTags);
	}

	return status;

}


/***************************************************************************************
* Function Name    : createChangeObject
* Description      : This function create change objects(CN,CM) based on input provided from different functions and paste them to New Stuff Folder.
*
* REQUIRED HEADERS : soamassobsolete1406impl.hxx
* INPUT PARAMS     : strNewObjectName       -- Object Name for Chnage Object
*                    strNewObjecttype       -- Object Type (CN,CM)
*                    tagChangeObjRev        -- return created change object
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :   1) Create change Object.
*                    	2) Paste created change objects to New Stuff Folder.
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date             Name              Company      Description of Change
* 29-11-16    		Rahul Yadav       Siemens      Initial Code for Common Methods in Both Utilities
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

__declspec(dllexport) int createChangeObject(tag_t tselectedCR,std::string strPlantName,std::string strNewObjectName,std::string strNewObjecttype,tag_t& tagChangeObjRev,vector<string>& vecStoreLogs,int& iErrorCount,std::string strOperation)
{
	int status                      = ITK_ok;
	tag_t tagChangeObject            = NULLTAG;
	tag_t tCreateDesc                = NULLTAG;
	tag_t tCreateRevDesc                = NULLTAG;
	tag_t tCreateInput               = NULLTAG;
	tag_t tCreateRevInput               = NULLTAG;
	tag_t tChangeType                = NULLTAG;
	tag_t tChangeRevType                = NULLTAG;
	char* cpCRChangeType			 = NULL;
	char *cpCRLabOffice              = NULL;
	tag_t tempCMItem                 = NULLTAG;
	date_t dpDate                    = NULLDATE;
	string strAddLog;

	try
	{

		AM__set_application_bypass(true);

		if(strNewObjectName.length()>0)
		{
			ITK_LR(ITEM_ask_item_of_rev(tselectedCR,&tempCMItem));
			ITK_LR(AOM_ask_value_string( tempCMItem, LAB_OFFICE_ATTR, &cpCRLabOffice ) );

			ITK_LOG(TCTYPE_find_type(strNewObjecttype.c_str(), "", &tChangeType));
			ITK_LOG(TCTYPE_ask_create_descriptor( tChangeType, &tCreateDesc ));
			ITK_LOG(TCTYPE_construct_create_input( tChangeType, &tCreateInput ));

			char * cpChangeName = ( char* )MEM_alloc( (50 ) * sizeof( char ) );
			tc_strcpy(cpChangeName,strNewObjectName.c_str());

			status = TCTYPE_set_create_display_value( tCreateInput,OBJECT_NAME , 1, (const char **)&cpChangeName );
			status = TCTYPE_set_create_display_value( tCreateInput,LAB_OFFICE_ATTR , 1, (const char **)&cpCRLabOffice );

			if(tc_strcmp(strNewObjecttype.c_str(),CHANGE_MASTER)==0)
			{
				ITK_LOG(TCTYPE_find_type(CM_REVISION, "", &tChangeRevType));
				ITK_LOG(TCTYPE_ask_create_descriptor( tChangeRevType, &tCreateRevDesc ));
				ITK_LOG(TCTYPE_construct_create_input( tChangeRevType, &tCreateRevInput ));

				char *cpCMChangeType          = NULL;
				cpCMChangeType = ( char* )MEM_alloc( (15 ) * sizeof( char ) );
				if(tc_strcmp(strOperation.c_str(),OBSOLETE)==0)
				{
					tc_strcpy(cpCMChangeType,OBSOLETE);
				}else
				{
					tc_strcpy(cpCMChangeType,STANDARD);
				}
				status = TCTYPE_set_create_display_value( tCreateInput,CHANGE_TYPE_ATTR , 1, (const char **)&cpCMChangeType );

				char *cpCMPlantName          = NULL;
				cpCMPlantName = ( char* )MEM_alloc( (15 ) * sizeof( char ) );
				tc_strcpy(cpCMPlantName,strPlantName.c_str());
				status = TCTYPE_set_create_display_value( tCreateRevInput,PLANT_ATT , 1, (const char **)&cpCMPlantName );

				char *cIrUid = NULL;
				ITK_LR(AOM_tag_to_string(tCreateRevInput, &cIrUid));
				ITK_LR(TCTYPE_set_create_display_value(tCreateInput, REVISION, 1, (const char **)&cIrUid )) ;

			}else
			{
				ITK_LR(AOM_ask_value_string( tempCMItem, CHANGE_TYPE_ATTR, &cpCRChangeType ) );
				status = TCTYPE_set_create_display_value( tCreateInput,CHANGE_TYPE_ATTR , 1, (const char **)&cpCRChangeType );

			}

			status = TCTYPE_create_object( tCreateInput, &tagChangeObject );

			if (status != ITK_ok)
			{
				iErrorCount++;
				strAddLog.clear();
				strAddLog.assign(" Error in creating Change Object type ");
				strAddLog.append(strNewObjecttype.c_str());
				strAddLog.append(" and name ");
				strAddLog.append(strNewObjectName.c_str());
				vecStoreLogs.push_back(strAddLog);


			}

			if( tagChangeObject != NULLTAG)
			{
				//save item and revision
				ITK_LOG(AOM_save(tagChangeObject));
				//get the latest rev
				ITK_LOG(ITEM_ask_latest_rev( tagChangeObject, &tagChangeObjRev ) );

				logical lIsLocked    = false;
				ITK_LOG( POM_modifiable( tagChangeObject, &lIsLocked ) ) ;

				if( !lIsLocked )
				{
					ITK_LOG(AOM_refresh( tagChangeObject, true ) );
				}

				//save item and revision
				ITK_LOG(AOM_save_with_extensions( tagChangeObject ) );
				ITK_LOG(AOM_save_with_extensions( tagChangeObjRev ) );

			}

			char* pcObjectString			= NULL;
			ITK_LR(AOM_ask_value_string( tagChangeObjRev, OBJECT_STRING, &pcObjectString ) );

			strAddLog.clear();
			strAddLog.assign(" Created Change Object :");
			strAddLog.append(pcObjectString);
			vecStoreLogs.push_back(strAddLog);

			if(tagChangeObjRev != NULL && tc_strcmp(strNewObjecttype.c_str(),CHANGE_NOTICE)==0)
			{
				char* pcCRObjectString			= NULL;
				ITK_LR(AOM_ask_value_string( tselectedCR, OBJECT_STRING, &pcCRObjectString ) );

				// create relation
				tag_t newRelation = NULLTAG;
				tag_t tRelationType = NULLTAG;
				ITK_LR(GRM_find_relation_type( CMIMPLEMENTS,&tRelationType ) );
				if(tRelationType != NULLTAG)
				{
					status =GRM_create_relation( tagChangeObjRev,tselectedCR, tRelationType, NULLTAG, &newRelation );
					status =GRM_save_relation( newRelation );
					if (status != ITK_ok)
					{
						iErrorCount++;
						strAddLog.clear();
						strAddLog.assign(" Error in creating Relation between ");
						strAddLog.append(pcObjectString);
						strAddLog.append(" and ");
						strAddLog.append(pcCRObjectString);
						vecStoreLogs.push_back(strAddLog);
					}
				}else
				{
					strAddLog.clear();
					strAddLog.assign(" Relation not found :");
					vecStoreLogs.push_back(strAddLog);
				}

			}else if(tc_strcmp(strNewObjecttype.c_str(),CHANGE_MASTER)==0 && tc_strcmp(strOperation.c_str(),OBSOLETE) != 0)
			{
				ITK_LOG(AOM_ask_value_date( tselectedCR, "CMTechRecommDate", &dpDate));
				ITK_LOG(AOM_refresh( tagChangeObjRev, true ) );
				ITK_LR(AOM_set_value_date(tagChangeObjRev,"d4g_CommonStartDate",dpDate ) );
				ITK_LOG(AOM_save(tagChangeObjRev));
				ITK_LOG(AOM_refresh( tagChangeObjRev, false ) );
			}
		}
		AM__set_application_bypass(false);

	}catch(...)
	{
		AM__set_application_bypass(false);
		strAddLog.clear();
		strAddLog.assign(" Failed Chnage Object :");
		strAddLog.append(strNewObjecttype.c_str());
		vecStoreLogs.push_back(strAddLog);
	}

	return status;
}


/***************************************************************************************
* Function Name    : createAttachLogDataset
* Description      : This function create Text dataset and export it to local directory and attaches to CR Rev with Reference Items relation.
*
* REQUIRED HEADERS : soamassobsolete1406impl.hxx
* INPUT PARAMS     : 	char*  cDatasetName,             //I
*                      char*  cDatasetDesc,            //I
*                      char*  cDatasetType,            //I
*                      char*  cFormatName,             //I
*                      char*  cDatasetRefName,         //I
*                      char*  cReferenceName,          //I
*                      char*  cRelationTypeName,       //I
*                      AE_reference_type_t ref_type,   //I
*                      tag_t  tagRevTag,               //I
*                      tag_t* tagNew_dataset )
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :   1) Create Dataset
*                    	2) Import log file
*                   	3) Attach log file with Reference Items relation.
*
*
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date             Name              Company      Description of Change
* 29-11-16    		Rahul Yadav       Siemens      Initial Code for Common Methods in Both Utilities
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

__declspec(dllexport) int createAttachLogDataset( char*  cDatasetName,             //I
	char*  cDatasetDesc,            //I
	char*  cDatasetType,            //I
	char*  cFormatName,             //I
	char*  cDatasetRefName,         //I
	char*  cReferenceName,          //I
	char*  cRelationTypeName,       //I
	AE_reference_type_t ref_type,   //I
	tag_t  tagRevTag,               //I
	tag_t* tagNew_dataset,
	vector<string>& vecStoreLogs,
	int& iErrorCount)         //0
{
	//Declaration For  Newly Created DataSet
	int   status                =   ITK_ok;
	tag_t tagDefault_tool_tag    =   NULLTAG ;
	tag_t tagDataset_type        =   NULLTAG;
	tag_t tagRelation_Type       =   NULLTAG;
	tag_t tagRelation            =   NULLTAG;
	tag_t tagFileTag             =   NULLTAG;
	IMF_file_t file_desc;
	string strAddLog;

	try
	{
		ITK_set_bypass(true);

		ITK_LOG(AE_find_datasettype( cDatasetType, &tagDataset_type ) );
		if( tagDataset_type != NULLTAG )
		{
			ITK_LOG(AE_create_dataset_with_id( tagDataset_type, cDatasetName, cDatasetDesc, NULL, NULL, &( *tagNew_dataset ) ) );

			if( ( *tagNew_dataset ) != NULLTAG )
			{
				ITK_LOG(AE_ask_datasettype_def_tool( tagDataset_type, &tagDefault_tool_tag ) );
			}
		}

		if( ( *tagNew_dataset ) != NULLTAG )
		{
			ITK_LOG(AE_set_dataset_format( ( *tagNew_dataset ), cFormatName ) );
			// Set the default tool for the new dataset
			ITK_LOG(AE_set_dataset_tool( ( *tagNew_dataset ), tagDefault_tool_tag ) );
			if( tc_strcmp( cFormatName, FORMAT_TEXT ) == 0 )
			{
				ITK_LOG(IMF_import_file( cDatasetRefName, NULL, SS_TEXT, &tagFileTag, &file_desc ) );
			}
			else
			{
				ITK_LOG(IMF_import_file( cDatasetRefName, NULL, SS_BINARY, &tagFileTag, &file_desc ) );
			}

			ITK_LOG(IMF_close_file( file_desc ) );
			ITK_LOG(AOM_save( tagFileTag ) );

			// adds named reference
			ITK_LOG(AE_add_dataset_named_ref( ( *tagNew_dataset ), cReferenceName, ref_type, tagFileTag ) );

			ITK_LOG(AOM_save( ( *tagNew_dataset ) ) );
			ITK_LOG(AOM_refresh( ( *tagNew_dataset ), false ) );

			if(tagRevTag != NULLTAG)
			{
				AM__set_application_bypass(true);
				// create tagRelation between  Item Revisions & newly created  dataset  for avaliable Items
				status = GRM_find_relation_type( cRelationTypeName, &tagRelation_Type );
				status = GRM_create_relation( tagRevTag, ( *tagNew_dataset ), tagRelation_Type, NULLTAG, &tagRelation );
				status = GRM_save_relation( tagRelation );
				if (status != ITK_ok)
				{
					iErrorCount++;
					strAddLog.clear();
					strAddLog.assign("Error in Attaching Log file to CR ");
					vecStoreLogs.push_back(strAddLog);
				}
				AM__set_application_bypass(false);
			}

		}
		ITK_set_bypass(false);

	}
	catch( ... )
	{
		ITK_set_bypass(false);
	}

	return status;
}

/***************************************************************************************
* Function Name    : sendUserNotification
* Description      : This function send notification to user who is running this utility that Utility has started and completed after completion.

*
* REQUIRED HEADERS : massobsolete_prepare_utility.h
* INPUT PARAMS     : tUser_Tag  -- User Tag
*					  cMailSub   -- Mail Subject
*					  cMailBody  -- Mail Body
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :   1) Create mail envelope
*                    	2) send mail to user.
*
*
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date              Name              Company      Description of Change
* 15-03-16    		Rahul Yadav       Siemens      Initial Code for Common Methods in Both Utilities
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

__declspec(dllexport) int sendUserNotification(tag_t tUser_Tag,char*  cMailSub,const char* cMailBody)
{
	int status                  = ITK_ok; //failure status, if this is ever not ITK_ok we MEM_FREE and abort

	tag_t envelope 				= NULLTAG;
	tag_t tType 				= NULLTAG;
	tag_t tEnvCreateInput 		= NULLTAG;


	try
	{
		if(tUser_Tag != NULLTAG)
		{
			TCTYPE_find_type( "Envelope" , NULL , &tType ) ;
			TCTYPE_construct_create_input( tType , &tEnvCreateInput ) ;
			AOM_set_value_string( tEnvCreateInput , "object_name" , cMailSub ) ;
			AOM_set_value_string( tEnvCreateInput , "object_desc" , cMailBody ) ;
			TCTYPE_create_object( tEnvCreateInput ,&envelope );
			AOM_save(envelope);

			ITK_LR(MAIL_add_envelope_receiver( envelope , tUser_Tag ) ) ;
			if(envelope != NULLTAG)
			{
				ITK_LR(MAIL_send_envelope( envelope ) ) ;
			}

		}

	}catch(...)
	{

	}

	return status;

}

