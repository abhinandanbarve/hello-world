/*
 * bomWindow.hxx
 *
 *  Created on: Feb 22, 2016
 *      Author: infodba
 */

#ifndef BOMWINDOW_HXX_
#define BOMWINDOW_HXX_

/*
 * This class represents a BOM window in the TC data model
 */
class bomWindow{
public:
	/*
	 * Destructor :
	 *
	 * Window will be closed in TC
	 */
	virtual ~bomWindow();
	/*
	 * Constructor:
	 *
	 * A TC BOM window will be opened. The given object will
	 * be the top line.
	 *
	 * @param object: top line of the new BOMWindow
	 * @param viewType: BOMView Type to be used for opening the BOM window
	 */
	explicit bomWindow(tag_t object, std::string viewType);
	/*
	 * @return the tag of the BOM window
	 */
	tag_t  getWindowTag();
	/*
	 * @return the top line of the BOM window
	 */
	tag_t getTopLine();
	/*
	 * sets a revision rule given by a name.
	 */
	void setRevisionRule(std::string revisionRule);
private:
	tag_t window;
	tag_t topLine;
};


#endif /* BOMWINDOW_HXX_ */
