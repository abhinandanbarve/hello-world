/*==============================================================================
 Copyright (c) 2015 KGU Consulting
 Unpublished - All Rights Reserved
 ===============================================================================

 Description:    commonly used tool functions for ITK

 ===============================================================================*/

#include "cToolbox.hxx"
#include "ITKtools.hxx"

#include <tc/preferences.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/releasestatus.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <epm/epm_task_template_itk.h>
#include <sa/site.h>

#include <ITKCallHeader.hxx>
#include <D4G_ErrorCodes.hxx>
#include <constants.hxx>

#include <string>
#include <ctype.h>
#include <set>
#include <vector>
#include <algorithm>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <boost/xpressive/xpressive.hpp>

using std::string;
using std::vector;
using std::set;

using namespace boost::xpressive::regex_constants;
using boost::xpressive::regex_search;
using boost::xpressive::smatch;
using boost::xpressive::regex_match;
using boost::xpressive::regex_replace;
using boost::xpressive::sregex;
using boost::xpressive::as_xpr;

//Returns 1 if the named property is in the list of properties of the object.
int ask_prop_exists(tag_t objecttag, char* propname){
	int status = 0;
	int found=0;
	int prop_count;
	char** prop_names = NULL; //MEM_FREE this
	ITK_LOG(
			AOM_ask_sorted_prop_names(objecttag, &prop_count, &prop_names));
	if(!status){
		found = StringInArray(propname, prop_names, prop_count);
	}
	for(int i=0; i<prop_count; i++){
		SAFE_SM_FREE( prop_names[i] );
	}
	SAFE_SM_FREE( prop_names );
	return found;
}

/*
 * gets a handler argument value from TC
 *
 * @param arguments, the TC argument list
 * @param name, name of the argument to be retrieved
 * @param value_cpp, value which will be set as output in this function
 * @param argExists, indicates if output was found
 * @param maxSize, maximum length of the string
 *
 * @return int, success of this operation.
 */
int ask_handler_arg(TC_argument_list_t* arguments,const char* name,
		string* value_cpp, bool* argExists,int maxSize) {
	int status=ITK_ok;
	*argExists=false;
	// iterate through all arguments
	if (arguments) {
		TC_init_argument_list(arguments);
		int numArgs=TC_number_of_arguments(arguments);
		for (int i=0;(status==ITK_ok)&&(i<numArgs);i++) {
			// get arg name & value
			char* argName=NULL;
			char* argValue=NULL;
			ITK_LOG(ITK_ask_argument_named_value(TC_next_argument(arguments),&argName,&argValue));
			char* substValue=NULL;
			ITK_LOG(EPM_substitute_keyword(argValue,&substValue));
			if(status==ITK_ok){
				// check name
				if (tc_strcmp(name,argName)==0) {
					*argExists=true;
					if (argValue!=NULL){
						// check size of value
						if ((maxSize<=0)||((maxSize>0)&&(tc_strlen(substValue)<=maxSize))) {
							*value_cpp=substValue?string(const_cast<const char *>(substValue)):"";
							//INFO << "Argument: <" << name << "> has value: <" << *value_cpp << ">" << ENDL;
						}
					}
				}
			}
			SAFE_SM_FREE(argName);
			SAFE_SM_FREE(argValue);
			SAFE_SM_FREE(substValue);
		}
	}
	return status;
}

int ask_handler_arg(TC_argument_list_t* arguments,const char* name,
		string* value_cpp, bool* argExists) {
	return ask_handler_arg(arguments, name, value_cpp, argExists, 0);
}

int ask_handler_arg(TC_argument_list_t* arguments,const char* name,
		string* value_cpp, int maxSize) {
	bool argExists;
	return ask_handler_arg(arguments, name, value_cpp, &argExists, maxSize);
}

int ask_handler_arg(TC_argument_list_t* arguments,const char* name,
		string* value_cpp) {
	bool argExists;
	return ask_handler_arg(arguments, name, value_cpp, &argExists, 0);
}

int ask_handler_arg(TC_argument_list_t* arguments,const char* name,
		bool* argExists) {
	string value_cpp;
	return ask_handler_arg(arguments, name, &value_cpp, argExists, 0);
}

/*
 * gets a handler argument value from TC and converts it to vector
 * interprets string as comma separated list and trims away spaces
 *
 * @param arguments, the TC argument list
 * @param name, name of the argument to be retrieved
 * @param values, value vector which will be set as output in this function
 * @param maxSize, maximum length of the string
 *
 * @return int, success of this operation.
 */
int ask_handler_arg_as_vector(TC_argument_list_t* arguments,const char* name,
		vector<string>* values, int maxSize){
	int status = ITK_ok;

	string value;
	bool argExists;
	ITK_LOG(ask_handler_arg(arguments,name,&value, &argExists, maxSize));
	if(argExists){
		//std::cout<<"setting values to split of ["<<value<<"]\n";
		*values =split_and_trim_to_vector(value,",", " ");
	}//else{std::cout<<"No value found\n";}
	return status;
}

int ask_handler_arg_as_vector(TC_argument_list_t* arguments,const char* name,
		vector<string>* values){
	return ask_handler_arg_as_vector(arguments, name, values, 0);
}

//set<tag_t> *get_attachments(tag_t task, int attachment_type){
//	int status=ITK_ok; //only needed for the ITK_LOG macro;
//	set<tag_t> *attachments=new set<tag_t>();
//	tag_t rootTask=NULLTAG;
//	ITK_LOG(EPM_ask_root_task(task, &rootTask));
//	int attachmentsCount=0;
//	tag_t *attachment_tags=NULL;
//	ITK_LOG(EPM_ask_attachments(rootTask,attachment_type,&attachmentsCount,&attachment_tags));
//	for(int i=0;i<attachmentsCount;++i){
//		attachments->insert(attachment_tags[i]);
//	}
//	SAFE_SM_FREE(attachment_tags);
//	return attachments;
//}

vector<tag_t> get_attachments_vector(tag_t task, int attachment_type){
	int status=ITK_ok; //only needed for the ITK_LOG macro;
	(void)attachment_type; // only needed for the C4100 error
	vector<tag_t> attachments;
	tag_t rootTask=NULLTAG;
	ITK_LOG(EPM_ask_root_task(task, &rootTask));
	int attachmentsCount=0;
	tag_t *attachment_tags=NULL;
	ITK_LOG(EPM_ask_attachments(rootTask,attachment_type,&attachmentsCount,&attachment_tags));
	for(int i=0;i<attachmentsCount;++i){
		attachments.push_back(attachment_tags[i]);
	}
	SAFE_SM_FREE(attachment_tags);
	return attachments;
}

/*
 * @param tag of the business object to get the type name for.
 * @return the type name of this Business object.
 */
string get_type_name(tag_t object){
	int status=ITK_ok; //only needed for the ITK_LOG macro;
	if (object == NULLTAG) {
		return string("NULL_OBJECT");
	}
	char *ctype_name=NULL;
	tag_t type_tag;
	ITK_LOG(TCTYPE_ask_object_type(object, &type_tag));
	ITK_LOG(TCTYPE_ask_name2(type_tag, &ctype_name));
	string result(const_cast<const char *>(ctype_name));
	SAFE_SM_FREE(ctype_name);
	return result;
}

/*
 * @return the value of a given bool property
 * @param attribute name.
 */
bool get_bool_property(tag_t object, string name){
	int status=ITK_ok; //only needed for the ITK_LOG macro;
	bool value = NULL;
	ITK_LOG(AOM_ask_value_logical(object, name.c_str(), &value));
	return value;
}

/*
 * @return the value of a given string property
 * @param attribute name.
 */
string get_string_property(tag_t object, string name){
	int status=ITK_ok; //only needed for the ITK_LOG macro;
	char* value = NULL;
	(void)object;
	(void)name;
	ITK_LOG(AOM_ask_value_string(object, name.c_str(), &value));
	string v("");
	if(value!=NULL){
		v=value;
	}
	SAFE_SM_FREE(value);
	return v;
}

/*
 * @return the display value of a given property
 * @param object tag, property name.
 */
string get_display_property(tag_t object, string name){
	int status=ITK_ok; //only needed for the ITK_LOG macro;
	int iNumValues = 0;
	char** value = NULL;
	
        //10-5-2017 : Robert : Deprecated API - "AOM_UIF_ask_value", replaced with "AOM_ask_displayable_values"
	//ITK_LOG(AOM_UIF_ask_value(object, name.c_str(), &value));
	ITK_LOG(AOM_ask_displayable_values(object, name.c_str(),&iNumValues, &value));

	string v("");
	if(value[0]!=NULL){
		v=value[0];
	}
	SAFE_SM_FREE(value);
	return v;
}

/*
 * @return the display name of a given property
 * @param object tag, property name.
 */
string get_property_display_name(tag_t object, string name){
	int status=ITK_ok; //only needed for the ITK_LOG macro;
	char* value = NULL;
	(void)object;
	(void)name;
	ITK_LOG(AOM_UIF_ask_name(object, name.c_str(), &value));
	string v("");
	if(value!=NULL){
		v=value;
	}
	SAFE_SM_FREE(value);
	return v;
}

/*
 * return vector of tag or tags from a given property
 * @param object tag, property name
 */
vector<tag_t> get_tags_property(tag_t object, string name){
	int status=ITK_ok;
	tag_t* value = NULL;
	int count;
	ITK_LOG(AOM_ask_value_tags(object, name.c_str(),&count, &value));
	vector<tag_t> result;
	for(int i=0; i<count; i++){
		if(value[i]!=NULLTAG){
			result.push_back(value[i]);
		}
	}
	SAFE_SM_FREE(value);
	return result;
}

vector<tag_t> get_tags_property_vector(tag_t object, string name){
	return get_tags_property(object, name);
}

string get_pref(string prefname, int index){
	int status = ITK_ok;
	char* value;
	ITK_LOG(PREF_ask_char_value(prefname.c_str(), index, &value));
	string out(value);
	SAFE_SM_FREE(value);
	return out;
}

string get_pref(string prefname){
	return get_pref(prefname, 0);
}

vector<string> get_prefs(std::string prefname){
	int status = ITK_ok;
	char** values;
	int count;
	ITK_LOG(PREF_ask_char_values(prefname.c_str(), &count, &values));
	vector<string> out;
	for (int i=0; i<count; i++){
		out.push_back(values[i]);
	}
	SAFE_SM_FREE(values);
	return out;
}

/*
 * check if user is in group::role combination specified by preference
 * Accepts following format for preference entries:
 *  group::role where group is valid group name and role is a valid role name.
 */
bool check_user_against_pref(std::string prefname){
	//get current group
	tag_t groupmembertag;
	SA_ask_current_groupmember(&groupmembertag);
	tag_t grouptag;
	char * group_name;
	SA_ask_groupmember_group(groupmembertag, &grouptag);
	SA_ask_group_name2(grouptag, &group_name);
	string group = group_name;
	SAFE_SM_FREE(group_name);

	//Collect parentgroups in format parentgroup.group.subgroup until root is reached
	tag_t parenttag;
	SA_ask_group_parent(grouptag, &parenttag);
	grouptag=parenttag;
	while(grouptag!=NULLTAG){
		SA_ask_group_name2(grouptag, &group_name);
		group.append(".");
		group.append(group_name);
		SAFE_SM_FREE(group_name);
		SA_ask_group_parent(grouptag, &parenttag);
		grouptag=parenttag;
	}

	//get current role
	tag_t roletag;
	char* role_name;
	SA_ask_current_role(&roletag);
	SA_ask_role_name2(roletag, &role_name);
	string role = role_name;
	SAFE_SM_FREE(role_name);

	//compare against all pref entries
	vector<string> privileged = get_prefs(prefname);
	for (int i=0; i<privileged.size(); i++){
		int colonpos = privileged[i].find("::");
		if(colonpos!=string::npos){
			string allowedGroup = Trim( privileged[i].substr(0, colonpos) ," ");
			if(match_with_wildcard(group, allowedGroup, "*")){
				string allowedRole = Trim( privileged[i].substr(colonpos+2,string::npos) ," ");
				if(match_with_wildcard(role, allowedRole, "*")){
					return true;
				}
			}
		}
	}
	return false;
}

int validate_type(string type){
	int status = ITK_ok;
	if(type=="ANY"||type=="NONE"){
		return status;
	}
	tag_t typetag = NULLTAG;
	ITK_LOG(TCTYPE_find_type(type.c_str(), NULL, &typetag));
	if(status!=ITK_ok ||typetag==NULLTAG){
		ITK_LOG(EMH_store_error_s1(EMH_severity_error, UE_WRONG_TYPE, type.c_str()));
		return UE_WRONG_TYPE;
	}
	return status;
}

int validate_type(vector<string> types){
	int status = ITK_ok;
	for(int i=0; i<types.size(); i++){
		status = validate_type(types[i]);
		if (status!=ITK_ok){
			return status;
		}
	}
	return status;
}

bool is_of_type(tag_t objtag, string type){
	if(type=="ANY"){
		return true;
	}
	if(type=="NONE"){
		return false;
	}
	bool answer=FALSE;
	int status = ITK_ok;
	tag_t typetag = NULL;
	ITK_LOG(TCTYPE_find_type(type.c_str(), NULL, &typetag));
	if(status==ITK_ok){
		tag_t objtypetag;
		ITK_LOG(TCTYPE_ask_object_type(objtag, &objtypetag));
		if(status==ITK_ok){
			ITK_LOG(TCTYPE_is_type_of(objtypetag,typetag, &answer));
		}
	}
	return answer;
}

bool is_of_type(tag_t objtag, vector<string> types){
	for(int i=0; i<types.size(); i++){
		if (is_of_type(objtag, types[i])){
			return true;
		}
	}
	return false;
}

string get_status_type(tag_t statustag){
	int status = ITK_ok;
	char* status_type;
	ITK_LOG(RELSTAT_ask_release_status_type(statustag,&status_type));
	string out(status_type);
	SAFE_SM_FREE(status_type);
	return out;
}

vector<string> get_status_vector(tag_t objtag){
	vector<tag_t> statustags=get_tags_property_vector(objtag,"release_status_list");
	vector<string> status;
	for (int i=0; i<statustags.size(); i++){
		status.push_back(get_status_type(statustags[i]));
	}
	return status;
}

bool hasStatus(tag_t objtag, string statusname){
	vector<string> status=get_status_vector(objtag);
	for(int i=0; i<status.size(); i++){
		if(status[i]==statusname){
			return true;
		}
	}
	return false;
}

/*
 * Sets bypass to supplied value and returns original bypass value
 * @param bypass value to set
 */
logical set_bypass(logical bypass){
	logical current;
	AM__ask_application_bypass(&current);
	if(current!=bypass){
		AM__set_application_bypass(bypass);
	}
	return current;
}

/*
 * Starts a subprocess of the given name with the given object as target.
 * @param object tag, process name, attach point
 */
tag_t start_sub_process(tag_t objtag, string process_name, int toattach){
	int status = ITK_ok;
	tag_t new_process = NULL;
	tag_t subprocess = NULL;
	ITK_LOG(EPM_find_process_template(process_name.c_str(), &subprocess));
	//	int attaches[] = {toattach};
	ITK_LOG(EPM_create_process(process_name.c_str(), "Created using D4G-subprocess handler.", subprocess,
			1, &objtag, &toattach, &new_process));
	return new_process;
}

/*
 * Collects primary items from named relation with specified item as secondary.
 * @param object tag, relation name, include type
 * @outparam vector of primary tags
 */
int get_primary_for_relation(tag_t objtag, string relation_name, string include_type,
		vector<tag_t>& primaries){
	primaries.clear();
	int status = ITK_ok;
	tag_t relTypeTag = 0;
	ITK_LOG(GRM_find_relation_type( relation_name.c_str(), &relTypeTag));
	if(!relTypeTag){
		return status;
	} else{
		int count= 0;
		tag_t * prims;
		ITK_LOG(GRM_list_primary_objects_only( objtag, relTypeTag, &count, &prims));
		for (int i=0; i<count; i++){
			if(is_of_type(prims[i], include_type)){
				primaries.push_back(prims[i]);
			}
		}
		SAFE_SM_FREE(prims);
	}
	return status;
}

int get_primary_for_relations(tag_t objtag, vector<string> relation_names, string include_type,
		vector<tag_t>& primaries){
	int status = ITK_ok;
	vector<tag_t> foundprims;
	for (int i=0; i<relation_names.size(); i++){
		status= get_primary_for_relation(objtag, relation_names[i], include_type, foundprims);
		if(status!=ITK_ok){
			return status;
		}
		primaries.insert(primaries.end(), foundprims.begin(), foundprims.end());
		foundprims.clear();
	}
	return status;
}

/*
 * Collects secondary items from named relation with specified item as primary.
 * @param object tag, relation name, include type
 * @outparam vector of secondary tags
 */
int get_secondary_for_relation(tag_t objtag, string relation_name, string include_type,
		vector<tag_t>& secondaries){
	secondaries.clear();
	int status = ITK_ok;
	tag_t relTypeTag = 0;
	ITK_LOG(GRM_find_relation_type( relation_name.c_str(), &relTypeTag));
	if(!relTypeTag){
		return status;
	} else{
		int count= 0;
		tag_t * prims;
		ITK_LOG(GRM_list_secondary_objects_only( objtag, relTypeTag, &count, &prims));
		for (int i=0; i<count; i++){
			if(is_of_type(prims[i], include_type)){
				secondaries.push_back(prims[i]);
			}
		}
		SAFE_SM_FREE(prims);
	}
	return status;
}

int get_secondary_for_relations(tag_t objtag, vector<string> relation_names, string include_type,
		vector<tag_t>& secondaries){
	int status = ITK_ok;
	vector<tag_t> foundprims;
	for (int i=0; i<relation_names.size(); i++){
		status= get_secondary_for_relation(objtag, relation_names[i], include_type, foundprims);
		if(status!=ITK_ok){
			return status;
		}
		secondaries.insert(secondaries.end(), foundprims.begin(), foundprims.end());
		foundprims.clear();
	}
	return status;
}

int store_error(TCerror err){
	int status = ITK_ok;
	if(err.args.size()==0){
		ITK_LOG(EMH_store_error(err.severity, err.errorid));
	} else if(err.args.size()==1){
		ITK_LOG(EMH_store_error_s1(err.severity, err.errorid, err.args[0].c_str()));
	} else if(err.args.size()==2){
		ITK_LOG(EMH_store_error_s2(err.severity, err.errorid, err.args[0].c_str(), err.args[1].c_str()));
	} else if(err.args.size()==3){
		ITK_LOG(EMH_store_error_s3(err.severity, err.errorid, err.args[0].c_str(), err.args[1].c_str(), err.args[2].c_str()));
	} else if(err.args.size()==4){
		ITK_LOG(EMH_store_error_s4(err.severity, err.errorid, err.args[0].c_str(), err.args[1].c_str(), err.args[2].c_str(), err.args[3].c_str()));
	} else if(err.args.size()==5){
		ITK_LOG(EMH_store_error_s5(err.severity, err.errorid, err.args[0].c_str(), err.args[1].c_str(), err.args[2].c_str(), err.args[3].c_str(), err.args[4].c_str()));
	} else{
		std::ostringstream stringStream;
		stringStream << "Error with errorcode "<<err.errorid<<" had more than 5 arguments.";
		string message = stringStream.str();
		ITK_LOG(EMH_store_error_s1(err.severity, -1, message.c_str()));
	}
	return status;
}


int store_errors(vector<TCerror> errvec){
	int status = ITK_ok;
	for(int i=0; i<errvec.size();i++){
		status = store_error((TCerror) errvec[i]);
		if(status!=ITK_ok){
			return status;
		}
	}
	return status;
}

int rename_attachments(tag_t objtag, string relation_name, string include_type, string newname){
	int status = ITK_ok;
	tag_t relTypeTag = 0;
	ITK_LOG(GRM_find_relation_type( relation_name.c_str(), &relTypeTag));
	if(!relTypeTag){
		return status;
	} else{
		int count= 0;
		tag_t* attachments;
		ITK_LOG(GRM_list_secondary_objects_only( objtag, relTypeTag, &count, &attachments));
		for (int i=0; i<count; i++){
			if(is_of_type(attachments[i], include_type)){
				ITK_LOG(AOM_lock(attachments[i]));
				ITK_LOG(AOM_assign_string(attachments[i], "object_name", newname.c_str()));
				//10-5-2017 : Robert : Deprecated API - "AOM_save", replaced with "AOM_save_with_extensions"
				//ITK_LOG(AOM_save(attachments[i]));
				ITK_LOG(AOM_save_with_extensions(attachments[i]));
			}
		}
		SAFE_SM_FREE(attachments);
	}
	return status;
}

int update_dataset_names(tag_t objtag, string relation_name, string oldRevId){
	int status = ITK_ok;
	string item_id = get_string_property(objtag,"item_id");
	string rev_id = get_string_property(objtag,"item_revision_id");
	tag_t relTypeTag = 0;
	ITK_LOG(GRM_find_relation_type( relation_name.c_str(), &relTypeTag));
	if(!relTypeTag){
		return status;
	} else{
		int count= 0;
		tag_t* datasets;
		ITK_LOG(GRM_list_secondary_objects_only( objtag, relTypeTag, &count, &datasets));
		for (int i=0; i<count; i++){
			if(is_of_type(datasets[i], "Dataset")){
				string prefname;
				if(is_of_type(datasets[i], "UGMASTER")){
					prefname = "UGMASTER_saveas_pattern";
				} else if(is_of_type(datasets[i], "UGALTREP")){
					prefname = "UGALTREP_saveas_pattern";
				} else if(is_of_type(datasets[i], "UGPART")){
					prefname = "UGPART_saveas_pattern";
				} else{
					prefname = "DATASET_saveas_pattern";
				}
				string namingrule = get_pref(prefname, 0);

				smatch matches;

				namingrule = regex_escape(namingrule);
				sregex RevisionID = as_xpr("\\${RevisionID}");
				if (regex_search(namingrule, RevisionID)){
					string fitpattern = "("+namingrule+")";
					fitpattern = regex_replace(fitpattern, RevisionID, ")("+oldRevId+")(", format_first_only);
					if (regex_search(fitpattern, RevisionID)){
						string message = "Error while renaming dataset. Namingrule in preference "+prefname
								+" contains ${RevisionID} more than once. This can not be handled.";
						ITK_LOG(EMH_store_error_s1(EMH_severity_error, -1, message.c_str()));
						status=-1;
					} else{
						sregex UserText= as_xpr("\\${UserText}");
						fitpattern = regex_replace(fitpattern, UserText, ".*");
						sregex ItemID = as_xpr("\\${ItemID}");
						fitpattern = regex_replace(fitpattern, ItemID, item_id);
						sregex pat= sregex::compile(fitpattern);
						string datasetname = get_string_property(datasets[i], "object_name");
						smatch matches;
						if (regex_match(datasetname, matches, pat)){
							string newdatasetname = regex_replace(datasetname, pat, "$1"+rev_id+"$3");
							if(newdatasetname!=""){
								ITK_LOG(AOM_lock(datasets[i]));
								ITK_LOG(AOM_assign_string(datasets[i], "object_name", newdatasetname.c_str()));
								//10-5-2017 : Robert : Deprecated API - "AOM_save", replaced with "AOM_save_with_extensions"
								//ITK_LOG(AOM_save(datasets[i]));
								ITK_LOG(AOM_save_with_extensions(datasets[i]));
							}
						}
					}
				}
			}
		}
	}
	return status;
}

tag_t get_bvr_from_revision(tag_t revision, string bvName){
	int status;
	vector<tag_t> bvrs=get_tags_property(revision,"structure_revisions");
	for(vector<tag_t>::iterator kt = bvrs.begin(); kt != bvrs.end(); ++kt) {
		tag_t bv;
		ITK_LOG(PS_ask_bom_view_of_bvr(*kt,&bv));
		tag_t view_type;
		ITK_LOG(PS_ask_bom_view_type(bv, &view_type));
		char* vtn;
		ITK_LOG(PS_ask_view_type_name(view_type, &vtn));
		std::string realBvrName(vtn);
		SAFE_SM_FREE(vtn);
		if(realBvrName==bvName){
			return *kt;
		}
	}
	return NULLTAG;
}

int create_bom_window(tag_t bvr, tag_t *window,tag_t * topBomLine){
	ITK_LR(BOM_create_window(window));
	ITK_LR(BOM_set_window_top_line_bvr(*window,bvr,topBomLine));
	return ITK_ok;
}

int set_revision_rule(tag_t window,string revisionRule){
	tag_t r;
	ITK_LR(CFM_find(revisionRule.c_str(), &r));
	ITK_LR(BOM_set_window_config_rule(window,r));
	return ITK_ok;
}

vector<tag_t> get_child_lines(tag_t bomLine){
	int status;
	vector<tag_t> result;
	int count;
	tag_t *children;
	ITK_LOG(BOM_line_ask_child_lines(bomLine, &count, &children));
	for (int i = 0; i < count; ++i) {
		if(children[i]!=NULLTAG){
			result.push_back(children[i]);
		}
	}
	if (count > 0) {
		SAFE_SM_FREE(children);
	}
	return result;
}


tag_t get_bomLine_object(tag_t bomLine) {
	int status;
	tag_t object;
	ITK_LOG(AOM_ask_value_tag(bomLine, "bl_line_object", &object));
	return object;
}

/*********************************************************************************************************************/
/*
/*  Function Name:      compareRevisionIds
/*  Program ID:         ITKtools.cxx
/*  Description:        This function is used to compare revision Id strings
/*  Input Parameters:   tag_t &revisionObj1, tag_t &revisionObj2
/*  Return Value:       boolean
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 11-09-2017	       Vivek Mundada 		  2739               Initial Creation
*
*************************************************************************************************************************/
bool compareRevisionIds( tag_t &revisionObj1, tag_t &revisionObj2 )
{
	int		status						;
	char	*revisionId1	= NULL		;
	char	*revisionId2	= NULL		;

	ITK_LOG( AOM_ask_value_string( revisionObj1, ITEM_REVISION_ID.c_str(), &revisionId1 ) );
	ITK_LOG( AOM_ask_value_string( revisionObj2, ITEM_REVISION_ID.c_str(), &revisionId2 ) );

    return tc_strcmp( revisionId1, revisionId2 ) < 0;
}

/*********************************************************************************************************************/
/*
/*  Function Name:      sortRevisionIds
/*  Program ID:         ITKtools.cxx
/*  Description:        This function is used to sort revision Ids of the Revision business objects
/*  Input Parameters:   tag_t *tRev_tags , int numberOfRevisions
/*  Return Value:       Void
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 11-09-2017	       Vivek Mundada 		  2739               Initial Creation
*
*************************************************************************************************************************/
void sortRevisionIds( tag_t *tRev_tags , int numberOfRevisions )
{
    std::sort( tRev_tags, tRev_tags + numberOfRevisions, compareRevisionIds );
}
