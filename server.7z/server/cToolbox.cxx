/*==============================================================================
 Copyright (c) 2015 KGU Consulting
 Unpublished - All Rights Reserved
 ===============================================================================

 Description:    commonly used tool functions for C++

 ===============================================================================*/

#include "cToolbox.hxx"

#include <string>
#include <ctype.h>
#include <set>
#include <vector>
#include <algorithm>
#include <boost/xpressive/xpressive.hpp>
#include <iostream>


int StringInArray(		char * element,		char ** array,		int arrayLength)
{
	for (int i=0; i<arrayLength;i++){
		if(tc_strcmp(element, array[i])==0){
			return 1;
		}
	}
	return 0;
}

// Converts all occurences of a-z in a string to A-Z
std::string StrCaps(std::string str)
{
	for (int i = 0; i < str.size(); i++)
	{
		if('a'<=str[i] && str[i]<='z'){
			str[i] = str[i]+'A'-'a';
		}
	}

	return str;
}

//trims all left side members of 'trimming' string
std::string TrimLeft(const std::string& str, std::string trimming)
{
	size_t startpos = str.find_first_not_of(trimming);
	return (startpos == std::string::npos) ? "" : str.substr(startpos);
}

//trims all right side members of 'trimming' string
std::string TrimRight(const std::string& str, std::string trimming)
{
	size_t endpos = str.find_last_not_of(trimming);
	return (endpos == std::string::npos) ? "" : str.substr(0, endpos+1);
}

//trims all left and right side members of 'trimming' string
std::string Trim(const std::string& str, std::string trimming)
{
	return TrimRight(TrimLeft(str, trimming), trimming);
}


/**
 *  Splits a string on a predefined delimiter and returns a set.
 *
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @return set of strings, split result.
 */
std::set<std::string> *
split(std::string const splitting, std::string const delimiter ) {
	size_t current;
	size_t next = -1;
	std::set<std::string> *result = new std::set<std::string>();
	do
	{
		current = next + 1;
		next = splitting.find_first_of( delimiter, current );
		std::string insert(splitting.substr( current, next - current ));
		if(insert != ""){
			result->insert(insert);
		}
	}
	while (next != std::string::npos);
	return result;
}

/**
 *  Splits a string on a predefined delimiter and returns a vector.
 *	Empty strings are not added into the vector.
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @return set of strings, split result.
 */
std::vector<std::string>
split_to_vector_nonempty(std::string const splitting, std::string const delimiter ) {
	size_t current;
	size_t next = -1;
	std::vector<std::string> result;
	do
	{
		current = next + 1;
		next = splitting.find_first_of( delimiter, current );
		std::string insert(splitting.substr( current, next - current ));
		if(insert!=""){
			result.push_back(insert);
		}
	}
	while (next != std::string::npos);
	return result;
}

/**
 *  Splits a string on a predefined delimiter and returns a vector.
 *	Empty strings are added into the vector.
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @return set of strings, split result.
 */
std::vector<std::string>
split_to_vector(std::string const splitting, std::string const delimiter ) {
	size_t current;
	size_t next = -1;
	std::vector<std::string> result;
	do
	{
		current = next + 1;
		next = splitting.find_first_of( delimiter, current );
		std::string insert(splitting.substr( current, next - current ));
		result.push_back(insert);
	}
	while (next != std::string::npos);
	return result;
}

/**
 *  Splits a string on a predefined delimiter, creates a vector
 *  and trims all elements according to second set of delimiters before returning vector.
 *	Empty strings are not added into the vector.
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @param trimming delimiter to trim from both ends of elements.
 *  @return set of strings, split result.
 */
std::vector<std::string>
split_and_trim_to_vector_nonempty(std::string const splitting, std::string const delimiter, std::string trimming) {
	std::vector<std::string> result = split_to_vector_nonempty(splitting, delimiter);
	for(int i=0;i<result.size();i++){
		result[i]=Trim(result[i], trimming);
	}
	return result;
}

/**
 *  Splits a string on a predefined delimiter, creates a vector
 *  and trims all elements according to second set of delimiters before returning vector.
 *	Empty strings are added into the vector.
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @param trimming delimiter to trim from both ends of elements.
 *  @return set of strings, split result.
 */
std::vector<std::string>
split_and_trim_to_vector(std::string const splitting, std::string const delimiter, std::string trimming) {
	std::vector<std::string> result = split_to_vector(splitting, delimiter);
	for(int i=0;i<result.size();i++){
		result[i]=Trim(result[i], trimming);
	}
	return result;
}

/**
 *  Splits a string on a predefined delimiter, creates a set
 *  and trims all elements according to second delimiter before returning set.
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @param trimming delimiter to trim from both ends of elements.
 *  @return set of strings, split result.
 */
std::set<std::string>
split_and_trim_to_set(std::string const splitting, std::string const delimiter, std::string const trimming ) {
	std::vector<std::string> resultasvector = split_and_trim_to_vector_nonempty(splitting, delimiter, trimming);
	std::set<std::string> result(resultasvector.begin(), resultasvector.end());
	return result;
}

/*
 *  Writes all entries of a vector<string> into a single comma separated string.
 *  Example output: [Hello, world, example]
 *
 *  @param vector<string> to convert into string,
 *  @return string
 */
std::string toString(std::vector<std::string> strings){
	std::string outstr;
	if(strings.size()>0){
		outstr.append("[");
		outstr.append(strings[0]);

		for(int i=1; i<strings.size(); i++){
			outstr.append(", ");
			outstr.append(strings[i]);
		}
		outstr.append("]");
	}

	return outstr;
}

// Xpressive Regex that catches all regex special characters
const boost::xpressive::sregex re_escape_text = boost::xpressive::sregex::compile("([\\^\\.\\$\\|\\(\\)\\[\\]\\*\\+\\?\\/\\\\])");

// Use regex_replace to escape (put a "\" in front of) every regex special character
std::string regex_escape(std::string text){
	text = boost::xpressive::regex_replace( text, re_escape_text, std::string("\\$1") );
	return text;
}

/*
 *  Tries to match a text to a pattern with a defined wildcard and returns the result.
 */
bool match_with_wildcard(std::string text, std::string pattern, std::string wildcard){
	wildcard = regex_escape(regex_escape(wildcard));
	//	std::cout<<"wildcard " << wildcard<<"\n";
	boost::xpressive::sregex rwildcard = boost::xpressive::sregex::compile(wildcard);
	std::string pattern2= regex_escape(pattern);
	pattern2= boost::xpressive::regex_replace( pattern2, rwildcard, std::string(".*"));
	//	std::cout<<"pattern " << pattern2<<"\n";
	boost::xpressive::sregex rpattern = boost::xpressive::sregex::compile(pattern2);
	boost::xpressive::smatch matches;
	return boost::xpressive::regex_match(text, matches, rpattern);
}
