#include <iostream>
#include <sstream>
#include <string>
#include <epm/epm_toolkit_tc_utils.h>
#include <epm/epm_toolkit_tc_utils.h>
#define ITK_CALL(x) {                                                        						\
	char *err_string = NULL;                                                 						\
	if( (status = (x)) != ITK_ok)                                            						\
	{                                                                        						\
		EMH_ask_error_text (status, &err_string);                 						            \
		TC_write_syslog("\nERROR: %d ERROR MSG: %s.\n", status, err_string);   						\
		TC_write_syslog("\nFUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__);				\
		std::cout << "\nERROR: " << status << "ERROR MSG: " << err_string << ".\n";					\
		std::cout << "\nFUNCTION: " << #x << "\nFILE: " << __FILE__ << "LINE: " << __LINE__ << "\n";\
		if(err_string) SAFE_SM_FREE(err_string);                                 					\
    }																								\
	else 																							\
	{          																						\
		std::cout << "\n";																			\
		std::cout << #x;																			\
		std::cout << "\tSUCCESS\n";																	\
	}                                                                      							\
}

#define ITK_LOG(x) {                                                        						\
	if( (status = (x)) != ITK_ok)                                            						\
	{                                                                        						\
		int index = 0;						\
		int n_ifails = 0;					\
		const int* severities = 0;			\
		const int* ifails = 0;				\
		const char** texts = NULL;			\
		EMH_ask_errors(&n_ifails, &severities, &ifails, &texts);			\
		std::ostringstream stream;											\
		stream << n_ifails << "error(s) occurred in in " << #x << ":" << "\n";						\
		for (index = 0; index < n_ifails; index++) {						\
			stream << "\tError " << ifails[index] << " " << texts[index];	\
			stream << "\n\t " << __FILE__ << "(line " << __LINE__ << ")";	\
			stream << "\n";											\
		}																	\
		TC_write_syslog(stream.str().c_str());   						\
    }																								\
}

#define ITK_LR(x) {                                                        						\
	int ret_status = 0;																				\
	if( (ret_status = (x)) != ITK_ok)                                            						\
	{                 																				\
		int index = 0;						\
		int n_ifails = 0;					\
		const int* severities = 0;			\
		const int* ifails = 0;				\
		const char** texts = NULL;			\
		EMH_ask_errors(&n_ifails, &severities, &ifails, &texts);			\
		std::ostringstream stream;											\
		stream << n_ifails << "error(s) occurred in in " << #x << ":" << "\n";						\
		for (index = 0; index < n_ifails; index++) {						\
			stream << "\tError " << ifails[index] << " " << texts[index];	\
			stream << "\n\t " << __FILE__ << "(line " << __LINE__ << ")";	\
			stream << "\n";											\
		}																	\
		TC_write_syslog(stream.str().c_str());   						\
		return ret_status;																			\
    }																								\
}

#define ITK_LR_BYPASS_RESET(x,bypass) {                                                        						\
	int ret_status = 0;																				\
	if( (ret_status = (x)) != ITK_ok)                                            						\
	{                 				\
		int index = 0;						\
		int n_ifails = 0;					\
		const int* severities = 0;			\
		const int* ifails = 0;				\
		const char** texts = NULL;			\
		EMH_ask_errors(&n_ifails, &severities, &ifails, &texts);			\
		std::ostringstream stream;											\
		stream << n_ifails << "error(s) occurred in in " << #x << ":" << "\n";						\
		for (index = 0; index < n_ifails; index++) {						\
			stream << "\tError " << ifails[index] << " " << texts[index];	\
			stream << "\n\t " << __FILE__ << "(line " << __LINE__ << ")";	\
			stream << "\n";											\
		}																	\
		TC_write_syslog(stream.str().c_str());   						\
		set_bypass(bypass); \
		return ret_status;																			\
    }																								\
}
