/*==============================================================================
 Copyright (c) 2015 KGU Consulting
 Unpublished - All Rights Reserved
 ===============================================================================

 Description:    commonly used tool functions for C++

 ===============================================================================*/

#ifndef CTOOLBOX_HXX_
#define CTOOLBOX_HXX_

#include <string>
#include <set>
#include <vector>
#include <epm/epm_toolkit_tc_utils.h>

int StringInArray(char * element, char ** array, int arrayLength);

// Converts all occurences of a-z in a string to A-Z
std::string StrCaps(std::string str);

//trims all left side members of 'trimming' string
std::string TrimLeft(const std::string& str, std::string trimming);

//trims all right side members of 'trimming' string
std::string TrimRight(const std::string& str, std::string trimming);

//trims all left and right side members of 'trimming' string
std::string Trim(const std::string& str, std::string trimming);

/**
 *  Splits a string on a predefined delimiter and returns a set.
 *
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @return set of strings, split result.
 */
std::set<std::string> *
split(std::string const splitting, std::string const delimiter );

/**
 *  Splits a string on a predefined delimiter and returns a vector.
 *	Empty strings are not added into the vector.
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @return set of strings, split result.
 */
std::vector<std::string>
split_to_vector_nonempty(std::string const splitting, std::string const delimiter );

/**
 *  Splits a string on a predefined delimiter, creates a vector
 *  and trims all elements according to second set of delimiters before returning vector.
 *	Empty strings are not added into the vector.
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @param trimming delimiter to trim from both ends of elements.
 *  @return set of strings, split result.
 */
std::vector<std::string>
split_and_trim_to_vector_nonempty(std::string const splitting, std::string const delimiter, std::string trimming);

/**
 *  Splits a string on a predefined delimiter, creates a vector
 *  and trims all elements according to second set of delimiters before returning vector.
 *	Empty strings are added into the vector.
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @param trimming delimiter to trim from both ends of elements.
 *  @return set of strings, split result.
 */
std::vector<std::string>
split_and_trim_to_vector(std::string const splitting, std::string const delimiter, std::string trimming);

/**
 *  Splits a string on a predefined delimiter, creates a set
 *  and trims all elements according to second delimiter before returning set.
 *
 *  @param string for splitting,
 *  @param delimiter delimiter to split the string on.
 *  @param trimming delimiter to trim from both ends of elements.
 *  @return set of strings, split result.
 */
std::set<std::string>
split_and_trim_to_set(std::string const splitting, std::string const delimiter, std::string const trimming );

/**
 *  Writes all entries of a vector<string> into a single comma separated string.
 *  Example output: [Hello, world, example]
 *
 *  @param vector<string> to convert into string,
 *  @return string
 */
std::string toString(std::vector<std::string> strings);

// Use regex_replace to escape (put a "\" in front of) every regex special character
std::string regex_escape(std::string text);

/*
 *  Tries to match a text to a pattern with a defined wildcard and returns the result.
 */
bool match_with_wildcard(std::string text, std::string pattern, std::string wildcard);


#endif /* CTOOLBOX_HXX_ */
