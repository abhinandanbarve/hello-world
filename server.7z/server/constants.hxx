/*
 * constants.hxx
 *
 *  Created on: Feb 18, 2016
 *      Author: Birger
 */

#ifndef CONSTANTS_HXX_
#define CONSTANTS_HXX_

#include <iostream>

//Type constants
const std::string VENDOR_PART_REVISION = "ManufacturerPart Revision";
const std::string DAN_PART_REVISON = "D4G_DanPartRevision";
const std::string CHANGE_MASTER_REVISiON = "D4G_ChangeMasterRevision";
const std::string BOM_ITEM_REVISON = "D4G_BOMItemRevision";
const std::string ITEM_REVISION = "ItemRevision";
const std::string BOM_VIEW_REVISION = "BomViewRevision";
const std::string D4G_DRAWING_REVISION = "D4G_DrawingRevision";
const std::string D4G_CA_DRAWING_REVISION = "D4G_CADrawingRevision";
const std::string DESIGN_REVISION = "D4G_DesignRevision";
const std::string CUS_APP_DESIGN = "D4G_CADesignRevision";
const std::string PART_REVISION = "Part Revision";
const std::string DESIGN_REVISON = "Design Revision";
const std::string D4G_RESTR_DOC_REVISION = "D4G_RestrDocRevision";
const std::string D4G_DOCUMENT_REL = "D4G_DocumentRel";
const std::string LATEST_WORKING_REV = "Latest Working";

const char D4G_PPAPSCHED[] = "D4G_PPAPSched";
const char D4G_DANPART[] = "D4G_DanPartRevision";
const char D4G_PPAPTASK[] = "D4G_PPAPTask";
const char D4G_CHANGE_MASTER_REVISION[] = "D4G_ChangeMasterRevision";
const char D4G_VENDORPART[] = "D4G_VendorPartRevision";
const char D4G_CHANGE_NOTICE_REVISION[] = "D4G_ChangeNoticeRevision";
const char D4G_CHANGE_REQUEST_REVISION[] = "D4G_ChangeReqRevision";
const char D4G_CUSTOMER_REQUEST_REVISION[] = "D4G_CustomerReqRevision";
const char OBSOLETE[] = "Obsolete";

//workflow
const std::string SAP_TRANSFER_WITH_BOM= "SAP transfer with BOM";
const std::string PROTOTYPE_RELEASE = "Prototype Release";

//Attribute constants
const std::string PART_ATTRIBUTE = "d4g_PartID";
const std::string PLANT_ATTRIBUTE = "d4g_Plant";
const std::string PRIMARY_OBJECT = "primary_object";
const std::string SECONDARY_OBJECT = "secondary_object";
const std::string OBJECT_NAME = "object_name";
const std::string RELEASE_STATUS_LIST = "release_status_list";
const std::string OFFICIAL_REVISION   = "d4g_official_revision";

//const std::string ITEM_ID     = "item_id";
const std::string BL_ITEM_ID  = "bl_item_item_id";
const std::string OBJECT_STRING = "object_string";
const std::string STRUCTURE_REVISIONS = "structure_revisions";
const std::string PRODUCTION_RELEVANT = "D4G_ProductionRel";
const std::string ITEM_ATTTRIBUTE = "items_tag";
const std::string PS_PARENTS = "ps_parents";
const std::string CHANGE_TYPE = "d4g_ChangeType";
const std::string ITEM_REVISION_ID = "item_revision_id";
const std::string DISPLAYABLE_REVISIONS = "displayable_revisions";
const std::string RECIPIENT = "recipient";
const std::string SUBJECT = "subject";
const std::string COMMENTS = "comments";
const std::string DESIGNER01 = "designer01";
const std::string USER = "User";
const std::string SUMMARY_TASK = "fnd0SummaryTask";
const std::string STATUS = "fnd0status";
const std::string DISABLED = "Disabled";
const std::string WORKFLOW_PROCESS = "workflow_process";
const std::string ASSIGNEE = "fnd0Assignee";
const std::string PPAPDECISIONMAKER ="d4g_PPAPDecisionMaker";
const std::string PPAPMANAGER ="d4g_PPAPManager";
const std::string PPAPREVIEWER ="d4g_PPAPReviewer";
const std::string OBJ_STRING = "object_string";
const std::string TASK_NAME = "fnd0AliasTaskName";
const std::string OBJECT_TYPE = "object_type";

//Schedule
#define SCHEDULE_CLASS					"Schedule"
#define IS_TEMPLATE_PROP				"is_template"
#define IS_PUBLIC_PROP					"is_public"
#define D4G_PPAP_REVIEWER_PROP			"d4g_PPAPReviewer"
#define D4G_PPAP_DECISIONMAKER_PROP		"d4g_PPAPDecisionMaker"
#define D4G_PLANT_PROP					"d4g_Plant"
#define D4G_SUMMARY_TASK_PROP			"fnd0SummaryTask"
#define D4G_CHILD_TASK_TAGLIST_PROP		"child_task_taglist"
#define D4G_DISABLED_PROP				"d4g_Disabled"
#define D4G_PREPROD_RELEVANT_PROP		"d4g_PreProdRelevant"

const char AllWORKFLOWS[] = "fnd0AllWorkflows";
const char REFERENCES[] = "awb0References";
const char OBJ_NAME[] = "object_name";
const char OBJ_GROUP[] = "object_group";
const char OBJECT_DESC	[] = "object_desc";
const char SCHEDULE_TAG[] = "schedule_tag";
//const char OBJ_STRING[] = "object_string";
const char SCHEDULE_MEMBER_TAGLIST[] = "fnd0Schedulemember_taglist";
const char MEMBER_TYPE[] = "fnd0MemberTypeString";
const char RESOURCE_TAG[] = "resource_tag";
const char D4G_REPLACED_BY[] = "d4g_ReplacedBy";
const char D4G_TRANSFERRED[] = "d4g_transferred";
const char ITEM_ID[]      = "item_id";
const char RELEASE_STATUS[] = "release_status_list";

//Relation constants
const std::string PART_PLANT_RELATION = "D4G_PartPlantRel";
const char TC_DRAWING_OF[] = "TC_DrawingOf";
const char TC_IS_REPRESENTED_BY[] = "TC_Is_Represented_By";
const char IMAN_RENDERING[] = "IMAN_Rendering";
const char CM_HAS_SOLUTION_ITEM[] = "CMHasSolutionItem";
const char CM_HAS_PROBLEM_ITEM[] = "CMHasProblemItem";
const char CM_HAS_WORK_BREAKDOWN[] = "CMHasWorkBreakdown";
const char CM_HAS_REFERENCE_ITEM[] = "CMReferences";
const char D4G_PART_PLANT_RELATION[] = "D4G_PartPlantRel";

//view types constants
const std::string DEFUALT_BOM_VIEW_TYPE ="view";

// Status constants
const std::string STATUS_OBSOLETE = "D4G_Obsolete";
const std::string STATUS_SERVICE = "D4G_Service";
const std::string STATUS_RELEASED = "D4G_Released";
const std::string STATUS_INREVIEW = "D4G_InReview";
const char STATUS_REJECTED[] = "D4G_Rejected";

//Handler args
const char INCLUDE_TYPE[] = "include_type";
const char EXCLUDE_TYPE[] = "exclude_type";
const char FROM_ATTACH[] = "from_attach";
const char SEARCH_STRING[] = "search_string";
const char TARGET_ATTACHMENT[] = "TARGET";
const char REFERENCE_ATTACHMENT[] = "REFERENCE";
const char SCHEDULE_TASK_ATTACHMENT[] = "SCHEDULE_TASK";
const char STATUS_TO_SET_ARG[] = "status_to_set";
const char PART_TYPE_ARG[] = "part_type";
const char BOM_ITEM_TYPE_ARG[] = "bom_item_type";
const char REVISION_RULE_ARG[] = "revision_rule";
const std::string PRODUCTION_RELEVANT_TRUE = "True";
const char RELATED_TYPE[] = "related_type";
const char RELATION[] = "relation";
const char REFERENCE[] = "reference";
const char TO_ATTACH[] = "to_attach";
const char ITEM[] = "item";
const char REVISION[] = "revision";
const char D4G_CHANGE_JOB_NAME_SWITCH[]= "refs_job_name_criteria";

//preferences

#define UPDATE_ITEM_DESC_PREF_NAME			"D4G_UpdateItem_name_desc_OnRelease"
#define ATTACH_PARTS_AS_REF_PREF_NAME		"D4G_Attach_PartsAs_Reference"
#define GET_PARTICIPANTS_FROM_SIGNOFF		"D4G_GetParticipantsFromSignOff"
#define DANFOSS_WORKFLOW_OBJECTS		"D4G_DanfossWorkflowObjects"
const std::string REVISON_PREFERENCE = "D4G_Revision_Rule";
const std::string WORKFLOW_TEMPLATES_FOR_MAIL_NOTIFICATION = "D4G_WorkflowTemplates_For_MailNotification";
const std::string USERS_ALLOWED_PREFERENCE = "D4G_users_allowed_to_modify_locked_relations";
#define D4G_CHANGE_IMPLEMENTATION_BOARD     "ChangeImplementationBoard"
#define D4G_CHANGE_REVIEW_BOARD     		"ChangeReviewBoard"

#endif /* CONSTANTS_HXX_ */
