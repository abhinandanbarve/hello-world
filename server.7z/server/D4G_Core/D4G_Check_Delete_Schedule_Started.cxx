/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Jan-J�rn Sommer

 Description:    contains the implementation for the Extension D4G_Check_Delete_Schedule_Started
 	 - A relation deletion PreCondition that checks if PPAP Schedules can be removed
 	 from Danfoss Part Revisions. If the PPAP Schedules are "not started" relation
 	 deletion is denied.
 	 Check is skipped if user has bypass or is specified in Preference
 	 D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/
#include <D4G_Core/D4G_Check_Delete_Schedule_Started.hxx>
#include <ITKCallHeader.hxx>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <string>
#include <tccore/item.h>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
using namespace std;
int D4G_Check_Delete_Schedule_Started( METHOD_message_t *msg, va_list args )
{
	// Skip Checks if user is privileged
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_relations")){return ITK_ok;}

	// Retrieve primary and secondary tags
	int result = ITK_ok;
	tag_t  object = msg->object_tag;
	tag_t secondary_object=NULLTAG;
	tag_t primary_object=NULLTAG;
	ITK_LR(GRM_ask_secondary(object, &secondary_object));
	ITK_LR(GRM_ask_primary(object, &primary_object));

	// Is relation to be removed attaching a PPAP Schedule to a Danfoss Part Revision?
	if(is_of_type(primary_object,"D4G_DanPartRevision") && is_of_type(secondary_object,"D4G_PPAPSched"))
	{
		//Check if PPAP Schedule is "not started". If yes error out.
		ITK_LR(AOM_refresh(secondary_object, false));
		//Robert - 18/7/2017 - fnd0sum_rollup_status property is obsolete in TC 11.2 onwards. Replaced with fnd0SSTStatus.
		//string rollupStatus = get_string_property(secondary_object, "fnd0sum_rollup_status");
		string rollupStatus = get_string_property(secondary_object, "fnd0SSTStatus");
		//if(rollupStatus != "not_started"){ //changed the string 'not_started' to 'Not Started'.
		if(rollupStatus != "Not Started"){
			ITK_LR(EMH_store_error_s1(EMH_severity_error,-1,
					"Already started PPAPs can not be removed from Part Revisions."));
			return -1;
		}
	}
	return result;

}
