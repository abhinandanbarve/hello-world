/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Jan J�rn Sommer

 Description:    contains the implementation for the Extension D4G_Property_Locked_by_Transfer
 	 - Property setter PreCondition that checks if none of the revisions of the
 	 item have been transfered to SAP. If any have property setting is denied.
 	 Check is skipped if user has bypass.

 ===============================================================================*/
#ifndef D4G_PROPERTY_LOCKED_BY_TRANSFER_HXX
#define D4G_PROPERTY_LOCKED_BY_TRANSFER_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_Property_Locked_by_Transfer(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_PROPERTY_LOCKED_BY_TRANSFER_HXX
