/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_DanPart_TransferStatus
    - A setter method override, that only allows the setting of a new value for
    the property d4g_DesignDesignation of no Parts are represented by this design yet.
    Users with bypass or those specified in the preference
    D4G_users_allowed_to_modify_locked_properties can override.

 ===============================================================================*/

#include <D4G_Core/D4G_DesignRevision_DesignDesignation.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>

#include <string>

#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>

using namespace std;

int D4G_DesignRevision_DesignDesignation( METHOD_message_t *msg, va_list args )
{
	// Check if user is privileged
	bool privileged = false;
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){privileged = true;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){privileged = true;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_properties")){privileged = true;}

	// Get the object tag and the list of represented Part Revision
	tag_t objtag= msg->object_tag;
	vector<tag_t> representedparts = get_tags_property_vector(objtag, "representation_for");

	// If represented objects were found and user is not privileged error out
	if(representedparts.size()>0 && !privileged){
		ITK_LR(EMH_store_error_s1(EMH_severity_error,-1,
				"Design Designation can not be changed on Design Revisions that already represent Parts."));
		return -1;
	} else{ // Else set the d4g_DesignDesignation to value
		(void*) va_arg(args, tag_t);
		string value(va_arg(args, char*));
		ITK_LR(AOM_assign_string(objtag, "d4g_DesignDesignation", value.c_str()));
		return ITK_ok;
	}
}
