/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_RelationLocked
 	 - A relation deletion and creation PreCondition that checks
 	 if user has bypass or is specified in Preference
 	 D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/
#ifndef D4G_RELATIONLOCKED_HXX
#define D4G_RELATIONLOCKED_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_RelationLocked(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_RELATIONLOCKED_HXX
