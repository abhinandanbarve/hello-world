/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_DanPart_TransferStatus
    - A setter method override, that only allows the setting of a new value for
    the property d4g_DesignDesignation of no Parts are represented by this design yet.
    Users with bypass or those specified in the preference
    D4G_users_allowed_to_modify_locked_properties can override.

 ===============================================================================*/

#ifndef D4G_DESIGNREVISION_DESIGNDESIGNATION_HXX
#define D4G_DESIGNREVISION_DESIGNDESIGNATION_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_DesignRevision_DesignDesignation(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_DESIGNREVISION_DESIGNDESIGNATION_HXX
