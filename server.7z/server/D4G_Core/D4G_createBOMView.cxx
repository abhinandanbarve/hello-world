/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Birger Nielsen

 Description:    contains the implementation for the Extension D4G_createBOMView
    - A createPost action on Part Revision create that creates a BOM View under
    new Part Revisions.

 ===============================================================================*/

#include <D4G_Core/D4G_createBOMView.hxx>
#include <ug_va_copy.h>
#include <metaframework/CreateInput.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <iostream>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <itkCallHeader.hxx>
#include <ps/ps.h>
#include <tccore/item.h>

int D4G_createBOMView( METHOD_message_t *msg, va_list args )
{
	va_list largs;
	va_copy( largs, args );

	Teamcenter::CreateInput *creInput=va_arg(largs,Teamcenter::CreateInput*);
	(void *) creInput;
	va_end(largs);

	// retrieve item from revision
	tag_t object=msg->object;
	tag_t item=NULLTAG;
	ITK_LR(AOM_ask_value_tag(object,"items_tag",&item));
	// get already existing bomViews from item
	int count;
	tag_t* bv_list;
	ITK_LR(ITEM_list_bom_views (item,&count,&bv_list));
	// get default view type
	tag_t default_view_type=NULLTAG;
	PS_ask_default_view_type(&default_view_type);
	tag_t bv=NULLTAG;
	// check whether the default bomView already exists
	for (int i = 0; i < count; ++i) {
		tag_t view_type;
		ITK_LR(PS_ask_bom_view_type(bv_list[i],&view_type));
		if(view_type==default_view_type){
			bv=bv_list[i];
		}
	}
	SAFE_SM_FREE(bv_list);
	// create default bomView if not existent
	if(bv==NULLTAG){
		ITK_LR(PS_create_bom_view(default_view_type, NULL, NULL, item, &bv));
		tag_t bvr;
		ITK_LR(PS_create_bvr(bv, NULL, NULL, false, object, &bvr));
	}
	return ITK_ok;
}
