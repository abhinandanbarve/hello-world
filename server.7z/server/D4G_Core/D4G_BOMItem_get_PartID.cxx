/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_BOMItem_get_PartID
    - A getter method override that first looks up if d4g_PartID is already set for this D4G_BOMItem
     in the database and if not tries to set it by checking for D4G_DanPartRevisions
     among its ps_parents and using their item_id.

 ===============================================================================*/

#include <D4G_Core/D4G_BOMItem_get_PartID.hxx>

#include <cxpom/attributeaccessor.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <pom/pom/pom.h>

#include <iostream>
#include <string>
#include <vector>

using std::vector;
using std::string;

#include <ItkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>

int D4G_BOMItem_get_PartID( METHOD_message_t *msg, va_list args )
{
	int status = ITK_ok;

	// Get object tag and attribute tag
	tag_t prop_tag = va_arg(args, tag_t);
	char **value = va_arg(args, char**);
	tag_t object_tag = NULLTAG;
	METHOD_PROP_MESSAGE_OBJECT(msg, object_tag);
	tag_t attr_tag;
	ITK_LOG(POM_attr_id_of_attr("d4g_PartID", "D4G_BOMItem", &attr_tag));

	// Get current value without invoking this getter
	string result;
	ITK_LOG(AttributeAccessor::getStringValue(object_tag, attr_tag, result));

	// If d4g_PartID is unset, try to find parent Parts item_id and use that
	if(result==""){
		vector<tag_t> revs = get_tags_property_vector(object_tag, "revision_list");
		if(revs.size()>0){
			vector<tag_t> parts=get_tags_property_vector(revs[0], "ps_parents");
			for (int i=0; i<parts.size() && result==""; i++){
				if(is_of_type(parts[i], "D4G_DanPartRevision")){
					result = get_string_property(parts[i], "item_id");
				}
			}
		}
		// Set found value as d4g_PartID
		if(result!=""){
			bool current = set_bypass(true);
			ITK_LOG(AOM_lock(object_tag));
			ITK_LOG(AttributeAccessor::setStringValue(object_tag, attr_tag, result));
			//9-5-2017 : Bipin : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
			//ITK_LOG(AOM_save(object_tag));
			ITK_LOG(AOM_save_with_extensions(object_tag));
			set_bypass(current);
		}
	}

	*value=MEM_string_copy(result.c_str());
	return status;
}
