/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_Property_Locked
 	 - A property setter PreCondition that checks if user has bypass or is specified
 	 in Preference D4G_users_allowed_to_modify_locked_properties.

 ===============================================================================*/
#include <D4G_Core/D4G_Property_Locked.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <string>

#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <D4G_ErrorCodes.hxx>

using std::string;

int D4G_Property_Locked( METHOD_message_t *msg, va_list args )
{
	// Check if user is privileged
	bool privileged = false;
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){privileged = true;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){privileged = true;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_properties")){privileged = true;}

	// Get object tag and property name
	tag_t objtag= msg->object_tag;
	string propname = msg->prop_name;

	// If user is not privileged error out
	if (!privileged){
		ITK_LR(EMH_store_error_s1(EMH_severity_error,PROPERTY_LOCKED, get_property_display_name(objtag, propname).c_str()));
		return PROPERTY_LOCKED;
	}

	// If allowed set property to value
	(void*) va_arg(args, tag_t);
	string value(va_arg(args, char*));
	ITK_LR(AOM_assign_string(objtag, propname.c_str(), value.c_str()));

	return ITK_ok;
}
