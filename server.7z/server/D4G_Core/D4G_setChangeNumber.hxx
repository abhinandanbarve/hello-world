/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_setChangeNumber
 	 - A relation creation PostAction that sets the property d4g_ChangeID of a
 	 secondary ItemRevision to the item_id of a primary D4G_ChangeNoticeRevision.
 	 Takes bypass to set property regardless of access rights.

 ===============================================================================*/

#ifndef D4G_SETCHANGENUMBER_HXX
#define D4G_SETCHANGENUMBER_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_setChangeNumber(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_SETCHANGENUMBER_HXX
