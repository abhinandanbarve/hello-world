/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_PartNumberList
    - A getter method override which returns contents at end of Compound Path
    schedule_tag.Schedule.D4G_TaskData

 ===============================================================================*/

#ifndef D4G_SCHEDULETASK_TASKDATA_HXX
#define D4G_SCHEDULETASK_TASKDATA_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_ScheduleTask_TaskData(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_SCHEDULETASK_TASKDATA_HXX
