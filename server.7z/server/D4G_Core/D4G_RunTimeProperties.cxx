//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*========================================================================================================================
Module  		: D4G_RunTimeProperties

Description		: File to register  the runtime properties


Date            Name      Task Id      		Description of Change
-------------------------------------------------------------------------------------------------------------------------
22-Jun-2017    Bhargav      2650        This file registers the runtime properties
                                        
========================================================================================================================*/


#include <D4G_Core/D4G_RunTimeProperties.hxx>
#include <ITKtools.hxx>
#include <epm/epm_toolkit_tc_utils.h>
#include <ItkCallHeader.hxx>
#include <constants.hxx>
#include <tccore/method.h>

#include <itk/mem.h>
#include <tccore/method.h>
#include <tccore/custom.h>
#include <tccore/tctype.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <tccore/grm.h>
#include <user_exits/user_exit_msg.h>
#include <user_exits/user_exits.h>
#include <tc/tc.h>
#include <ict/ict_userservice.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <tc/preferences.h>
#include <constants/constants.h>
#include <unidefs.h>
#include <string.h>

/***************************************************************************************
*Function Name   : D4G_RunTimeProperties
*Description     : this file contains the details of registered runtime properties
*Extension on    : BMF_SESSION_register_properties operation of the "session" object
*Extension Point : Base_action
*Dll name	     : libD4G_Extensions
*Library Name	 : D4G_Extensions
*Issue number 	 : 2650
*Author			 : Bhargav
***********************************************************************************/

int D4G_RunTimeProperties( METHOD_message_t * msg, va_list args )
{
 
	(void)msg;
	(void)args;
	int   ifail     = ITK_ok;
	METHOD_id_t     mReferenceChangeID;

	/*Registering post action for the property to find the referenced ChangeItemRevision for the proposed item revision*/
	ifail = METHOD_find_prop_method("D4G_DanPartRevision", "d4g_DeviationRequest",PROP_ask_value_tags_msg,&mReferenceChangeID);

	if(mReferenceChangeID.id != 0)
	{
		ifail = METHOD_add_action(mReferenceChangeID,METHOD_post_action_type,(METHOD_function_t )D4G_FindDeviationReq,NULL);
	}
	return ifail;

}

extern DLLAPI int libD4G_Core_register_callbacks()
{
	int      ifail  = ITK_ok;

	//registering the dll name
	ifail = CUSTOM_register_exit("libD4G_Core", "USER_register_properties", (CUSTOM_EXIT_ftn_t)D4G_RunTimeProperties);
	return ifail;
}


/***************************************************************************************
*Function Name   		: D4G_FindDeviationReq
*Description     		: code to get all the deviation requests on Danpart revision which are already related
*Runtime property name 	: d4g_DeviationRequest
*Extension on    		: BMF_SESSION_register_properties operation of the "session" object
*Extension Point 		: Base_action
*Dll name	     		: libD4G_Extensions
*Library Name	 		: D4G_Extensions
*Issue number 	 		: 2650
*Author			 		: Bhargav
***********************************************************************************/

int D4G_FindDeviationReq( METHOD_message_t* msg, va_list args)
{


	int       status                 		= ITK_ok;
    int       iInx                   		= 0;
    int*      iPropCount            		= 0;
    int       iItemRevCount         		= 0;

    tag_t     tObjectTag            		= NULLTAG;
    tag_t     tPropTag              		= NULLTAG;
    tag_t     tTypeTag              		= NULLTAG;
	tag_t     tRelType              		= NULLTAG;
    tag_t *   tItemRev              		= NULL;
    tag_t **  tItemRevArray         		= NULL;

    char   cTypeName[TCTYPE_name_size_c+1] = {'\0'};
    char * cpPropertyName                  = NULL;

    (void)msg;

    //getting the property tag from the args
	tPropTag                   = va_arg( args, tag_t );

	// num The count of values.
    iPropCount                 = va_arg( args, int* );

    // tags of objects (Deviation Requests)
    tItemRevArray              = va_arg( args, tag_t**); // tags of objects..

    //getting the tag for the object which is owning the run time property
    ITK_LOG( PROP_ask_owning_object( tPropTag, &tObjectTag ));

    //asking the type tag for the object
    ITK_LOG( TCTYPE_ask_object_type( tObjectTag, &tTypeTag ));

    //getting the type name of the object
    ITK_LOG( TCTYPE_ask_name( tTypeTag ,cTypeName ));

    //getting the type name of the property
    ITK_LOG( PROP_ask_name  (tPropTag, &cpPropertyName ));

    //getting the relation type tag for the relation name
    ITK_LOG( GRM_find_relation_type(CM_HAS_PROBLEM_ITEM,&tRelType));

	if( tRelType!=NULLTAG )
	{
		//Find related primary objects(D4g_Deviation Request revisions
		ITK_LOG( GRM_list_primary_objects_only  ( tObjectTag, tRelType, &iItemRevCount, &tItemRev ));
	}

	if( (iItemRevCount > 0))
    {
        //// Memory reallocation for the object tag

		(*tItemRevArray) = (tag_t *)MEM_alloc ((iItemRevCount * sizeof (tag_t)));
        for( iInx = 0; iInx<iItemRevCount; iInx++ )
        {
            (*tItemRevArray)[iInx] = tItemRev[iInx];
        }
        // updating property count
        *iPropCount = iItemRevCount;
    }

	SAFE_SM_FREE (tItemRev);
	SAFE_SM_FREE (cpPropertyName);

	return status;
}
