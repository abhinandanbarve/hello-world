/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_WriteOnlyIfNull
    - A setter method override which sets a property only if it is still NULL.
    Users with bypass can override.

 ===============================================================================*/

#include <D4G_Core/D4G_WriteOnlyIfNull.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <string>

#include <ItkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>

using std::string;

int D4G_WriteOnlyIfNull( METHOD_message_t *msg, va_list args )
{
	// Get object tag and property name
	int result = -1;
	tag_t objtag= msg->object_tag;
	string propname = msg->prop_name;

	// Check if any bypass is set. If so allow change.
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){result= ITK_ok;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){result= ITK_ok;}

	// Check if value is currently null. If so allow change.
	if(result!=ITK_ok){
		string propvalue = get_string_property(objtag, propname);
		if(propvalue.empty()){
			result = ITK_ok;
		}
	}

	// If result ok assign value (this does not trigger any checks). If not trigger error message.
	if (result==ITK_ok){
		(void*) va_arg(args, tag_t);
		string value(va_arg(args, char*));
		ITK_LR(AOM_assign_string(objtag, propname.c_str(), value.c_str()));
	} else{
		string message("Property "+get_property_display_name(objtag, propname)
				+" can not be changed.");
		ITK_LR(EMH_store_error_s1(EMH_severity_error,-1, message.c_str()));
	}
	return result;
}
