/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_deriveChangemasterId
    - A createPost action on CMImplements relation create that derives a new
    item_id for a D4G_ChangeMaster if a D4G_ChangeNoticeRevision is being attached
    to a D4G_ChangeMasterRevision.
    The new derived item_id for the Change Masteris the item_id of the
    Change Notice with the prefix CN replaced by CM and a 3 digit running number
    appended.
    The old item_id of the Change Master is stored in d4g_storeditemid.

 ===============================================================================*/

#include <D4G_Core/D4G_deriveChangeMasterId.hxx>

#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <metaframework/CreateInput.hxx>

#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>

int D4G_deriveChangeMasterId( METHOD_message_t *msg, va_list args )
{
	int status = ITK_ok;

	// Get primary and secondary opbject tag
	Teamcenter::CreateInput * creinput = va_arg(args, Teamcenter::CreateInput*);
	bool isNull = false;
	tag_t primarytag = NULLTAG;
	tag_t secondarytag = NULLTAG;
	creinput->getTag("primary_object", primarytag, isNull);
	creinput->getTag("secondary_object", secondarytag, isNull);

	//If primary object is Change Master and secondary is Change Notice derive item_id
	string primarytype = get_string_property(primarytag, "object_type");
	string secondarytype = get_string_property(secondarytag, "object_type");
	if(primarytype=="D4G_ChangeMasterRevision" &&
			(secondarytype=="D4G_ChangeNoticeRevision" || secondarytype=="D4G_CustomerReqRevision")){

		//Get main objects from revisions
		tag_t cmtag;
		//9-5-2017 : Bipin : Deprecated API -"AOM_get_value_tag", replaced with "AOM_ask_value_tag"
		//ITK_LOG(AOM_get_value_tag(primarytag, "items_tag", &cmtag));
		ITK_LOG(AOM_ask_value_tag(primarytag, "items_tag", &cmtag));
		tag_t noticetag;
		//ITK_LOG(AOM_get_value_tag(secondarytag, "items_tag", &noticetag));
		ITK_LOG(AOM_ask_value_tag(secondarytag, "items_tag", &noticetag));

		//Store old item_id for restoring when relation is deleted
		ITK_LOG(AOM_refresh(cmtag, true));

		//Derive CM id from CN id
		string noticeid=get_string_property(secondarytag, "item_id");
		string newid = "CM";
		newid.append(noticeid.substr(2,7));

		//Find first free suffix between 001 and 999
		std::ostringstream oss;
		tag_t revTag = 1;
		int number =0;
		while(revTag!=NULL && number<1000 && status==ITK_ok){
			number++;
			oss.str("");
			oss << std::setw(3) << std::setfill('0') << number;
			ITK_LOG(ITEM_find_item((newid+oss.str()).c_str(), &revTag));
		}
		//append suffix to derived CM id stub
		if(status==ITK_ok){
			if(get_string_property(cmtag, "d4g_storeditemid").empty()){
				ITK_LOG(AOM_set_value_string(cmtag, "d4g_storeditemid", get_string_property(cmtag, "item_id").c_str()));
			}
			newid.append(oss.str());
			ITK_LOG(AOM_set_value_string(cmtag, "item_id", newid.c_str()));
		}
		//9-5-2017 : Bipin : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
		//ITK_LOG(AOM_save(cmtag));
		ITK_LOG(AOM_save_with_extensions(cmtag));
		ITK_LOG(AOM_unlock(cmtag));
	}
	return status;
}
