/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Birger Nielsen

 Description:    contains the implementation for the Extension D4G_CMHasSolutionItemPlantCondition.
 	 - A CMHasSolutionItem Relation Creation Pre-Condition that makes sure that
 	 only Vendor Part Revisions and Danfoss Part Revisions with the correct plant
 	 value may be related to a Change Master via the CMHasSolutionItem Relation.
 	 Check is skipped if user has bypass or is specified in Preference
 	 D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/

#include <D4G_Core/D4G_CMHasSolutionItemPlantCondition.hxx>
#include "ug_va_copy.h"
#include <itkCallHeader.hxx>
#include <metaframework/CreateInput.hxx>
#include <iostream>
#include <ITKtools.hxx>
#include <D4G_ErrorCodes.hxx>
#include <constants.hxx>

using std::string;
using std::vector;

int D4G_CMHasSolutionItemPlantCondition( METHOD_message_t *msg, va_list args )
{
	// Skip Checks if user is privileged
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_relations")){return ITK_ok;}

	// Retrieve primary and secondary object tag
	Teamcenter::CreateInput *creInput=va_arg(args,Teamcenter::CreateInput*);
	tag_t secondary_tag=NULLTAG;
	tag_t primary_tag=NULLTAG;
	bool isNull=true;
	ITK_LR(creInput->getTag(PRIMARY_OBJECT,primary_tag,isNull));
	ITK_LR(creInput->getTag(SECONDARY_OBJECT,secondary_tag,isNull));


	// Only Change Master Revisions will be handled
	if(is_of_type(primary_tag,CHANGE_MASTER_REVISiON)){
		// get plant attribute from change Master Revision
		string correctPlant=get_string_property(primary_tag, PLANT_ATTRIBUTE);
		// Check for Vendor Part or Danfoss Part
		if(is_of_type(secondary_tag,DAN_PART_REVISON) || is_of_type(secondary_tag,VENDOR_PART_REVISION)){
			// get all plants from part
			vector<tag_t> plants=get_tags_property(secondary_tag,PART_PLANT_RELATION);
			bool hasPlant=false;
			// for every available plant, check plant value
			for (vector<tag_t>::iterator it= plants.begin(); it!=plants.end(); ++it) {
				tag_t plant_tag = *it;
				string localPlant=get_string_property(plant_tag,OBJECT_NAME);
				if(localPlant==correctPlant){
					hasPlant = true;
				}
			}
			if(!hasPlant){
				// display error, if the correct plant is not available on secondary object
				string partDisplay = get_string_property(secondary_tag, OBJECT_STRING);
				ITK_LR(EMH_store_error_s2(EMH_severity_error,WRONG_PLANT,partDisplay.c_str(),correctPlant.c_str()));
				return WRONG_PLANT;
			}
			// Check for Bom Item
		} //Already done in D4G_CMHasSolutionItemRelCondition (also wrong here)
			//else if(is_of_type(secondary_tag,BOM_ITEM_REVISON)) {
//			string localPlant=get_string_property(secondary_tag,OBJECT_NAME);
//			if(localPlant!=correctPlant){
//				// display error, if the correct plant is not available on secondary object
//				string bomItemDisplay = get_string_property(secondary_tag, OBJECT_STRING);
//				ITK_LR(EMH_store_error_s2(EMH_severity_error,WRONG_PLANT,bomItemDisplay.c_str(),correctPlant.c_str()));
//				return WRONG_PLANT_ERROR;
//			}
//		}
	}
	return ITK_ok;
}
