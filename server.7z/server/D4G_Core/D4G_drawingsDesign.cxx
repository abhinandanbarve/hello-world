/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Birger Nielsen

 Description:    contains the implementation for the Extension D4G_drawingsDesign
    - A getter method override retrieving JT Datasets. It uses the TC_DrawingOf
    Relation Backwards to get Primary objects. Afterwards it uses the
    IMAN_Rendering relation to get all JT Datasets.

 ===============================================================================*/

#include <D4G_Core/D4G_drawingsDesign.hxx>

#include <tccore/aom.h>
#include <tccore/grm.h>
#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <constants.hxx>
#include <algorithm>

int D4G_drawingsDesign( METHOD_message_t *msg, va_list args )
{
	// get the property tag
	tag_t prop_tag = va_arg(args, tag_t);
	(tag_t)prop_tag;
	// get the output array
	int *count = va_arg(args, int*);
	tag_t **values = va_arg(args, tag_t**);
	// retrieve the object tag
	tag_t object_tag = NULLTAG;
	METHOD_PROP_MESSAGE_OBJECT(msg, object_tag);
	std::vector<tag_t> directModels;
	// use the TC_DRAWING_OF backwards, to get the primary objects.
	tag_t drawingOf;
	ITK_LR(GRM_find_relation_type(TC_DRAWING_OF,&drawingOf));
	ITK_LR(AOM_refresh(object_tag, false));
	int number;
	tag_t *primaryObjects;
	ITK_LR(GRM_list_primary_objects_only(object_tag,drawingOf,&number,&primaryObjects));
	for(int i=0;i<number;++i){
			//lookup the IMAN Rendering relation to get JT datasets
			ITK_LR(AOM_refresh(primaryObjects[i], false));
			std::vector<tag_t> renderings=get_tags_property_vector(primaryObjects[i],IMAN_RENDERING);
			for(std::vector<tag_t>::iterator kt=renderings.begin();kt!=renderings.end();++kt){
				// save JT Datasets in a vector
				directModels.push_back(*kt);
			}
	}
	SAFE_SM_FREE(primaryObjects);
	// erase duplicate directModels
	std::sort(directModels.begin(), directModels.end());
	directModels.erase( unique( directModels.begin(), directModels.end() ), directModels.end() );
	// copy vector to output parameter
	*count=directModels.size();
	*values=(tag_t *)MEM_alloc (sizeof(tag_t)*(*count));
	int counter=0;
	for(std::vector<tag_t>::iterator it=directModels.begin();it!=directModels.end();++it){
		(*values)[counter]=*it;
		counter++;
	}
	return ITK_ok;
}
