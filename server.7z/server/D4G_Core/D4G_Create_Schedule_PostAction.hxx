/*==============================================================================
 Copyright $2017. Danfoss Power Solutions
 Siemens Product Lifecycle Management Software Inc. - All Rights Reserved
 ===============================================================================

 Module  : D4G_Create_Schedule_PostAction
 Author  : Robert Williams D

 Description:  This file contains the implementation for the Extension D4G_Create_Schedule_PostAction.
=========================================================================================================================

Date           Name                   Task Id     Description of Change
-------------------------------------------------------------------------------------------------------------------------
D4G_Create_Schedule_PostAction.hxx

08-August-2017 Robert Williams D	   - 		  Since the 'NewScheduleDialog' JAVA class is obsolete in TC11.2 onwards,
												  the post-action written (over Schedule create) in RAC will be void.
												  The same functionality is now moved from RAC to this Server extension.
 ========================================================================================================================*/
 
#ifndef D4G_CREATE_SCHEDULE_POSTACTION_HXX
#define D4G_CREATE_SCHEDULE_POSTACTION_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_Create_Schedule_PostAction(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_CREATE_SCHEDULE_POSTACTION_HXX
