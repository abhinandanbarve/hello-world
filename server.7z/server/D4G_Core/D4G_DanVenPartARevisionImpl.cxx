/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Business Object D4G_DanVenPartARevision
    - A getter method for the property d4g_CommercialPartsFolder that returns all
    objects that this objects item is related to via VMRepresents Relation.
    - A setter method for the property d4g_testRuns that checks if any of the
    pasted objects are D4G_TestContRevision's and if yes attaches this
    Vendor Part Revision to them via D4G_TestContRel Relation.

 ===============================================================================*/

#include <D4G_Core/D4G_DanVenPartARevision.hxx>
#include <D4G_Core/D4G_DanVenPartARevisionImpl.hxx>
#include <fclasses/tc_string.h>
// 9-05-2017 Bipin: Obsolete function <tc/tc.h> replaced with <tcinit/tcinit.h> and <tc/tc_startup.h>
//#include <tc/tc.h>
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>

#include <iostream>
#include <vector>

#include <ITKCallHeader.hxx>
#include <ITKtools.hxx>

using namespace Danfoss_Global_PLM; 

//----------------------------------------------------------------------------------
// D4G_DanVenPartARevisionImpl::D4G_DanVenPartARevisionImpl(D4G_DanVenPartARevision& busObj)
// Constructor for the class
//---------------------------------------------------------------------------------- 
D4G_DanVenPartARevisionImpl::D4G_DanVenPartARevisionImpl( D4G_DanVenPartARevision& busObj )
: D4G_DanVenPartARevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// D4G_DanVenPartARevisionImpl::~D4G_DanVenPartARevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
D4G_DanVenPartARevisionImpl::~D4G_DanVenPartARevisionImpl()
{
}

//----------------------------------------------------------------------------------
// D4G_DanVenPartARevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int D4G_DanVenPartARevisionImpl::initializeClass()
{
	int ifail = ITK_ok;
	static bool initialized = false;

	if( !initialized )
	{
		ifail = D4G_DanVenPartARevisionGenImpl::initializeClass( );
		if ( ifail == ITK_ok )
		{
			initialized = true;
		}
	}
	return ifail;
}


/**
 * Getter for a Tag Array Property
 * Returns all objects that this objects item is related to via VMRepresents Relation.
 * @param values - Parameter value
 * @param isNull - Returns true for an array element if the parameter value at that location is null
 * @return - Status. 0 if successful
 */
int  D4G_DanVenPartARevisionImpl::getD4g_CommercialPartsFolderBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const
{
	int status = ITK_ok;

	// Get this Vendor Part Revision tag and its items tag
	tag_t thisTag = this->getD4G_DanVenPartARevision()->getTag();
	tag_t itemTag;
	ITK_LOG(AOM_ask_value_tag(thisTag, "items_tag", &itemTag));

	// Get the tags for all objects that are primary in VMRepresents relations
	// where this Vendor Part Revision is secondary and save them as return values
	ITK_LOG(get_primary_for_relation(itemTag, "VMRepresents", "ANY", values));
	if (status==ITK_ok){
		isNull = std::vector<int>(values.size(), FALSE);
	}
	return status;
}

/**
 * Setter for a Tag Array Property
 * If pasted object is D4G_TestContRevision adds this D4G_DanVenPartARevision to it via D4G_TestContRel Relation
 * @param values - Values to be set for the parameter
 * @param isNull - If array element is true, set the parameter value at that location as null
 * @return - Status. 0 if successful
 */
int  D4G_DanVenPartARevisionImpl::setD4g_testRunsBase( const std::vector<tag_t> &values, const std::vector<int> *isNull )
{
	for(int i=0; i<isNull->size();i++){
		if(&isNull[i]==NULL){
			std::cout<<"True isNull abort\n";
			TC_write_syslog("Aborted setter because of isNull value set to TRUE");
			return ITK_ok;
		}
	}

	// Get this Vendor Part Revision tag
	tag_t thisTag = this->getD4G_DanVenPartARevision()->getTag();

	// If any values are to be set find D4G_TestContRel relation tag
	if(values.size()>0){
		tag_t relationTypeTag;
		ITK_LR(GRM_find_relation_type("D4G_TestContRel",&relationTypeTag));

		// For every object to be attached via D4G_testRuns check if it is a D4G_TestContRevision
		tag_t relation;
		for (int i=0;i<values.size();i++){
			if(is_of_type(values[i],"D4G_TestContRevision")){
				// Attach this Danfoss Part Revision to the D4G_TestContRevision via D4G_TestContRel relation
				ITK_LR(GRM_create_relation(values[i], thisTag, relationTypeTag, NULLTAG, &relation));
				ITK_LR(GRM_save_relation(relation));
			}
		}
	}
	return ITK_ok;
}

