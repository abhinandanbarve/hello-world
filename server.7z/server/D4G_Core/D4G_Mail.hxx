/*==============================================================================
 Copyright (c) 2017 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Author  : Chandrashekher Gonnabathula

 Description:  Header File for the D4G_mail.cxx
=========================================================================================================================

Date              Name             Task Id             Description
-------------------------------------------------------------------------------------------------------------------------

30-Aug-2017    Chandrashekher       3273           Intitial Creation

 ===============================================================================*/


#ifndef D4G_MAIL_HXX_
#define D4G_MAIL_HXX_

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <tccore/aom.h>




class D4G_Mail {

private:
	std::ifstream stdMailFormatFile;
	std::ofstream outputMailFile;
	std::vector<std::string> vInputFileLines;
	std::string sSender;
	std::string sMailServer;
	std::string sMailSubject;
	std::vector<std::string> vMailReceipents;
	std::string sOutputFilePath;

public:
	D4G_Mail();
	virtual ~D4G_Mail();

	std::ifstream& getFile();
	std::ofstream& getMailBody();
	std::string generateCommand();
	std::string getSender();
	std::string getMailServer();
	void setSender(std::string senderName);
	void setMailSubject(std::string sMailSubject);
	std::string getMailSubject();
	void setMailReceipents(std::vector<std::string>);
	std::string getMailReceipents();
	std::string getDefaultReplacementStr(std::string  sPlaceHolderCont);


	int sendMail();
	void replaceBodyContent(std::string sTaskName, std::string sProcessName, std::string sDueDate, std::string sEmailFrom, std::string sComments, std::string sInstructions, std::vector<tag_t> vTargets, std::vector<tag_t> vReferences);
	//void replaceBodyContent(std::string sTaskName, std::string sProcessName, std::string sDueDate, std::string sEmailFrom, std::string sComments, std::string sInstructions, std::vector<std::string> vTargets, std::vector<std::string> vReferences);




};

#endif /* D4GMAIL_HXX_ */
