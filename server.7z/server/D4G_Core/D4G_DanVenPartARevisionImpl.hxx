/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Business Object D4G_DanVenPartARevision
    - A getter method for the property d4g_CommercialPartsFolder that returns all
    objects that this objects item is related to via VMRepresents Relation.
    - A setter method for the property d4g_testRuns that checks if any of the
    pasted objects are D4G_TestContRevision's and if yes attaches this
    Vendor Part Revision to them via D4G_TestContRel Relation.

 ===============================================================================*/

#ifndef DANFOSS_GLOBAL_PLM__D4G_DANVENPARTAREVISIONIMPL_HXX
#define DANFOSS_GLOBAL_PLM__D4G_DANVENPARTAREVISIONIMPL_HXX

#include <D4G_Core/D4G_DanVenPartARevisionGenImpl.hxx>

#include <D4G_Core/libd4g_core_exports.h>

#define D4G_DanVenPartARevisionPomClassName "D4G_DanVenPartARevision"

namespace Danfoss_Global_PLM
{
   class D4G_DanVenPartARevisionImpl; 
   class D4G_DanVenPartARevisionDelegate;
}
 
class  D4G_CORE_API Danfoss_Global_PLM::D4G_DanVenPartARevisionImpl
           : public Danfoss_Global_PLM::D4G_DanVenPartARevisionGenImpl 
{
public:    

    // find method
    // static status_t find();  


   /**
    * Getter for a Tag Array Property
    * @param values - Parameter value
    * @param isNull - Returns true for an array element if the parameter value at that location is null
    * @return - Status. 0 if successful
    */
    int  getD4g_CommercialPartsFolderBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const;

   /**
    * Setter for a Tag Array Property
    * @param values - Values to be set for the parameter
    * @param isNull - If array element is true, set the parameter value at that location as null
    * @return - Status. 0 if successful
    */
    int  setD4g_testRunsBase( const std::vector<tag_t> &values, const std::vector<int> *isNull );


protected:
    // Constructor for a D4G_DanVenPartARevision
    explicit D4G_DanVenPartARevisionImpl( D4G_DanVenPartARevision& busObj );

    // Destructor
    ~D4G_DanVenPartARevisionImpl();


private:
    // Default Constructor for the class
    D4G_DanVenPartARevisionImpl();
    
    // Private default constructor. We do not want this class instantiated without the business object passed in.
    D4G_DanVenPartARevisionImpl( const D4G_DanVenPartARevisionImpl& );

    // Copy constructor
    D4G_DanVenPartARevisionImpl& operator=( const D4G_DanVenPartARevisionImpl& );

    // Method to initialize this Class
    static int initializeClass();

    //static data
    friend class Danfoss_Global_PLM::D4G_DanVenPartARevisionDelegate;

};

#include <D4G_Core/libd4g_core_undef.h>
#endif // DANFOSS_GLOBAL_PLM__D4G_DANVENPARTAREVISIONIMPL_HXX
