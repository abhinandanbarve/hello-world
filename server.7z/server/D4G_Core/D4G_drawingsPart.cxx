/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Birger Nielsen

 Description:    contains the implementation for the Extension D4G_drawingsPart
    - A getter method override which uses the TC_IS_REPRESENTED_BY
    relation to get Designs. From the Designs, this function uses the TC_DRAWING_OF
    relation backwards, to get DrawingRevisions.

 ===============================================================================*/

#include <D4G_Core/D4G_drawingsPart.hxx>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <constants.hxx>
#include <algorithm>

int D4G_drawingsPart( METHOD_message_t *msg, va_list args )
{
	// get the property tag
	tag_t prop_tag = va_arg(args, tag_t);
	// get the output array
	int *count = va_arg(args, int*);
	tag_t **values = va_arg(args, tag_t**);
	// retrieve the object tag
	tag_t object_tag = NULLTAG;
	METHOD_PROP_MESSAGE_OBJECT(msg, object_tag);
	std::vector<tag_t> drawingRevisions;

	// get all TC_is_Represented_By related designs
	ITK_LR(AOM_refresh(object_tag, false));
	std::vector<tag_t> designs=get_tags_property(object_tag, TC_IS_REPRESENTED_BY);
	// use the designs to go backwards on the TC_DRAWING_OF Relation, i. e. find primary_objects.
	tag_t drawingOf;
	ITK_LR(GRM_find_relation_type(TC_DRAWING_OF,&drawingOf));
	for(std::vector<tag_t>::iterator it=designs.begin();it!=designs.end();++it){
		ITK_LR(AOM_refresh(*it, false));
		int count;
		tag_t *primaryObjects;
		ITK_LR(GRM_list_primary_objects_only(*it,drawingOf,&count,&primaryObjects));
		// save primary objects in a vector
		for(int i=0;i<count;++i){
			drawingRevisions.push_back(primaryObjects[i]);
		}
		SAFE_SM_FREE(primaryObjects);
	}
	// erase duplicate drawingRevisions
	std::sort(drawingRevisions.begin(), drawingRevisions.end());
	drawingRevisions.erase( unique( drawingRevisions.begin(), drawingRevisions.end() ), drawingRevisions.end() );
	// copy the drawingRevisions vector into the output array
	*count=drawingRevisions.size();
	*values=(tag_t *)MEM_alloc (sizeof(tag_t)*(*count));
	int counter=0;
	for(std::vector<tag_t>::iterator it=drawingRevisions.begin();it!=drawingRevisions.end();++it){
		(*values)[counter]=*it;
		counter++;
	}
	return ITK_ok;
}
