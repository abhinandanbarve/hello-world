/*==============================================================================
 Copyright $2017. Danfoss Power Solutions
 Siemens Product Lifecycle Management Software Inc. - All Rights Reserved
 ===============================================================================

 Module  : D4G_Create_Schedule_PostAction
 Author  : Robert Williams D

 Description:  This file contains the implementation for the Extension D4G_Create_Schedule_PostAction.
=========================================================================================================================

Date           Name                   Task Id     Description of Change
-------------------------------------------------------------------------------------------------------------------------
D4G_Create_Schedule_PostAction.cxx

08-August-2017 Robert Williams D	   - 		  Since the 'NewScheduleDialog' JAVA class is obsolete in TC11.2 onwards,
												  the post-action written (over Schedule create) in RAC will be void.
												  The same functionality is now moved from RAC to this Server extension.
 ========================================================================================================================*/

#include <D4G_Core/D4G_Create_Schedule_PostAction.hxx>

#include <ug_va_copy.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>

#include <constants.hxx>
#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>

#include <string>

using namespace std;

using std::string;

void copyProperty	 (tag_t tSchedule, tag_t tScheduleTemplate);
void copyTaskProperty(tag_t tSchSumTask, tag_t tSchTempSumTask);

int D4G_Create_Schedule_PostAction( METHOD_message_t * msg, va_list args )
{
	//TC_write_syslog("\n\n\n----->Start : D4G_Create_Schedule_PostAction\n\n");

	int 		 status 			= ITK_ok;
	tag_t        tPrimaryObjTag		= NULLTAG;
	tag_t        tSecObjectTag		= NULLTAG;
	tag_t        tschClassID		= NULLTAG;
	tag_t        tPrimaryClassID	= NULLTAG;
	tag_t        tSecClassID		= NULLTAG;
	logical		 lIsDescendent		= false;
	va_list 	 largs;

	va_copy( largs, args );

	//Get the Primary and Secondary objects
	tPrimaryObjTag 	= va_arg(largs, tag_t ); //Schedule
	tSecObjectTag   = va_arg(largs, tag_t ); //Schedule Template

	if(tPrimaryObjTag != NULLTAG)
	{
		//Get the 'Schedule' class ID
		ITK_LOG(POM_class_id_of_class(SCHEDULE_CLASS,&tschClassID));

		//Get the Primary object class ID
		ITK_LOG(POM_class_of_instance(tPrimaryObjTag,&tPrimaryClassID));

		//Check is Primary object a descendant of 'Schedule'
		ITK_LOG(POM_is_descendant(tschClassID, tPrimaryClassID, &lIsDescendent));

		if(lIsDescendent)
		{
			//Log the Primary schedule object
			//string sObjectName = get_string_property(tPrimaryObjTag, OBJECT_STRING);
			//TC_write_syslog("Primary Schedule object name: %s\n", sObjectName.c_str());

			// Check if the schedule is a template or not. Proceed if it is not a template.
			if(get_bool_property(tPrimaryObjTag, IS_TEMPLATE_PROP))
			{
				//TC_write_syslog("Primary schedule object is a template.\n");
				return status;

			}else
			{
				if(tSecObjectTag != NULLTAG)
				{
					lIsDescendent = false;
					//sObjectName.clear();

					//Get the Secondary object class ID
					ITK_LOG(POM_class_of_instance(tSecObjectTag,&tSecClassID));

					//Check is Secondary object a descendant of 'Schedule'
					ITK_LOG(POM_is_descendant(tschClassID, tSecClassID, &lIsDescendent));

					if(lIsDescendent)
					{
						//Log the Secondary schedule object
						//sObjectName = get_string_property(tSecObjectTag, OBJECT_STRING);
						//TC_write_syslog("Secondary Schedule object name: %s\n", sObjectName.c_str());

						//Call copyProperty(schedule, scheduleTemplate) method
						copyProperty(tPrimaryObjTag, tSecObjectTag );
					}

				}//else TC_write_syslog("Secondary object is Null. Schedule is created without a template.\n");
			}
		}

	}//else TC_write_syslog("Primary object is Null.\n");

	va_end( largs );

	//TC_write_syslog("\n\n\n----->End : D4G_Create_Schedule_PostAction\n\n");
	return status;
}

void copyProperty(tag_t tSchedule, tag_t tScheduleTemplate)
{
	//TC_write_syslog("\n----->Start : copyProperty\n");
	int 		 status 			= ITK_ok;
	int 		 iPropCnt			= 0;
	char*		 cpPropType			= NULL;
	//char*		 cpPropType1		= NULL;
	char**		 cpPropList;
	tag_t 		 tSchValueTag		= NULLTAG;
	tag_t 		 tSchTempValueTag	= NULLTAG;
	string 		 sSchPropValue;
	string 		 sSchTempPropValue;
	//string 		 sObjName;
	logical		 lIsValid			= false;
	PROP_type_t  propType;
	//PROP_type_t  propType1;

	//Get Property list
	ITK_LOG(AOM_ask_prop_names(tScheduleTemplate, &iPropCnt, &cpPropList));

//	TC_write_syslog("\nObject Type - %s;   Name - %s.\n",
//			get_string_property(tScheduleTemplate, "object_type"),
//			get_string_property(tScheduleTemplate, "object_string").c_str());

	for(int iCnt = 0; iCnt < iPropCnt; iCnt++)
	{
		if(tc_strstr(cpPropList[iCnt],"d4g") != NULL || tc_strstr(cpPropList[iCnt],"D4G") != NULL)
		{
//			ITK_LOG(AOM_ask_property_type(tScheduleTemplate, cpPropList[iCnt], &propType1, &cpPropType1));
//			TC_write_syslog("Property - %s   Type -  %s.\n", cpPropList[iCnt], cpPropType1);

			//Proceed if the property is d4g_PPAPReviewer, d4g_PPAPDecisionMaker and d4g_Plant
			if(tc_strcmp(cpPropList[iCnt],D4G_PPAP_REVIEWER_PROP) == 0 ||
				tc_strcmp(cpPropList[iCnt],D4G_PPAP_DECISIONMAKER_PROP) == 0 ||
				tc_strcmp(cpPropList[iCnt],D4G_PLANT_PROP) == 0 )
			{
				//Check the type of property
				ITK_LOG(AOM_ask_property_type(tScheduleTemplate, cpPropList[iCnt], &propType, &cpPropType));

				//d4g_PPAPReviewer and d4g_PPAPDecisionMaker are of PROP_reference type.
				if(propType == PROP_reference)
				{
					ITK_LOG(AOM_ask_value_tag(tSchedule, cpPropList[iCnt], &tSchValueTag));

					if(tSchValueTag == NULLTAG) lIsValid = true;
					//else TC_write_syslog("Property - %s , is not NULL.\n", cpPropList[iCnt]);

				}else //d4g_Plant is of PROP_attribute type
				{
					sSchPropValue = get_string_property( tSchedule, cpPropList[iCnt]);

					if(sSchPropValue.empty()) lIsValid = true;
					//else TC_write_syslog("Property - %s , is not NULL.\n", cpPropList[iCnt]);
				}

				lIsValid = lIsValid && !(tc_strcmp(cpPropList[iCnt],D4G_PPAP_REVIEWER_PROP) == 0);
				lIsValid = lIsValid && !(tc_strcmp(cpPropList[iCnt],D4G_PPAP_DECISIONMAKER_PROP) == 0);
				lIsValid = lIsValid && !(tc_strcmp(cpPropList[iCnt],D4G_PLANT_PROP) == 0);

				//TC_write_syslog("lIsValid - %s.\n", lIsValid ? "true" : "false");

				if(lIsValid)
				{
					// Lock the object
					ITK_LOG(AOM_refresh(tSchedule, TRUE));
					//sObjName = get_string_property(tSchedule, OBJECT_STRING);

					if(propType == PROP_reference)
					{
						//TC_write_syslog("Setting the Schedule Property - %s in %s.\n", cpPropList[iCnt], sObjName.c_str());
						ITK_LOG(AOM_ask_value_tag(tScheduleTemplate, cpPropList[iCnt], &tSchTempValueTag));
						ITK_LOG(AOM_set_value_tag(tSchedule, cpPropList[iCnt], tSchTempValueTag));

					}else
					{
						//TC_write_syslog("Setting the Schedule Property - %s in %s.\n", cpPropList[iCnt], sObjName.c_str());
						sSchTempPropValue = get_string_property( tScheduleTemplate, cpPropList[iCnt]);
						ITK_LOG(AOM_set_value_string(tSchedule, cpPropList[iCnt], (char*) sSchTempPropValue.c_str()));
					}

					// Save the object
					ITK_LOG(AOM_save_with_extensions(tSchedule));

					// Unlock the object
					ITK_LOG(AOM_refresh(tSchedule, FALSE));
				}
			}
		}
		//Copying the 'is_public' property value from Schedule Template to Schedule.

		// Lock the object
		ITK_LOG(AOM_refresh(tSchedule, TRUE));

		ITK_LOG(AOM_set_value_logical(tSchedule, IS_PUBLIC_PROP, get_bool_property(tScheduleTemplate, IS_PUBLIC_PROP)));

		// Save the object
		ITK_LOG(AOM_save_with_extensions(tSchedule));

		// Unlock the object
		ITK_LOG(AOM_refresh(tSchedule, FALSE));

		//sObjName.clear();
		sSchPropValue.clear();
		sSchTempPropValue.clear();
	}

	//Get the Summary Tasks
	tag_t 	tSchSumTask  		= NULLTAG;
	tag_t 	tSchTempSumTask  	= NULLTAG;

	ITK_LOG(AOM_ask_value_tag(tSchedule, D4G_SUMMARY_TASK_PROP, &tSchSumTask)); //Schedule Summary task
	ITK_LOG(AOM_ask_value_tag(tScheduleTemplate, D4G_SUMMARY_TASK_PROP, &tSchTempSumTask)); //Schedule Template Summary task

	if(tSchSumTask != NULLTAG && tSchTempSumTask != NULLTAG )
	{
		//Copy Schedule Task Properties
		copyTaskProperty(tSchSumTask, tSchTempSumTask);
	}

	//Mem free
	SAFE_SM_FREE(cpPropList);
	SAFE_SM_FREE(cpPropType);
	//SAFE_SM_FREE(cpPropType1);

	//TC_write_syslog("\n----->End : copyProperty\n");
}

void copyTaskProperty(tag_t tSchSumTask, tag_t tSchTempSumTask)
{
	//TC_write_syslog("\n----->Start : copyTaskProperty\n");
	int 		 status 			= ITK_ok;
	int 		 iTaskListCnt		= 0;
	int 		 iPropCnt			= 0;
	char*		 cpPropType;
	//char*		 cpPropType1;
	char**		 cpPropList;
	//string 		 sObjName;
	tag_t        tSchValueTag		= NULLTAG;
	tag_t        tSchTempValueTag	= NULLTAG;
	tag_t*		 tSchTaskList;
	tag_t*		 tSchTempTaskList;
	logical		 lIsValid			= false;
	PROP_type_e  propType;
	//PROP_type_e  propType1;

	//Get Child tasks
	ITK_LOG(AOM_ask_value_tags(tSchSumTask, D4G_CHILD_TASK_TAGLIST_PROP, &iTaskListCnt, &tSchTaskList));
	ITK_LOG(AOM_ask_value_tags(tSchTempSumTask, D4G_CHILD_TASK_TAGLIST_PROP, &iTaskListCnt, &tSchTempTaskList));

	for(int iCnt = 0; iCnt < iTaskListCnt; iCnt++)
		copyTaskProperty(tSchTaskList[iCnt], tSchTempTaskList[iCnt]);

	//Get Property list
	ITK_LOG(AOM_ask_prop_names(tSchTempSumTask, &iPropCnt, &cpPropList));

//	TC_write_syslog("\nObject Type - %s;   Name - %s.\n",
//				get_string_property(tSchTempSumTask, "object_type"),
//				get_string_property(tSchTempSumTask, "object_string").c_str());

	for(int iCnt = 0; iCnt < iPropCnt; iCnt++)
	{
		if(tc_strstr(cpPropList[iCnt],"d4g") != NULL || tc_strstr(cpPropList[iCnt],"D4G") != NULL)
		{
//			ITK_LOG(AOM_ask_property_type(tSchTempSumTask, cpPropList[iCnt], &propType1, &cpPropType1));
//			TC_write_syslog("Property - %s   Type -  %s.\n", cpPropList[iCnt], cpPropType1);

			//Proceed if the property is d4g_PPAPReviewer, d4g_PPAPDecisionMaker and d4g_Plant
			if(tc_strcmp(cpPropList[iCnt],D4G_PPAP_REVIEWER_PROP) == 0 ||
				tc_strcmp(cpPropList[iCnt],D4G_PPAP_DECISIONMAKER_PROP) == 0 ||
				tc_strcmp(cpPropList[iCnt],D4G_DISABLED_PROP) == 0 ||
				tc_strcmp(cpPropList[iCnt],D4G_PREPROD_RELEVANT_PROP) == 0 )
			{
				//Check the type of property
				ITK_LOG(AOM_ask_property_type(tSchTempSumTask, cpPropList[iCnt], &propType, &cpPropType));

				//d4g_PPAPReviewer and d4g_PPAPDecisionMaker are of PROP_reference type.
				if(propType == PROP_reference)
				{
					ITK_LOG(AOM_ask_value_tag(tSchSumTask, cpPropList[iCnt], &tSchValueTag));

					if(tSchValueTag == NULLTAG) lIsValid = true;
					//else TC_write_syslog("Property - %s , is not NULL.\n", cpPropList[iCnt]);

				}else lIsValid = false; // Since boolean type d4g_Disabled and d4g_PreProdRelevant will not be NULL

				lIsValid = lIsValid || (tc_strcmp(cpPropList[iCnt],D4G_DISABLED_PROP) == 0);
				lIsValid = lIsValid || (tc_strcmp(cpPropList[iCnt],D4G_PREPROD_RELEVANT_PROP) == 0);
				lIsValid = lIsValid && !(tc_strcmp(cpPropList[iCnt],D4G_PPAP_REVIEWER_PROP) == 0);
				lIsValid = lIsValid && !(tc_strcmp(cpPropList[iCnt],D4G_PPAP_DECISIONMAKER_PROP) == 0);

				//TC_write_syslog("copyTaskProperty lIsValid - %s.\n", lIsValid ? "true" : "false");

				if(lIsValid)
				{
					// Lock the object
					ITK_LOG(AOM_refresh(tSchSumTask, TRUE));
					//sObjName = get_string_property(tSchSumTask, OBJECT_STRING);

					if(propType == PROP_reference)
					{
						//TC_write_syslog("Setting the Schedule Property - %s in %s.\n", cpPropList[iCnt], sObjName.c_str());
						ITK_LOG(AOM_ask_value_tag(tSchTempSumTask, cpPropList[iCnt], &tSchTempValueTag));
						ITK_LOG(AOM_set_value_tag(tSchSumTask, cpPropList[iCnt], tSchTempValueTag));

					}else
					{
						//TC_write_syslog("Setting the Schedule Property - %s in %s.\n", cpPropList[iCnt], sObjName.c_str());

						//TC_write_syslog("Setting the value from %s to %s.\n",
							//	get_bool_property(tSchSumTask, cpPropList[iCnt]) ? "true" : "false",
							//	get_bool_property(tSchTempSumTask, cpPropList[iCnt]) ? "true" : "false");

						ITK_LOG(AOM_set_value_logical(tSchSumTask, cpPropList[iCnt], get_bool_property(tSchTempSumTask, cpPropList[iCnt])));
					}

					// Save the object
					ITK_LOG(AOM_save_with_extensions(tSchSumTask));

					// Unlock the object
					ITK_LOG(AOM_refresh(tSchSumTask, FALSE));
				}
			}
		}

		//sObjName.clear();
	}

	//Mem free
	SAFE_SM_FREE(tSchTaskList);
	SAFE_SM_FREE(tSchTempTaskList);
	SAFE_SM_FREE(cpPropList);
	SAFE_SM_FREE(cpPropType);
	//SAFE_SM_FREE(cpPropType1);

	//TC_write_syslog("\n----->End : copyTaskProperty\n");
}
