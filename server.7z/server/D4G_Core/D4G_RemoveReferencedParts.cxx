/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Ravikiran Choudhari

 Description:    This extension is used to update the list of Parts to which Process document is attached.
 	 	 	 	 Issue-2837
 	 	 	 	 This extension is added on "Documented By" relationship object on  IMAN_delete operation which update d4g_PartsString property on
 	 	 	 	 process document once it is deleted from Danfoss Part.


 ===============================================================================*/

#include <D4G_Core/D4G_RemoveReferencedParts.hxx>
#include <ug_va_copy.h>
#include <ITKCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <mld/logging/Logger.hxx>
using namespace std;

static std::string loggerName = "Danfoss.D4G_Core.D4G_RemoveReferencedParts";
static Teamcenter::Logging::Logger *logger = Teamcenter::Logging::Logger::getLogger(loggerName);

int D4G_RemoveReferencedParts( METHOD_message_t *msg, va_list args )
{
	logger->debug("[DANFOSS][D4G_Core][D4G_RemoveReferencedParts][D4G_RemoveReferencedParts] - Entering the method");
	tag_t primary_tag = NULLTAG;
	tag_t secondary_tag = NULLTAG;
	tag_t relation = NULLTAG;
	char* pszItemID;
	char* pszPartsString;
	va_list     copyArgs;

	// Get the parameters from the ITEM_save message
	va_copy(copyArgs, args);
	relation = va_arg(copyArgs, tag_t);
	va_end(copyArgs);
	ITK_LR(AOM_ask_value_tag(relation, "primary_object", &primary_tag));
	ITK_LR(AOM_ask_value_tag(relation, "secondary_object", &secondary_tag));

	if(is_of_type(primary_tag,"D4G_DanPartRevision") && is_of_type(secondary_tag,"D4G_ProcessDocRevision"))
		{
			logger->debug("[DANFOSS][D4G_Core][D4G_RemoveReferencedParts][D4G_RemoveReferencedParts] - Entering the method");


			ITK_LR(AOM_ask_value_string(primary_tag, "item_id", &pszItemID));
			ITK_LR(AOM_ask_value_string(secondary_tag, "d4g_PartsString", &pszPartsString));

			std::string pszPartCompare = pszPartsString;
			std::string pszCheckID = "";
			std::string pszFinalParts = "";
			if(pszPartsString!=NULL && strlen(pszPartsString) != 0)
			{

				pszCheckID = pszItemID;
				string::size_type idsize = pszCheckID.length();
				// removing part number and commas
				  for (string::size_type pos = pszPartCompare.find(pszCheckID);
				      pos != string::npos;
				      pos = pszPartCompare.find(pszCheckID))
				  {
					  if(pos>idsize)
					  {
						  pszPartCompare.erase(pos-1, idsize+1);
					  }else if (idsize>pos && pszPartCompare.length()>idsize)
					  {
						  pszPartCompare.erase(pos, idsize+1);
					  }else
					  {
						  pszPartCompare.erase(pos, idsize);
					  }
					  pszFinalParts=pszPartCompare;
				  }
			}

			char* pszPart = (char*) MEM_alloc(CHARSIZE*sizeof(char));
			strcpy(pszPart, pszFinalParts.c_str());
			// Take bypass and with bypass empty the property d4g_PartsString on secondary object
			logical current;
			AM__ask_application_bypass(&current);
			set_bypass(true);
			ITK_LR(AOM_lock(secondary_tag));
			ITK_LR(AOM_set_value_string(secondary_tag, "d4g_PartsString", pszPart));
			ITK_LR(AOM_save_without_extensions(secondary_tag));
			ITK_LR(AOM_unlock(secondary_tag));
			set_bypass(current);
			if(pszPart != NULL)
			{
				if(strlen(pszPart) != 0)
				{
					SAFE_SM_FREE(pszPart);
				}
			}
		}

	logger->debug("[DANFOSS][D4G_Core][D4G_RemoveReferencedParts][D4G_RemoveReferencedParts] - Exiting the method");
	return 0;
}
