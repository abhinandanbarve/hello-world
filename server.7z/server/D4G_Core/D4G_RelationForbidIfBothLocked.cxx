/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_RelationForbidIfBothLocked
 	 - A relation creation PreCondition that checks if the both primary and
 	 secondary object have no status.
 	 Check is skipped if user has bypass or is specified in Preference
 	 D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/

#include <D4G_Core/D4G_RelationForbidIfBothLocked.hxx>

#include <tc/emh.h>
#include <metaframework/CreateInput.hxx>
#include <tccore/grm.h>
#include <tccore/aom.h>
#include <sa/site.h>

#include <vector>

#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <D4G_ErrorCodes.hxx>

using namespace std;

int D4G_RelationForbidIfBothLocked( METHOD_message_t *msg, va_list args )
{
	// Skip Checks if user is privileged
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_relations")){return ITK_ok;}

	// Retrieve primary and secondary object tags and their status lists
	Teamcenter::CreateInput *creInput=va_arg(args,Teamcenter::CreateInput*);

	bool isNull=true;
	tag_t primarytag=NULLTAG;
	ITK_LR(creInput->getTag("primary_object",primarytag,isNull));
	ITK_LR(AOM_refresh(primarytag, false));
	vector<tag_t> primarystati = get_tags_property_vector(primarytag, "release_status_list");

	tag_t secondarytag=NULLTAG;
	ITK_LR(creInput->getTag("secondary_object",secondarytag,isNull));
	ITK_LR(AOM_refresh(secondarytag, false));
	vector<tag_t> secondarystati = get_tags_property_vector(secondarytag, "release_status_list");

	// If status is set on both primary and secondary object then error out.
	if(primarystati.size()>0 && secondarystati.size()>0){
		ITK_LR(EMH_store_error_s2(EMH_severity_error,RELATIONCREATE_LOCKED_BY_STATUS,
				get_string_property(primarytag, "object_string").c_str(),
				get_string_property(secondarytag, "object_string").c_str()));
		return RELATIONCREATE_LOCKED_BY_STATUS;
	}

	return ITK_ok;
}
