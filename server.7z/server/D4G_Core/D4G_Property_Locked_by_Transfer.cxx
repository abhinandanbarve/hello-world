/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Jan J�rn Sommer

 Description:    contains the implementation for the Extension D4G_Property_Locked_by_Transfer
 	 - Property setter PreCondition that checks if none of the revisions of the
 	 item have been transfered to SAP. If any have property setting is denied.
 	 Check is skipped if user has bypass.

 ===============================================================================*/
#include <D4G_Core/D4G_Property_Locked_by_Transfer.hxx>

#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <string>

#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <D4G_ErrorCodes.hxx>

using std::string;

int D4G_Property_Locked_by_Transfer( METHOD_message_t *msg, va_list args )
{
	// Skips checks if User has privilege
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}

	// Retrieve object tag and property name
	tag_t objtag= msg->object_tag;
	string propname = msg->prop_name;

	// get all Revisions
	std::vector<tag_t> revisions =get_tags_property_vector(objtag, "revision_list");
	for(int i=0; i<revisions.size(); i++){
		/*get d4g_transferred*/
		bool transferred = get_bool_property(revisions[i],"d4g_transferred");
		/*if Revision was transferred store error and return -1*/
		if(transferred){
			ITK_LR(EMH_store_error_s2(EMH_severity_error,PROPERTY_LOCKED_BY_TRANSFER,
					get_property_display_name(objtag, propname).c_str(),
					get_string_property(objtag, "object_string").c_str()));
			return PROPERTY_LOCKED_BY_TRANSFER;
		}
	}
	return ITK_ok;
}
