/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Jan J�rn Sommer

 Description:    contains the implementation for the Extension D4G_PDP_ItemCreatePost_PostAction
 	 - A D4G_PDPItem creation PostAction that checks if property
 	 d4g_AutoCreateProject is True and if so creates a project for the PDP Item
 	 and adds the PDP Item to the newly created project.

 ===============================================================================*/

#ifndef D4G_PDP_ITEMCREATEPOST_POSTACTION_HXX
#define D4G_PDP_ITEMCREATEPOST_POSTACTION_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_PDP_ItemCreatePost_PostAction(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_PDP_ITEMCREATEPOST_POSTACTION_HXX
