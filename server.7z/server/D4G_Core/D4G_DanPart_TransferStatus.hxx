/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Jan-J�rn Sommer

 Description:    contains the implementation for the Extension D4G_DanPart_TransferStatus
    - A setter method override, that only allows the setting of a new value if
    no Revision has been transfered to SAP. Users with bypass or those specified in
    the preference D4G_users_allowed_to_modify_locked_properties can override.

 ===============================================================================*/
#ifndef D4G_DANPART_TRANSFERSTATUS_HXX
#define D4G_DANPART_TRANSFERSTATUS_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_DanPart_TransferStatus(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_DANPART_TRANSFERSTATUS_HXX
