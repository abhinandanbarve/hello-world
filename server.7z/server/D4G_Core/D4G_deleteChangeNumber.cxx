/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_deleteChangeNumber
 	 - A relation deletion PreAction that clears the property d4g_ChangeID on
 	 any ItemRevision that is no longer to be connected to a
 	 D4G_ChangeNoticeRevision by CMHasSolutionItems relation.
 	 Takes bypass to clear property regardless of access rights.

 ===============================================================================*/

#include <D4G_Core/D4G_deleteChangeNumber.hxx>
#include <ug_va_copy.h>
#include <ITKCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <mld/logging/Logger.hxx>

static std::string loggerName = "Danfoss.D4G_Core.D4G_deleteChangeNumber";
static Teamcenter::Logging::Logger *logger = Teamcenter::Logging::Logger::getLogger(loggerName);

int D4G_deleteChangeNumber( METHOD_message_t *msg, va_list args )
{
	logger->debug("[DANFOSS][D4G_Core][D4G_deleteChangeNumber][D4G_deleteChangeNumber] - Entering the method");

	// Get primary object tag and check if it a Change Notice Revision
	tag_t relation = va_arg(args, tag_t);
	tag_t primary;
	ITK_LR(AOM_ask_value_tag(relation, "primary_object", &primary));

	if(is_of_type(primary,"D4G_ChangeNoticeRevision"))
	{
		logger->debug("[DANFOSS][D4G_Core][D4G_deleteChangeNumber][D4G_deleteChangeNumber] - Primary is CN");

		// Get secondary object tag and check if it is an Item Revision
		tag_t secondary;
		ITK_LR(AOM_ask_value_tag(relation, "secondary_object", &secondary));

		if(is_of_type(secondary,"ItemRevision"))
		{
			logger->debug("[DANFOSS][D4G_Core][D4G_deleteChangeNumber][D4G_deleteChangeNumber] - Secondary is is ItemRevision");

			// Take bypass and with bypass empty the property d4g_ChangeID on secondary object
			logical current;
			AM__ask_application_bypass(&current);
			set_bypass(true);
			ITK_LR(AOM_lock(secondary));
			ITK_LR(AOM_assign_string(secondary, "d4g_ChangeID",""));
			//9-5-2017 : Bipin : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
			//ITK_LR(AOM_save(secondary));
			ITK_LR(AOM_save_with_extensions(secondary));
			ITK_LR(AOM_unlock(secondary));
			set_bypass(current);
		}
	}
	logger->debug("[DANFOSS][D4G_Core][D4G_deleteChangeNumber][D4G_deleteChangeNumber] - Exiting the method");
	return 0;
}
