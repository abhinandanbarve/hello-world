//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/***************************************************************************************
*Function Name   : D4G_Populate_Workflow_RefItems
*Description     : Adds the reference of the DanPart Revision from the workflow task on adding the schedule in
       	   	   	   the Danpart revision  schedules folder
*Extension on    : GRM_Create operation of the "CMHasWorkBreakDown" relation
*Extension Point : Post_action
*Extension File	 : d4g_extensions.xml
*Dll name	     : libD4G_Extensions
*Library Name	 : D4G_Extensions
*Issue number 	 : 3851 (Issue 2)
*Author			 : Bhargav
***********************************************************************************/
 
#ifndef D4G_POPULATE_WORKFLOW_REFITEMS_HXX
#define D4G_POPULATE_WORKFLOW_REFITEMS_HXX
#include <tccore/method.h>

#include <epm/epm.h>
#include <tc/preferences.h>
#include <lov/lov.h>
#include <base_utils/Mem.h>
#include <sa/sa.h>
#include <sa/user.h>
#include <sa/role.h>
#include <sa/group.h>
#include <tccore/aom.h>
#include <tc/folder.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <ics/ics.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <sa/groupmember.h>
#include <constants/constants.h>
#include <tccore/item_msg.h>
#include <tccore/project.h>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <epm/epm_toolkit_tc_utils.h>

#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_Populate_Workflow_RefItems(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_POPULATE_WORKFLOW_REFITEMS_HXX
