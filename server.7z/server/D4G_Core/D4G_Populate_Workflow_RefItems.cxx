//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*========================================================================================================================
Module  		: D4G_Populate_Workflow_RefItems

Description		: contains the extension code for adding the item references to the  workflow task .


Date            Name      Task Id      Description of Change
-------------------------------------------------------------------------------------------------------------------------
15-Jun-2017    Bhargav      3851        Adds the reference of the DanPart Revision from the workflow task on adding the schedule in
                                        the Danpart revision  schedules folder
========================================================================================================================*/

/********************************************************************************************************************
*Function Name   : D4G_Populate_Workflow_RefItems
*Extension on    : GRM_Create operation of the "CMHasWorkBreakDown" relation
*Extension Point : Post_action
*Extension File	 : default.xml
*Dll name	     : libD4G_core
*Library Name	 : D4G_Core
*Input Parameters: va_list args ---tag of danfoss part, schedule and relation type tag.
*Return Value	 : int ifail -- return status

/* History
Date            Name      		Task Id      								Description of Change
-------------------------------------------------------------------------------------------------------------------------
15-Jun-2017    Bhargav      3851(Issue 2)        Adds the reference of the DanPart Revision from the workflow task on adding the schedule in
												 the Danpart revision  schedules folder
31-07-2017	   Bhargav			3851			 Modified the logic of getting the references of schedule objects .
**************************************************************************************************************************/

#include <D4G_Core/D4G_Populate_Workflow_RefItems.hxx>
#include <constants.hxx>
#include <epm/epm.h>
#include <ItkCallHeader.hxx>

int D4G_Populate_Workflow_RefItems( METHOD_message_t * msg, va_list args)
{
 
	int		   iTagCount					 = 0;
	int		   iNum							 = 0;
	int		   iWorkFlowCount				 = 0;
	int		   iIndex						 = 0;
	int		   iPrefCount					 = 0;
	int		   iValCount					 = 0;
	int 	   status 						 = ITK_ok;
	int		   iTempIntVal[1]				 = {EPM_reference_attachment};
	int*	   iLevels						 = NULL;


	char*      cpRelationName                = NULL;
	char*      primeObjectName               = NULL;
	char*      secObjectName                 = NULL;
	char*	   cpValObjectName      	     = NULL;
	char**	   cppRelations					 = NULL;
	char**	   cppPrefValue		    		 = NULL;

	tag_t      primary_object                = NULLTAG;
	tag_t      secondary_object              = NULLTAG;
	tag_t      relationTypeTag               = NULLTAG;
	tag_t      priTypeTag                    = NULLTAG;
	tag_t      secTypeTag                    = NULLTAG;
	tag_t	   tValTypeTag				     = NULLTAG;
	tag_t*	   tWorkFlowTag				     = NULLTAG;
	tag_t*	   tSchedValueTags			     = NULLTAG;





	msg=0;

	va_list copyArgs;
	va_copy(copyArgs,args);

	//getting the tag for the primary object (D4G_DanPartRevision )
	primary_object       = va_arg( copyArgs, tag_t );

	//getting the tag for the secondary object (D4G_PPAPSched )
	secondary_object     = va_arg( copyArgs, tag_t );

	//getting the relation type tag (CMHasWorkBreakDown)
	relationTypeTag      = va_arg( copyArgs, tag_t );

	va_end( copyArgs );

	//Getting the type tag for primary object
	ITK_LOG(TCTYPE_ask_object_type(primary_object,&priTypeTag));

	//Getting the type tag for secondary object
	ITK_LOG(TCTYPE_ask_object_type(secondary_object,&secTypeTag));

	//asking the name of relation type
	ITK_LOG(AOM_ask_name( relationTypeTag ,&cpRelationName));

	//asking the name of primary object type
	ITK_LOG(TCTYPE_ask_name2(priTypeTag,&primeObjectName));

	//asking the name of secondary object type
	ITK_LOG(TCTYPE_ask_name2(secTypeTag,&secObjectName));

	//getting the count of the preference values of 'D4G_Attach_PartsAs_Reference' preference
	ITK_LOG(PREF_ask_value_count ( ATTACH_PARTS_AS_REF_PREF_NAME, &iPrefCount));

	if (iPrefCount > 0)
	{
		//getting the values from 'D4G_Attach_PartsAs_Reference' preference.It consists of names of different schedule task

		ITK_LOG(PREF_ask_char_values ( ATTACH_PARTS_AS_REF_PREF_NAME, &iPrefCount, &cppPrefValue));

	}

	for(iValCount=0;iValCount<iPrefCount;iValCount++)
	{

		if((tc_strcmp(cppPrefValue[iValCount],primeObjectName)==0)&&(tc_strcmp(D4G_PPAPSCHED,secObjectName)==0)&&(tc_strcmp(CM_HAS_WORK_BREAKDOWN,cpRelationName)==0))
		{
			//getting the tags for the references of the secondary object
			ITK_LOG(WSOM_where_referenced(secondary_object,1,&iTagCount,&iLevels,&tSchedValueTags,&cppRelations));

		for (iNum = 0; iNum < iTagCount; iNum++)
		{
			//asking the type of the referenced object
			ITK_LOG(TCTYPE_ask_object_type(tSchedValueTags[iNum],&tValTypeTag));

			//getting the type name of all the references of the schedule

			ITK_LOG(TCTYPE_ask_name2(tValTypeTag,&cpValObjectName));

			//comparing the reference name with the D4G_PPAPTask
			if (tc_strcmp(cpValObjectName,D4G_PPAPTASK) == 0)
			{

				//getting the tags for the workflows of scheduke task
				ITK_LOG(AOM_ask_value_tags (tSchedValueTags[iNum],AllWORKFLOWS,&iWorkFlowCount,&tWorkFlowTag));


				for(iIndex=0;iIndex<iWorkFlowCount;iIndex++)
				{

					if(tWorkFlowTag[iIndex]!=NULLTAG)
					{

						//if workflow tag is existing then add the dan part revision to the workflow task as an attachment
						ITK_LOG(EPM_add_attachments (tWorkFlowTag[iIndex],1, &primary_object, iTempIntVal ));
					}
				}

			}
		}
}
}
	SAFE_SM_FREE(tWorkFlowTag);
	SAFE_SM_FREE(tSchedValueTags);
	SAFE_SM_FREE(cpRelationName);
	SAFE_SM_FREE(cppPrefValue);
	SAFE_SM_FREE(primeObjectName);
	SAFE_SM_FREE(secObjectName);
	SAFE_SM_FREE(cpValObjectName);
	SAFE_SM_FREE(iLevels);
	SAFE_SM_FREE(cppRelations);

return status;

}
