//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension D4G_ITEMDeepCopy_PostAction
 *
 */
 
#ifndef D4G_ITEMDEEPCOPY_POSTACTION_HXX
#define D4G_ITEMDEEPCOPY_POSTACTION_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_ITEMDeepCopy_PostAction(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_ITEMDEEPCOPY_POSTACTION_HXX
