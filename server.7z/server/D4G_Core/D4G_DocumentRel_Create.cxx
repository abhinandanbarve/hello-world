//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_DocumentRel_Create
/*  Program ID:         D4G_DocumentRel_Create.cxx
/*  Description:        This function is implemented to check whether to allow to create Document Relation or not based on conditions.
/*  Input Parameters:   METHOD_message_t * msg, va_list args
/*  Return Value:       int ifail -- return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 09-08-2017	       Vivek Mundada 		  3421               Initial Creation
*
*************************************************************************************************************************/

#include <D4G_Core/D4G_DocumentRel_Create.hxx>
#include <metaframework/CreateInput.hxx>
#include <tccore/releasestatus.h>
#include <constants.hxx>
#include "ug_va_copy.h"
#include <iostream>

#include <tc/emh.h>
#include <tc/preferences.h>
#include <bom/bom.h>
#include <epm/epm_toolkit_tc_utils.h>

#include <sa/user.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <tccore/project.h>
#include <tcinit/tcinit.h>

#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <set>
#include <sstream>
#include <vector>
#include <algorithm>
#include <map>
#include <memory>
#include <constants.hxx>

using namespace std;

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ItkCallHeader.hxx>
#include <D4G_ErrorCodes.hxx>

using std::string;
using std::vector;

int D4G_DocumentRel_Create( METHOD_message_t * msg, va_list args )
{
	int 	status				 	= ITK_ok	;
	int 	iReleaseStatusCount 	= 0			;
	char	*cpReleaseStatusName	 	= NULL		;
	tag_t 	*tReleaseStatusListTags = NULLTAG	;

	tag_t   tPrimaryObj				= NULLTAG	;
	tag_t   tSecondaryObj			= NULLTAG	;
	bool 	isNull					= true		;

	// Get primary and secondary object tags
	Teamcenter::CreateInput *creInput = va_arg( args, Teamcenter::CreateInput* );

	ITK_LR( creInput->getTag( PRIMARY_OBJECT, tPrimaryObj, isNull) );
	ITK_LR( creInput->getTag( SECONDARY_OBJECT, tSecondaryObj, isNull ) );

	if( check_user_against_pref( USERS_ALLOWED_PREFERENCE ) )
	{
		return ITK_ok;
	}

	ITK_LOG( AOM_ask_value_tags( tPrimaryObj, RELEASE_STATUS_LIST.c_str(), &iReleaseStatusCount, &tReleaseStatusListTags ) );

	if( ( is_of_type( tPrimaryObj, PART_REVISION ) || is_of_type( tPrimaryObj, BOM_ITEM_REVISON ) )
			|| ( is_of_type( tPrimaryObj, DESIGN_REVISON ) && is_of_type( tSecondaryObj, D4G_RESTR_DOC_REVISION ) ) )
	{
		for( int iReleaseStatusCounter = 0; iReleaseStatusCounter < iReleaseStatusCount; iReleaseStatusCounter++ )
		{
			ITK_LOG( AOM_ask_value_string( tReleaseStatusListTags[iReleaseStatusCounter], OBJECT_NAME.c_str(), &cpReleaseStatusName ) );

			if( cpReleaseStatusName != NULL && tc_strcmp( cpReleaseStatusName, STATUS_OBSOLETE.c_str() ) == 0 )
			{
				string partDisplay = get_string_property( tPrimaryObj, OBJECT_STRING );
				ITK_LR( EMH_store_error_s1( EMH_severity_error, CREATE_RELATION_OBSOLETE, partDisplay.c_str() ) );
				return CREATE_RELATION_OBSOLETE;
			}
		}
	}
	else if( is_of_type( tPrimaryObj, DESIGN_REVISON ) && iReleaseStatusCount != 0 )
	{
		string partDisplay = get_string_property( tPrimaryObj, OBJECT_STRING );
		ITK_LR( EMH_store_error_s1( EMH_severity_error, CREATE_RELATION_OBSOLETE, partDisplay.c_str() ) );
		return CREATE_RELATION_OBSOLETE;
	}

	SAFE_SM_FREE( tReleaseStatusListTags );

	return ITK_ok;
}
