//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/***************************************************************************************
*Function Name   : D4G_RunTimeProperties
*Description     : this file contains the details of registered runtime properties
*Extension on    : BMF_SESSION_register_properties operation of the "session" object
*Extension Point : Base_action
*Dll name	     : libD4G_Extensions
*Library Name	 : D4G_Extensions
*Issue number 	 : 2650
*Author			 : Bhargav
***********************************************************************************/
 
#ifndef D4G_RUNTIMEPROPERTIES_HXX
#define D4G_RUNTIMEPROPERTIES_HXX

#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_RunTimeProperties(METHOD_message_t* msg, va_list args);

extern D4G_CORE_API  int D4G_FindDeviationReq( METHOD_message_t* msg, va_list args);


                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_RUNTIMEPROPERTIES_HXX
