/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_PartNumberList
    - A getter method override which returns a list of all item_id of Parts in
    representation_for Reference property.

 ===============================================================================*/

#include <D4G_Core/D4G_PartNumberList.hxx>

#include <tccore/aom.h>

#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
int D4G_PartNumberList( METHOD_message_t *msg, va_list args )
{
	// Get object tag and value
	(tag_t) va_arg(args, tag_t);
	char **value = va_arg(args, char**);
	tag_t object_tag = NULLTAG;
	METHOD_PROP_MESSAGE_OBJECT(msg, object_tag);
	std::string result;
	ITK_LR(AOM_refresh(object_tag, false));

	// Get tags of all objects representing our object and write them to comma separated string
	std::vector<tag_t> parts=get_tags_property_vector(object_tag, "representation_for");
	bool isFirst=true;
	for(std::vector<tag_t>::iterator it=parts.begin();it!=parts.end();++it){
		if(isFirst){
			isFirst=false;
		} else {
			result.append(",");
		}
		result.append(get_string_property(*it,"item_id"));
	}

	// Cut result string if too long
	int length;
	if(result.size()<4000){
		length=result.size();
	} else {
		length=4000;
	}
	result.substr(0,length);

	*value=MEM_string_copy(result.substr(0,length).c_str());
	return ITK_ok;
}
