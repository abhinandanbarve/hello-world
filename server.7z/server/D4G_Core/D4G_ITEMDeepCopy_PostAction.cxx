//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_ITEMDeepCopy_postAction
/*  Program ID:         D4G_ITEMDeepCopy_postAction.cxx
/*  Description:        This function is implemented to check whether Deep copy objects are copied based on conditions and to copy the official revision.
/*  Input Parameters:   METHOD_message_t * msg, va_list args
/*  Return Value:       int ifail -- return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 14-08-2017	       Vivek Mundada 		  3421               Initial Creation
*
*************************************************************************************************************************/

#include <D4G_Core/D4G_ITEMDeepCopy_PostAction.hxx>

#include <metaframework/DeepCopyData.hxx>
#include <tccore/releasestatus.h>
#include <constants.hxx>
#include "ug_va_copy.h"

#include <tc/preferences.h>
#include <bom/bom.h>
#include <epm/epm_toolkit_tc_utils.h>

#include <sa/user.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <tccore/project.h>
#include <tcinit/tcinit.h>

#include <cstdlib>
#include <iostream>
#include <set>
#include <sstream>
#include <algorithm>
#include <map>
#include <memory>
#include <constants.hxx>

using namespace std;

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ItkCallHeader.hxx>

using std::string;
using std::vector;

int D4G_ITEMDeepCopy_PostAction( METHOD_message_t * msg, va_list args )
{
	int 					 status 					  = ITK_ok					 ;
	int 					 iNumObjsFound 			   	 		    				 ;
	tag_t 					 *tSecondaryObjects 		  = NULLTAG					 ;
	int 					 iReleaseStatusCount 		  = 0						 ;
	int 					 iReleaseStatusCounter 		  = 0						 ;
	char					 *cpReleaseStatusName	 	  = NULLTAG					 ;
	tag_t 					 *tReleaseStatusListTags 	  = NULLTAG					 ;
	tag_t					 tSoltuionItemsRelationType	  = NULLTAG					 ;
	tag_t					 tSolutionItemsRelation		  = NULLTAG					 ;
	logical     			 lIsOfficial					 						 ;
	tag_t   				 tItem_tag         			  = NULLTAG					 ;   				/* 		Item  tag 				*/
	tag_t   				 *tRevs_list    			  = NULLTAG					 ;   				/* 		Revision list 	 		*/
	int     				 iRevisionCount         	  = 0						 ;   				/* 		Number of revisions 	*/
	tag_t					 tRelation					  = NULLTAG					 ;

	va_list localArgs;
	va_copy( localArgs, args );

	tag_t                    tNew_rev         			  = va_arg( localArgs, tag_t );   				// The Tag of the newly created Item Revision
	char*                    cpOperation       			  = va_arg( localArgs, char* );   				// Whether the operation is Save As/Revise
	tag_t                    tParent_rev      			  = va_arg( localArgs, tag_t );   				// The Tag of the Item Revision over which Save As/Revise operation will be performed
	int                      iCopyCount       			  = va_arg( localArgs, int );     				// Number of deep copy rules set
	ITEM_deepcopy_info_t*    copyInfo        			  = va_arg( localArgs, ITEM_deepcopy_info_t* ); // Deep Copy Rule Information
	int*                     iCount           			  = va_arg( localArgs, int* );					// Number of Datasets attached
	tag_t**                  tCopied_objects  			  = va_arg( localArgs, tag_t** );				// The tags of the deep copied attachments

	ITK_LOG( GRM_find_relation_type( D4G_DOCUMENT_REL.c_str(), &tSoltuionItemsRelationType ) );

	ITK_LOG( GRM_list_secondary_objects_only( tNew_rev, tSoltuionItemsRelationType, &iNumObjsFound, &tSecondaryObjects ) );

	for( int docObj = 0; docObj < iNumObjsFound; docObj++ )
	{
		logical checkLogicalRequired = true;
		ITK_LOG( AOM_ask_value_tags( tSecondaryObjects[docObj], RELEASE_STATUS_LIST.c_str(), &iReleaseStatusCount, &tReleaseStatusListTags ) );

		for( iReleaseStatusCounter = 0; iReleaseStatusCounter < iReleaseStatusCount; iReleaseStatusCounter++ )
		{
			ITK_LOG( AOM_ask_value_string( tReleaseStatusListTags[iReleaseStatusCounter], OBJECT_NAME.c_str(), &cpReleaseStatusName ) );

			if( cpReleaseStatusName != NULL && tc_strcmp( cpReleaseStatusName, STATUS_OBSOLETE.c_str() ) == 0 )
			{
				// Delete the relation
				ITK_LOG( GRM_find_relation( tNew_rev, tSecondaryObjects[docObj], tSoltuionItemsRelationType, &tSolutionItemsRelation ) );

				ITK_LOG( GRM_delete_relation( tSolutionItemsRelation ) );
				checkLogicalRequired = false;
				break;
			}
		}

		if( checkLogicalRequired )
		{
			ITK_LOG( ITEM_ask_item_of_rev( tSecondaryObjects[docObj], &tItem_tag ) );
			ITK_LOG( ITEM_list_all_revs( tItem_tag, &iRevisionCount , &tRevs_list ) );

			for( int revCounter = 0; revCounter < iRevisionCount; revCounter++ )
			{
				ITK_LOG( AOM_ask_value_logical( tRevs_list[revCounter], OFFICIAL_REVISION.c_str(), &lIsOfficial ) );

				if( lIsOfficial != NULL && lIsOfficial == true && tSecondaryObjects[docObj] != tRevs_list[revCounter] )
				{
					// Add Official revision
					ITK_LOG( GRM_create_relation( tNew_rev, tRevs_list[revCounter], tSoltuionItemsRelationType, NULLTAG, &tRelation ) );

					ITK_LOG( GRM_save_relation( tRelation ) );

					break;
				}
			}
		}
	}

	SAFE_SM_FREE( tSecondaryObjects );
	SAFE_SM_FREE( tReleaseStatusListTags );
	va_end( localArgs );

	return ITK_ok;
}
