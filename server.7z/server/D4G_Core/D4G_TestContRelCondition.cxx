/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_TestContRelCond
 	 - A relation creation PreCondition that checks if the object added to a
 	 Test Container Revision has any status other than In Review.
 	 Check is skipped if user has bypass or is specified in Preference
 	 D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/

#include <D4G_Core/D4G_TestContRelCondition.hxx>
#include "ug_va_copy.h"
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <D4G_ErrorCodes.hxx>
#include <tc/emh.h>
#include <vector>
#include <iostream>
#include <metaframework/CreateInput.hxx>
int D4G_TestContRelCondition( METHOD_message_t *msg, va_list args )
{
	// Skip Checks if user is privileged
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_relations")){return ITK_ok;}

	// Retrieve primary and secondary tags.
	Teamcenter::CreateInput *creInput=va_arg(args,Teamcenter::CreateInput*);

	tag_t secondary_tag=NULLTAG;
	tag_t primary_tag=NULLTAG;
	bool isNull=true;
	ITK_LR(creInput->getTag(std::string("primary_object"),primary_tag,isNull));
	ITK_LR(creInput->getTag(std::string("secondary_object"),secondary_tag,isNull));

	// If primary is Test Container Revision
	if(is_of_type(primary_tag,"D4G_TestContRevision")){
		// Store status list
		ITK_LR(AOM_refresh(secondary_tag, false));
		std::vector<tag_t> status=get_tags_property_vector(secondary_tag,"release_status_list");

		// Count In Review status in status list
		int inReviewCount=0;
		for(std::vector<tag_t>::iterator it=status.begin();it!=status.end();++it){
			char *status_type;
			ITK_LR(RELSTAT_ask_release_status_type(*it,&status_type));
			std::string typeName(status_type);
			if(typeName=="D4G_InReview"){
				inReviewCount++;
			}
		}
		// If all statuses are In Review error out.
		if(inReviewCount==status.size()){
			std::string objectName(get_string_property(secondary_tag,"object_string"));
			ITK_LR(EMH_store_error_s1(EMH_severity_error,CHECK_WAS_APPROVED,objectName.c_str()));
			return CHECK_WAS_APPROVED;
		}
	}

	return ITK_ok;
}
