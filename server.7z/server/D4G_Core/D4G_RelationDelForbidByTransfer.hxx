/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Jan J�rn Sommer

 Description:    contains the implementation for the Extension D4G_RelationDelForbidByTransfer
 	 - A relation deletion PreCondition that checks if the secondary object is an
 	 Item or Item Revision. Then checks if none of the Items Revisions are
 	 transferred to SAP.
 	 Check is skipped if user has bypass or is specified in Preference
 	 D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/
#ifndef D4G_RELATIONDELFORBIDBYTRANSFER_HXX
#define D4G_RELATIONDELFORBIDBYTRANSFER_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_RelationDelForbidByTransfer(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_RELATIONDELFORBIDBYTRANSFER_HXX
