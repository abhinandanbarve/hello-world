/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_resetChangeMasterId
 	 - A relation deletion PreAction that resets the property item_id of a
 	 D4G_ChangeMasterRevision back to the d4g_storeditemid if the Change Master no
 	 longer CMImplements its Change Notice.
 	 Does not touch the item_id if Change Master is locked.

 ===============================================================================*/

#include <D4G_Core/D4G_resetChangeMasterId.hxx>

#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <pom/pom/pom.h>
#include <metaframework/CreateInput.hxx>

#include <string>

using namespace std;

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>

int D4G_resetChangeMasterId( METHOD_message_t *msg, va_list args )
{
	int status = ITK_ok;

	// Get primary and secondary object tags
	tag_t relationtag = va_arg(args, tag_t);
	tag_t primarytag = NULLTAG;
	tag_t secondarytag = NULLTAG;
	//9-5-2017 : Bipin : Deprecated API -"AOM_get_value_tag", replaced with "AOM_ask_value_tag"
	//ITK_LOG(AOM_get_value_tag(relationtag, "primary_object", &primarytag));
	//ITK_LOG(AOM_get_value_tag(relationtag, "secondary_object", &secondarytag));
	ITK_LOG(AOM_ask_value_tag(relationtag, "primary_object", &primarytag));
	ITK_LOG(AOM_ask_value_tag(relationtag, "secondary_object", &secondarytag));

	//If primary object is Change Master and secondary is Change Notice derive item_id
	string primarytype = get_string_property(primarytag, "object_type");
	string secondarytype = get_string_property(secondarytag, "object_type");
	if(primarytype=="D4G_ChangeMasterRevision" &&
			(secondarytype=="D4G_ChangeNoticeRevision" || secondarytype=="D4G_CustomerReqRevision")){

		//Get D4G_ChangeMaster from revision
		tag_t cmtag;
		//9-5-2017 : Bipin : Deprecated API -"AOM_get_value_tag", replaced with "AOM_ask_value_tag"
		//ITK_LOG(AOM_get_value_tag(primarytag, "items_tag", &cmtag));
		ITK_LOG(AOM_ask_value_tag(primarytag, "items_tag", &cmtag));
		int islocked=POM_no_lock;
		ITK_LOG(POM_ask_instance_lock(cmtag, &islocked));

		//If item was not locked restore old item_id from d4g_storeditemid
		if(islocked==POM_no_lock) {
			ITK_LOG(AOM_refresh(cmtag, true));
			string storedid = get_string_property(cmtag, "d4g_storeditemid");
			if(!storedid.empty()){
				ITK_LOG(AOM_set_value_string(cmtag, "item_id", storedid.c_str()));
			}
			//9-5-2017 : Bipin : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
			//ITK_LOG(AOM_save(cmtag));
			ITK_LOG(AOM_save_with_extensions(cmtag));
			ITK_LOG(AOM_unlock(cmtag));
		}
	}
	return ITK_ok; //Relation deletion should not stop if id change errors out
}
