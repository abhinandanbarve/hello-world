/*==============================================================================
 Copyright (c) 2014 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Business Object D4G_CustomerReq
    - The setter method for the reference property d4g_Customer deletes all existing
    D4G_CustomerCaseRel of this D4G_CustomerReq and creates a new D4G_CustomerCaseRel
    to the specified D4G_Customer.
    - The Post Create method reads the value of the property d4g_Customer, deletes
    all existing D4G_CustomerCaseRel of this D4G_CustomerReq and creates a new
    D4G_CustomerCaseRel to the specified D4G_Customer.

 ===============================================================================*/

#include <epm/epm_toolkit_tc_utils.h>
#include <fclasses/tc_string.h>
#include <tc/emh.h>
// 9-05-2017 Bipin: Obsolete function <tc/tc.h> replaced with <tcinit/tcinit.h> and <tc/tc_startup.h>
//#include <tc/tc.h>
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <tccore/aom_prop.h>

#include <iostream>

using std::cout;

#include <ITKCallHeader.hxx>
#include <D4G_Core/D4G_CustomerReq.hxx>
#include <D4G_Core/D4G_CustomerReqImpl.hxx>

using namespace Danfoss_Global_PLM; 

//----------------------------------------------------------------------------------
// D4G_CustomerReqImpl::D4G_CustomerReqImpl(D4G_CustomerReq& busObj)
// Constructor for the class
//---------------------------------------------------------------------------------- 
D4G_CustomerReqImpl::D4G_CustomerReqImpl( D4G_CustomerReq& busObj )
   : D4G_CustomerReqGenImpl( busObj ) 
{
}

//----------------------------------------------------------------------------------
// D4G_CustomerReqImpl::~D4G_CustomerReqImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
D4G_CustomerReqImpl::~D4G_CustomerReqImpl()
{
}
 
//----------------------------------------------------------------------------------
// D4G_CustomerReqImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int D4G_CustomerReqImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = D4G_CustomerReqGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}


/**
 * Setter for a Tag Property
 * @param value - Value to be set for the parameter
 * @param isNull - If true, set the parameter value to null
 * @return - Status. 0 if successful
 */
int  D4G_CustomerReqImpl::setD4g_CustomerBase( const tag_t &value, bool isNull )
{
	int status = ITK_ok;
	if (!isNull){
		// Get object tag and Customer value to be set
		tag_t thisTag = this->getD4G_CustomerReq()->getTag();
		tag_t values[]= {value};

		// Create D4G_CustomerCaseRel relation to Customer.
		// This deletes all existing D4G_CustomerCaseRel for this Customer Request
		ITK_LOG(AOM_set_value_tags(thisTag, "D4G_CustomerCaseRel", 1, values));
	}
	return status;
}


/**
 * desc for createPost
 * @param creInput - Description for the Create Input
 * @return - return desc for createPost
 */
int  D4G_CustomerReqImpl::createPostBase( Teamcenter::CreateInput *creInput )
{
	int status = ITK_ok;

	// Get object tag and Customer tag from d4g_Customer
	bool isNull = TRUE;
	tag_t customerTag = NULL;
	tag_t thisTag = this->getD4G_CustomerReq()->getTag();
	ITK_LOG(creInput->getTag("d4g_Customer", customerTag, isNull));

	// Create D4G_CustomerCaseRel relation to Customer
	// This deletes all existing D4G_CustomerCaseRel for this Customer Request
	if(!status){
		tag_t values[]= {customerTag};
		ITK_LOG(
				AOM_set_value_tags(thisTag, "D4G_CustomerCaseRel", 1, values));
	} else {
		EMH_store_error( EMH_severity_error, status );
	}
	// Call OOTB createPostBase function
	ITK_LOG(D4G_CustomerReqGenImpl::super_createPostBase(creInput));
	return status;
}
