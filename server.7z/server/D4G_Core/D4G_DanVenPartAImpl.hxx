/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Business Object D4G_DanPartRevision
    - A standard setter method for the d4g_NetPrice property.
    - A standard setter method for the d4g_plannedDeliveryTime property.
    - A standard setter method for the d4g_StdQuantity property.
    - A standard setter method for the d4g_TaxCode property.

 ===============================================================================*/

#ifndef DANFOSS_GLOBAL_PLM__D4G_DANVENPARTAIMPL_HXX
#define DANFOSS_GLOBAL_PLM__D4G_DANVENPARTAIMPL_HXX

#include <D4G_Core/D4G_DanVenPartAGenImpl.hxx>

#include <D4G_Core/libd4g_core_exports.h>

#define D4G_DanVenPartAPomClassName "D4G_DanVenPartA"

namespace Danfoss_Global_PLM
{
   class D4G_DanVenPartAImpl; 
   class D4G_DanVenPartADelegate;
}
 
class  D4G_CORE_API Danfoss_Global_PLM::D4G_DanVenPartAImpl
           : public Danfoss_Global_PLM::D4G_DanVenPartAGenImpl 
{
public:    

    // find method
    // static status_t find();  


   /**
    * Setter for a Double Property
    * @param value - Value to be set for the parameter
    * @param isNull - If true, set the parameter value to null
    * @return - Status. 0 if successful
    */
    int  setD4g_NetPriceBase( double value, bool isNull );

   /**
    * Setter for an Integer Property
    * @param value - Value to be set for the parameter
    * @param isNull - If true, set the parameter value to null
    * @return - Status. 0 if successful
    */
    int  setD4g_plannedDeliveryTimeBase( int value, bool isNull );

   /**
    * Setter for an Integer Property
    * @param value - Value to be set for the parameter
    * @param isNull - If true, set the parameter value to null
    * @return - Status. 0 if successful
    */
    int  setD4g_StdQuantityBase( int value, bool isNull );

   /**
    * Setter for a string Property
    * @param value - Value to be set for the parameter
    * @param isNull - If true, set the parameter value to null
    * @return - Status. 0 if successful
    */
    int  setD4g_TaxCodeBase( const std::string &value, bool isNull );


protected:
    // Constructor for a D4G_DanVenPartA
    explicit D4G_DanVenPartAImpl( D4G_DanVenPartA& busObj );

    // Destructor
    ~D4G_DanVenPartAImpl();


private:
    // Default Constructor for the class
    D4G_DanVenPartAImpl();
    
    // Private default constructor. We do not want this class instantiated without the business object passed in.
    D4G_DanVenPartAImpl( const D4G_DanVenPartAImpl& );

    // Copy constructor
    D4G_DanVenPartAImpl& operator=( const D4G_DanVenPartAImpl& );

    // Method to initialize this Class
    static int initializeClass();

    //static data
    friend class Danfoss_Global_PLM::D4G_DanVenPartADelegate;

};

#include <D4G_Core/libd4g_core_undef.h>
#endif // DANFOSS_GLOBAL_PLM__D4G_DANVENPARTAIMPL_HXX
