/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_CMHasSolutionItemRelCondition
    - A relation creation PreCondition that checks if objects should be allowed
    to be related to a Change Notice Revision or Change Master Revision via
    CMHasSolutionItems Relation.
    For Change Notice the object types Part Revision and BOM Item Revision are only
    allowed if they are "Released" or if this is the first Change Notice Revision
    they are added to.
    For Change Master the object type BOM Item Revision is only allowed to be
    attached if the BOM Item Revision is for the same plant as the Change Master and
    the BOM Item Revisions item_id is not yet represented in the Change Masters
    Solution Items. Additionally the BOM Item Revision should not already be attached
    to a Change Master of the same type or, if our Change Masters type is Standard,
    to any other Change Master.
    Check is skipped if user has bypass or is specified in Preference
    D4G_users_allowed_to_modify_locked_relations.
 ===============================================================================*/

#include <D4G_Core/D4G_CMHasSolutionItemRelCondition.hxx>

#include <tc/emh.h>
#include <metaframework/CreateInput.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <tccore/grm.h>
#include <constants.hxx>
#include "ug_va_copy.h"
#include <vector>
#include <iostream>

#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <D4G_ErrorCodes.hxx>

using std::string;
using std::vector;

int D4G_CMHasSolutionItemRelCondition( METHOD_message_t *msg, va_list args )
{
	// Skip Checks if user is privileged
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_relations")){return ITK_ok;}

	// Get primary and secondary object tags
	Teamcenter::CreateInput *creInput=va_arg(args,Teamcenter::CreateInput*);
	tag_t secondary_tag=NULLTAG;
	tag_t primary_tag=NULLTAG;
	bool isNull=true;
	ITK_LR(creInput->getTag(string("primary_object"),primary_tag,isNull));
	ITK_LR(creInput->getTag(string("secondary_object"),secondary_tag,isNull));

	// Is relation adding a Part Revision or D4G_BOMItemRevision to a D4G_ChangeNoticeRevision?
	if(is_of_type(primary_tag,"D4G_ChangeNoticeRevision")
			&& (is_of_type(secondary_tag, "Part Revision") || is_of_type(secondary_tag, "D4G_BOMItemRevision"))){
		ITK_LR(AOM_refresh(secondary_tag, false));
		// If the secondary item is not released and has a Change Notice already: error out
		if(!hasStatus(secondary_tag, "D4G_Released")){
			vector<tag_t> ChangeNoticeTags;
			ITK_LR(get_primary_for_relation(secondary_tag, "CMHasSolutionItem", "D4G_ChangeNoticeRevision", ChangeNoticeTags));
			if(ChangeNoticeTags.size()>0){
				ITK_LR(EMH_store_error_s1(EMH_severity_error, CMHASSOLUTIONITEM_LOW_STATUS,
						get_string_property(secondary_tag,"object_string").c_str()));
				return CMHASSOLUTIONITEM_LOW_STATUS;
			}
		}
	}// Is relation adding a D4G_BOMItemRevision to a D4G_ChangeMasterRevision?
	else if(is_of_type(primary_tag,"D4G_ChangeMasterRevision") && is_of_type(secondary_tag, "D4G_BOMItemRevision")){
		ITK_LR(AOM_refresh(secondary_tag, false));

		// Store plants for Change Master and BOM
		string CMplant = get_string_property(primary_tag, "d4g_Plant");
		string BOMplant = get_string_property(secondary_tag, "d4g_Plant");

		// If plants are different error out
		if(CMplant !=BOMplant){
			ITK_LR(EMH_store_error_s3(EMH_severity_error, CMHASSOLUTIONITEM_PLANT_MISMATCH,
					get_string_property(secondary_tag, "object_string").c_str(),
					BOMplant.c_str(), CMplant.c_str()));
			return CMHASSOLUTIONITEM_PLANT_MISMATCH;
		}

		// Store Id of the D4G_BOMItemRevision and Solution Items of the D4G_ChangeMasterRevision
		string BOMid = get_string_property(secondary_tag, "item_id");
		vector<tag_t> solutiontags = get_tags_property_vector(primary_tag, "CMHasSolutionItem");

		// Check if the D4G_BOMItemRevisions item_id is represented in Solution Items already.
		// If yes error out.
		for (int i=0; i<solutiontags.size(); i++){
			if(BOMid==get_string_property(solutiontags[i], "item_id")){
				ITK_LR(EMH_store_error_s2(EMH_severity_error,CMHASSOLUTIONITEM_CM_TWO_REVS,
						get_string_property(solutiontags[i],"object_string").c_str(),
						get_display_property(solutiontags[i], "object_type").c_str()));
				return CMHASSOLUTIONITEM_CM_TWO_REVS;
			}
		}

		// Get the type of the D4G_ChangeMaster
		tag_t CMtag;
		ITK_LR(AOM_ask_value_tag(primary_tag, "items_tag", &CMtag));
		string changeType = get_string_property(CMtag, "d4g_ChangeType");

		// If the Change Type is Service or Obsolete check if D4G_BOMItemRevision is already attached
		// to a D4G_ChangeMasterRevision of this type. If yes error out.
		if (changeType=="Service" || changeType=="Obsolete"){
			vector<tag_t> ChangeMasterTags;
			ITK_LR(get_primary_for_relation(secondary_tag,
					"CMHasSolutionItem", "D4G_ChangeMasterRevision", ChangeMasterTags));
			if(ChangeMasterTags.size()>0){
				for( int j=0; j<ChangeMasterTags.size(); j++){
					string otherType = get_string_property(ChangeMasterTags[j], "d4g_ChangeType");
					if(otherType==changeType){
						ITK_LR(EMH_store_error_s2(EMH_severity_error,CMHASSOLUTIONITEM_TWO_CMS_TYPE,
								get_string_property(secondary_tag, "object_string").c_str(),
								changeType.c_str()));
						return CMHASSOLUTIONITEM_TWO_CMS_TYPE;
					}
				}
			}
		} else{// Change Type is Standard. Check if D4G_BOMItemRevision is already attached
			// to any other D4G_ChangeMasterRevision of any type. If yes error out.
			vector<tag_t> ChangeMasterTags;
			ITK_LR(get_primary_for_relation(secondary_tag,
					"CMHasSolutionItem", "D4G_ChangeMasterRevision", ChangeMasterTags));
			if(ChangeMasterTags.size()>0){
				ITK_LR(EMH_store_error_s1(EMH_severity_error,CMHASSOLUTIONITEM_TWO_CMS,
						get_string_property(secondary_tag, "object_string").c_str()));
				return CMHASSOLUTIONITEM_TWO_CMS;
			}
		}
	}
	return ITK_ok;
}
