/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_PDPRelationPostActionProjectAssign
 	 - A relation creation PostAction that adds the secondary object to all
 	 projects the primary object is in.

 ===============================================================================*/

#include <D4G_Core/D4G_PDPRelationPostActionProjectAssign.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/project.h>

#include <vector>

using std::vector;

int D4G_PDPRelationPostActionProjectAssign( METHOD_message_t *msg, va_list args )
{
	int status = ITK_ok;

	// Get primary and secondary object tags and project lists for both
	tag_t primary 		= va_arg(args, tag_t);
	tag_t secondary		= va_arg(args, tag_t);
	tag_t* primaryprojects 	= NULL;
	int primarycount;
	tag_t* secondaryprojects 	= NULL;
	int secondarycount;
	ITK_LOG(AOM_refresh(primary, false));
	ITK_LOG(AOM_refresh(secondary, false));
	ITK_LOG(AOM_ask_value_tags(primary,"project_list",&primarycount, &primaryprojects));
	ITK_LOG(AOM_ask_value_tags(secondary,"project_list",&secondarycount, &secondaryprojects));

	// If primary object is in projects filter out those that secondary object is also in
	vector<tag_t> projectsToSet;
	for(int i=0; i<primarycount; i++){
		bool tobeset = true;
		for(int j=0; tobeset && j<secondarycount; j++){
			if(primaryprojects[i]==secondaryprojects[j]){
				tobeset=false;
			}
		}
		if(tobeset){
			projectsToSet.push_back(primaryprojects[i]);
		}
	}
	SAFE_SM_FREE(primaryprojects);
	SAFE_SM_FREE(secondaryprojects);

	// If any projects are left after filtering assign them to the secondary object
	if(projectsToSet.size()>=1){
		ITK_LOG(PROJ_assign_objects(projectsToSet.size(),&projectsToSet[0],1,&secondary));
	}

	return status;

}
