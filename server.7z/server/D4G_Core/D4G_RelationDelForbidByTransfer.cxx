/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Jan J�rn Sommer

 Description:    contains the implementation for the Extension D4G_RelationDelForbidByTransfer
 	 - A relation deletion PreCondition that checks if the secondary object is an
 	 Item or Item Revision. Then checks if none of the Items Revisions are
 	 transferred to SAP.
 	 Check is skipped if user has bypass or is specified in Preference
 	 D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/
#include <D4G_Core/D4G_RelationDelForbidByTransfer.hxx>


#include <tc/emh.h>
#include <metaframework/CreateInput.hxx>
#include <tccore/grm.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <sa/site.h>

#include <vector>

#include <ItkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <D4G_ErrorCodes.hxx>

using namespace std;

int D4G_RelationDelForbidByTransfer( METHOD_message_t *msg, va_list args )
{
	// Skip Checks if user is privileged
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_relations")){return ITK_ok;}

	// Retrieve secondary object tag
	tag_t reltag=va_arg(args,tag_t);
	tag_t secondarytag=NULLTAG;
	ITK_LR(GRM_ask_secondary(reltag, &secondarytag));
	ITK_LR(AOM_refresh(secondarytag, false));

	// Check if secondary object is an Item or Item Revision. If neither error out.
	// Store Item tag once identified.
	tag_t itemtag;
	if(is_of_type(secondarytag, "Item")){
		itemtag=secondarytag;
	} else if(is_of_type(secondarytag, "ItemRevision")){
		//9-5-2017 : Bipin : Deprecated API -"AOM_get_value_tag", replaced with "AOM_ask_value_tag"
		//AOM_get_value_tag(secondarytag, "items_tag", &itemtag);
		AOM_ask_value_tag(secondarytag, "items_tag", &itemtag);
	} else{
		ITK_LR(EMH_store_error_s1(EMH_severity_error,-1,
				"This code should never be called if the secondary object is neither an Item nor an Item Revision."));
				return -1;
	}
	/*get all Revisions*/
	std::vector<tag_t> revisions =get_tags_property_vector(itemtag, "revision_list");
	for(int i=0; i<revisions.size(); i++){
		/*get d4g_transferred*/
		bool transferred = get_bool_property(revisions[i],"d4g_transferred");
		/*if Revision was transferred store error and return -1*/
		if(transferred){
			ITK_LR(EMH_store_error_s1(EMH_severity_error,RELATIONDEL_LOCKED_BY_TRANSFER,
					get_string_property(itemtag, "object_string").c_str()));
			return RELATIONDEL_LOCKED_BY_TRANSFER;
		}
	}

	return ITK_ok;
}
