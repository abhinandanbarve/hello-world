/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_RelationDelForbidIfBothLocked
 	 - A relation deletion PreCondition that checks if the both primary and
 	 secondary object have no status.
 	 Check is skipped if user has bypass or is specified in Preference
 	 D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/
#ifndef D4G_RELATIONDELFORBIDIFBOTHLOCKED_HXX
#define D4G_RELATIONDELFORBIDIFBOTHLOCKED_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_RelationDelForbidIfBothLocked(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_RELATIONDELFORBIDIFBOTHLOCKED_HXX
