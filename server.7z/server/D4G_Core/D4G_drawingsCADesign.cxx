/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Birger Nielsen

 Description:    contains the implementation for the Extension D4G_drawingsCADesign
    - A getter method override that call D4G_drawingsDesign and returns the result.

 ===============================================================================*/

#include <D4G_Core/D4G_drawingsCADesign.hxx>
#include <D4G_Core/D4G_drawingsDesign.hxx>
int D4G_drawingsCADesign( METHOD_message_t *msg, va_list args )
{
	return D4G_drawingsDesign(msg,args);
}
