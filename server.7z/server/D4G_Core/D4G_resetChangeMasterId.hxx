/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_resetChangeMasterId
 	 - A relation deletion PreAction that resets the property item_id of a
 	 D4G_ChangeMasterRevision back to the d4g_storeditemid if the Change Master no
 	 longer CMImplements its Change Notice.
 	 Does not touch the item_id if Change Master is locked.

 ===============================================================================*/

#ifndef D4G_RESETCHANGEMASTERID_HXX
#define D4G_RESETCHANGEMASTERID_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_resetChangeMasterId(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_RESETCHANGEMASTERID_HXX
