/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Jan J�rn Sommer

 Description:    contains the implementation for the Extension D4G_PDP_ItemCreatePost_PostAction
 	 - A D4G_PDPItem creation PostAction that checks if property
 	 d4g_AutoCreateProject is True and if so creates a project for the PDP Item
 	 and adds the PDP Item to the newly created project.

 ===============================================================================*/

#include <D4G_Core/D4G_PDP_ItemCreatePost_PostAction.hxx>

#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <metaframework/CreateInput.hxx>

#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
using namespace std;

#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>
#include <tccore/project.h>

int D4G_PDP_ItemCreatePost_PostAction( METHOD_message_t *msg, va_list args )
{
	int 	status 		= ITK_ok;
	tag_t 	item		= msg->object_tag;
	string	description	= "Project was auto-generated during PDP Item creation.";
	logical generate	= NULL;
	tag_t	project		= NULLTAG;
	TCTYPE_save_operation_context_e enum_value = TCTYPE_unknown_operation_context;
	TCTYPE_ask_save_operation_context(&enum_value);
	if(enum_value != TCTYPE_save_on_create){return status;}


	/*check if Project should be generated and assigned*/
	ITK_LOG(AOM_ask_value_logical(item,"d4g_AutoCreateProject",&generate));
	if(!generate)return status;
	TC_write_syslog("Create Project \n");
	/*TODO: Generate description from preferences:
	 * PREF_ask_char_value 	( 	const char * preference_name,
								int  		 index,
								char **  	 value
							)
    */

	string item_id 	= get_string_property(item, "item_id");
	string object_name = get_string_property(item, "object_name");

	TC_write_syslog("\n Item ID: %s \n Name: %s \n", item_id, object_name);

	/*create the project*/
	ITK_LOG(PROJ_create_project(item_id.c_str(),object_name.c_str(),description.c_str(),&project));
	if(status != ITK_ok){
		return status;
	}
	/*assign the PDP Item to the new created project*/
	ITK_CALL(PROJ_assign_objects(1,&project,1,&item));
	if(status != ITK_ok)return status;

	return status;
}
