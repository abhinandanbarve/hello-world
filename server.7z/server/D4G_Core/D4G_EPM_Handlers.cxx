/*==============================================================================
 Copyright (c) 2014 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers
 Author  : Sven Simonsen

 Description:    contains the implementation of the D4G_EPM_Handlers
 	 and registration calls for said handlers.
=========================================================================================================================

Date          Name                        Task Id     Description of Change
-------------------------------------------------------------------------------------------------------------------------

 22-May-2017   Bhargav         2722       Added D4G_UpdateItemOnRevise function for ImpactAnalysis_2722
 05-Jun-2017   Bhargav         3851       Added D4G_AttachPartsAsReference function and D4G_Add_Tag_To_Array function  for ImpactAnalysis_3851
 26-Jun-2017   Chandrashekher  2244       Added D4G_CheckSignoffComments function for ImpactAnalysis_2244
 22-May-2017   Bhargav                    2722       Added D4G_UpdateItemOnRevise function for ImpactAnalysis_2722
 05-Jun-2017   Bhargav                    3851       Added D4G_AttachPartsAsReference function and D4G_Add_Tag_To_Array function  for ImpactAnalysis_3851
 26-Jun-2017   Chandrashekher             2244       Added D4G_CheckSignoffComments function for ImpactAnalysis_2244
 05-07-2017    Chandrashekher G           2244       Modified to remove some unnecessary Arguments and modified Function Header
20-Jul-2017    Mohammed Minam             3547       Added D4G_ValidateMapReplacementPart function for ImpactAnalysis_3547
31-Jul-2017    Mohammed Minam  		  3857       Added D4G_ModifyPlantProperty function for ImpactAnalysis_3857
31-07-2017     Bhargav		   	  3851       Modified the logic of getting the references of schedule objects in D4G_AttachPartsAsReference function
17-08-2017     Bhargav			  2722       Regression issue fix during Danfoss user testing.Modified the code of D4G_UpdateItemOnRevise function
01-07-2017     Jayant		   	  3842       Added new action handler D4G_ChangeScheduleJobName
09-11-2017     Chandrashekher G           3273       Added new Handler D4G_SendMailNotification Action Handler for send mail to all particpants involved in Workflow.
29-Aug-2017    Bhargav			  3674	     Added D4G_GetParticipantsFromSignOff function for ImpactAnalysis 3764
27-Sep-2017    Mohammed Minam 		  3857	     Added logic to skip update of property d4g_tansferred to true while Plant having Rejected Status
20-sep-2017    Bhargav			  3674	     Modified D4G_GetParticipantsFromSignOff function for ImpactAnalysis 3764 so that code includes ChangeNoticeRevision
29-10-2017     Jayant                     2944       Added new rule handler D4G-check-alternate-BOMs
10-Oct-2017    Mohammed Minam 		  3857	     Added logic to skip update of property d4g_tansferred to true while Plant doesn't have any Status
06-10-2017     Jayant                     3842       Fixed D4G_ScheduleJobChangeName
10-10-2017     Mohammed Minam Nakhuda 	  3547       Added logic to skip validation of property "Replaced by"
						     on BOM items and other object type other than Dan part revision
10-10-2017     Mohammed Minam Nakhuda 	  3547	     Added logic to skip validation if Change type is not obsolete
13-Oct-2017    Bhargav                    2745, 3446  Handler added to verify owning group
3-Nov-2017     Amruta                     3273        Fixed issue for use case  PPAP Reviewer or Manager is not selected
 ===============================================================================*/

#include <D4G_Core/D4G_EPM_Handlers.hxx>
#include <epm/epm.h>
#include <user_exits/epm_rule_handlers.h>

#include <tc/emh.h>
#include <tc/preferences.h>
#include <bom/bom.h>
#include <epm/signoff.h>
#include <epm/epm_toolkit_tc_utils.h>

#include <sa/user.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <tccore/project.h>

#include <tcinit/tcinit.h>

#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <set>
#include <sstream>
#include <vector>
#include <algorithm>
#include <map>
#include <memory>
#include <constants.hxx>

using namespace std;

#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ItkCallHeader.hxx>
#include <D4G_ErrorCodes.hxx>
#include <D4G_Handlers\ProjectHandlers.hxx>
#include <D4G_Handlers\deleteObjectHandler.hxx>
#include <D4G_Handlers\CheckPropertiesHandler.hxx>
#include <D4G_Handlers\SetPropertiesHandler.hxx>
#include <D4G_handlers\CheckForObsoleteHandler.hxx>
#include <D4G_handlers\MassUpdateReplaceItemsHandler.hxx>
#include <D4G_handlers\MassUpdatePreparationHandler.hxx>
#include <D4G_handlers\MassObsoletePreparationHandler.hxx>
#include <D4G_handlers\D4G_CheckAlternateBOMsHandlers.hxx>
#include <D4G_Core\D4G_Mail.hxx>

string version("V0.80");

typedef struct osMailDetail_s
{
	string sMailSubject;
	string sMailComments;
	string sTaskName;
	string sProcessName;
	string sDueDate;
	string sComments;
	string sInstructions;
	string sEmailFrom;
	vector<tag_t> vTargetObjs;
	vector<tag_t> vReferenceObjs;
	vector<string> mailReceipents;
}osMailDetail_t;



extern int  D4G_common_send_os_mail(osMailDetail_t mailDetail);
extern int  D4G_traverse_and_get_all_tasks(tag_t tSchedSummaryTask , vector<tag_t>* vChildSchedTasks);

/**
 * A rule handler checking Approver.
 *
 * - Approver must be set and shall not be "empty"
 * - If not_owner is set: Approver shall not be identical to Job Owner or Task Owner or Responsible Party
 *
 * Handler arguments:
 *  -not_owner
 */
EPM_decision_t D4G_RequireApprover(EPM_rule_message_t msg){
	int status = ITK_ok; //failure status
	int userError = ITK_ok; //User input error status

	//get all arguments from the msg
	bool not_owner;
	ITK_LOG(ask_handler_arg(msg.arguments,"not_owner",&not_owner));

	// retrieve user name used as Approver
	vector<tag_t> signoffattachments = get_tags_property_vector(msg.task, "signoff_attachments");
	vector<string> reviewer;
	for(int i=0; i<signoffattachments.size() && status==ITK_ok; i++){
		tag_t signoff_user_id;
		ITK_LOG(AOM_ask_value_tag(signoffattachments[i],"group_member",&signoff_user_id));
		reviewer.push_back(get_string_property(signoff_user_id, "user_name"));
	}

	// check if no Approver was given
	if (reviewer.size() == 0) {
		ITK_LOG(EMH_store_error_s1(EMH_severity_error, -1,"At least one Approver must be assigned!"));
		return EPM_nogo;
	} else if(not_owner){
	// retrieve the root task of this process
	tag_t job=NULLTAG;
	ITK_LOG(EPM_ask_job(msg.task,&job));
	ITK_LOG(AOM_refresh(job,false));
	tag_t rootTask=NULLTAG;
	ITK_LOG(EPM_ask_root_task(job,&rootTask));

	// retrieve user name of the user who started the job
	tag_t user_tag;
	char* user_id = NULL;
	ITK_LOG(AOM_ask_owner(job, &user_tag));
	ITK_LOG(POM_ask_user_id(user_tag, &user_id));
	std::string job_user(user_id);
	if(user_id) MEM_free(user_id);

	// retrieve user name of the user who is owner of the root task
	user_id = NULL;
	ITK_LOG(AOM_ask_value_tag(msg.task, "fnd0Assignee", &user_tag));
	ITK_LOG(POM_ask_user_id(user_tag, &user_id));
	std::string resp_party(user_id);
	if(user_id) MEM_free(user_id);

	// retrieve user name of the user who is responsible party of the task
	user_id = NULL;
	ITK_LOG(AOM_ask_owner(rootTask, &user_tag));
	ITK_LOG(POM_ask_user_id(user_tag, &user_id));
	std::string task_user(user_id);
	if(user_id) MEM_free(user_id);
	
	std::string approver;
	for (int i=0; i<reviewer.size();i++){
		approver =reviewer[i];
		// check if the Approver matches the user name of the job
		if (job_user.compare(approver) == 0){
			ITK_LOG(EMH_store_error_s1(EMH_severity_error, -1,
					"Approver of the Item(s) cannot be the same as the Person which starts the Workflow!"));
			return EPM_nogo;
			// check if the Approver matches the user name of the Task
		} else if(task_user.compare(approver) == 0) {
			ITK_LOG(EMH_store_error_s1(EMH_severity_error, -1,
					"Approver of the Item(s) cannot be the same as the Person which starts the Workflow!"));
			return EPM_nogo;
		} else if(resp_party.compare(approver) == 0){
			ITK_LOG(EMH_store_error_s1(EMH_severity_error, -1,
					"Approver of the Item(s) cannot be the same as the Person which selects the Approvers!"));
			return EPM_nogo;
		}
	}
	}
	//	cout << "Finished handler W4P_check_approver\n";
	return EPM_go;
}



/*********************************************************************************************************************/
/*
/*  Function Name:   D4G_CheckSignoffComments
/*
/*  Program ID:      D4G_EPM_Handlers.cxx
/*
/*  Description:     This handler is responsible for checking the signoff comments on the condition task and throw
/*                   error if comments are not provided for the specified values in handler argument.
/*
/*  INPUT PARAMS     EPM_rule_message_t msg
/*
/*  Return Value:    0 - on Success
/*                   1 - on Failure
/*
/* History
*------------------------------------------------------------------------------
*   Date         		      Name			     Task Id              Description
*
* 26-06-2017	       Chandrashekher G 		  2244               Initial Creation
* 05-07-2017           Chandrashekher G           2244               Modified to remove some unnecessary Arguments and modified Function Header
*
*************************************************************************************************************************/


EPM_decision_t D4G_CheckSignoffComments(EPM_rule_message_t msg){

	    int            status                                   = ITK_ok;
	    char* arg                                                = NULL;

	    EPM_decision_t decision = EPM_go;

	    char*   taskComments          = NULL;
	    char* taskDecision            = NULL;
	    string argValue ;
        bool isDecision;
		
		/* Get the value of the argument provided in the workflow handler*/
        ITK_LOG(ask_handler_arg( msg.arguments,"decision",&argValue,&isDecision));

        /* Get the value of the selected decision*/
	    ITK_LOG(AOM_ask_value_string(msg.task, "task_result" , &taskDecision));
        
	    	/* Split the Value String and separate it using comma and store each value in a vector */
	    vector<string> argValues =split_and_trim_to_vector_nonempty(argValue,",", " \t");

        int valCnt = argValues.size();
          for(int cnt=0; cnt<valCnt;cnt++)
          {
	         if(tc_strcmp((argValues[cnt]).c_str(),taskDecision)==0)
	           {
             /* If comments are provided for the current task decision, throw error*/
	    	    ITK_LOG(AOM_ask_value_string(msg.task, "comments" , &taskComments));
	    		    					string commValue= taskComments;
	    		    					MEM_free(taskComments);


	    		    					if ( commValue.empty())
	    		    					{
	    		    					    ITK_LOG(EMH_store_error_s1(EMH_severity_error, HAS_COMMENTS,taskDecision));
	    		    						decision =EPM_nogo;

	    		    					}
					break;

	            }
          }
          MEM_free(taskDecision);
          return decision;
          }







/*---------------------------------------------------------------------------*/

/*
 * Action Handler that creates relation between specified primary and secondary items:
 *  -relation, -primary_attachment, -primary_type, -secondary_attachment, -secondary_type, -bypass
 */

int D4G_CreateRelation( EPM_action_message_t msg ){
	int status = ITK_ok; //failure status, if this is ever not 0 we MEM_FREE and abort
	int userError = ITK_ok;

	string primary_attachment("TARGET"); //If argument not specified default to TARGET
	int primaryattach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"primary_attachment",&primary_attachment,0));
	primary_attachment= StrCaps(primary_attachment);
	if(primary_attachment=="TARGET"){primaryattach = EPM_target_attachment;
	} else if(primary_attachment=="REFERENCE"){primaryattach = EPM_reference_attachment;
	} else if(primary_attachment=="SCHEDULE_TASK"){primaryattach = EPM_schedule_task_attachment;
	} else if(!primary_attachment.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "primary_attachment", "TARGET, REFERENCE or SCHEDULE_TASK"));
	}

	string secondary_attachment("TARGET"); //If argument not specified default to TARGET
	int secondaryattach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"secondary_attachment",&secondary_attachment,0));
	secondary_attachment= StrCaps(secondary_attachment);
	if(secondary_attachment=="TARGET"){secondaryattach = EPM_target_attachment;
	} else if(secondary_attachment=="REFERENCE"){secondaryattach = EPM_reference_attachment;
	} else if(secondary_attachment=="SCHEDULE_TASK"){secondaryattach = EPM_schedule_task_attachment;
	} else if(!secondary_attachment.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "secondary_attachment", "TARGET, REFERENCE or SCHEDULE_TASK"));
	}

	string primary_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"primary_type",&primary_type,0));
	vector<string> primarytypes =split_and_trim_to_vector_nonempty(primary_type,",", " \t");
	if (primarytypes.empty()){
		primarytypes.push_back("ANY");
	}
	if(validate_type(primarytypes)){userError--;}


	string secondary_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"secondary_type",&secondary_type,0));
	vector<string> secondarytypes =split_and_trim_to_vector_nonempty(secondary_type,",", " \t");
	if (secondarytypes.empty()){
		secondarytypes.push_back("ANY");
	}
	if(validate_type(secondarytypes)){userError--;}

	string relation("");
	tag_t relationtag = 0;
	ITK_LOG(ask_handler_arg(msg.arguments,"relation",&relation,0));
	if(relation.empty()){
		EMH_store_error_s1(EMH_severity_error, UE_MISSING_ARG, "relation");
		userError--;
	} else{
		GRM_find_relation_type( relation.c_str(), &relationtag);
		if (!relationtag){
			EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "relation", "any relation name");
			userError--;
		}
	}

	string bypass_arg("FALSE"); //If argument not specified handle all types
	bool bypass = FALSE;
	ITK_LOG(ask_handler_arg(msg.arguments,"bypass",&bypass_arg,0));
	bypass_arg = StrCaps(bypass_arg);
	if (bypass_arg=="TRUE"){
		bypass=TRUE;
	} else if (bypass_arg=="FALSE"){
		bypass=FALSE;
	} else if (!bypass_arg.empty()){
		userError--;
		EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "bypass", "TRUE or FALSE");
	}

	//Collect the primary objects
	vector<tag_t> primaries;
	if(status==ITK_ok && userError==ITK_ok){
		//get the attachments
		vector<tag_t> primaryAttachments = get_attachments_vector(msg.task,primaryattach);
		//cout<<"Found "<<primaryAttachments.size()<<" primaryAttachments.\n";
		for(int i=0; status==ITK_ok && i<primaryAttachments.size(); i++){
			//cout<<"Checking primary: "<<get_string_property(primaryAttachments[i], "object_name")<<".\n";
			if (is_of_type(primaryAttachments[i], primarytypes)){
				//cout<<"Type correct.\n";
				primaries.push_back(primaryAttachments[i]);
			}
		}
	}

	//Collect the secondary objects
	vector<tag_t> secondaries;
	if(status==ITK_ok && userError==ITK_ok){
		//get the attachments
		vector<tag_t> secondaryAttachments = get_attachments_vector(msg.task,secondaryattach);
		//cout<<"Found "<<secondaryAttachments.size()<<" secondaryAttachments.\n";
		for(int i=0; status==ITK_ok && i<secondaryAttachments.size(); i++){
			//cout<<"Checking secondary: "<<get_string_property(secondaryAttachments[i], "object_name")<<".\n";
			if (is_of_type(secondaryAttachments[i], secondarytypes)){
				//cout<<"Type correct.\n";
				secondaries.push_back(secondaryAttachments[i]);
			}
		}
	}

	if(status==ITK_ok && userError==ITK_ok && !primaries.empty() && !secondaries.empty()){
		logical current = false;
		if(bypass){current = set_bypass(true);}
		tag_t newreltag;
		//		for(int j=0; status==ITK_ok && j<secondaries.size();j++){
		//			cout<<"secondary number "<<j<<": "<<get_string_property(secondaries[j], "object_name")<<".\n";
		//		}
		for(int i=0; status==ITK_ok && i<primaries.size();i++){
			for(int j=0; status==ITK_ok && j<secondaries.size();j++){
				//cout<<"Rel for secondary number "<<j<<": "<<get_string_property(secondaries[j], "object_name")<<".\n";
				newreltag=0;
				ITK_LOG(GRM_find_relation(primaries[i], secondaries[j], relationtag, &newreltag));
				if(!newreltag){
					ITK_LOG(GRM_create_relation(primaries[i], secondaries[j], relationtag, NULLTAG, &newreltag));
					if(status==ITK_ok){
						ITK_LOG(GRM_save_relation(newreltag));
					}
				}
			}
		}
		if(bypass){set_bypass(current);}
	}
	return status;
}

int D4G_deleteRelatedObject( EPM_action_message_t msg ){
	handlers::deleteObjectHandler handler(msg);
	return handler.startHandler();
}

EPM_decision_t D4G_CheckForObsolete(EPM_rule_message_t msg){
	handlers::CheckForObsoleteHandler handler(msg);
	return handler.startHandler();
}

/*
 * Action Handler that starts specified subprocess on specified related items that match specified properties.
 * Compares value found in attached objects from_property with value in object at end of search paths to_property.
 * Compares value from argument with value in object at end of search paths property.
 * Handler arguments:
 *  -template, -from_attach, -to_attach, -include_type, -search_string
 *  -from_property, -to_property, -property, -value, -allowed_status, -disallowed_status
 */

//recursive submethod
int subprocessSearchPath(tag_t objtag, vector<string> searchpath, int pos, vector<tag_t> & subprocesses,
		vector<string> fromvalues, vector<string> toproperties, vector<string> values, vector<string> properties,
		set<string> allowedstati, set<string> disallowedstati, string processname, int toattach);

int D4G_SubprocessDeepSearch( EPM_action_message_t msg ){
	int status = ITK_ok; //failure status, if this is ever not 0 we MEM_FREE and abort
	int userError = ITK_ok;

	string from_attach("TARGET"); //If argument not specified default to TARGET
	int fromattach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"from_attach",&from_attach,0));
	from_attach= StrCaps(from_attach);
	if(from_attach=="TARGET"){fromattach = EPM_target_attachment;
	} else if(from_attach=="REFERENCE"){fromattach = EPM_reference_attachment;
	} else if(from_attach=="SCHEDULE_TASK"){fromattach = EPM_schedule_task_attachment;
	} else if(!from_attach.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "from_attach", "TARGET, REFERENCE or SCHEDULE_TASK"));
	}

	string to_attach("TARGET"); //If argument not specified default to TARGET
	int toattach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"to_attach",&to_attach,0));
	to_attach= StrCaps(to_attach);
	if(to_attach=="TARGET"){toattach = EPM_target_attachment;
	} else if(to_attach=="REFERENCE"){toattach = EPM_reference_attachment;
	} else if(!to_attach.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "to_attach", "TARGET or REFERENCE"));
	}

	string include_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"include_type",&include_type,0));
	vector<string> includetypes =split_and_trim_to_vector_nonempty(include_type,",", " \t");
	if (includetypes.empty()){
		includetypes.push_back("ANY");
	}
	if(validate_type(includetypes)){userError--;}

	string exclude_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"exclude_type",&exclude_type,0));
	vector<string> excludetypes =split_and_trim_to_vector_nonempty(exclude_type,",", " \t");
	if(validate_type(excludetypes)){userError--;}

	string search_string(""); //If argument not set use targets
	ITK_LOG(ask_handler_arg(msg.arguments,"search_string",&search_string,0));
	vector<string> searchpath =split_and_trim_to_vector_nonempty(search_string,",.", " ");
	if(searchpath.size() %2!=0){
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE,
				"search_string", "an even number of dot separated values"));
		userError--;
	}

	string templatename("");
	ITK_LOG(ask_handler_arg(msg.arguments,"template",&templatename,0));
	if(templatename==""){
		ITK_LOG(EMH_store_error_s1(EMH_severity_error, UE_MISSING_ARG, "template"));
		userError--;
	}

	//Pairs of compare values. Have to match in number. If a pair is not set we ignore it.
	string fromproperty("");
	ITK_LOG(ask_handler_arg(msg.arguments,"from_property",&fromproperty,0));
	vector<string> fromproperties =split_and_trim_to_vector_nonempty(fromproperty,",", " ");

	string toproperty("");
	ITK_LOG(ask_handler_arg(msg.arguments,"to_property",&toproperty,0));
	vector<string> toproperties =split_and_trim_to_vector_nonempty(toproperty,",", " ");

	if(fromproperties.size()!=toproperties.size()){
		userError--;
		ITK_LOG(EMH_store_error(EMH_severity_error, UE_TO_FROM_NR));
	}

	string property("");
	ITK_LOG(ask_handler_arg(msg.arguments,"property",&property,0));
	vector<string> properties =split_and_trim_to_vector_nonempty(property,",", " ");

	string value("");
	ITK_LOG(ask_handler_arg(msg.arguments,"value",&value,0));
	vector<string> values =split_and_trim_to_vector_nonempty(value,",", " ");

	if(properties.size()!=values.size()){
		userError--;
		ITK_LOG(EMH_store_error(EMH_severity_error, UE_PROP_VALUE_NR));
	}

	//Status checking is mutually exclusive
	string allowedstatus("");
	ITK_LOG(ask_handler_arg(msg.arguments,"allowed_status",&allowedstatus,0));
	set<string> allowedstati =split_and_trim_to_set(allowedstatus,",", " ");

	string disallowedstatus("");
	ITK_LOG(ask_handler_arg(msg.arguments,"disallowed_status",&disallowedstatus,0));
	set<string> disallowedstati= split_and_trim_to_set(disallowedstatus,",", " ");

	if(!allowedstati.empty()&& !disallowedstati.empty()){
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_EXCLUSIVE_ARGS,
				"allowed_status", "disallowed_status"));
		userError--;
	}

	if(status==ITK_ok && userError==ITK_ok){
		vector<string> fromvalues;
		//get the attachments
		vector<tag_t> attachments = get_attachments_vector(msg.task,fromattach);
		vector<tag_t> subprocesses;
		for(int i=0; status==ITK_ok && i<attachments.size(); i++){
			if(is_of_type(attachments[i], includetypes)&&!is_of_type(attachments[i], excludetypes)){
				ITK_LOG(AOM_refresh(attachments[i], false));
				fromvalues.clear();
				for(int j=0; j<fromproperties.size();j++){
					fromvalues.push_back(get_display_property(attachments[i], fromproperties[j]));
				}
				int pos =0;
				ITK_LOG(subprocessSearchPath(attachments[i], searchpath, pos, subprocesses,
						fromvalues, toproperties, values, properties,
						allowedstati, disallowedstati,
						templatename, toattach));
			}
		}
		vector<tag_t> roottasks;
		vector<int> attachtypes;
		for(int i=0; i<subprocesses.size(); i++){
			tag_t workflowtag;
			ITK_LOG(EPM_ask_root_task(subprocesses[i], &workflowtag));
			roottasks.push_back(workflowtag);
			attachtypes.push_back(EPM_interprocess_task_attachment);
		}
		if(subprocesses.size()>0){
			tag_t jobtag = NULLTAG;
			ITK_LOG(EPM_ask_job(msg.task, &jobtag));
			ITK_LOG(EPM_attach_sub_processes(jobtag,  subprocesses.size(), &subprocesses[0]));

			ITK_LOG(EPM_add_attachments(msg.task, roottasks.size(), &roottasks[0], &attachtypes[0]));
		}
		//		for(int i=0; i<subprocesses.size();i++){
		//			ITK_CALL(EPM_trigger_action(subprocesses[i], EPM_complete_action, "Sample comment"));
		//			//			1. Create the sub-process using EPM_create_process_deferred_start
		//			//			2. Attach the created sub-process to parent process using
		//			//					EPM_attach_sub_processes( parentProcessTag, 1, &subProcessTag );
		//			//			3. Add the task dependency using EPM_add_attachments( parentTask, 1,
		//			//					&dependentSubProcTask, &attachmentTypes ); where int attachmentTypes =
		//			//					EPM_interprocess_task_attachment.
		//			//			4. Start the sub-process using EPM_trigger_action( rootSubProcTaskTag,
		//			//					EPM_complete_action, "Sample comment" )
		//		}
	}
	return status;
}

/*
 * Recursive submethod that goes one step closer to the end of the searchpath and if it has reached the end
 * starts workflow template with objects that match requirements as target.
 */
int subprocessSearchPath(tag_t objtag, vector<string> searchpath, int pos, vector<tag_t> & subprocesses,
		vector<string> fromvalues, vector<string> toproperties, vector<string> values, vector<string> properties,
		set<string> allowedstati, set<string> disallowedstati, string processname, int toattach){
	int status = ITK_ok;
	//Decide if we should call recursively to go deeper or if we have reached the end of the searchpath
	if(pos<searchpath.size()){
		//we call recursively on all items that fit the next step of the searchpath
		string property = searchpath[pos];
		string type = searchpath[pos+1];
		int found = ask_prop_exists(objtag, (char*) property.c_str());
		if(found){
			ITK_LOG(AOM_refresh(objtag, false));
			vector<tag_t> targets = get_tags_property(objtag, (char*) property.c_str());
			//Go through items in next step as long as nothing goes wrong
			for(auto itTargets = targets.begin(); status==ITK_ok && itTargets!=targets.end(); itTargets++){
				if(is_of_type(*itTargets, type) ){
					//Set status to outcome of recursive request
					ITK_LOG(subprocessSearchPath(*itTargets, searchpath, pos+2, subprocesses,
							fromvalues, toproperties, values, properties,
							allowedstati, disallowedstati, processname, toattach));
				}
			}
		}
	} else{
		//assume match until first mismatch
		ITK_LOG(AOM_refresh(objtag, false));
		bool match=TRUE;
		for(int i=0; match && i<fromvalues.size(); i++){
			string propvalue = get_display_property(objtag, toproperties[i]);
			if(fromvalues[i]!=propvalue){
				match=FALSE;
			}
		}
		for(int i=0; match && i<values.size(); i++){
			string propvalue = get_display_property(objtag, properties[i]);
			if(values[i]!=propvalue){
				match=FALSE;
			}
		}

		if(!allowedstati.empty() || !disallowedstati.empty()){
			vector<tag_t> stati = get_tags_property_vector(objtag, "release_status_list");
			if (stati.size()==0	&& (!allowedstati.count("NONE") || disallowedstati.count("NONE") ) ){
				match=false;
			}
			if (stati.size()>0 && disallowedstati.count("ANY") ){
				match=false;
			}
			if (!allowedstati.count("ANY") ){
				for (int i=0; match && i<stati.size(); i++){
					string name = get_string_property(stati[i], "object_name");
					if (!allowedstati.empty()
							&& find(allowedstati.begin(), allowedstati.end(), name) == allowedstati.end()){
						match=false;
					}
					if (!disallowedstati.empty()
							&& find(disallowedstati.begin(), disallowedstati.end(), name)!=disallowedstati.end()){
						match=false;
					}
				}
			}
		}

		if(!allowedstati.empty() || !disallowedstati.empty()){
			vector<tag_t> stati = get_tags_property_vector(objtag, "release_status_list");
			//			cout<<"Found "<<stati.size()<<" stati.\n";
			if (stati.size()==0
					&& ((!allowedstati.empty() && !allowedstati.count("NONE") ) || disallowedstati.count("NONE") ) ){
				//				cout<<"No stati found and that is not OK.\n";
				match=false;
			}
			if (stati.size()>0 && disallowedstati.count("ANY") ){
				//				cout<<"Many stati found and that is not OK.\n";
				match=false;
			}
			if (match && !allowedstati.count("ANY") ){
				//				cout<<"Some stati found and that is to be checked.\n";
				for (int i=0; match && i<stati.size(); i++){
					string name = get_string_property(stati[i], "object_name");
					//					cout<<"Found status "<<name<<"\n";
					if (!allowedstati.empty()
							&& !allowedstati.count(name)){
						match=false;
					}
					if (disallowedstati.count(name)){
						match=false;
					}
				}
			}
		}

		if(match){
			tag_t jobtag= start_sub_process(objtag, processname, toattach);
			subprocesses.push_back(jobtag);
		}
	}
	return status;
}

/*
 * Action Handler that sets the item_revision_id to the next major revision
 * (that is revision ids with format AA...nn... will be set to AA...+1)
 * If revision id is invalid or object_type is not a Revision throws an exception
 * Handler arguments: -to_attach, -include_type
 */
int D4G_SetMajorRevision( EPM_action_message_t msg ){
	int status = ITK_ok; //failure status, if this is ever not 0 we MEM_FREE and abort
	int userError = ITK_ok;

	//get all arguments from the msg
	string to_attach("TARGET"); //If argument not specified default to TARGET
	int attach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"to_attach",&to_attach,0));
	to_attach= StrCaps(to_attach);
	if(to_attach=="TARGET"){attach = EPM_target_attachment;
	} else if(to_attach=="REFERENCE"){attach = EPM_reference_attachment;
	} else if(!to_attach.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "to_attach", "TARGET or REFERENCE"));
	}

	string include_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"include_type",&include_type,0));
	vector<string> includetypes =split_and_trim_to_vector_nonempty(include_type,",", " \t");
	if (includetypes.empty()){
		includetypes.push_back("ANY");
	}
	if(validate_type(includetypes)){userError--;}

	string exclude_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"exclude_type",&exclude_type,0));
	vector<string> excludetypes =split_and_trim_to_vector_nonempty(exclude_type,",", " \t");
	if(validate_type(excludetypes)){userError--;}


	//	cout<<"User input done with status "<<status<<" and "<<userError<<".\n";
	if(status==ITK_ok && userError==ITK_ok){
		logical current = set_bypass(TRUE);

		//get the attachments
		vector<tag_t> attachments = get_attachments_vector(msg.task, attach);
		//Set the item_revision_id to the next major revision on all targeted revisions.
		string revid("");
		string newrev;
		int pos;
		for(int i=0; status==ITK_ok && userError==ITK_ok && i<attachments.size(); i++){
			//Filter types and only handle revisions
			if(is_of_type(attachments[i], includetypes)&&!is_of_type(attachments[i], excludetypes)
					&&is_of_type(attachments[i], "ItemRevision")){
				ITK_LOG(AOM_refresh(attachments[i], false));
				revid = get_string_property(attachments[i],"item_revision_id");
				newrev.clear();
				//check if revid is only numbers
				pos=0;
				while(revid[pos]>='0' && revid[pos]<='9'){
					pos++;
				}
				if(revid.size()==pos){
					newrev = "A";
				}

				//check if revid has format AA...nn... and increment alphabetical head and use as newrev
				if(newrev.size()==0){
					pos=0;
					while(revid[pos]>='A' && revid[pos]<='Z'){
						pos++;
					}
					for(int j=pos-1; j>=0 && newrev.size()==0; j--){
						if(revid[j]<'Z'){
							revid[j]++;
							newrev= string(revid, 0, pos);
						} else{
							revid[j]='A';
							if(j==0){
								newrev= string(revid, 0, pos);
								newrev.push_back('A');
							}
						}
					}

					//Check if tail is only numbers otherwise store error
					while(revid[pos]>='0' && revid[pos]<='9'){
						pos++;
					}
					if(pos<revid.size()){
						status = UE_ILLEGAL_REVID;
						ITK_LOG(EMH_store_error_s1(EMH_severity_error, UE_ILLEGAL_REVID, revid.c_str()));
						newrev.clear();
					}
				}
				//
				if(newrev.size()>0){
					vector<tag_t> revisions = get_tags_property_vector(attachments[i], "revision_list");
					bool revCollision = false;
					for(int k=0; k<revisions.size()&&!revCollision;k++){
						if(newrev==get_string_property(revisions[k], "item_revision_id")){
							revCollision=true;
							string message("Attempted to create duplicate Major revision '" +newrev
									+ "' from " +get_string_property(attachments[i],"object_string")+ ".");
									status = -1;
							ITK_CALL(EMH_store_error_s1(EMH_severity_error, -1, message.c_str()));
						}
					}
					if(!revCollision){
						string currentRevId = get_string_property(attachments[i],"item_revision_id");
						ITK_LOG(AOM_lock(attachments[i]));
						ITK_LOG(AOM_assign_string(attachments[i], "item_revision_id", newrev.c_str()));
						ITK_LOG(AOM_assign_logical(attachments[i], "d4g_isMajorRevision", true));
						ITK_LOG(AOM_assign_string(attachments[i], "d4g_wasMinorRevision", currentRevId.c_str()));
						vector<string> prefvalues = get_prefs("D4G_MajorRevisionHandler_RenameRelations");
						for (int k=0; k<prefvalues.size(); k++){
							cout<<"Renaming Datasets related via "<<prefvalues[k]<<":\n";
							ITK_LOG(update_dataset_names(attachments[i], prefvalues[k], currentRevId));
						}
						//9-5-2017 : Bipin : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
						//ITK_LOG(AOM_save(attachments[i]));
						ITK_LOG(AOM_save_with_extensions(attachments[i]));
					}
				}
			}
		}
		set_bypass(current);
	}

	return status;
}


/*
 * Rule Handler that checks if all PPAP Schedules connected to a D4G_ChangeMasterRevision
 * with the same D4G_Plant value as the D4G_ChangeMasterRevision are finished.
 * Handler arguments: -to_attach, -include_type, -status
 */
#define STATUS_COMPLETE 1
#define STATUS_PREPRODUCTION 2
EPM_decision_t checkPreProd(tag_t task);

EPM_decision_t D4G_CheckPPAP( EPM_rule_message_t msg )
{
	EPM_decision_t decision = EPM_go;
	int status = ITK_ok; //failure status, if this is ever not ITK_ok we MEM_FREE and abort
	int userError = ITK_ok;

	char* solutionRelType = "CMHasSolutionItem";
	char* plantPropName = "d4g_Plant";

	//get all arguments from the msg
	string to_attach("TARGET"); //If argument not specified default to TARGET
	int toattach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"to_attach",&to_attach,0));
	to_attach= StrCaps(to_attach);
	if(to_attach=="TARGET"){toattach = EPM_target_attachment;
	} else if(to_attach=="REFERENCE"){toattach = EPM_reference_attachment;
	} else if(to_attach=="SCHEDULE_TASK"){toattach = EPM_schedule_task_attachment;
	} else if(!to_attach.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "to_attach", "TARGET, REFERENCE or SCHEDULE_TASK"));
	}

	string include_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"include_type",&include_type,0));
	vector<string> includetypes =split_and_trim_to_vector_nonempty(include_type,",", " \t");
	if (includetypes.empty()){
		includetypes.push_back("ANY");
	}
	if(validate_type(includetypes)){userError--;}

	string exclude_type(""); //If argument not specified handle all types
	ITK_LOG(ask_handler_arg(msg.arguments,"exclude_type",&exclude_type,0));
	vector<string> excludetypes =split_and_trim_to_vector_nonempty(exclude_type,",", " \t");
	if(validate_type(excludetypes)){userError--;}

	string requiredStatus("COMPLETE");
	int mode = STATUS_COMPLETE;
	ITK_LOG(ask_handler_arg(msg.arguments, "status", &requiredStatus, 0));
	requiredStatus= StrCaps(requiredStatus);
	if(requiredStatus=="COMPLETE"){
		mode = STATUS_COMPLETE;
	} else if(requiredStatus=="PREPRODUCTION"){
		mode = STATUS_PREPRODUCTION;
	} else{
		userError = -1;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE,
				"status", "COMPLETE and PREPRODUCTION"));
	}

	//get the target items
	int targetcount =0;
	tag_t* targets = NULL; //MEM_FREE this
	if(status==ITK_ok && userError == ITK_ok){
		ITK_LOG(EPM_ask_attachments( msg.task, toattach, &targetcount, &targets));
	}

	int solutioncount=0;
	tag_t* solutionitems = NULL;         /* MEM_FREE this */
	int schedulecount=0;
	tag_t* schedules     = NULL;         /* MEM_FREE this */
	tag_t sumtask;
	int taskcount = 0;
	tag_t* tasks         = NULL;         /* MEM_FREE this */

	//for all target items that are in -include_types
	for(int i=0; i<targetcount && status==ITK_ok && userError==ITK_ok && decision != EPM_nogo; i++){
		if(is_of_type(targets[i], includetypes)&&!is_of_type(targets[i], excludetypes) ){
			string type = get_string_property(targets[i], "object_type");
			//find all Part Revisions in Solution Items
			if(status==ITK_ok && !ask_prop_exists(targets[i], solutionRelType)){
				EMH_store_error_s2(EMH_severity_error, UE_TYPE_NO_PROP, type.c_str(), solutionRelType);
				userError--;
			} else if(status==ITK_ok && mode==STATUS_COMPLETE && !ask_prop_exists(targets[i], plantPropName)){
				EMH_store_error_s2(EMH_severity_error, UE_TYPE_NO_PROP, type.c_str(), plantPropName);
				userError--;
			} else if (status==ITK_ok && userError==ITK_ok){
				AOM_refresh(targets[i], false);
				//9-5-2017 : Bipin : Deprecated API -"AOM_get_value_tags", replaced with "AOM_ask_value_tags"
				//ITK_LOG(AOM_get_value_tags(targets[i], solutionRelType, &solutioncount, &solutionitems));
				ITK_LOG(AOM_ask_value_tags(targets[i], solutionRelType, &solutioncount, &solutionitems));
				for(int j=0; status==ITK_ok && j<solutioncount && decision != EPM_nogo; j++){
					type = get_string_property(solutionitems[j], "object_type");
					if(status==ITK_ok && type=="D4G_DanPartRevision"){
						AOM_refresh(solutionitems[j], false);
						//Find all PPAP Schedules
						//9-5-2017 : Bipin : Deprecated API -"AOM_get_value_tags", replaced with "AOM_ask_value_tags"
						//ITK_LOG(AOM_get_value_tags(solutionitems[j], "CMHasWorkBreakdown", &schedulecount, &schedules));
						ITK_LOG(AOM_ask_value_tags(solutionitems[j], "CMHasWorkBreakdown", &schedulecount, &schedules));
						for(int k=0; status==ITK_ok && k<schedulecount && decision != EPM_nogo; k++){
							ITK_LOG(AOM_refresh(schedules[k], false));

							//If mode is STATUS_COMPLETE check that the PPAP Schedules
							//with the same plant as our Change Master are complete
							if(status==ITK_ok && mode==STATUS_COMPLETE){
								string cmplant = get_string_property(targets[i], plantPropName);
								string ppapplant = get_string_property(schedules[k], plantPropName);
								if(cmplant==ppapplant){
									//Robert - 18/7/2017 - fnd0sum_rollup_status property is obsolete in TC 11.2 onwards. Replaced with fnd0SSTStatus.
									//string ppapstatus = get_string_property(schedules[k], "fnd0sum_rollup_status");
									string ppapstatus = get_string_property(schedules[k], "fnd0SSTStatus");
									//if(ppapstatus !="complete" && ppapstatus !="Disabled"){ //changed the string 'complete' to 'Complete'.
									if(ppapstatus !="Complete" && ppapstatus !="Disabled"){
										decision = EPM_nogo;
									}
								}
							}

							//If mode is STATUS_PREPRODUCTION
							//check recursively that all PreProduction relevant PPAP Tasks are complete or disabled
							if(status==ITK_ok && mode==STATUS_PREPRODUCTION){
								//Robert - 18/7/2017 - sch_summary_task property is obsolete in TC 11.2 onwards. Replaced with fnd0SummaryTask.
								//ITK_LOG(AOM_ask_value_tag(schedules[k], "sch_summary_task", &sumtask));
								ITK_LOG(AOM_ask_value_tag(schedules[k], "fnd0SummaryTask", &sumtask));
								if(status==ITK_ok){
									AOM_refresh(sumtask, false);
									ITK_LOG(AOM_ask_value_tags(sumtask, "child_task_taglist", &taskcount, &tasks));
								}
								for(int m=0; status==ITK_ok && m<taskcount &&  decision != EPM_nogo; m++){
									decision = checkPreProd(tasks[m]);
								}
							}
						}
					}
				}
			}
		}
	}

	SAFE_SM_FREE( tasks );
	SAFE_SM_FREE( schedules );
	SAFE_SM_FREE( solutionitems );
	SAFE_SM_FREE( targets );
	return decision;
}

EPM_decision_t checkPreProd(tag_t task){
	AOM_refresh(task, false);
	int status = ITK_ok;
	string taskstatus = get_string_property(task, "fnd0status");
	if(status==ITK_ok && taskstatus=="complete"){
		return EPM_go;
	}

	string type= get_string_property(task, "object_type");
	if(status==ITK_ok && type=="D4G_PPAPTask"){
		bool isRelevant = FALSE;
		//9-5-2017 : Bipin : Deprecated API -"AOM_get_value_logical", replaced with "AOM_ask_value_logical"
		//ITK_LOG(AOM_get_value_logical(task, "d4g_PreProdRelevant", &isRelevant));
		ITK_LOG(AOM_ask_value_logical(task, "d4g_PreProdRelevant", &isRelevant));
		if(status==ITK_ok && isRelevant && taskstatus!="complete" && taskstatus!="Disabled"){
			return EPM_nogo;
		}
	}
	if (status==ITK_ok){
		vector<tag_t> subtasks =get_tags_property(task, "child_task_taglist");
		for(std::vector<tag_t>::iterator it=subtasks.begin();it!=subtasks.end() && status==ITK_ok;++it){
			if(checkPreProd(*it)==EPM_nogo){
				return EPM_nogo;
			}
		}
	}
	if(status!=ITK_ok){
		EMH_store_error_s1(EMH_severity_error, -1, "TC error while searching through task structure.");
		return EPM_nogo;
	}
	return EPM_go;
}

/*
 * Rule Handler that compares Workflow Initiator with specified by argument -allowed_initiators
 * Collects these initiators from Participants list
 * Handler arguments: -allowed_initiator
 */
EPM_decision_t D4G_CheckCurrentUser(EPM_rule_message_t msg)
{
	EPM_decision_t ruleCheck = EPM_nogo;
	int status =0; //failure status, if this is ever not 0 we MEM_FREE and abort

	//make an array of all allowed Initiators of the workflow
	int nrAI = 7;
	char ** initiatorTypes = (char**) MEM_alloc (nrAI*sizeof(char *));  /* MEM_FREE this */
	initiatorTypes[0] = "$REQUESTOR";
	initiatorTypes[1] = "$ANALYST";
	initiatorTypes[2] = "$CHANGE_SPECIALIST1";
	initiatorTypes[3] = "$CHANGE_SPECIALIST2";
	initiatorTypes[4] = "$CHANGE_SPECIALIST3";
	initiatorTypes[5] = "$CHANGE_REVIEW_BOARD";
	initiatorTypes[6] = "$CHANGE_IMPLEMENTATION_BOARD";

	//get tag of current user
	char* ownername      = NULL;         /* MEM_FREE this */
	tag_t ownertag       = NULL;

	if(status==ITK_ok){
		ITK_LOG(
				POM_get_user( &ownername, &ownertag ));
	}

	//	cout << "Owner is called " << ownername << " with tag " << ownertag << "\n";
	SAFE_SM_FREE( ownername );

	/* loop through the arguments and collect the allowed initiator tags */
	char* arg            = NULL;
	char* flag           = NULL;         /* MEM_FREE this */
	char* value          = NULL;         /* MEM_FREE this */
	char* token          = NULL;         /* MEM_FREE this */
	int gmcount=0;
	tag_t* gmtags        = NULL;         /* MEM_FREE this */
	int rpcount;
	tag_t* rptags        = NULL;         /* MEM_FREE this */
	tag_t partag;
	int allowedcount=0;
	tag_t* initiatortags = NULL;         /* MEM_FREE this */

	int arg_cnt = TC_number_of_arguments( msg.arguments );
	if(status==ITK_ok){
		ITK_LOG(
				EPM_setup_parser( msg.task ));
	}
	for ( int i = 1; i <= arg_cnt && status==ITK_ok; i++ )
	{
		arg = TC_next_argument( msg.arguments );

		ITK_LOG(
				ITK_ask_argument_named_value( (const char*)arg,
						&flag, &value));

		if (status==ITK_ok && tc_strcmp( flag , "allowed_initiator" )==0 )
		{
			token = tc_strtok(value, " ,");
			while (token && status==ITK_ok){
				if ( StringInArray(token, initiatorTypes,nrAI) )
				{
					ITK_LOG(
							EPM_ask_participants_for_token(
									msg.task, token,  &gmcount, &gmtags, &rpcount, &rptags));
					if(gmcount>0){
						allowedcount += gmcount;
						initiatortags =
								(tag_t *) MEM_realloc((initiatortags), (allowedcount)*sizeof(tag_t));
						for (int j=0;j<gmcount && status==ITK_ok;j++){
							ITK_LOG(
									//9-5-2017 : Bipin : Deprecated API -"AOM_get_value_tag", replaced with "AOM_ask_value_tag"
									//AOM_get_value_tag(gmtags[j], "user", &partag));
									AOM_ask_value_tag(gmtags[j], "user", &partag));
							initiatortags[allowedcount-gmcount+j]= partag;
						}
					}
				}
				token = tc_strtok(NULL, " ,");
			}
		}
	}
	SAFE_SM_FREE( initiatorTypes );
	SAFE_SM_FREE( token );
	SAFE_SM_FREE( value );
	SAFE_SM_FREE( flag );
	SAFE_SM_FREE( gmtags );
	SAFE_SM_FREE( rptags );

	//	char* username = NULL;
	// Compare allowed initiatortags to current user tag and send EPM_go if match is found
	if(status==ITK_ok){
		for (int i=0; i<allowedcount; i++){
			//			ITK_LOG(
			//					AOM_get_value_string(initiatortags[i], "os_username", &username));
			//			cout << "Initiator " << username << " with tag " << initiatortags[i] << "\n";
			if(initiatortags[i]==ownertag){
				ruleCheck = EPM_go;
			}
		}
	}

	SAFE_SM_FREE( initiatortags );

	if(status==ITK_ok){return ruleCheck;}
	else {
		EMH_store_error( EMH_severity_error, status );
		return EPM_nogo;
	}
}

/*
 * This workflow handler is used to create baselines on ItemRevisions.
 *
 * handler arguments:
 *
 * -to_attach :
 * 		Attachment type where to get the attachments from.
 * 		possible attachmentTypes are TARGET and REFERENCE
 * -include_Type :
 *      "," and whitespace separated list of real name types.
 *		Only attachments of those types will be considered in this handler.
 * -set_rev_id :
 *		Boolean value. If it is set to FALSE the revision Id of the baseline revision will be the object_name of the 
 *		schedule attachment. If that revision ID already exists a counter will be added to the object_name.
 * 		If the parameter is not set to FALSE the Revision Id will be set automatically.
 * -read_rev_id_from (optional):
 * 		the only possible value is SCHEDULE_TASK_NAME. Setting this parameter has no effect currently.
 * -to_attach_new_rev :
 *		Possible values are TARGET and REFERENCE. This parameter defines where to attach the newly created baseline revision.
 * -baseline_proc_name :
 * 		Name of the workflow process for setting a status afterwards. This workflow can only have the start and finish tasks.
 */
int D4G_baseline_PDP_item_revision( EPM_action_message_t msg ){
	logical current = set_bypass(TRUE);
	int status=ITK_ok;
	int userError=ITK_ok;
	tag_t rootTask=NULLTAG;
	ITK_LR_BYPASS_RESET(EPM_ask_root_task(msg.task,&rootTask),current);
	// reading worklow parameters
	std::string to_attach("");
	ITK_LR_BYPASS_RESET(ask_handler_arg(msg.arguments,"to_attach",&to_attach,0),current);
	std::string include_type("");
	ITK_LR_BYPASS_RESET(ask_handler_arg(msg.arguments,"include_type",&include_type,0),current);
	std::unique_ptr<std::set<std::string>> types(split(include_type,", \t"));
	std::string set_rev_id("");
	ITK_LR_BYPASS_RESET(ask_handler_arg(msg.arguments,"set_rev_id",&set_rev_id,0),current);
	std::string read_rev_id_from("");
	ITK_LR_BYPASS_RESET(ask_handler_arg(msg.arguments,"read_rev_id_from",&read_rev_id_from,0),current);
	std::string to_attach_new_rev("");
	ITK_LR_BYPASS_RESET(ask_handler_arg(msg.arguments,"to_attach_new_rev",&to_attach_new_rev,0), current);
	std::string baseline_proc_name("");
	ITK_LR_BYPASS_RESET(ask_handler_arg(msg.arguments,"baseline_proc_name",&baseline_proc_name,0),current);
	// validating workflow parameters
	if(types->empty()){
		userError=-1;
		ITK_LR_BYPASS_RESET(EMH_store_error_s1(EMH_severity_error, UE_MISSING_ARG,"include_type"), current);
	}
	if(to_attach.empty()){
		userError=-1;
		ITK_LR_BYPASS_RESET(EMH_store_error_s1(EMH_severity_error, UE_MISSING_ARG,"to_attach"), current);
	}
	if(read_rev_id_from.empty()){
		userError=-1;
		ITK_LR_BYPASS_RESET(EMH_store_error_s1(EMH_severity_error, UE_MISSING_ARG,"read_rev_id_from"),current);
	}
	if(to_attach_new_rev.empty()){
		userError=-1;
		ITK_LR_BYPASS_RESET(EMH_store_error_s1(EMH_severity_error, UE_MISSING_ARG,"to_attach_new_rev"),current);
	}
	if(baseline_proc_name.empty()){
		userError=-1;
		ITK_LR_BYPASS_RESET(EMH_store_error_s1(EMH_severity_error, UE_MISSING_ARG,"baseline_proc_name"), current);
	}
	// read schedule task attachment
	vector<tag_t> schedule_attachments = get_attachments_vector(rootTask,EPM_schedule_task_attachment);
	tag_t schedule=NULLTAG;
	// only one schedule task attachment is expected
	if(schedule_attachments.size()>0){
		schedule=schedule_attachments[0];
	}
	if(status==ITK_ok && userError==ITK_ok){
		// parsing the to_attach workflow parameter
		vector<tag_t> attachments;
		if(to_attach=="TARGET"){
			attachments=get_attachments_vector(msg.task,EPM_target_attachment);
		} else if(to_attach=="REFERENCE"){
			attachments=get_attachments_vector(msg.task,EPM_reference_attachment);
		}
		// iterate through all attachments
		for(int i=0;i<attachments.size() && status==ITK_ok && userError==ITK_ok;i++){
			// only the defined types are considered
			if(types->find(get_type_name(attachments[i])) != types->end()){
				// build jobName for baseline function. 
				std::string source_rev_id(get_string_property(attachments[i],"item_revision_id"));
				std::string source_rev_desc(get_string_property(attachments[i],"object_desc"));
				std::string jobName("Milestone baseline "+get_string_property(attachments[i],"item_id")+source_rev_id);
				// preparing baseline by locking the item.
				tag_t baseline_rev=NULLTAG;
				tag_t item=NULLTAG;
				ITK_LR_BYPASS_RESET(AOM_ask_value_tag(attachments[i],"items_tag",&item), current);
				ITK_LR_BYPASS_RESET(AOM_lock(item), current);
				if(set_rev_id!="FALSE"){
					// if the baseline Item Revision Id shall not be set automatically, we expect a schedule task attachment.
					if(schedule==NULLTAG){
						userError=-1;
						ITK_LR_BYPASS_RESET(EMH_store_error_s1(EMH_severity_error, -1,"There must be at least one Schedule related."), current);
						break;
					}
					// compute the new revision id
					std::string new_revid(get_string_property(schedule,"object_name"));
					int count=1;
					std::string revIdToSet(new_revid);
					vector<tag_t> revisions =get_tags_property(item,"displayable_revisions");
					bool retest=false;
					// if a revision with this revision id already exists, add a counter.
					do{
						for(std::vector<tag_t>::iterator jt=revisions.begin();jt!=revisions.end();++jt){
							std::string revisionId(get_string_property(*jt,"item_revision_id"));
							if(revisionId==revIdToSet){
								// increase counter in case of already existing revision id.
								std::stringstream buffer;
								buffer << new_revid;
								buffer << " ";
								buffer << count;
								revIdToSet=buffer.str();
								count++;
								retest=true;
								break;
							} else {
								retest=false;
							}
						}

					} while(retest==true);
					// start baseline function
					int deepCopiedObjCount;
					tag_t* deepCopiedObjs;
					ITK_LR_BYPASS_RESET(ITEM_baseline_rev(attachments[i],revIdToSet.c_str(),source_rev_desc.c_str(),baseline_proc_name.c_str(),
							jobName.c_str(),"Automatic milestone baseline",&baseline_rev,&deepCopiedObjCount,
							&deepCopiedObjs),current);
					SAFE_SM_FREE(deepCopiedObjs);
					if(status != ITK_ok){
						set_bypass(current);
						return status;
					}
				} else {
					// start baseline function
					int deepCopiedObjCount;
					tag_t* deepCopiedObjs;
					ITK_LR_BYPASS_RESET(ITEM_baseline_rev(attachments[i],NULL,source_rev_desc.c_str(),baseline_proc_name.c_str(),
							jobName.c_str(),"Automatic milestone baseline",&baseline_rev,&deepCopiedObjCount,
							&deepCopiedObjs),current);
					SAFE_SM_FREE(deepCopiedObjs);
					if(status != ITK_ok){
						set_bypass(current);
						return status;
					}
				}
				// save and unlock item
				//9-5-2017 : Bipin : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
				//ITK_LR_BYPASS_RESET(AOM_save(item), current);
				ITK_LR_BYPASS_RESET(AOM_save_with_extensions(item), current);
				ITK_LR_BYPASS_RESET(AOM_unlock(item),current);
				// attach newly created baseline revision to workflow process
				if(to_attach_new_rev=="TARGET"){
					int attachment_type[1] = {EPM_target_attachment};
					ITK_LR_BYPASS_RESET(EPM_add_attachments(rootTask,1,&baseline_rev,attachment_type),current);
				} else if(to_attach_new_rev=="REFERENCE"){
					int attachment_type[1] = {EPM_reference_attachment};
					ITK_LR_BYPASS_RESET(EPM_add_attachments(rootTask,1,&baseline_rev,attachment_type), current);
				}
			}
		}
	}
	set_bypass(current);
	return userError;
}

EPM_decision_t D4G_CheckPDPMilestones( EPM_rule_message_t msg ){
	int status = ITK_ok; //failure status, if this is ever not 0 we MEM_FREE and abort
	int userError = ITK_ok;
	char** milestones = NULL;
	int count =0;

	//Check if "to_attach" argument exists and if value is "TARGET" or "REFERENCE"
	string to_attach("TARGET"); //If argument not specified default to TARGET
	int toattach = EPM_target_attachment;
	ITK_LOG(ask_handler_arg(msg.arguments,"to_attach",&to_attach,0));
	to_attach= StrCaps(to_attach);
	if(to_attach=="TARGET"){
		toattach = EPM_target_attachment;
	} else if(to_attach=="REFERENCE"){
		toattach = EPM_reference_attachment;
	} else if(!to_attach.empty()){
		userError--;
		ITK_LOG(EMH_store_error_s2(EMH_severity_error, UE_WRONG_VALUE, "to_attach", "TARGET or REFERENCE"));
	}

	/*collect the milestones from the given preference*/
	string pref_req_milestones("");
	ITK_LOG(ask_handler_arg(msg.arguments,"pref_req_milestones",&pref_req_milestones,0));
	if(pref_req_milestones=="")
	{
		userError--;
		ITK_LOG(EMH_store_error_s1(EMH_severity_error, UE_WRONG_VALUE, "pref_req_milestones argument is missing"));
	}else
	{
		//Read from pref into milestones vector

		PREF_ask_char_values(pref_req_milestones.c_str(), &count, &milestones);
		if(count<1)
		{
			userError--;
			ITK_LOG(EMH_store_error_s1(EMH_severity_error, UE_WRONG_VALUE, "pref_req_milestones has no values"));
		}
	}
	/*return Errors if there is something not ok with arguments*/
	if( status || userError ){
		SAFE_SM_FREE(milestones);
		return EPM_nogo;
	}

	//Collect the object tags for target objects
	tag_t rootTask = NULLTAG;
	int attachmentsCount =0;
	tag_t *attachment_tags = NULLTAG;
	char * object_type = NULL;
	char * item_revision_id = NULL;
	char * item_id = NULL;
	tag_t *baselinedRevisions = NULLTAG;
	logical found = false;
	int revcount;

	ITK_LOG(EPM_ask_root_task(msg.task, &rootTask));
	if(status != ITK_ok)return EPM_nogo;

	ITK_LOG(EPM_ask_attachments(rootTask,toattach,&attachmentsCount,&attachment_tags));
	if(status != ITK_ok)return EPM_nogo;
	/*Build pattern with item_id and item_revision_id*/
	for(int i=0;i<attachmentsCount;i++){

		tag_t object = attachment_tags[i];
		ITK_LOG(AOM_ask_value_string(object,"object_type", &object_type));
		if(status != ITK_ok)
		{
			SAFE_SM_FREE(object_type);
			return EPM_nogo;
		}

		if(tc_strcmp(object_type , "D4G_PDPItemRevision")==0){
			tag_t pdpitemtag;
			/*get PDP Item from Revision*/
			ITK_LOG(AOM_ask_value_tag(object, "items_tag", &pdpitemtag));
			/*from Item get all revisions*/
			//ITEM_list_all_revs(pdpitemtag,&revcount,&baselinedRevisions);
			ITK_LOG(AOM_ask_value_tags(pdpitemtag,"revision_list",&revcount,&baselinedRevisions));
			if(status != ITK_ok)
			{
				SAFE_SM_FREE(baselinedRevisions);
				return EPM_nogo;
			}
			/*iterate all milestones to search for in the revisions*/
			for(int j=0;j<count;j++){
				found = false;
				/* search in all revisions for the milestone,
				 * even if revcount smaler than count we will iterate
				 * to find out which one is missing*/
				for(int k=0;k<revcount;k++){
					ITK_LOG(AOM_ask_value_string(baselinedRevisions[k],"item_revision_id", &item_revision_id));
					if(status != ITK_ok)
					{
						return EPM_nogo;
					}
					/*if found continue with next mileston*/
					//cout<<"rev_id: "<<item_revision_id<<"milestone: "<<	milestones[j]<<"\n";
					if(tc_strstr(item_revision_id,milestones[j])!= NULL){
						found = true;
						SAFE_SM_FREE(item_revision_id);
						break;
					}
					SAFE_SM_FREE(item_revision_id);
				}
				if(!found){
					userError--;
					ITK_LOG(EMH_store_error_s2(EMH_severity_error, CHECK_MILESTONES, "milestone is missing:",milestones[j]));
				}
			}
			SAFE_SM_FREE(baselinedRevisions);
			if(userError){
				ITK_LOG(AOM_ask_value_string(object,"object_string", &item_id));
				if(status != ITK_ok){
					SAFE_SM_FREE(item_id);
					return EPM_nogo;
				}
				ITK_LOG(EMH_store_error_s2(EMH_severity_error, CHECK_MILESTONES, "milestones are not complete for item",item_id));
				SAFE_SM_FREE(item_id);
			}
		}
		SAFE_SM_FREE(object_type);
	}
	SAFE_SM_FREE(milestones);
	return EPM_go;
}


/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_UpdateItemOnRevise
/*  Program ID:         D4G_EPM_Handlers.cxx
/*  Description:        Updates Name and description on Item if there is a released status on the ItemRevision
/*  Input Parameters:   EPM_action_message_t msg -- EPM task
/*  Return Value:    int ifail -- ITK_ok
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 26-06-2017	       Bhargav 		     2722               Initial Creation
* 17-08-2017		   Bhargav				  2722				 Regression issue fix during Danfoss user testing.Modified the code to save the changes done on the Item object
*************************************************************************************************************************/
int D4G_UpdateItemOnRevise( EPM_action_message_t msg )
{
    
  int				iCount					= 0;
  int				iIndex					= 0;
	int			  iPrefCount		= 0;
	int				iTargCount			= 0;
	int				iStatCount			= 0;
	int				iNum					  = 0;
	int				ifail					 = ITK_ok;
	int 			status 				 = ITK_ok;


  char**		cppPrefValue		    = NULL;
	char*			cpTargObjectName      	= NULL;
	char*			cpDescValue		    	= NULL;
	char*			cpStringValue		    = NULL;

  tag_t			tRootTask				= NULLTAG;
	tag_t			tItemTag				= NULLTAG;
	tag_t			tTargTypeTag   	= NULLTAG;
	tag_t*	  tTarget					= NULLTAG;


	cout <<"*********InsideD4G_UpdateItemOnRevise*********\n ";

	ITK_LOG(EPM_ask_root_task(msg.task, &tRootTask));

	// getting the tag for the target item that are attached with the workflow

    ITK_LOG(EPM_ask_attachments( tRootTask, EPM_target_attachment, &iCount, &tTarget) );

	//getting the count of the preference values of 'D4G_UpdateItemNames&DescriptionOnRelease' preference
	
	ITK_LOG(PREF_ask_value_count ( UPDATE_ITEM_DESC_PREF_NAME, &iPrefCount));

	if (iPrefCount > 0)
	{
		//getting the values stored in the 'D4G_UpdateItemNames&DescriptionOnRelease' preference
		ITK_LOG(PREF_ask_char_values ( UPDATE_ITEM_DESC_PREF_NAME, &iPrefCount, &cppPrefValue));
	}
	if (iPrefCount > 0)
	{
		for(iTargCount = 0;iTargCount < iCount ;iTargCount++)
		{

			//asking the type tag for the business object that has been attached as a target
			ITK_LOG(TCTYPE_ask_object_type(tTarget[iTargCount],&tTargTypeTag));

			//asking the name (eg:D4G_DocumentRevision) of the type tag  
			ITK_LOG(TCTYPE_ask_name2(tTargTypeTag,&cpTargObjectName));

			//traversing through preference values which are business object revisions
			for(iIndex= 0;iIndex < iPrefCount ;iIndex++)
			{
				//checking whether the attached target object is matching with any value in the preference
				if(tc_strcmp(cppPrefValue[iIndex],cpTargObjectName)==0)
				{

					//getting the item tag for the item revision
					 ITK_LOG(ITEM_ask_item_of_rev(tTarget[iTargCount],&tItemTag ));

					 //asking the value of the 'object name' property of item revision
					 ITK_LOG(AOM_ask_value_string(tTarget[iTargCount],OBJ_NAME,&cpStringValue));
					 
					 //asking the value of the 'object desc' property of item revision
					 ITK_LOG(AOM_ask_value_string(tTarget[iTargCount],OBJECT_DESC,&cpDescValue));

					 //locking the item object to modify the properties of it.
					 //As part of Regreesion Issue fix , AOM_refresh,AOM_save_with_extensions APIs were added.
					 ITK_LOG(AOM_refresh(tItemTag,TRUE));

					 //setting  the 'object name' property value which we got from item revision to object name property value of item
					 ITK_LOG(AOM_set_value_string(tItemTag,OBJ_NAME,cpStringValue));

					 //setting  the 'object desc' property value which we got from item revision to object name property value of item
					 ITK_LOG(AOM_set_value_string(tItemTag,OBJECT_DESC,cpDescValue));
					 
					 //saving the changes done on the Item object
					 ITK_LOG(AOM_save_with_extensions(tItemTag));
					 
					 //unlocking the item object.
					 ITK_LOG(AOM_refresh(tItemTag,FALSE));

				}
			}
		}
	}

	SAFE_SM_FREE(cppPrefValue);
	SAFE_SM_FREE(cpTargObjectName);
	SAFE_SM_FREE(cpDescValue);
	SAFE_SM_FREE(cpStringValue);
	SAFE_SM_FREE(tTarget);

	return ifail;

}



/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_AttachPartsAsReference
/*  Program ID:         D4G_EPM_Handlers.cxx
/*  Description:        Attach all the related Danfoss parts that are associated to the schedule as reference to the workflow task
/*  Input Parameters:   EPM_action_message_t msg -- Workflow task
/*  Return Value:      int ifail -- return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 26-06-2017	       Bhargav 		     	  3851               Initial Creation
* 31-07-2017		   Bhargav				  3851				 Modified the logic of getting the references of schedule objects 
*************************************************************************************************************************/
int D4G_AttachPartsAsReference(EPM_action_message_t msg)
{
	int				iCount					= 0;
	int				iTargCount				= 0;
	int			    iPrefCount				= 0;
	int				iIndex					= 0;
	int				iTagCount				= 0;
	int				iNum					= 0;
	int				iDanCount				= 0;
	int				iDanTagCount			= 0;
	int 			status 					= ITK_ok;
	int				ifail					= ITK_ok;
	int*			iTempIntVal				= NULL;
	int*			iLevels					= NULL;

	char*			cpTargObjectName      	= NULL;
	char*			cpValObjectName      	= NULL;
	char**			cppPrefValue		    = NULL;
	char**			cppRelations			= NULL;

	tag_t			tRootTask				= NULLTAG;
	tag_t			tValTypeTag				= NULLTAG;
	tag_t			tPropValueTag			= NULLTAG;
	tag_t			tTargTypeTag         	= NULLTAG;
	tag_t*			tTarget					= NULLTAG;
	tag_t*			tSchedValueTags			= NULLTAG;
	tag_t*			tDanTags				= NULL;

	ITK_LOG(EPM_ask_root_task(msg.task, &tRootTask));

	//Getting the target tag from the root task

	ITK_LOG(EPM_ask_attachments( tRootTask, EPM_schedule_task_attachment, &iCount, &tTarget));

	for (iTargCount = 0; iTargCount < iCount; iTargCount++)
	{
		//traversing through all the target values and asking the type tag of the object to sort out the required target object i.e D4G_PPAPSCHED

		ITK_LOG(TCTYPE_ask_object_type(tTarget[iTargCount],&tTargTypeTag));

		//asking the type name of the schedule object
		ITK_LOG(TCTYPE_ask_name2(tTargTypeTag,&cpTargObjectName));

		//comparing the target object name to match with any of  the preference value

		if (tc_strcmp(cpTargObjectName, D4G_PPAPTASK) == 0)
		{
			//getting the tag for the value of schedule tag property of the D4G_PPAPSCHED target object 
			ITK_LOG(AOM_ask_value_tag (tTarget[iTargCount],SCHEDULE_TAG,&tPropValueTag));

			//getting all the tags for the schedule object references
			ITK_LOG(WSOM_where_referenced(tPropValueTag,1,&iTagCount,&iLevels,&tSchedValueTags,&cppRelations));

			//getting the count of the preference values of 'D4G_Attach_PartsAs_Reference' preference
			ITK_LOG(PREF_ask_value_count ( ATTACH_PARTS_AS_REF_PREF_NAME, &iPrefCount));

			if (iPrefCount > 0)
			{
				//getting the values from 'D4G_Attach_PartsAs_Reference' preference.It consists of names of different schedule task

				ITK_LOG(PREF_ask_char_values ( ATTACH_PARTS_AS_REF_PREF_NAME, &iPrefCount, &cppPrefValue));

			}
			if (iPrefCount > 0)
			{

				for (iNum = 0; iNum < iTagCount; iNum++)
				{

					//getting the type tag of the refrences of the D4G_PPAPSCHED schedule object
					ITK_LOG(TCTYPE_ask_object_type(tSchedValueTags[iNum],&tValTypeTag));

					//getting the type name of all the references of the D4G_PPAPSCHED schedule object

					ITK_LOG(TCTYPE_ask_name2(tValTypeTag,&cpValObjectName));

					for (iIndex = 0; iIndex < iPrefCount; iIndex++)
					{
						//checking whether the reference is of type danpart rev / vendor part rev or not
						if (tc_strcmp(cpValObjectName, cppPrefValue[iIndex]) == 0)
						{
							//calling the function for adding the tag of Danfoos part into an array

							D4G_Add_Tag_To_Array(tSchedValueTags[iNum],&iDanTagCount, &tDanTags);

							//allocating memory for the int type values (EPM_Reference_attachment)
							if (iDanCount == 0)
							{
								iTempIntVal = (int*) MEM_alloc(1 * sizeof(int));
							}
							else
							{
								iTempIntVal = (int*) MEM_realloc(iTempIntVal,(iDanCount + 1) * sizeof(int));
							}
							iTempIntVal[iDanCount] = EPM_reference_attachment;
							iDanCount++;

						}

					}
				}

					//all the danfoss parts will get attached to the references folder of the workflow task as an attachment
				ITK_LOG(EPM_add_attachments (tRootTask,iDanCount, tDanTags, iTempIntVal ));



			}
		}

	}

	SAFE_SM_FREE(iTempIntVal);
	SAFE_SM_FREE(cpTargObjectName);
	SAFE_SM_FREE(cpValObjectName);
	SAFE_SM_FREE(tTarget);
	SAFE_SM_FREE(cppPrefValue);
	SAFE_SM_FREE(tSchedValueTags);
	SAFE_SM_FREE(tDanTags);
	SAFE_SM_FREE(iLevels);
	SAFE_SM_FREE(cppRelations);

	return ifail;

}

/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_ChangeScheduleJobName
/*  Program ID:         D4G_EPM_Handlers.cxx
/*  Description:        Update EPM Job name based on Schedule task
/*  Input Parameters:   EPM_action_message_t msg -- Workflow task
/*  Handler Parameters: -refs_job_name_criteria
/*							One of below value for schedules other than PPAP
/*							item : task name to be prepended by the item_id of the attached reference.
/*							revision : task name to be prepended by the item_id and item_revision_id of the attached reference.
/*	Algorithm
/*						Get schedule task
/* 							Fetch Schedule Attached to the workflow
/* 								If Schedule is PPAP Schedule
/* 									Fetch item id of Schedule, prepend it to job name.
/* 								else
/* 									Fetch references attached to the workflow.
/* 									Get id of from reference revision
/* 										Based on handler argument get "item_id" or "item_id+/+item_revision_id". Default is item_id
/* 									Prepend id from above step to the job name
/*  Return Value:       return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
*  31-07-2017	         Jayant 		     3842                Initial Creation
*  08-09-2017            Jayant              3842                Modified to read target incase no reference found
*  06-10-2017            Jayant              3842                Fixed so that job can be modified
*************************************************************************************************************************/
int D4G_ChangeScheduleJobName(EPM_action_message_t msg)
{
    int             iCount                  = 0;
    int             iTargCount              = 0;
    int             iRefOrTarCount         = 0;
	int             iIRCount                = 0;
	int 			iNumArgs				= 0;

    int             status                  = ITK_ok;

    logical         lJobNameUpdated         = false;
    logical 		isDescendant            = false;

    char*           cpScheduleObjectClassName       = NULL;
    char*           cpScheduleID                    = NULL;
    char*           cpJobName                       = NULL;
    char*           cpTargObjectName                = NULL;
    char*			cpArgs							= NULL;
    char*			cpSwitch						= NULL;
    char*			cpValue							= NULL;
    char*			cpScheduleRevID					= NULL;

    tag_t           tJob                    = NULLTAG;
    tag_t           tRootTask               = NULLTAG;
    tag_t			tIRClassId              = NULLTAG;
    tag_t           tScheduleTag            = NULLTAG;
    tag_t           tScheduleTypeTag        = NULLTAG;
	tag_t           tRefOrTarClassId             = NULLTAG;
	tag_t 			tRefOrTarIR            = NULLTAG;
    tag_t*          tTarget                 = NULL;
    tag_t*          tRefOrTarAttachments  = NULL;

    std::string strJobName;
    std::string strScheduleId;
    std::string strNewJobName;
    std::string strSeperator("-");
    std::string strForwardSlash("/");
    std::string strFirstScheduleID;
    std::string strTempItemId;
    std::string strTempRevId;

	try
	{
		ITK_LOG(EPM_ask_root_task(msg.task, &tRootTask));

		ITK_LOG(EPM_ask_job( tRootTask, &tJob ));

		ITK_LOG(AOM_ask_value_string(tJob, OBJ_NAME, &cpJobName));

		strJobName.assign(cpJobName);

		ITK_LOG(EPM_ask_attachments( tRootTask, EPM_schedule_task_attachment, &iTargCount, &tTarget));

		ITK_LOG(POM_class_id_of_class  ( ITEM_REVISION.c_str(),  &tIRClassId) );

		iNumArgs=TC_number_of_arguments( msg.arguments );

		for (iCount = 0; iCount < iTargCount; iCount++) /*Traverse through all schedule attached */
		{
			ITK_LOG(AOM_ask_value_tag (tTarget[iCount], SCHEDULE_TAG, &tScheduleTag));

			if(tScheduleTag != NULLTAG)
			{
				ITK_LOG(TCTYPE_ask_object_type(tScheduleTag,&tScheduleTypeTag));

				ITK_LOG(TCTYPE_ask_name2(tScheduleTypeTag,&cpScheduleObjectClassName));

				if(tc_strcmp(cpScheduleObjectClassName, D4G_PPAPSCHED) == 0) /*If PPAP Schedule, job name to prepended with item id */
				{
					ITK_LOG(AOM_ask_value_string(tScheduleTag,"item_id",&cpScheduleID));
					strScheduleId.assign(cpScheduleID);
				}
				else/*For other schedule get the reference and check for Item Revision, if found get the id to be prepended*/
				{
					ITK_LOG(EPM_ask_attachments(tRootTask, EPM_reference_attachment,&iRefOrTarCount,&tRefOrTarAttachments));

					if(iRefOrTarCount == 0)
					{
						ITK_LOG(EPM_ask_attachments(tRootTask, EPM_target_attachment,&iRefOrTarCount,&tRefOrTarAttachments));
					}

					if(iRefOrTarCount >= 1)
					{
						iIRCount = 0;
						tRefOrTarIR = NULLTAG;

						for(int iRCount = 0; iRCount < iRefOrTarCount; iRCount++)
						{

							ITK_LOG(POM_class_of_instance ( tRefOrTarAttachments[iRCount], &tRefOrTarClassId));

							ITK_LOG(POM_is_descendant(tIRClassId,tRefOrTarClassId,&isDescendant));

							if(isDescendant == true)/*Fetch property only if reference attachment is subclass of Item Revision*/
							{
								iIRCount++;
								if(iIRCount >= 1 && tRefOrTarIR == NULLTAG)/*In case more than 1 reference revision attched get the id of the first*/
									tRefOrTarIR = tRefOrTarAttachments[iRCount];/*Revision whose id to updated for job name*/
							}
						}

						if(tRefOrTarIR != NULLTAG)/*Revision whose id to fetched*/
						{
							if(iNumArgs == 1)/*if handler arguments defined, fetch and check*/
							{
								cpArgs = TC_next_argument( msg.arguments );
								ITK_LOG(ITK_ask_argument_named_value(cpArgs,&cpSwitch,& cpValue));

								if(tc_strcmp(cpSwitch, D4G_CHANGE_JOB_NAME_SWITCH) == 0)
								{
									if(tc_strcmp(cpValue,REVISION) == 0)/*if revision then string like,CN2000014/01 to be prepended*/
									{
										ITK_LOG(AOM_ask_value_string(tRefOrTarIR,ITEM_ID,&cpScheduleID));
										strTempItemId.assign(cpScheduleID);
										ITK_LOG(AOM_ask_value_string(tRefOrTarIR,ITEM_REVISION_ID.c_str(),&cpScheduleRevID));
										strTempRevId.assign(cpScheduleRevID);
										strScheduleId=strTempItemId + strForwardSlash + strTempRevId;
									}
									else if(tc_strcmp(cpValue,ITEM) == 0)/*if item then only item id to be prepended*/
									{
										ITK_LOG(AOM_ask_value_string(tRefOrTarIR,ITEM_ID,&cpScheduleID));
										strScheduleId.assign(cpScheduleID);
									}
								}
							}
							else/*if handler arguments not defined, default as item id*/
							{
								ITK_LOG(AOM_ask_value_string(tRefOrTarIR,ITEM_ID,&cpScheduleID));
								strScheduleId.assign(cpScheduleID);
							}
						}
					}
					else{
						ITK_LOG(AOM_ask_value_string(tScheduleTag,OBJ_NAME,&cpScheduleID));
						strScheduleId.assign(cpScheduleID);
					}
				}

				/*Update job name with the id*/
				if((!strScheduleId.empty()) && (!(tc_strstr(cpJobName, strScheduleId.c_str()) != NULL)))
				{
					if(lJobNameUpdated == false)
					{
						strNewJobName = strScheduleId + strSeperator + strJobName;
						//Updated below for access related with Test Interface system.
						//Set am bypass so that access issue ignored.
						bool current = set_bypass(true);
						ITK_LOG(AOM_refresh(tJob, true));
						ITK_LOG(AOM_set_value_string(tJob,OBJ_NAME,strNewJobName.c_str()));
						ITK_LOG(AOM_save(tJob));
						ITK_LOG(AOM_refresh(tJob, false));
						lJobNameUpdated = true;
						set_bypass(current);
					}
				}
			}
		}
	}
	catch(...)
	{
		TC_write_syslog("\nError!! caught in function D4G_ChangeScheduleJobName !!");
	}

    SAFE_SM_FREE(cpTargObjectName);
    SAFE_SM_FREE(cpScheduleObjectClassName);
    SAFE_SM_FREE(cpJobName);
    SAFE_SM_FREE(cpScheduleID);
    SAFE_SM_FREE(cpSwitch);
    SAFE_SM_FREE(cpValue);
    SAFE_SM_FREE(cpScheduleRevID);
    SAFE_SM_FREE(tTarget);
    SAFE_SM_FREE(tRefOrTarAttachments);

    return status;
}

/*********************************************************************************************************************/
/*


/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_ValidateMapReplacementPart
/*  Program ID:         D4G_EPM_Handlers.cxx
/*  Description:        To validate if all parts from solution items are mapped with replacement part
/*  Input Parameters:   EPM_rule_message_t msg -- Workflow task
/*  Return Value:      int ifail -- return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 20-07-2017	 Mohammed Minam Nakhuda 	   3547              Initial Creation
* 10-10-2017	 Mohammed Minam Nakhuda 	   3547              Added logic to skip validation of property "Replaced by"
* 								     on BOM items and other object type other than Dan part revision
* 10-10-2017     Mohammed Minam Nakhuda 	   3547	             Added logic to skip validation if Change type is not obsolete
*************************************************************************************************************************/
EPM_decision_t D4G_ValidateMapReplacementPart(EPM_rule_message_t msg)
{
	int				iTargetCount			= 0;
	int				iSolutionItemsCount 		= 0;
	int				iReferenceItemscount 		= 0;
	int				iSolutionItemsIndex		= 0;
	int				iReferenceItemsIndex		= 0;
	int				iIndex				= 0;
	int				iTargetCountIndex		= 0;

	int 				status 				= ITK_ok;
	EPM_decision_t 			decision			= EPM_go;

	char*				cpTargObjectName      		= NULL;
	char*				cpReplacedByPropertyValue	= NULL;
	char*				cpChangeTypeValue		= NULL;
	char*				cpObjectStringValue		= NULL;
	char*				cpSolnObjectName		= NULL;

	tag_t				tRootTask			= NULLTAG;
	tag_t*				tpTarget			= NULLTAG;
	tag_t				tTargetType	         	= NULLTAG;
	tag_t				tSolnObjectType			= NULLTAG;
	tag_t 	        		tSolutionItemRelationType	= NULLTAG;
	tag_t 	        		tReferenceItemRelationType  	= NULLTAG;
	tag_t *				tpSolutionObjects		= NULLTAG;
	tag_t *				tpReferenceObjects		= NULLTAG;

	try {
		ITK_LOG(EPM_ask_root_task(msg.task, &tRootTask));

		//Getting the target tag from the root task

		ITK_LOG(EPM_ask_attachments( tRootTask, EPM_target_attachment, &iTargetCount, &tpTarget));

			for (iTargetCountIndex = 0; iTargetCountIndex < iTargetCount; iTargetCountIndex++)
			{
				//traversing through all the target values to sort out the required target object

				ITK_LOG(TCTYPE_ask_object_type(tpTarget[iTargetCountIndex],&tTargetType));

				ITK_LOG(TCTYPE_ask_name2(tTargetType,&cpTargObjectName));

				if ((tc_strcmp(cpTargObjectName, D4G_CHANGE_MASTER_REVISION) == 0 ))
						{
							AOM_ask_value_string(tpTarget[iTargetCountIndex],CHANGE_TYPE.c_str(),&cpChangeTypeValue);
							if((tc_strcmp(cpChangeTypeValue, OBSOLETE) == 0 ))
							{
							//traversing through all the secondary target values with relation of solution item
							ITK_LOG(GRM_find_relation_type	(CM_HAS_SOLUTION_ITEM, &tSolutionItemRelationType));
							ITK_LOG(GRM_list_secondary_objects_only	(tpTarget[iTargetCountIndex],tSolutionItemRelationType,&iSolutionItemsCount,&tpSolutionObjects));

							for(iSolutionItemsIndex=0; iSolutionItemsIndex<iSolutionItemsCount; iSolutionItemsIndex++)
								{
									ITK_LOG(TCTYPE_ask_object_type(tpSolutionObjects[iSolutionItemsIndex],&tSolnObjectType));
									ITK_LOG(TCTYPE_ask_name2(tSolnObjectType,&cpSolnObjectName));
									if ((tc_strcmp(cpSolnObjectName, D4G_DANPART) == 0 ))
										{
										ITK_LOG(AOM_ask_value_string(tpSolutionObjects[iSolutionItemsIndex],D4G_REPLACED_BY,&cpReplacedByPropertyValue));
										//check if replaced by property is empty
										if((tc_strcmp(cpReplacedByPropertyValue, "") == 0 ))
											{
												ITK_LOG(EMH_store_error(EMH_severity_error, Validate_Map_Replacement_Part));
												decision =EPM_nogo;
											}
										}
								}
							//traversing through all the secondary target values with relation of reference item
							ITK_LOG(GRM_find_relation_type	(CM_HAS_REFERENCE_ITEM, &tReferenceItemRelationType));
							ITK_LOG(GRM_list_secondary_objects_only	(tpTarget[iTargetCountIndex],tReferenceItemRelationType,&iReferenceItemscount,&tpReferenceObjects ));
							for(iReferenceItemsIndex=0; iReferenceItemsIndex<iReferenceItemscount; iReferenceItemsIndex++)
							{
								ITK_LOG(AOM_ask_value_string(tpReferenceObjects[iReferenceItemsIndex],OBJ_STRING.c_str(),&cpObjectStringValue));
								for(iSolutionItemsIndex=0; iSolutionItemsIndex<iSolutionItemsCount; iSolutionItemsIndex++)
								{
									ITK_LOG(TCTYPE_ask_object_type(tpSolutionObjects[iSolutionItemsIndex],&tSolnObjectType));
									ITK_LOG(TCTYPE_ask_name2(tSolnObjectType,&cpSolnObjectName));
									if ((tc_strcmp(cpSolnObjectName, D4G_DANPART) == 0 ))
										{
										ITK_LOG(AOM_ask_value_string(tpSolutionObjects[iSolutionItemsIndex],D4G_REPLACED_BY,&cpReplacedByPropertyValue));
										//check if reference objects are used atleast once and populated in obsolete part replaced by property
										if((tc_strcmp(cpObjectStringValue, cpReplacedByPropertyValue) == 0 ))
											{
											iIndex++;
											}
										}
								}
								if(iIndex==0)
									{
										ITK_LOG(EMH_store_error(EMH_severity_error, Validate_Map_Replacement_Part));
										decision =EPM_nogo;
									}
								}
							}
						}
			}
			MEM_free(tpTarget);
			MEM_free(cpTargObjectName);
			MEM_free(cpObjectStringValue);
			MEM_free(cpReplacedByPropertyValue);
			MEM_free(cpSolnObjectName);
	}
	catch (...) {
		decision =EPM_nogo;
	}
			return decision;
}


/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_ModifyPlantProperty
/*  Program ID:         D4G_EPM_Handlers.cxx
/*  Description:        Modify d4g_tansferred property of plants associated to Dan Part rev to True while its been send to SAP
/*  Input Parameters:   EPM_action_message_t msg -- Workflow task
/*  Return Value:       int ifail -- return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 31-07-2017	 Mohammed Minam Nakhuda 	   3857              Initial Creation
* 27-09-2017	 Mohammed Minam Nakhuda 	   3857              Added logic to skip update of property d4g_tansferred to true while Plant having Rejected Status
* 10-10-2017	 Mohammed Minam Nakhuda 	   3857              Added logic to skip update of property d4g_tansferred to true while Plant doesn't have any Status
*************************************************************************************************************************/

int D4G_ModifyPlantProperty(EPM_action_message_t msg)
{
	int			iTargetCount			= 0;
	int			iTargetCountIndex		= 0;
	int 			status 				= ITK_ok;
	int			ifail				= ITK_ok;
	int			iPlantCount 			= 0;
	int 			iPlantIndex			= 0;
	int			iSolutionItemCount 		= 0;
	int 			iSolutionItemIndex		= 0;
	int			iReleaseStatusCount		= 0;
	int 			iReleaseStatusCounter		= 0;
	int 			iRejectedReleaseStatus 		= 0;

	char*			cpTargObjectName      		= NULL;
	char*			cpTargObjectName1      		= NULL;
	char*			cpPlantItemTypeClass		= NULL;
	char *			cpPlantReleaseStatus		= NULL;

	tag_t			tRootTask			= NULLTAG;
	tag_t			tTargTypeTag         		= NULLTAG;
	tag_t			tPlantItemTypeTag       	= NULLTAG;
	tag_t			tSolutionItemTypeTag  		= NULLTAG;
	tag_t 	  		tPlantRelationType      	= NULLTAG;
	tag_t 	  		tSolutionItemRelationType	= NULLTAG;
	tag_t*			tpTarget			= NULLTAG;
	tag_t*			tpPlantObject			= NULLTAG;
	tag_t*			tpSolutionItem			= NULLTAG;
	tag_t			tSAPAttrID			= NULLTAG;
	tag_t			tPlantItemClassID		= NULLTAG;
	tag_t*			tpReleaseStatus			= NULLTAG;

	try{
		ITK_LOG(EPM_ask_root_task(msg.task, &tRootTask));

		//Getting the target tag from the root task

		ITK_LOG(EPM_ask_attachments( tRootTask, EPM_target_attachment, &iTargetCount, &tpTarget));
		for (iTargetCountIndex = 0; iTargetCountIndex < iTargetCount; iTargetCountIndex++)
		{
			//traversing through all the target values to sort out the required target object
			ITK_LOG(TCTYPE_ask_object_type(tpTarget[iTargetCountIndex],&tTargTypeTag));

			ITK_LOG(TCTYPE_ask_name2(tTargTypeTag,&cpTargObjectName));

			//comparing the target object name to match with DanPart Revision or VendorPart Revision

			if ((tc_strcmp(cpTargObjectName, D4G_DANPART) == 0 )|| (tc_strcmp(cpTargObjectName, D4G_VENDORPART) == 0 ))
			{
				bool current = set_bypass(true);

				ITK_LOG(GRM_find_relation_type	(D4G_PART_PLANT_RELATION, &tPlantRelationType));

				//listing all plant object associated with DanPart Revision or VendorPart Revision
				ITK_LOG(GRM_list_secondary_objects_only	(tpTarget[iTargetCountIndex],tPlantRelationType,&iPlantCount,&tpPlantObject ));

				for(iPlantIndex=0; iPlantIndex<iPlantCount; iPlantIndex++)
				{
					//check if Plant has rejected status, to skip SAP transfer property update
					AOM_ask_value_tags(tpPlantObject[iPlantIndex],RELEASE_STATUS,&iReleaseStatusCount,&tpReleaseStatus);
					if(tpReleaseStatus!=NULLTAG)
					{
					for( iReleaseStatusCounter = 0; iReleaseStatusCounter < iReleaseStatusCount; iReleaseStatusCounter++ )
						{
						AOM_ask_value_string( tpReleaseStatus[iReleaseStatusCounter],OBJ_NAME, &cpPlantReleaseStatus );
						if ((cpPlantReleaseStatus != NULL) && (tc_strcmp(cpPlantReleaseStatus,STATUS_REJECTED)==0))
							{
								iRejectedReleaseStatus = 1;
							}
						}
						if(iRejectedReleaseStatus!=1)
						{
						//traversing through all plant objects to update SAP transfer value to True
							ITK_LOG(TCTYPE_ask_object_type(tpPlantObject[iPlantIndex],&tPlantItemTypeTag));

							ITK_LOG(TCTYPE_ask_class_name2(tPlantItemTypeTag, &cpPlantItemTypeClass ));

							ITK_LOG(POM_attr_id_of_attr( D4G_TRANSFERRED , cpPlantItemTypeClass, &tSAPAttrID ));

							ITK_LOG(POM_unload_instances( 1, &tpPlantObject[iPlantIndex] ));

							ITK_LOG(POM_class_id_of_class( cpPlantItemTypeClass, &tPlantItemClassID ));

							ITK_LOG(POM_load_instances( 1, &tpPlantObject[iPlantIndex], tPlantItemClassID, POM_modify_lock ));

							ITK_LOG(POM_set_attr_logical( 1, &tpPlantObject[iPlantIndex], tSAPAttrID, true ));

							ITK_LOG(POM_save_instances( 1, &tpPlantObject[iPlantIndex], TRUE ));

							ITK_LOG(POM_refresh_instances(1, &tpPlantObject[iPlantIndex], NULLTAG, POM_no_lock));
						}
						iRejectedReleaseStatus = 0;
					}
				}
				set_bypass(current);
			}
			else if ((tc_strcmp(cpTargObjectName, D4G_CHANGE_MASTER_REVISION) == 0 ) || (tc_strcmp(cpTargObjectName, D4G_CHANGE_NOTICE_REVISION) == 0 ))
					{
					ITK_LOG(GRM_find_relation_type	(CM_HAS_SOLUTION_ITEM, &tSolutionItemRelationType));

					ITK_LOG(GRM_list_secondary_objects_only	(tpTarget[iTargetCountIndex],tSolutionItemRelationType,&iSolutionItemCount,&tpSolutionItem ));

						for(iSolutionItemIndex=0; iSolutionItemIndex<iSolutionItemCount; iSolutionItemIndex++)
							{
							//traversing through all the target values to sort out the required target object
							ITK_LOG(TCTYPE_ask_object_type(tpSolutionItem[iSolutionItemIndex],&tSolutionItemTypeTag));

							ITK_LOG(TCTYPE_ask_name2(tSolutionItemTypeTag,&cpTargObjectName1));

							//comparing the target object name to match with DanPart Revision or VendorPart Revision
							if ((tc_strcmp(cpTargObjectName1, D4G_DANPART) == 0) || (tc_strcmp(cpTargObjectName1, D4G_VENDORPART) == 0))
								{
									bool current = set_bypass(true);
									ITK_LOG(GRM_find_relation_type	(D4G_PART_PLANT_RELATION, &tPlantRelationType));

									//listing all plant object associated with DanPart Revision or VendorPart Revision
									ITK_LOG(GRM_list_secondary_objects_only	(	tpSolutionItem[iSolutionItemIndex],tPlantRelationType,&iPlantCount,&tpPlantObject ));

									for(iPlantIndex=0; iPlantIndex<iPlantCount; iPlantIndex++)
									{
										//check if Plant has rejected status, to skip SAP transfer property update
										AOM_ask_value_tags(tpPlantObject[iPlantIndex],RELEASE_STATUS,&iReleaseStatusCount,&tpReleaseStatus);
										if(tpReleaseStatus!=NULLTAG)
											{
											for( iReleaseStatusCounter = 0; iReleaseStatusCounter < iReleaseStatusCount; iReleaseStatusCounter++ )
												{
													AOM_ask_value_string( tpReleaseStatus[iReleaseStatusCounter],OBJ_NAME, &cpPlantReleaseStatus );
													if ((cpPlantReleaseStatus != NULL) && (tc_strcmp(cpPlantReleaseStatus,STATUS_REJECTED)==0))
														{
															iRejectedReleaseStatus = 1;
														}
												}
											if(iRejectedReleaseStatus!=1)
												{
													//traversing through all plant objects to update SAP transfer value to True
													ITK_LOG(TCTYPE_ask_object_type(tpPlantObject[iPlantIndex],&tPlantItemTypeTag));

													ITK_LOG(TCTYPE_ask_class_name2(tPlantItemTypeTag, &cpPlantItemTypeClass ));

													ITK_LOG(POM_attr_id_of_attr( D4G_TRANSFERRED , cpPlantItemTypeClass, &tSAPAttrID ));

													ITK_LOG(POM_unload_instances( 1, &tpPlantObject[iPlantIndex] ));

													ITK_LOG(POM_class_id_of_class( cpPlantItemTypeClass, &tPlantItemClassID ));

													ITK_LOG(POM_load_instances( 1, &tpPlantObject[iPlantIndex], tPlantItemClassID, POM_modify_lock ));

													ITK_LOG(POM_set_attr_logical( 1, &tpPlantObject[iPlantIndex], tSAPAttrID, true ));

													ITK_LOG(POM_save_instances( 1, &tpPlantObject[iPlantIndex], TRUE ));

													ITK_LOG(POM_refresh_instances(1, &tpPlantObject[iPlantIndex], NULLTAG, POM_no_lock));
												}
												iRejectedReleaseStatus = 0;
											}
									}
									set_bypass(current);
								}
							}
					}
		}
	}
	catch (...) {

		}
	SAFE_SM_FREE(tpTarget);
	SAFE_SM_FREE(cpTargObjectName);
	SAFE_SM_FREE(tpPlantObject);
	SAFE_SM_FREE(cpPlantItemTypeClass);
	SAFE_SM_FREE(tpSolutionItem);
	SAFE_SM_FREE(cpTargObjectName1);
	SAFE_SM_FREE(tpReleaseStatus);
	SAFE_SM_FREE(cpPlantReleaseStatus);

	return ifail;
}

/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_Add_Tag_To_Array
/*  Program ID:         D4G_EPM_Handlers.cxx
/*  Description:        This function will all add a set of tags into an array/*
/*  Input Parameters:   tag_t add_tag       --- Tag to be added to array
                        int *n_tag_array    --- No of values in array
                        tag_t **tag_array   --- Tag array 
/*  Return Value:    void
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 26-06-2017	       Bhargav 		     3851               Initial Creation
*
*************************************************************************************************************************/
void D4G_Add_Tag_To_Array(tag_t add_tag, int *n_tag_array, tag_t **tag_array)
{
    int count = *n_tag_array;
    count++;

    //allocating memory for the tag type values to store the danfoss part tags

    if (count == 1)
    {
     (*tag_array) = (tag_t *) MEM_alloc(sizeof(tag_t));
    }
    else
    {
     (*tag_array) = (tag_t *) MEM_realloc((*tag_array), count * sizeof(tag_t));
    }

    //adding the  tags into an array
    (*tag_array)[count - 1] = add_tag;
    *n_tag_array = count;
}




/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_SendEmailNotification
/*  Program ID:         D4G_EPM_Handlers.cxx
/*  Description:        Sends Email notifications to all the user who actually performed the task, members in the schedulemembership dialog
/*                      PPAP Manager, PPAP Reviewer and PPAP Decision Maker. Excludes the Roles and Designer01 user,DBA roles which are by default obtained
 *                      on using the existing template and creating the Schedule.
/*  Input Parameters:   EPM_action_message_t msg -- Workflow task
/*  Return Value:       int ifail -- return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 08-08-2017	       Chandrashekher G  	   3273              Initial Creation
*
*************************************************************************************************************************/
extern int D4G_SendEmailNotification(EPM_action_message_t msg)
{

	int		status		= 	ITK_ok;
	int 	iTargetCnt =0;
	int 	iSchedMemCnt =0;
	int 	iRecpIndx	=	0;

	char* 	arg 		= 	NULL;
	char*   pcTaskComments	= 	NULL;
	char* 	pcTaskDecision	= 	NULL;

	string 	sMailRecipients ;
	string 	sMailSubject ;
	string  sMailComments ;

	tag_t	tRootTask	= 	NULLTAG;
	tag_t* 	tScheduleTask = NULL;//
	tag_t 	tSchedule;
	tag_t* 	tSchedMems;//

	vector < string > vRecipientsMailId;
	vector < tag_t > vRecipientUsers;
	// Structure to hold the mail related information.
	osMailDetail_t detail;
	const char SCHEDULE_MEMBERS[] = "$SCHEDULE_MEMBERS";
	const char TASK_PERFORMER[] = "$TASK_PERFORMER";
	const char PPAP_DECISION_MAKER[] = "$PPAP_DECISIONMAKER";
	const char PPAP_REVIEWER[] = "$PPAP_REVIEWER";
	const char PPAP_MANAGER[] = "$PPAP_MANAGER";


	ITK_LOG(EPM_ask_root_task(msg.task, &tRootTask));
	/* Get the value of the argument provided in the workflow handler*/
	ITK_LOG(ask_handler_arg( msg.arguments,RECIPIENT.c_str(),&sMailRecipients));
	ITK_LOG(ask_handler_arg( msg.arguments,SUBJECT.c_str(),&sMailSubject));
	ITK_LOG(ask_handler_arg( msg.arguments,COMMENTS.c_str(),&sMailComments));
	vector<string> vRecipients =split_and_trim_to_vector_nonempty(sMailRecipients,","," \t");
	vector<tag_t> schedule_attachments = get_attachments_vector(msg.task,EPM_schedule_task_attachment);
	ITK_LOG(AOM_ask_value_tag(schedule_attachments[0],SCHEDULE_TAG,&tSchedule));

	for(iRecpIndx=0; iRecpIndx<vRecipients.size(); iRecpIndx++)
	{
		/*From recipients check if the value is $SCHEDULE_MEMBERS*/
		if(tc_strcmp(vRecipients[iRecpIndx].c_str(),SCHEDULE_MEMBERS)==0)
		{

			if(schedule_attachments.size()==1 && schedule_attachments[0]!=NULLTAG)
			{

				ITK_LOG(AOM_ask_value_tags(tSchedule, SCHEDULE_MEMBER_TAGLIST, &iSchedMemCnt, &tSchedMems));
				/*For each value of Schedule Membership dialog, check if the Member Type and allow only if memeber type is user. And also
				designer01 User is not allowed to get the mail notification */
				for(int iSchMemIdx=0; iSchMemIdx<iSchedMemCnt; iSchMemIdx++)
				{
					char* 	pcSchedMemName 	= NULL;
					char*   pcSchedMemType  = NULL;
					tag_t 	tUser			= NULLTAG;
					tag_t 	tPerson			= NULLTAG;
					char* 	pcMailId 		= NULL;
					ITK_LOG(AOM_ask_value_string(tSchedMems[iSchMemIdx], OBJ_NAME , &pcSchedMemName));
					ITK_LOG(AOM_ask_value_string(tSchedMems[iSchMemIdx], MEMBER_TYPE , &pcSchedMemType));
					/*Loop through each ScheduleMember and store the value of  mail id
					 * of the person whom to send the mail notification*/
					if(tc_strcmp(pcSchedMemType,USER.c_str())==0 && tc_strcmp(pcSchedMemName,DESIGNER01.c_str())!=0)
					{
						ITK_LOG(AOM_ask_value_tag(tSchedMems[iSchMemIdx],RESOURCE_TAG,&tUser));
						ITK_LOG(SA_ask_user_person( tUser,&tPerson));
						ITK_LOG(SA_ask_person_email_address( tPerson, &pcMailId ));
						string	sMailId(pcMailId);
						SAFE_SM_FREE(pcMailId);
						vRecipientsMailId.push_back(sMailId);

					}
					SAFE_SM_FREE(pcSchedMemName);
					SAFE_SM_FREE(pcSchedMemType);
				}

				}

		}

		/* If the recipients Value is $TASK_PERFORMER the condition is passed and here in this we are checking for the user who actually peformed the task
		 * because there will be scenarios where the assiged user may further assign it to the some other user. */
		else if(tc_strcmp(vRecipients[iRecpIndx].c_str(),TASK_PERFORMER)==0)
		{
			vector<tag_t> vChildSchedTasks;

			if(schedule_attachments.size()==1 && schedule_attachments[0]!=NULLTAG)
			{
				tag_t	tSchedSummaryTask	=	NULLTAG;

				ITK_LOG(AOM_ask_value_tag(tSchedule,SUMMARY_TASK.c_str(),&tSchedSummaryTask));
				/*Get all the Child tasks under a schedule by traversing through the last level if there are any subtasks availble under a task.*/
				ITK_LOG(D4G_traverse_and_get_all_tasks(tSchedSummaryTask,&vChildSchedTasks));

				/* Read the below Multiple Value prefrence to get task performer.
				 * The Task performer of the tasks which are mentioned in the Prefrence is only obtained.
				 * make sure to add the value of the task name and workflow name in prefrence as avalue to receive the mail notification
				 * to the actual performer of task.*/
				vector<std::string> vWorkflowTemplateDetails = get_prefs(WORKFLOW_TEMPLATES_FOR_MAIL_NOTIFICATION);
				map<std::string,std::string> mTemplateNameToTaskName;

				for (int iTemplateDetailIdx = 0; iTemplateDetailIdx < vWorkflowTemplateDetails.size(); iTemplateDetailIdx++)
				{
					vector<std::string> vSplittedWorkflowTemplateDetail = split_and_trim_to_vector(vWorkflowTemplateDetails[iTemplateDetailIdx],"|"," \t");
					if(vSplittedWorkflowTemplateDetail.size()==2)
					{
						mTemplateNameToTaskName.insert(make_pair(vSplittedWorkflowTemplateDetail[0],vSplittedWorkflowTemplateDetail[1]));
					}
				}
				/*Loop through each child task and get the actual performer of the task and store the value of the mail id
				 * of the person whom to send the mail notification*/
				for(int iChildTaskIdx =0;iChildTaskIdx<vChildSchedTasks.size();iChildTaskIdx++)
				{
					string  sSchedState = get_string_property(vChildSchedTasks[iChildTaskIdx],STATUS.c_str());
					if(sSchedState.compare(DISABLED.c_str())==0)
						continue;

					tag_t	tSchedWorkflowProcess	=	NULLTAG;
					ITK_LOG(AOM_ask_value_tag(vChildSchedTasks[iChildTaskIdx],WORKFLOW_PROCESS.c_str(),&tSchedWorkflowProcess));

					if(tSchedWorkflowProcess == NULLTAG)
					{
						continue;
					}

					tag_t	tRootTask	=	NULLTAG;
					int		iSubTasksCnt	=	0;
					tag_t*	tSubTasks	=	NULL;
					tag_t 	tPerson			= NULLTAG;
					char* 	pcMailId 		= NULL;
					ITK_LOG(EPM_ask_root_task(tSchedWorkflowProcess,&tRootTask));
					string tRootTaskName = get_string_property(tRootTask,OBJECT_NAME.c_str());
					std::map<string, string>::iterator mTemplateToTaskIter = mTemplateNameToTaskName.find(tRootTaskName);

					if(mTemplateToTaskIter == mTemplateNameToTaskName.end())
					{
						continue;
					}

					ITK_LOG(EPM_ask_sub_tasks(tRootTask,&iSubTasksCnt,&tSubTasks));
					for(int iSubTaskIdx=0;iSubTaskIdx<iSubTasksCnt;iSubTaskIdx++)
					{
						string sSubTaskName = get_string_property(tSubTasks[iSubTaskIdx],OBJ_NAME);
						tag_t	tTaskPerformerUser	= NULLTAG;

						if(mTemplateToTaskIter->second.compare(sSubTaskName)!=0)
						{
							continue;
						}

						ITK_LOG(AOM_ask_value_tag(tSubTasks[iSubTaskIdx],ASSIGNEE.c_str(),&tTaskPerformerUser));

						ITK_LOG(SA_ask_user_person( tTaskPerformerUser,&tPerson));
						ITK_LOG(SA_ask_person_email_address( tPerson, &pcMailId ));
						string	sMailId(pcMailId);
						SAFE_SM_FREE(pcMailId);
						vRecipientsMailId.push_back(sMailId);


						break;
					}
					SAFE_SM_FREE(tSubTasks);
				}
			}
		}

		/* If the recipients Value is $PPAP_DECISIONMAKER then we are getting the mail id of the PPAP Decison Maker */
		else if(tc_strcmp(vRecipients[iRecpIndx].c_str(),PPAP_DECISION_MAKER)==0)
		{


			if(schedule_attachments.size()==1 && schedule_attachments[0]!=NULLTAG && is_of_type(schedule_attachments[0],D4G_PPAPTASK))
			{
				tag_t 	tPPAPDecisionMakerUser	=	NULLTAG;
				tag_t 	tPerson			= NULLTAG;
				char* 	pcMailId 		= NULL;

				ITK_LOG(AOM_ask_value_tag(schedule_attachments[0],PPAPDECISIONMAKER.c_str(),&tPPAPDecisionMakerUser));
				if(tPPAPDecisionMakerUser != NULLTAG ){
				ITK_LOG(SA_ask_user_person( tPPAPDecisionMakerUser,&tPerson));
				ITK_LOG(SA_ask_person_email_address( tPerson, &pcMailId ));
				string	sMailId(pcMailId);
				SAFE_SM_FREE(pcMailId);
				vRecipientsMailId.push_back(sMailId);
				}
			}
		}
		/* If the recipients Value is $PPAP_MANAGER then we are getting the mail id of the PPAP Manager */
		else if(tc_strcmp(vRecipients[iRecpIndx].c_str(),PPAP_MANAGER)==0)
		{
			if(schedule_attachments.size()==1 && schedule_attachments[0]!=NULLTAG && is_of_type(schedule_attachments[0],D4G_PPAPTASK))
			{
				tag_t 	tPPAPManagerUser	=	NULLTAG;
				tag_t 	tPerson			= NULLTAG;
				char* 	pcMailId 		= NULL;

				ITK_LOG(AOM_ask_value_tag(schedule_attachments[0],PPAPMANAGER.c_str(),&tPPAPManagerUser));
				if( tPPAPManagerUser!= NULLTAG ){
				ITK_LOG(SA_ask_user_person( tPPAPManagerUser,&tPerson));
				ITK_LOG(SA_ask_person_email_address( tPerson, &pcMailId ));
				string	sMailId(pcMailId);
				SAFE_SM_FREE(pcMailId);
				vRecipientsMailId.push_back(sMailId);
				}
			}
		}
		/* If the recipients Value is $PPAP_REVIEWER then we are getting the mail id of the PPAP Reviewer */
		else if(tc_strcmp(vRecipients[iRecpIndx].c_str(),PPAP_REVIEWER)==0)
		{
			if(schedule_attachments.size()==1 && schedule_attachments[0]!=NULLTAG && is_of_type(schedule_attachments[0],D4G_PPAPTASK))
			{
				tag_t 	tPPAPReviewerUser	=	NULLTAG;
				tag_t 	tPerson			= NULLTAG;
				char* 	pcMailId 		= NULL;
				ITK_LOG(AOM_ask_value_tag(schedule_attachments[0],PPAPREVIEWER.c_str(),&tPPAPReviewerUser));
				if( tPPAPReviewerUser != NULLTAG )
				{
				ITK_LOG(SA_ask_user_person( tPPAPReviewerUser,&tPerson));
				ITK_LOG(SA_ask_person_email_address( tPerson, &pcMailId ));
				string	sMailId(pcMailId);
				SAFE_SM_FREE(pcMailId);
				vRecipientsMailId.push_back(sMailId);
				}

			}
		}
	}

	tag_t 	tAssignee;
	char*   pcMailFrom = NULL;
	char*   pcProcessName = NULL;
	char*   pctaskName    = NULL;
	vector<tag_t> tPartObjTags;
	vector<tag_t> tTargetObjects;
	/*Get the Reference object where the schedule is refrenced to pass it to mail arguments.*/
	if(schedule_attachments.size()==1 && schedule_attachments[0]!=NULLTAG)
	{
		tag_t rRelationTag = NULLTAG;
		int  iPrimObjCount  = 0;
		tag_t* partObjectTag;

		ITK_LOG(GRM_find_relation_type(CM_HAS_WORK_BREAKDOWN,&rRelationTag));
		ITK_LOG(GRM_list_primary_objects_only(tSchedule, rRelationTag, &iPrimObjCount, &partObjectTag));//memfree
		for(int iPartCnt = 0 ; iPartCnt < iPrimObjCount ; iPartCnt++)
		{
			tPartObjTags.push_back(partObjectTag[iPartCnt]);
		}
		SAFE_SM_FREE(partObjectTag);
	}
	/*Get the required arguments to pass it mail details.*/
	ITK_LOG(AOM_ask_value_tag(tRootTask,ASSIGNEE.c_str(),&tAssignee));
	ITK_LOG(AOM_ask_value_string(tAssignee, OBJ_STRING.c_str() , &pcMailFrom));//memfree
	ITK_LOG(AOM_ask_value_string(tSchedule, OBJ_STRING.c_str() , &pcProcessName));//memfree
	ITK_LOG(AOM_ask_value_string(msg.task,TASK_NAME.c_str(), &pctaskName));//memfree

	/*Storing the information related to mail*/
	detail.sComments = sMailComments;
	detail.sMailSubject = sMailSubject;
	detail.mailReceipents = vRecipientsMailId;
	detail.sTaskName = pctaskName;
	detail.sProcessName = pcProcessName;
	detail.sInstructions = "None";
	detail.sEmailFrom = pcMailFrom;
	detail.vReferenceObjs = tPartObjTags;
	detail.vTargetObjs = tTargetObjects;

	if(vRecipientsMailId.size()>0)
	{

		ITK_LOG(D4G_common_send_os_mail(detail));
	}

	SAFE_SM_FREE(tSchedMems);
	SAFE_SM_FREE(pcMailFrom);
	SAFE_SM_FREE(pcProcessName);
	SAFE_SM_FREE(pctaskName);

	return status;



}
/*This Method traverses through the tasks recursively to get all the child tasks present under each task.*/
extern int  D4G_traverse_and_get_all_tasks(tag_t tSchedSummaryTask , vector<tag_t>* vChildSchedTasks)
{

	int		status				=	ITK_ok;
	vector<tag_t> vSubTasks	=	get_tags_property(tSchedSummaryTask,"child_task_taglist");

	for(int child = 0 ; child < vSubTasks.size() ; child++)
		{
		vChildSchedTasks->push_back(vSubTasks[child]);
			//Recursive loop till the child count is zero
		ITK_LOG(D4G_traverse_and_get_all_tasks(vSubTasks[child],vChildSchedTasks));
		}
	return status;
}


/*This method will send an email to the mentioned recepients*/
extern int  D4G_common_send_os_mail(osMailDetail_t mailDetail)
{
	int		status				=	ITK_ok;

	D4G_Mail* d4gOsMail = new D4G_Mail();
	d4gOsMail->setMailSubject(mailDetail.sMailSubject);
	d4gOsMail->setMailReceipents(mailDetail.mailReceipents);
	d4gOsMail->replaceBodyContent(mailDetail.sTaskName,mailDetail.sProcessName,mailDetail.sDueDate,mailDetail.sEmailFrom,mailDetail.sComments,mailDetail.sInstructions,mailDetail.vTargetObjs,mailDetail.vReferenceObjs);
	status = d4gOsMail->sendMail();

	return status;
}

/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_GetParticipantsFromSignOff
/*  Program ID:         D4G_EPM_Handlers.cxx
/*  Description:        Gets the participants  present in the  sign off team  who are assigned by the manager
/*  Input Parameters:   EPM_action_message_t msg -- Workflow task
/*  Return Value:       int ifail -- return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 29-08-2017	         Bhargav 		     	  3674               Initial Creation
*
* 20-09-2017			 Bhargav				3674				Modified D4G_GetParticipantsFromSignOff function to include ChangeNoticeRevision
* 16-10-2017			 Jayant 				3674				Fixed for QPMR 163, 118 and 135.
*************************************************************************************************************************/
int D4G_GetParticipantsFromSignOff(EPM_action_message_t msg)
{
	int 			iCount				=0;
	int 			iPrefCount			=0;
	int 			iTargCount			=0;
	int 			iIndex				=0;
	int 			isignoffcount		=0;
	int 			iNum				=0;
	int 			iMemberCount		=0;
	int 			iTemp				=0;
	int 			iMemTagCount		=0;
	int 			iTagCount			=0;
	int 			status 				=ITK_ok;
	int 			ifail 				=ITK_ok;

	char**			cppPrefValue		=NULL;
	char*			cpTargObjectName	=NULL;

	SIGNOFF_TYPE_t  tSignOffMemberType 	=SIGNOFF_UNDEFINED ;

	tag_t			tRootTask			=NULLTAG;
	tag_t			tTargTypeTag		=NULLTAG;
	tag_t			tSignOffMember		=NULLTAG;
    tag_t   		tSignOffUser 		=NULLTAG;
    tag_t   		tSignOffGroup 		=NULLTAG;
    tag_t   		tSignOffRole 		=NULLTAG;
    tag_t   		tpersonTag 			=NULLTAG;
    tag_t 			tParticipantType 	=NULLTAG;
    tag_t 			tParticipant 		=NULLTAG;
    tag_t 			tGroupTag 			=NULLTAG;
    tag_t 			tRoleTag 			=NULLTAG;
    tag_t* 			tMemTagArray 		=NULLTAG;
	tag_t*			tSignOffProfiles	=NULLTAG;
	tag_t*			tTarget				=NULLTAG;
	tag_t*			tMemberTags			=NULLTAG;
	logical     	vAllowSubgroup 		=FALSE  ;


	//getting the tag for the workflow task from the the 'start'(msg.task) task
	ITK_LOG(EPM_ask_root_task(msg.task, &tRootTask));

	//getting the tag for the objects attached to the workflow task as a target
	ITK_LOG(EPM_ask_attachments( tRootTask, EPM_target_attachment, &iCount, &tTarget));

	//getting the count of the preference values present in the "D4G_GetParticipantsFromSignOff" preference
	ITK_LOG(PREF_ask_value_count ( GET_PARTICIPANTS_FROM_SIGNOFF, &iPrefCount));

	if (iPrefCount > 0)
	{
		//getting the values stored in the "D4G_GetParticipantsFromSignOff" preference
		ITK_LOG(PREF_ask_char_values ( GET_PARTICIPANTS_FROM_SIGNOFF, &iPrefCount, &cppPrefValue));

	}
	for (iTargCount = 0; iTargCount < iCount; iTargCount++)
	{

		char*			cpObjName			=NULL;

		//getting the target typetag of the target objects
		ITK_LOG(TCTYPE_ask_object_type(tTarget[iTargCount],&tTargTypeTag));

		//getting the type name(eg:D4g_CustomerRequestRevision) of the type tag
		ITK_LOG(TCTYPE_ask_name2(tTargTypeTag,&cpTargObjectName));

		//allocating the memory as per the type of the runtime property(ChangeReviewBoard) used
		if(tc_strcmp(cpTargObjectName,D4G_CHANGE_REQUEST_REVISION)==0)
		{
			cpObjName = (char*)MEM_alloc((tc_strlen(D4G_CHANGE_REVIEW_BOARD) + 1) * sizeof(char));
			tc_strcpy(cpObjName,D4G_CHANGE_REVIEW_BOARD);

		}

		//allocating the memory as per the type of the runtime property(ChangeImplementationBoard or change notice revision) used
		else if((tc_strcmp(cpTargObjectName,D4G_CUSTOMER_REQUEST_REVISION)==0)||(tc_strcmp(cpTargObjectName,D4G_CHANGE_NOTICE_REVISION)==0))
		{
			cpObjName = (char*)MEM_alloc((tc_strlen(D4G_CHANGE_IMPLEMENTATION_BOARD) + 1) * sizeof(char) );
			tc_strcpy(cpObjName,D4G_CHANGE_IMPLEMENTATION_BOARD);

		}

		if(cpObjName != NULL)
		{
			//getting the tags for the signoff profiles assigned by the manager from the 'select sign-off' task (msg.task)
			 ITK_LOG(EPM_ask_attachments(msg.task,EPM_signoff_attachment,&isignoffcount,&tSignOffProfiles));

			for(iIndex= 0;iIndex < iPrefCount ;iIndex++)
			{

				if(tc_strcmp(cppPrefValue[iIndex],cpTargObjectName)==0)
				{

				 for(iNum= 0;iNum< isignoffcount ;iNum++)
				 {

				   //getting the tag for the members who are assigned by the manager from the tag of the sign off profiles
				   ITK_LOG(EPM_ask_signoff_member(tSignOffProfiles[iNum],&tSignOffMember,&tSignOffMemberType));

				   if( tSignOffMemberType == SIGNOFF_GROUPMEMBER )
	               {

					    //Getting the type tag for the participant type name
						ITK_LOG(EPM_get_participanttype(cpObjName , &tParticipantType ) );

						//creating the participant tag for the  tSignOffMember which is of ChangeImplementationBoard type (tParticipantType)
						ITK_LOG(EPM_create_participant( tSignOffMember, tParticipantType, &tParticipant ) );

						//locking the target object(eg:D4g_CustomerRequestRevision) for making changes
						ITK_LOG(AOM_refresh(tTarget[iTargCount],TRUE));

						//adding participant to target object which auomatically gets added to ChangeImplementationBoard participant type
						ITK_LOG(ITEM_rev_add_participant(tTarget[iTargCount], tParticipant ) );

						//Releasing the target object (eg:D4g_CustomerRequestRevision)
						ITK_LOG(AOM_refresh(tTarget[iTargCount],FALSE));

					   }
					   else if(tSignOffMemberType == SIGNOFF_RESOURCEPOOL)
					   {
						   ITK_LOG(EPM_ask_resource_pool_group_role(tSignOffMember, &tGroupTag,&tRoleTag,&vAllowSubgroup) );

						   ITK_LOG(SA_find_groupmember_by_role(tRoleTag,tGroupTag,&iMemberCount,&tMemberTags));

						   int iTagCount=0;
						   for(iTemp=0;iTemp<iMemberCount;iTemp++)
						   {
							   D4G_Add_Tag_To_Array(tMemberTags[iTemp],&iMemTagCount, &tMemTagArray);
							   iTagCount++;

						   }
						   int iEntry =0;
						   for(iEntry=0;iEntry<iTagCount;iEntry++)
						   {

							   ITK_LOG(EPM_get_participanttype(cpObjName , &tParticipantType ) );

							   ITK_LOG(EPM_create_participant( tMemTagArray[iEntry], tParticipantType, &tParticipant ) );

							   ITK_LOG(AOM_refresh(tTarget[iTargCount],TRUE));

							   ITK_LOG(ITEM_rev_add_participant(tTarget[iTargCount], tParticipant ) );

								   ITK_LOG(AOM_refresh(tTarget[iTargCount],FALSE));
							   }
						   }
					 }
				}
			}
		}
		SAFE_SM_FREE(cpObjName);
		SAFE_SM_FREE(cpTargObjectName);
	}

	SAFE_SM_FREE(cppPrefValue);
	SAFE_SM_FREE(tSignOffProfiles);
	SAFE_SM_FREE(tTarget);
	SAFE_SM_FREE(tMemberTags);
	SAFE_SM_FREE(tMemTagArray);


	return ifail;
}

/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_SetOfficialRevision
/*  Program ID:         D4G_EPM_Handlers.cxx
/*  Description:        This workflow handler is used to set Official to true on the latest released revision and set Official to false on the other revisions of the Item
/*  Input Parameters:   EPM_action_message_t msg -- Workflow task
/*  Return Value:       int ifail -- return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 11-09-2017	       Vivek Mundada 		  2739               Initial Creation
*
*************************************************************************************************************************/
int D4G_SetOfficialRevision( EPM_action_message_t msg )
{
	int 	status				 	= ITK_ok	;
	tag_t   tRootTaskTag     		= NULLTAG	;
	tag_t	*tTargetTags	 		= NULL		;
	int		iTargetCount	 		= 0			;
	tag_t   tTargetObjTag	 		= NULLTAG	;
	int		iCounter		 		= 0			;

	tag_t   target_item_tag         = NULLTAG	;   /* 		Item  tag 	     */
	int     iRevisionCount         	= 0			;   /* 	Number of revisions  */
	tag_t   *tRev_tags    			= NULL		;   /* 		Revision tags 	 */
	tag_t 	tSpecRelTypeTag			= NULLTAG	;
	int 	iNumObjsFound 			= 0			;
	tag_t 	*tSecondaryObjects 		= NULL		;

	int 	iReleaseStatusCount 	= 0			;
	char	*cpReleaseStatusName	= NULL		;
	tag_t 	*tReleaseStatusListTags = NULL		;

	ITK_LOG( EPM_ask_root_task( msg.task, &tRootTaskTag ) );

	ITK_LOG( EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tTargetTags ) );

	for( iCounter = 0; iCounter < iTargetCount; iCounter++ )
	{
		tTargetObjTag = tTargetTags[iCounter];

		ITK_LOG( GRM_find_relation_type( "CMHasSolutionItem", &tSpecRelTypeTag ) );

		ITK_LOG( GRM_list_secondary_objects_only( tTargetObjTag, tSpecRelTypeTag, &iNumObjsFound, &tSecondaryObjects ) );

		for( int docRev = 0 ; docRev < iNumObjsFound ; docRev++ )
		{
			if( tSecondaryObjects[docRev] != NULLTAG )
			{
				ITK_LOG( ITEM_ask_item_of_rev( tSecondaryObjects[docRev], &target_item_tag ) );

				ITK_LOG( ITEM_list_all_revs( target_item_tag, &iRevisionCount , &tRev_tags ) );

				if( iRevisionCount > 1 )
				{
					sortRevisionIds( tRev_tags, iRevisionCount );
				}

				if( tSecondaryObjects[docRev] == tRev_tags[iRevisionCount-1] )
				{
					ITK_LOG( AOM_ask_value_tags( tSecondaryObjects[docRev], RELEASE_STATUS_LIST.c_str(), &iReleaseStatusCount, &tReleaseStatusListTags ) );

					for( int iReleaseStatusCounter = 0; iReleaseStatusCounter < iReleaseStatusCount; iReleaseStatusCounter++ )
					{
						ITK_LOG( AOM_ask_value_string( tReleaseStatusListTags[iReleaseStatusCounter], OBJECT_NAME.c_str(), &cpReleaseStatusName ) );

						if( cpReleaseStatusName != NULL && tc_strcmp( cpReleaseStatusName, STATUS_RELEASED.c_str() ) == 0 )
						{
							set_bypass( true );

							for( int iRevisionCounter = 0; iRevisionCounter < iRevisionCount-1; iRevisionCounter++ )
							{
								ITK_LOG( AOM_refresh( tRev_tags[iRevisionCounter], true ) );
								ITK_LOG( AOM_set_value_logical( tRev_tags[iRevisionCounter], OFFICIAL_REVISION.c_str(), false ) );
								ITK_LOG( AOM_save( tRev_tags[iRevisionCounter] ) );
								ITK_LOG( AOM_refresh( tRev_tags[iRevisionCounter], false ) );
							}

							ITK_LOG( AOM_refresh( tRev_tags[iRevisionCount-1], true ) );
							ITK_LOG( AOM_set_value_logical( tRev_tags[iRevisionCount-1], OFFICIAL_REVISION.c_str(), true ) );
							ITK_LOG( AOM_save( tRev_tags[iRevisionCount-1] ) );
							ITK_LOG( AOM_refresh( tRev_tags[iRevisionCount-1], false ) );

							set_bypass( false );

							break;
						}
						else if( cpReleaseStatusName != NULL && tc_strcmp( cpReleaseStatusName, STATUS_OBSOLETE.c_str() ) == 0 )
						{
							set_bypass( true );

							for( int iRevisionCounter = 0; iRevisionCounter < iRevisionCount; iRevisionCounter++ )
							{
								ITK_LOG( AOM_refresh( tRev_tags[iRevisionCounter], true ) );
								ITK_LOG( AOM_set_value_logical( tRev_tags[iRevisionCounter], OFFICIAL_REVISION.c_str(), false ) );
								ITK_LOG( AOM_save( tRev_tags[iRevisionCounter] ) );
								ITK_LOG( AOM_refresh( tRev_tags[iRevisionCounter], false ) );
							}

							set_bypass( false );

							break;
						}
					}
				}
			}
		}
	}

	SAFE_SM_FREE( tTargetTags );
	SAFE_SM_FREE( tSecondaryObjects );
	SAFE_SM_FREE( tRev_tags );
	SAFE_SM_FREE( tReleaseStatusListTags );

	return status;
}

/*********************************************************************************************************************/
/*
/*  Function Name:      D4G_CheckOwningGroup
/*  Program ID:         D4G_EPM_Handlers.cxx
/*  Description:        Checks whether the object owning group and role's owning group are same
/*  Input Parameters:   EPM_rule_message_t msg -- Workflow task
/*  Return Value:       EPM_desision_t -- return status
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 13-10-2017	         Bhargav 		     	2745               Initial Creation
*
*************************************************************************************************************************/
EPM_decision_t D4G_CheckOwningGroup(EPM_rule_message_t msg)
{

	int 			iCount				=0;
	int 			iPrefCount			=0;
	int 			iTargCount			=0;
	int 			iIndex				=0;
	int 			status 				=ITK_ok;

	char**			cppPrefValue		=NULL;
	char*			cpTargObjectName	=NULL;
	char*			cpRoleName	=NULL;
	char*			cpObjectName	=NULL;

	tag_t			tRootTask			=NULLTAG;
	tag_t			tCurrentGroupmemberTag		=NULLTAG;
	tag_t			tGroupTag		=NULLTAG;
	tag_t			tCurrentRoleTag		=NULLTAG;
	tag_t			tOwningGroup		=NULLTAG;
	tag_t			tTargTypeTag		=NULLTAG;
	tag_t*			tTarget				=NULLTAG;


	//getting the tag for the workflow task from the the 'start'(msg.task) task
	ITK_LOG(EPM_ask_root_task(msg.task, &tRootTask));

	//getting the tag for the objects attached to the workflow task as a target
	ITK_LOG(EPM_ask_attachments( tRootTask, EPM_target_attachment, &iCount, &tTarget));

	//getting the count of the preference values present in the "D4G_DanfossWorkflowObjects" preference
	ITK_LOG(PREF_ask_value_count ( DANFOSS_WORKFLOW_OBJECTS, &iPrefCount));

	if (iPrefCount > 0)
	{
		//getting the values stored in the "D4G_DanfossWorkflowObjects" preference
		ITK_LOG(PREF_ask_char_values ( DANFOSS_WORKFLOW_OBJECTS, &iPrefCount, &cppPrefValue));

	}
	for (iTargCount = 0; iTargCount < iCount; iTargCount++)
	{
		//getting the target typetag of the target objects
		ITK_LOG(TCTYPE_ask_object_type(tTarget[iTargCount],&tTargTypeTag));

		//getting the type name(eg:D4g_DanPartRevision) of the type tag
		ITK_LOG(TCTYPE_ask_name2(tTargTypeTag,&cpTargObjectName));

		for(iIndex= 0;iIndex < iPrefCount ;iIndex++)
		{
			//checking whether the target object is matching with any value in the preference
			if(tc_strcmp(cppPrefValue[iIndex],cpTargObjectName)==0)
			{

				//getting the tag for the value of the 'owning_group' property of the target item
				ITK_LOG(AOM_ask_value_tag(tTarget[iTargCount],"owning_group",&tOwningGroup));

				//getting the tag for the user
				ITK_LOG( SA_ask_current_groupmember	(&tCurrentGroupmemberTag));

				//Getting the current user's grouptag
				ITK_LOG( SA_ask_groupmember_group(tCurrentGroupmemberTag,&tGroupTag));

				//getting the tag for the value of the 'object_string' property of the target item
				ITK_LOG(AOM_ask_value_string(tTarget[iTargCount],OBJ_STRING.c_str(),&cpObjectName));

				if(tOwningGroup!=tGroupTag)
				{
					ITK_LOG(EMH_store_error_s1(EMH_severity_error,OWNING_GROUP,cpObjectName));
					return EPM_nogo;
				}

			}
		}
	}
	SAFE_SM_FREE(tTarget);
	SAFE_SM_FREE(cppPrefValue);
	SAFE_SM_FREE(cpTargObjectName);
	SAFE_SM_FREE(cpRoleName);
	SAFE_SM_FREE(cpObjectName);

	return EPM_go;
}
extern int D4G_EPM_Handlers(METHOD_message_t* msg, va_list args)
{
	(void)msg;
	(void)args;
	int status = 0;
	string loadmsg = "Loading custom handler library <D4G_EPM_Handlers> "+version+" ("+__DATE__+" "+__TIME__+")";
	cout <<loadmsg<<"\n";
	TC_write_syslog(loadmsg.c_str());
	// Rule Handler register calls
	ITK_LOG(EPM_register_rule_handler("D4G-check-current-user",
			"Checks if the current user is one of the participants specified by -allowed_initiator argument.",
			D4G_CheckCurrentUser));
	ITK_LOG(EPM_register_rule_handler("D4G-check-for-obsolete",
			"",
			D4G_CheckForObsolete));
	ITK_LOG(EPM_register_rule_handler("D4G-check-PDP-Milestones",
			"Checks if Milestones defined by preference are done for attached PDP Items.",
			D4G_CheckPDPMilestones));
	ITK_LOG(EPM_register_rule_handler("D4G-check-properties",
			"Checks if properties at the object at the end of the search path have the correct values.",
			D4G_CheckPropertiesDeepSearch));
	ITK_LOG(EPM_register_rule_handler("D4G-check-ppap",
			"Checks if all attached PPAP Schedules have the desired status.",
			D4G_CheckPPAP));
	ITK_LOG(EPM_register_rule_handler("D4G-require-approver",
			"Checks if approver is set on task and if that approver is not the same user that started the task.",
			D4G_RequireApprover));
	ITK_LOG(EPM_register_rule_handler("D4G-Check-Signoff-Comments",
				"Checks whether signoff comments are added while setting a decision on a task.",
				D4G_CheckSignoffComments));
	ITK_LOG(EPM_register_rule_handler( "D4G-Validate-Map-Replacement-Part",
					"to validate if all parts from solution items are mapped with replacement part",
					D4G_ValidateMapReplacementPart ));
	ITK_LOG(EPM_register_rule_handler( "D4G-check-alternate-BOMs",
					"Validate if alternate bom exist under Change Master",
					D4G_CheckAlternateBOMs ));
	ITK_LOG(EPM_register_rule_handler( "D4G-check-Owning-Group",
						"checks owning group of object and role",
						D4G_CheckOwningGroup ));

	// Action Handler register calls
	ITK_LOG(EPM_register_action_handler("D4G-assign-to-project",
			"Assigns attached objects to specified projects.",
			D4G_AssignToProject));
	ITK_LOG(EPM_register_action_handler("D4G-Baseline-PDP-item-revision",
			"Baselines item revisions,",D4G_baseline_PDP_item_revision));
	ITK_LOG(EPM_register_action_handler("D4G-create-relation",
			"Creates relation between specified primary and secondary items.",
			D4G_CreateRelation));
	ITK_LOG(EPM_register_action_handler("D4G-delete-related-object",
			"Deletes relations and the related objects as well, if they are an orphan.",
			D4G_deleteRelatedObject));
	ITK_LOG(EPM_register_action_handler("D4G-remove-from-project",
			"Removes attached objects from specified projects.",
			D4G_RemoveFromProject));
	ITK_LOG(EPM_register_action_handler("D4G-set-major-revision",
			"Sets the item revision to the next major revision.",
			D4G_SetMajorRevision));
	ITK_LOG(EPM_register_action_handler("D4G-set-properties",
			"Sets properties on the objects at the end of the search path.",
			D4G_SetProperties));
	ITK_LOG(EPM_register_action_handler("D4G-subprocess",
			"Starts subprocess on related items that match properties of target item.",
			D4G_SubprocessDeepSearch));
	ITK_LOG(EPM_register_action_handler( "D4G_UpdateItemOnRevise",
			"Update Item name & description when released status is set",
			D4G_UpdateItemOnRevise));
	ITK_LOG(EPM_register_action_handler( "D4G_AttachPartsAsReference",
			"Attach all the related Danfossparts as reference to the workflow task",
			D4G_AttachPartsAsReference ));
	ITK_LOG(EPM_register_action_handler( "D4G_ModifyPlantProperty",
				"Modify d4g_tansferred property of plants associated to Dan Part rev to True while its been send to SAP ",
				D4G_ModifyPlantProperty ));
	ITK_LOG(EPM_register_action_handler("D4G-mass-update-replace-items",
				"Replace Bom Items in Mass Mass Update",
				D4G_Mass_Update_Replace_Items));
	ITK_LOG(EPM_register_action_handler("D4G-mass-obsolete-preparation",
				"Mass Obsolete Preparation",
				D4G_Mass_Obsolete_Preparation));
	ITK_LOG(EPM_register_action_handler("D4G-mass-update-preparation",
				"Mass Mass Update Preparation",
				D4G_Mass_Update_Preparation));
	ITK_LOG(EPM_register_action_handler( "D4G-change-schedule-job-name",
				"Change Job name for Schedule workflow",
				D4G_ChangeScheduleJobName ));			
	ITK_LOG(EPM_register_action_handler( "D4G_SendEmailNotification",
			"Send Emails to the specified persons in the Handler argument",
			D4G_SendEmailNotification ));	
	ITK_LOG(EPM_register_action_handler( "D4G_GetParticipantsFromSignOff",
			"Gets the participants  present in the  sign off team  who are assigned by the manager",
			D4G_GetParticipantsFromSignOff ));
	ITK_LOG(EPM_register_action_handler( "D4G-set-official-revision",
			"This workflow handler is used to set Official to true on the latest released revision and set Official to false on the other revisions of the Item",
			D4G_SetOfficialRevision ));
	return ITK_ok;
}
