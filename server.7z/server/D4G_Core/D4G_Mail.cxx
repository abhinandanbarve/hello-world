/*==============================================================================
 Copyright (c) 2017 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Author  : Chandrashekher Gonnabathula

 Description:  This class has the implementation to send os mail in OOTB mail notification format.
=========================================================================================================================

Date              Name                          Description
-------------------------------------------------------------------------------------------------------------------------


30-Aug-2017    Chandrashekher                   Intitial Creation


 ===============================================================================*/

#include <D4G_Core/D4G_Mail.hxx>
#include <stdlib.h>
#include <cstdlib>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <time.h>


/*HTML elements for adding new table row under Target and Reference section*/
std::string newTableDataStyle("<td style=\"border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 1.5pt\">");
std::string newTableData("<p class=\"MsoNormal\" align=\"center\" style=\"text-align:center\"><span style=\"font-family:&quot;Arial&quot;,sans-serif\">$TABLE_DATA");

/*Default Constructor*/
D4G_Mail::D4G_Mail( )
{

    getFile();
}
/*Default Destructor*/
D4G_Mail::~D4G_Mail( )
{
}

/*This method reads the input file which has the OOTB mail format information.This file will be read line by line and stored in the Vector.*/
std::ifstream& D4G_Mail::getFile( )
{
	std::string sHTMLFileLocation = "";
	char* sTCRoot = getenv("TC_ROOT");
	sHTMLFileLocation.append(sTCRoot);
	sHTMLFileLocation.append("\\bin\\");
	sHTMLFileLocation.append("d4g_danfoss_mail_format.htm");
    stdMailFormatFile.open(sHTMLFileLocation);

    std::string thisLine;
    while (getline(stdMailFormatFile, thisLine))
    {
        vInputFileLines.push_back(thisLine);
    }
    return stdMailFormatFile;
}
using namespace std;
/*This method creates the output HTML file that will be sent as the mail body*/
std::ofstream& D4G_Mail::getMailBody( )
{
    char* sDefaultTempDir = getenv("TC_TMP_DIR");
    if (sDefaultTempDir == NULL)
        sDefaultTempDir = getenv("TEMP");

    std::string sOutputFileName("danfoss_mail_notification_");

    time_t timeNow;
    struct tm * timeinfo;
    char cTimeStamp[30];

    time(&timeNow);
    timeinfo = localtime(&timeNow);

    strftime(cTimeStamp, 30, "%Y%m%d%H%M%S", timeinfo);
    sOutputFileName.append(cTimeStamp);

    sOutputFilePath.append(sDefaultTempDir);
    sOutputFilePath.append("\\");
    sOutputFilePath.append(sOutputFileName);
    sOutputFilePath.append(".htm");

    outputMailFile.open(sOutputFilePath);

    std::string thisLine;
    for (int iLineIdx = 0; iLineIdx < vInputFileLines.size(); iLineIdx++)
    {
        outputMailFile << vInputFileLines[iLineIdx]<<endl;


    }
    outputMailFile.close();

    return outputMailFile;
}

std::string D4G_Mail::getSender( )
{
    return "chandrashekher.gonnabathula@siemens.com";
}
/*Reading the mail server name from preference and passing it to the mail server argument */
std::string D4G_Mail::getMailServer( )
{
    char* pcMailServerName = NULL;
    PREF_ask_char_value("Mail_server_name", 0, &pcMailServerName);

    sMailServer = pcMailServerName;
    MEM_free(pcMailServerName);

    return sMailServer;
}
/*Reading the mail subject and passing it to the mail subject argument */
std::string D4G_Mail::getMailSubject( )
{
    return sMailSubject;
}
/*Sets mail subject.By default mail subjec will be enclosed in the double quotes to scenarios like spaces in mail subject.
 *  so that there will be no further issues while executing utility*/
void D4G_Mail::setMailSubject(std::string sMailSubject)
{
    this->sMailSubject.append("\"");
    this->sMailSubject.append(sMailSubject);
    this->sMailSubject.append("\"");
}
/*This invokes the TC OOTB utility with the specified arguments.
 *  once the utility is successfully executed the output html which served as the mail body will be deleted.*/
using namespace std;
int D4G_Mail::sendMail( )
{
	std::string commandStr = generateCommand();

    cout << "Command to be executed is" << endl;
    cout << commandStr << endl;

    int status = system(commandStr.c_str());

    if (status == 0)
    {
        cout << "Sent Mail successfully" << endl;
        remove(sOutputFilePath.c_str());
    }
    else
    {
        cout << "Issue in Sending mail" << endl;
    }
return status;
}

/*Sets the recepients email id*/
void D4G_Mail::setMailReceipents(std::vector<std::string> vMailReceipents)
{
    this->vMailReceipents = vMailReceipents;
}
/*Gets recipinets email id and passes it as a -to(argument) for the utility */
std::string D4G_Mail::getMailReceipents( )
{
    std::string sMailReceipentStr("");
    for (int iRecIdx = 0; iRecIdx < vMailReceipents.size(); iRecIdx++)
    {
        sMailReceipentStr.append(vMailReceipents[iRecIdx]);
        sMailReceipentStr.append(" ");
        if (iRecIdx != (vMailReceipents.size() - 1))
            sMailReceipentStr.append("-to=");
    }

    return sMailReceipentStr;
}
/*This method generates the command along with its argument for the execution of "tc_mail_smtp.exe" utility*/
std::string D4G_Mail::generateCommand( )
{
    string sCommand;

    sCommand.append("tc_mail_smtp.exe ");
    sCommand.append("-to=");
    sCommand.append(getMailReceipents());
    sCommand.append(" ");

    sCommand.append("-server=");
    sCommand.append(getMailServer());
    sCommand.append(" ");

    sCommand.append("-subject=");
    sCommand.append(getMailSubject());
    sCommand.append(" ");

    getMailBody();

    sCommand.append("-body=");
    sCommand.append(sOutputFilePath);
    sCommand.append(" ");

    return sCommand;
}

/*This method gives the default value if the user argument is empty or none.*/
std::string D4G_Mail::getDefaultReplacementStr(std::string  sPlaceHolderCont)
{
    std::string defaultReplacementStr("None");
    for(int iStrIdx=4;iStrIdx<sPlaceHolderCont.length();iStrIdx++)
        defaultReplacementStr.append(" ");

    return defaultReplacementStr;
}


/*This method reads the vector(vInputFileLines) which we populated it with OOTB mail format information in getFile() method.
 * It reads each elements of the vector and looks for the specific key words like($TASK_NAME,$PROCESS_NAME,$DUE_DATE,.....,$REFERENCES) and
 * replace them with specified input information obtained from the arguments. */

void D4G_Mail::replaceBodyContent(std::string sTaskName,
        std::string sProcessName, std::string sDueDate, std::string sEmailFrom,
        std::string sComments, std::string sInstructions,
        std::vector<tag_t> vTargets, std::vector<tag_t> vReferences)
{

    std::string sTaskNameConst("$TASK_NAME");
    std::string sProcessNameConst("$PROCESS_NAME");
    std::string sDueDateConst("$DUE_DATE");
    std::string sEmailFromConst("$EMAIL_FROM");
    std::string sCommentConst("$COMMENTS");
    std::string sInstructionsConst("$INSTRUCTIONS");
    std::string sTargetsConst("$TARGETS");
    std::string sReferencesConst("$REFERENCES");

    for (int iLineIdx = 0; iLineIdx < vInputFileLines.size(); iLineIdx++)
    {
        size_t pos = vInputFileLines[iLineIdx].find(sTaskNameConst);
                if (pos != string::npos)
                {

                    if(sTaskName.empty() || sTaskName.compare("NONE")==0 || sTaskName.compare("None")==0)
                        vInputFileLines[iLineIdx].replace(pos, sTaskNameConst.length(), getDefaultReplacementStr(sTaskNameConst));
                    else
                        vInputFileLines[iLineIdx].replace(pos, sTaskName.length(), sTaskName);
                    continue;
                }

                pos = vInputFileLines[iLineIdx].find(sProcessNameConst);
                if (pos != string::npos)
                {

                    if(sProcessName.empty() || sProcessName.compare("NONE")==0 || sProcessName.compare("None")==0)
                        vInputFileLines[iLineIdx].replace(pos, sProcessNameConst.length(), getDefaultReplacementStr(sProcessNameConst));
                    else
                        vInputFileLines[iLineIdx].replace(pos, sProcessName.length(), sProcessName);
                    continue;
                }

                pos = vInputFileLines[iLineIdx].find(sDueDateConst);
                if (pos != string::npos)
                {

                    if (sDueDate.empty() || sDueDate.compare("None")==0 || sDueDate.compare("NONE")==0)
                        vInputFileLines[iLineIdx].replace(pos, sDueDateConst.length(), getDefaultReplacementStr(sDueDateConst));
                    else
                        vInputFileLines[iLineIdx].replace(pos, sDueDate.length(), sDueDate);
                    continue;
                }

                pos = vInputFileLines[iLineIdx].find(sEmailFromConst);
                if (pos != string::npos)
                {

                    if (sEmailFrom.empty() || sEmailFrom.compare("None")==0 || sEmailFrom.compare("NONE")==0)
                        vInputFileLines[iLineIdx].replace(pos, sEmailFromConst.length(), getDefaultReplacementStr(sEmailFromConst));
                    else
                        vInputFileLines[iLineIdx].replace(pos, sEmailFrom.length(), sEmailFrom);
                    continue;
                }

                pos = vInputFileLines[iLineIdx].find(sCommentConst);
                if (pos != string::npos)
                {

                    if (sComments.empty() || sComments.compare("None")==0 || sComments.compare("NONE")==0)
                        vInputFileLines[iLineIdx].replace(pos, sCommentConst.length(), getDefaultReplacementStr(sCommentConst));
                    else
                        vInputFileLines[iLineIdx].replace(pos, sComments.length(), sComments);
                    continue;
                }

                pos = vInputFileLines[iLineIdx].find(sInstructionsConst);
                if (pos != string::npos)
                {

                    if (sInstructions.empty() || sInstructions.compare("None")==0 || sInstructions.compare("NONE")==0)
                        vInputFileLines[iLineIdx].replace(pos, sInstructionsConst.length(), getDefaultReplacementStr(sInstructionsConst));
                    else
                        vInputFileLines[iLineIdx].replace(pos, sInstructions.length(), sInstructions);
                    continue;
                }

        pos = vInputFileLines[iLineIdx].find(sTargetsConst);
        if (pos != string::npos)
        {

            string sTargetsStr;

            if(vTargets.size()==0)
            {
                vInputFileLines[iLineIdx].replace(pos, sTargetsConst.length(), sTargetsStr);
                continue;
            }

            for (int iTargetIdx = 0; iTargetIdx < vTargets.size(); iTargetIdx++)
            {
                string thisTargetStr;
                thisTargetStr.append("<tr>");

                thisTargetStr.append(newTableDataStyle);
                thisTargetStr.append(newTableData);

                char* pcObjStr = NULL;
                char* pcObjType = NULL;
                AOM_ask_value_string(vTargets[iTargetIdx], "object_string", &pcObjStr);
                AOM_ask_value_string(vTargets[iTargetIdx], "object_type", &pcObjType);

                string sObjStr(pcObjStr);
                string sObjectType(pcObjType);

                MEM_free(pcObjStr);
                MEM_free(pcObjType);

                size_t targetPos = thisTargetStr.find("$TABLE_DATA");
                thisTargetStr.replace(targetPos, sObjStr.length(), sObjStr);

                thisTargetStr.append("</span></p></td>");
                thisTargetStr.append(newTableDataStyle);
                thisTargetStr.append(newTableData);

                size_t targetPos1 = thisTargetStr.find("$TABLE_DATA");
                thisTargetStr.replace(targetPos1, sObjectType.length(), sObjectType);

                thisTargetStr.append("</span></p></td>");
                thisTargetStr.append("</tr>");
                sTargetsStr.append(thisTargetStr);
            }
            vInputFileLines[iLineIdx].replace(pos, sTargetsStr.length(), sTargetsStr);
            continue;
        }

        pos = vInputFileLines[iLineIdx].find(sReferencesConst);
        if (pos != string::npos)
        {

            string sReferenceStr;

            if(vReferences.size()==0)
            {
                vInputFileLines[iLineIdx].replace(pos,sReferencesConst.length(), sReferenceStr);
                continue;
            }

            for (int iRefIdx = 0; iRefIdx < vReferences.size(); iRefIdx++)
            {
                string thisReferenceStr;
                thisReferenceStr.append("<tr>");

                thisReferenceStr.append(newTableDataStyle);
                thisReferenceStr.append(newTableData);

                char* pcObjStr = NULL;
                char* pcObjType = NULL;
                AOM_ask_value_string(vReferences[iRefIdx], "object_string", &pcObjStr);
                AOM_ask_value_string(vReferences[iRefIdx], "object_type", &pcObjType);

                string sObjStr(pcObjStr);
                string sObjectType(pcObjType);

                MEM_free(pcObjStr);
                MEM_free(pcObjType);

                size_t targetPos = thisReferenceStr.find("$TABLE_DATA");
                thisReferenceStr.replace(targetPos, sObjStr.length(), sObjStr);

                thisReferenceStr.append("</span></p></td>");
                thisReferenceStr.append(newTableDataStyle);
                thisReferenceStr.append(newTableData);

                size_t targetPos1 = thisReferenceStr.find("$TABLE_DATA");
                thisReferenceStr.replace(targetPos1, sObjectType.length(), sObjectType);

                thisReferenceStr.append("</span></p></td>");
                thisReferenceStr.append("</tr>");
                sReferenceStr.append(thisReferenceStr);
            }
            vInputFileLines[iLineIdx].replace(pos, sReferenceStr.length(), sReferenceStr);
            continue;
        }
    }
}

