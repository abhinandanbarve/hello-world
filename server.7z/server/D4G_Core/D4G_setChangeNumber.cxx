/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_setChangeNumber
 	 - A relation creation PostAction that sets the property d4g_ChangeID of a
 	 secondary ItemRevision to the item_id of a primary D4G_ChangeNoticeRevision.
 	 Takes bypass to set property regardless of access rights.

 ===============================================================================*/

#include <D4G_Core/D4G_setChangeNumber.hxx>
#include <ug_va_copy.h>
#include <metaframework/CreateInput.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <ITKCallHeader.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <mld/logging/Logger.hxx>

static std::string loggerName = "Danfoss.D4G_Core.D4G_setChangeNumber";
static Teamcenter::Logging::Logger *logger = Teamcenter::Logging::Logger::getLogger(loggerName);

int D4G_setChangeNumber( METHOD_message_t *msg, va_list args )
{
	logger->debug("[DANFOSS][D4G_Core][D4G_setChangeNumber][D4G_setChangeNumber] - Entering the method");

	// Get primary and secondary object tags
	Teamcenter::CreateInput *creInput=va_arg(args,Teamcenter::CreateInput*);
	tag_t secondary=NULLTAG;
	tag_t primary=NULLTAG;
	bool isNull=true;
	creInput->getTag(std::string("secondary_object"),secondary,isNull);
	creInput->getTag(std::string("primary_object"),primary,isNull);

	// If relation attaches ItemRevision to Change Notice Revision
	if(is_of_type(primary,"D4G_ChangeNoticeRevision") && is_of_type(secondary,"ItemRevision"))
	{
		logger->debug("[DANFOSS][D4G_Core][D4G_setChangeNumber][D4G_setChangeNumber] - Primary is CN and Secondary is ItemRevision");
		// Set property d4g_ChangeID on secondary to primary item_id using bypass
		std::string changeNumber = get_string_property(primary,"item_id");
		logical current;
		AM__ask_application_bypass(&current);
		set_bypass(true);
		ITK_LR(AOM_lock(secondary));
		ITK_LR(AOM_assign_string(secondary, "d4g_ChangeID",changeNumber.c_str()));
		//9-5-2017 : Robert : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
		//ITK_LR(AOM_save(secondary));
		ITK_LR(AOM_save_with_extensions(secondary));
		ITK_LR(AOM_unlock(secondary));
		set_bypass(current);
	}
	logger->debug("[DANFOSS][D4G_Core][D4G_setChangeNumber][D4G_setChangeNumber] - Exiting the method");
	return ITK_ok;
}
