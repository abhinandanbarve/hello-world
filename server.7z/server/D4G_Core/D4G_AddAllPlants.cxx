/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Ravikiran Choudhari

 Description:   This Extension is added on IMAN_save to copy all values from d4g_Plants array properties to redundant d4g_PlanstsString property on process document.
				Issue = 2837
				redundant proprty is added because array properties are not allowed to map in office attribute mapping.

				TC_save_msg       "IMAN_save"
				Assign single object to a project

				@param tag_t   item_tag
				@param tag_t   proj_tag
				@param int    *errorCode
				@param logical alwaysPropagate
				@param TagList projObjList
				@param TagList wsoObjList

 ===============================================================================*/

#include <D4G_Core/D4G_AddAllPlants.hxx>
#include <ug_va_copy.h>
#include <ITKCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <mld/logging/Logger.hxx>

static std::string loggerName = "Danfoss.D4G_Core.D4G_AddAllPlants";
static Teamcenter::Logging::Logger *logger = Teamcenter::Logging::Logger::getLogger(loggerName);

int D4G_AddAllPlants( METHOD_message_t *msg, va_list args )
{
	logger->debug("[DANFOSS][D4G_Core][D4G_AddAllPlants][D4G_AddAllPlants] - Entering the method");
	tag_t       ItemRev_tag = NULLTAG;
	va_list     copyArgs;
	char** pszPlants = NULL;
	int iPlants = 0, i;

	// Get the parameters from the ITEM_save message
	va_copy(copyArgs, args);
	ItemRev_tag = va_arg(copyArgs, tag_t);
	va_end(copyArgs);
	
	// Get values of property d4g_Plants
	ITK_LR(AOM_ask_value_strings(ItemRev_tag, "d4g_Plants", &iPlants, &pszPlants));

	std::string pszPlantAll = "";
	if (pszPlants!=NULL)
	{
		logger->debug("[DANFOSS][D4G_Core][D4G_AddAllPlants][D4G_AddAllPlants] - Entering the method");
		pszPlantAll = pszPlants[0];
		//get comma seperated string of all values from d4g_Plants
		for (i = 1; i < iPlants; i++)
		{
			pszPlantAll = pszPlantAll + ","+ pszPlants[i];
		}

		char* pszPlant = (char*) MEM_alloc(CHARSIZE*sizeof(char));
		strcpy(pszPlant, pszPlantAll.c_str());

		//Take bypass and with bypass fill the property d4g_PlantsString on process document
		logical current;
		AM__ask_application_bypass(&current);
		set_bypass(true);
		ITK_LR(AOM_lock(ItemRev_tag));
		ITK_LR(AOM_set_value_string(ItemRev_tag, "d4g_PlantsString", pszPlant));
		ITK_LR(AOM_save_without_extensions(ItemRev_tag));
		ITK_LR(AOM_unlock(ItemRev_tag));
		set_bypass(current);

		if(pszPlant != NULL)
		{
			if(strlen(pszPlant) != 0)
			{
				SAFE_SM_FREE(pszPlant);
			}
		}

	}
return 0;
}
