/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Business Object D4G_DanPartRevision
    - The Condition Operation for the Condition d4g_hasObsoletePlant that checks
    that no Obsolete plants exist, before adding a DanPartRevision to a BOMItemRevision.
    - A setter method for the property d4g_testRuns that checks if any of the
    pasted objects are D4G_TestContRevision's and if yes attaches this
    Danfoss Part Revision to them via D4G_TestContRel Relation.
    - A standard setter method for the d4g_ReplacedBy property.

 ===============================================================================*/

#ifndef DANFOSS_GLOBAL_PLM__D4G_DANPARTREVISIONIMPL_HXX
#define DANFOSS_GLOBAL_PLM__D4G_DANPARTREVISIONIMPL_HXX

#include <D4G_Core/D4G_DanPartRevisionGenImpl.hxx>

#include <D4G_Core/libd4g_core_exports.h>

#define D4G_DanPartRevisionPomClassName "D4G_DanPartRevision"

namespace Danfoss_Global_PLM
{
   class D4G_DanPartRevisionImpl; 
   class D4G_DanPartRevisionDelegate;
}
 
class  D4G_CORE_API Danfoss_Global_PLM::D4G_DanPartRevisionImpl
           : public Danfoss_Global_PLM::D4G_DanPartRevisionGenImpl 
{
public:    

    // find method
    // static status_t find();  


   /**
    * 
    * @param bomItemRevision - bomItemRevision
    * @param output - 
    * @return - 
    */
    int  d4g_hasObsoletePlantBase( tag_t bomItemRevision, bool *output );

    /**
     * Setter for a Tag Array Property
     * @param values - Values to be set for the parameter
     * @param isNull - If array element is true, set the parameter value at that location as null
     * @return - Status. 0 if successful
     */
     int  setD4g_testRunsBase( const std::vector<tag_t> &values, const std::vector<int> *isNull );


protected:
    // Constructor for a D4G_DanPartRevision
    explicit D4G_DanPartRevisionImpl( D4G_DanPartRevision& busObj );

    // Destructor
    ~D4G_DanPartRevisionImpl();

    /**
     * Setter for a string Property
     * @param value - Value to be set for the parameter
     * @param isNull - If true, set the parameter value to null
     * @return - Status. 0 if successful
     */
    int  setD4g_ReplacedBy( const std::string &value, bool isNull );


private:
    // Default Constructor for the class
    D4G_DanPartRevisionImpl();
    
    // Private default constructor. We do not want this class instantiated without the business object passed in.
    D4G_DanPartRevisionImpl( const D4G_DanPartRevisionImpl& );

    // Copy constructor
    D4G_DanPartRevisionImpl& operator=( const D4G_DanPartRevisionImpl& );

    // Method to initialize this Class
    static int initializeClass();

    //static data
    friend class Danfoss_Global_PLM::D4G_DanPartRevisionDelegate;

};

#include <D4G_Core/libd4g_core_undef.h>
#endif // DANFOSS_GLOBAL_PLM__D4G_DANPARTREVISIONIMPL_HXX
