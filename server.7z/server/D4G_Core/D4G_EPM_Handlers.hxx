/*==============================================================================
 Copyright (c) 2014 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Handlers
 Author  : Sven Simonsen

 Description:    contains the implementation of the D4G_EPM_Handlers
 	 and registration calls for said handlers.

 ===============================================================================*/
 
#ifndef D4G_EPM_HANDLERS_HXX
#define D4G_EPM_HANDLERS_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_EPM_Handlers(METHOD_message_t* msg, va_list args);
void D4G_Add_Tag_To_Array(tag_t add_tag, int *n_tag_array, tag_t **tag_array);

                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_EPM_HANDLERS_HXX
