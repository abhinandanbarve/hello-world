/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_BOMItem_get_PartID
    - A getter method override that first looks up if d4g_PartID is already set for this D4G_BOMItem
     in the database and if not tries to set it by checking for D4G_DanPartRevisions
     among its ps_parents and using their item_id.

 ===============================================================================*/
 
#ifndef D4G_BOMITEM_GET_PARTID_HXX
#define D4G_BOMITEM_GET_PARTID_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_BOMItem_get_PartID(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_BOMITEM_GET_PARTID_HXX
