/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Business Object D4G_DanPartRevision
    - A standard setter method for the d4g_NetPrice property.
    - A standard setter method for the d4g_plannedDeliveryTime property.
    - A standard setter method for the d4g_StdQuantity property.
    - A standard setter method for the d4g_TaxCode property.

 ===============================================================================*/

#include <D4G_Core/D4G_DanVenPartA.hxx>
#include <D4G_Core/D4G_DanVenPartAImpl.hxx>
#include <fclasses/tc_string.h>
// 9-05-2017 Bipin: Obsolete function <tc/tc.h> replaced with <tcinit/tcinit.h> and <tc/tc_startup.h>
//#include <tc/tc.h>
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>

#include <tccore/aom_prop.h>

#include <iostream>

#include <ITKCallHeader.hxx>

using namespace Danfoss_Global_PLM; 

//----------------------------------------------------------------------------------
// D4G_DanVenPartAImpl::D4G_DanVenPartAImpl(D4G_DanVenPartA& busObj)
// Constructor for the class
//---------------------------------------------------------------------------------- 
D4G_DanVenPartAImpl::D4G_DanVenPartAImpl( D4G_DanVenPartA& busObj )
   : D4G_DanVenPartAGenImpl( busObj ) 
{
}

//----------------------------------------------------------------------------------
// D4G_DanVenPartAImpl::~D4G_DanVenPartAImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
D4G_DanVenPartAImpl::~D4G_DanVenPartAImpl()
{
}
 
//----------------------------------------------------------------------------------
// D4G_DanVenPartAImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int D4G_DanVenPartAImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = D4G_DanVenPartAGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}


/**
 * Setter for a Double Property
 * @param value - Value to be set for the parameter
 * @param isNull - If true, set the parameter value to null
 * @return - Status. 0 if successful
 */
int  D4G_DanVenPartAImpl::setD4g_NetPriceBase( double value, bool isNull )
{
    tag_t thisTag = this->getD4G_DanVenPartA()->getTag();
    return D4G_DanVenPartAGenImpl::setD4g_NetPriceBase(value, isNull);
}

/**
 * Setter for an Integer Property
 * @param value - Value to be set for the parameter
 * @param isNull - If true, set the parameter value to null
 * @return - Status. 0 if successful
 */
int  D4G_DanVenPartAImpl::setD4g_plannedDeliveryTimeBase( int value, bool isNull )
{
    tag_t thisTag = this->getD4G_DanVenPartA()->getTag();
    return D4G_DanVenPartAGenImpl::setD4g_plannedDeliveryTimeBase(value, isNull);
}

/**
 * Setter for an Integer Property
 * @param value - Value to be set for the parameter
 * @param isNull - If true, set the parameter value to null
 * @return - Status. 0 if successful
 */
int  D4G_DanVenPartAImpl::setD4g_StdQuantityBase( int value, bool isNull )
{
    tag_t thisTag = this->getD4G_DanVenPartA()->getTag();
    return D4G_DanVenPartAGenImpl::setD4g_StdQuantityBase(value, isNull);
}

/**
 * Setter for a string Property
 * @param value - Value to be set for the parameter
 * @param isNull - If true, set the parameter value to null
 * @return - Status. 0 if successful
 */
int  D4G_DanVenPartAImpl::setD4g_TaxCodeBase( const std::string &value, bool isNull )
{
    tag_t thisTag = this->getD4G_DanVenPartA()->getTag();
    return D4G_DanVenPartAGenImpl::setD4g_TaxCodeBase(value, isNull);
}

