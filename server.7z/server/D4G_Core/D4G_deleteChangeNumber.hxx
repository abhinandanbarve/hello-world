/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_deleteChangeNumber
 	 - A relation deletion PreAction that clears the property d4g_ChangeID on
 	 any ItemRevision that is no longer to be connected to a
 	 D4G_ChangeNoticeRevision by CMHasSolutionItems relation.
 	 Takes bypass to clear property regardless of access rights.

 ===============================================================================*/
#ifndef D4G_DELETECHANGENUMBER_HXX
#define D4G_DELETECHANGENUMBER_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_deleteChangeNumber(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_DELETECHANGENUMBER_HXX
