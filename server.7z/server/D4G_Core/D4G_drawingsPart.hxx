/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Birger Nielsen

 Description:    contains the implementation for the Extension D4G_drawingsPart
    - A getter method override which uses the TC_IS_REPRESENTED_BY
    relation to get Designs. From the Designs, this function uses the TC_DRAWING_OF
    relation backwards, to get DrawingRevisions.

 ===============================================================================*/

#ifndef D4G_DRAWINGSPART_HXX
#define D4G_DRAWINGSPART_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_drawingsPart(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_DRAWINGSPART_HXX
