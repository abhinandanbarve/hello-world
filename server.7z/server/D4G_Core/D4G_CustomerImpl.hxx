/*==============================================================================
 Copyright (c) 2014 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Business Object D4G_Customer
    - The getter method for the runtime property d4g_CustomerRequests finds all Customer Requests
    that are related to this Customer by D4G_CustomerCaseRel and lists them.

 ===============================================================================*/

#ifndef DANFOSS_GLOBAL_PLM__D4G_CUSTOMERIMPL_HXX
#define DANFOSS_GLOBAL_PLM__D4G_CUSTOMERIMPL_HXX

#include <D4G_Core/D4G_CustomerGenImpl.hxx>

#include <D4G_Core/libd4g_core_exports.h>

#define D4G_CustomerPomClassName "D4G_Customer"

namespace Danfoss_Global_PLM
{
   class D4G_CustomerImpl; 
   class D4G_CustomerDelegate;
}
 
class  D4G_CORE_API Danfoss_Global_PLM::D4G_CustomerImpl
           : public Danfoss_Global_PLM::D4G_CustomerGenImpl 
{
public:    

    // find method
    // static status_t find();  


   /**
    * Getter for a Tag Array Property
    * @param values - Parameter value
    * @param isNull - Returns true for an array element if the parameter value at that location is null
    * @return - Status. 0 if successful
    */
    int  getD4g_CustomerRequestsBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const;


protected:
    // Constructor for a D4G_Customer
    explicit D4G_CustomerImpl( D4G_Customer& busObj );

    // Destructor
    ~D4G_CustomerImpl();


private:
    // Default Constructor for the class
    D4G_CustomerImpl();
    
    // Private default constructor. We do not want this class instantiated without the business object passed in.
    D4G_CustomerImpl( const D4G_CustomerImpl& );

    // Copy constructor
    D4G_CustomerImpl& operator=( const D4G_CustomerImpl& );

    // Method to initialize this Class
    static int initializeClass();

    //static data
    friend class Danfoss_Global_PLM::D4G_CustomerDelegate;

};

#include <D4G_Core/libd4g_core_undef.h>
#endif // DANFOSS_GLOBAL_PLM__D4G_CUSTOMERIMPL_HXX
