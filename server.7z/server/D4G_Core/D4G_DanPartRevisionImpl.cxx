/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Business Object D4G_DanPartRevision
    - The Condition Operation for the Condition d4g_hasObsoletePlant that checks
    that no Obsolete plants exist, before adding a DanPartRevision to a BOMItemRevision.
    - A setter method for the property d4g_testRuns that checks if any of the
    pasted objects are D4G_TestContRevision's and if yes attaches this
    Danfoss Part Revision to them via D4G_TestContRel Relation.
    - A standard setter method for the d4g_ReplacedBy property.

 ===============================================================================*/

#include <D4G_Core/D4G_DanPartRevision.hxx>
#include <D4G_Core/D4G_DanPartRevisionImpl.hxx>
#include <fclasses/tc_string.h>
// 9-05-2017 Bipin: Obsolete function <tc/tc.h> replaced with <tcinit/tcinit.h> and <tc/tc_startup.h>
//#include <tc/tc.h>
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <epm/epm.h>

#include <iostream>
#include <vector>

#include <ITKCallHeader.hxx>
#include <ITKtools.hxx>
#include <constants.hxx>
#include <D4G_ErrorCodes.hxx>

using namespace Danfoss_Global_PLM; 

//----------------------------------------------------------------------------------
// D4G_DanPartRevisionImpl::D4G_DanPartRevisionImpl(D4G_DanPartRevision& busObj)
// Constructor for the class
//---------------------------------------------------------------------------------- 
D4G_DanPartRevisionImpl::D4G_DanPartRevisionImpl( D4G_DanPartRevision& busObj )
: D4G_DanPartRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// D4G_DanPartRevisionImpl::~D4G_DanPartRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
D4G_DanPartRevisionImpl::~D4G_DanPartRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// D4G_DanPartRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int D4G_DanPartRevisionImpl::initializeClass()
{
	int ifail = ITK_ok;
	static bool initialized = false;

	if( !initialized )
	{
		ifail = D4G_DanPartRevisionGenImpl::initializeClass( );
		if ( ifail == ITK_ok )
		{
			initialized = true;
		}
	}
	return ifail;
}


/**
 * Condition Operation for checking Obsolete plants, when adding a DanPartRevision to a BOMItemRevision.
 * 
 * @param bomItemRevision - bomItemRevision
 * @param output - false if the relevant plant is Obsolete
 * @return - ErrorCode if an error occurs
 */
int  D4G_DanPartRevisionImpl::d4g_hasObsoletePlantBase( tag_t bomItemRevision, bool *output )
{
	*output=true;

	// Check if user has privilege and skip all checks if yes
	logical hasBypass;
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_relations")){return ITK_ok;}

	int status = ITK_ok;
	// Get Plant value from BOM Item Revision
	std::string plantValue(get_string_property(bomItemRevision,PLANT_ATTRIBUTE));

	// Get Part Revision tag and list of plant tags from plant extension relation
	tag_t partRev(getD4G_DanPartRevision()->getTag());
	std::vector<tag_t> plants(get_tags_property(partRev,PART_PLANT_RELATION));

	// Go through all plants
	for(std::vector<tag_t>::iterator it=plants.begin(); it!=plants.end(); ++it){
		std::string plantName(get_string_property(*it,"object_name"));

		// If a plant matches the BOM Item Revisions plant and is Obsolete, error out
		if(plantName==plantValue){
			if(hasStatus(*it,STATUS_OBSOLETE)){
				*output=false;
				std::string partDisplay(get_string_property(partRev,"object_string"));
				ITK_LOG(EMH_store_error_s2(EMH_severity_error, PART_BOM_PASTE_ERROR_OBSOLETE,
						partDisplay.c_str(), plantValue.c_str()));
				status = PART_BOM_PASTE_ERROR_OBSOLETE;
			}
		}
	}

	return status;
}

/**
 * Setter for a Tag Array Property
 * If pasted object is D4G_TestContRevision adds this D4G_DanPartRevision to it via D4G_TestContRel Relation.
 * @param values - Values to be set for the parameter
 * @param isNull - If array element is true, set the parameter value at that location as null
 * @return - Status. 0 if successful
 */
int  D4G_DanPartRevisionImpl::setD4g_testRunsBase( const std::vector<tag_t> &values, const std::vector<int> *isNull )
{
	for(int i=0; i<isNull->size();i++){
		if(&isNull[i]==NULL){
			std::cout<<"True isNull abort\n";
			TC_write_syslog("Aborted setter because of isNull value set to TRUE");
			return ITK_ok;
		}
	}

	// Get object tag
	tag_t thisTag = this->getD4G_DanPartRevision()->getTag();

	// If any values are to be set find D4G_TestContRel relation tag
	if(values.size()>0){
		tag_t relationTypeTag;
		ITK_LR(GRM_find_relation_type("D4G_TestContRel",&relationTypeTag));

		// For every object to be attached via D4G_testRuns check if it is a D4G_TestContRevision
		tag_t relation;
		for (int i=0;i<values.size();i++){
			if(is_of_type(values[i],"D4G_TestContRevision")){
				// Attach this Danfoss Part Revision to the D4G_TestContRevision via D4G_TestContRel relation
				ITK_LR(GRM_create_relation(values[i], thisTag, relationTypeTag, NULLTAG, &relation));
				ITK_LR(GRM_save_relation(relation));
			}
		}
	}
	return ITK_ok;
}

/**
 * Setter for a string Property
 * @param value - Value to be set for the parameter
 * @param isNull - If true, set the parameter value to null
 * @return - Status. 0 if successful
 */
int  D4G_DanPartRevisionImpl::setD4g_ReplacedBy( const std::string &value, bool isNull )
{
	tag_t thisTag = this->getD4G_DanPartRevision()->getTag();
	return D4G_DanPartRevisionGenImpl::setD4g_ReplacedBy(value, isNull);
}
