/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Birger Nielsen

 Description:    contains the implementation for the Extension D4G_drawingsDesign
    - A getter method override retrieving JT Datasets. It uses the TC_DrawingOf
    Relation Backwards to get Primary objects. Afterwards it uses the
    IMAN_Rendering relation to get all JT Datasets.

 ===============================================================================*/

#ifndef D4G_DRAWINGSDESIGN_HXX
#define D4G_DRAWINGSDESIGN_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_drawingsDesign(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_DRAWINGSDESIGN_HXX
