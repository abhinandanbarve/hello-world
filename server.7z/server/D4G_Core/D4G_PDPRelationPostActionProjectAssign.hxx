/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_PDPRelationPostActionProjectAssign
 	 - A relation creation PostAction that adds the secondary object to all
 	 projects the primary object is in.

 ===============================================================================*/

#ifndef D4G_PDPRELATIONPOSTACTIONPROJECTASSIGN_HXX
#define D4G_PDPRELATIONPOSTACTIONPROJECTASSIGN_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_PDPRelationPostActionProjectAssign(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_PDPRELATIONPOSTACTIONPROJECTASSIGN_HXX
