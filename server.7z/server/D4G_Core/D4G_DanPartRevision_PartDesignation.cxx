/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_BOMItem_get_PartID
    - A setter method override  that first looks up if object is represented by a design.
    If not sets value on property. Otherwise throws error.
    Users with bypass or those specified in the preference
    D4G_users_allowed_to_modify_locked_properties can override.

 ===============================================================================*/

#include <D4G_Core/D4G_DanPartRevision_PartDesignation.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>

#include <string>

#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <D4G_ErrorCodes.hxx>

using namespace std;

int D4G_DanPartRevision_PartDesignation( METHOD_message_t *msg, va_list args )
{
	// Check if user is privileged
	bool privileged = false;
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){privileged = true;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){privileged = true;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_properties")){privileged = true;}

	// Get object tag, property name
	tag_t objtag= msg->object_tag;
	string propname = msg->prop_name;

	// Refresh object and get list of representing designs
	ITK_LR(AOM_refresh(objtag, false));
	vector<tag_t> representingdesigns = get_tags_property_vector(objtag, "TC_Is_Represented_By");

	// If object is already represented by design error out
	if(representingdesigns.size()>0 && !privileged){
		ITK_LR(EMH_store_error_s1(EMH_severity_error,PROPERTY_LOCKED_BY_REPRESENTEDBY,
				get_property_display_name(objtag, propname).c_str()));
		return PROPERTY_LOCKED_BY_REPRESENTEDBY;
	} else{ // Set property to value
		(void*) va_arg(args, tag_t);
		string value(va_arg(args, char*));
		ITK_LR(AOM_lock(objtag));
		ITK_LR(AOM_assign_string(objtag, propname.c_str(), value.c_str()));
		//9-5-2017 : Bipin : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
		//ITK_LR(AOM_save(objtag));
		ITK_LR(AOM_save_with_extensions(objtag));
		return ITK_ok;
	}
}
