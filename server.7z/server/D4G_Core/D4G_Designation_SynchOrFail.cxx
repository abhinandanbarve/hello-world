/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_Designation_SynchOrFail
    - A relation creation PreCondition that checks if Design Revisions should be
    allowed to be attached to Danfoss Part Revisions via TC_Is_Represented_By
    relation. If Design Designation and Part Designation have a mismatch relation
    creation is denied. If Design Designation is empty it is set to Part Designation.
    Check is skipped if user has bypass or is specified in Preference
    D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/
#include <D4G_Core/D4G_Designation_SynchOrFail.hxx>

#include <tc/emh.h>
#include <metaframework/CreateInput.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <tccore/grm.h>

#include "ug_va_copy.h"
#include <vector>
#include <iostream>

#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>

int D4G_Designation_SynchOrFail( METHOD_message_t *msg, va_list args )
{
	// Skip Checks if user is privileged
	bool privileged=false;
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){privileged=true;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){privileged = true;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_relations")){privileged = true;}

	// Retrieve primary and secondary object tags
	Teamcenter::CreateInput *creInput=va_arg(args,Teamcenter::CreateInput*);
	bool isNull=true;
	tag_t partrevtag=NULLTAG;
	ITK_LR(creInput->getTag("primary_object",partrevtag,isNull));
	tag_t designrevtag=NULLTAG;
	ITK_LR(creInput->getTag("secondary_object",designrevtag,isNull));

	// Is relation to be created attaching a Design Revision to a Danfoss Part Revision?
	if(is_of_type(partrevtag,"D4G_DanPartRevision") && is_of_type(designrevtag, "D4G_DesignRevision")){
		// Store Designation values of Part and Design
		ITK_LR(AOM_refresh(partrevtag, false));
		ITK_LR(AOM_refresh(designrevtag, false));
		std::string partdesignation = get_string_property(partrevtag, "d4g_PartDesignation");
		std::string designdesignation = get_string_property(designrevtag, "d4g_DesignDesignation");

		// If Part Designation is empty error out.
		if(partdesignation==""){
			ITK_LR(EMH_store_error_s1(EMH_severity_error,-1,"No Part Designation found."));
			return -1;
		} else {
			// If Design Designation is empty set it to Part Designation
			if(designdesignation==""){
				int status = ITK_ok;
				bool current = set_bypass(true);
				ITK_LOG(AOM_lock(designrevtag));
				ITK_LOG(AOM_assign_string(designrevtag, "d4g_DesignDesignation",partdesignation.c_str()));
				//9-5-2017 : Bipin : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
				//ITK_LOG(AOM_save(designrevtag));
				ITK_LOG(AOM_save_with_extensions(designrevtag));
				set_bypass(current);
				return status;
			}
			// If Part Designation is not equal to Design Designation check if user has privilege. If not error out.
			else if(partdesignation!=designdesignation && !privileged){
				ITK_LR(EMH_store_error_s1(EMH_severity_error,-1,"Mismatch between Part and Design Designation detected."));
				return -1;
			} else{
				return ITK_ok;
			}
		}
	}

	return ITK_ok;
}
