/*==============================================================================
 Copyright (c) 2014 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Business Object D4G_Customer
    - The getter method for the runtime property d4g_CustomerRequests finds all Customer Requests
    that are related to this Customer by D4G_CustomerCaseRel and lists them.

 ===============================================================================*/

#include <D4G_Core/D4G_Customer.hxx>
#include <D4G_Core/D4G_CustomerImpl.hxx>

#include <epm/epm_toolkit_tc_utils.h>
#include <fclasses/tc_string.h>
#include <tc/emh.h>
// 9-05-2017 Bipin: Obsolete function <tc/tc.h> replaced with <tcinit/tcinit.h> and <tc/tc_startup.h>
//#include <tc/tc.h>
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <tccore/aom_prop.h>

#include <iostream>
#include <vector>

using std::cout;

#include <ITKCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>

using namespace Danfoss_Global_PLM; 

//----------------------------------------------------------------------------------
// D4G_CustomerImpl::D4G_CustomerImpl(D4G_Customer& busObj)
// Constructor for the class
//---------------------------------------------------------------------------------- 
D4G_CustomerImpl::D4G_CustomerImpl( D4G_Customer& busObj )
: D4G_CustomerGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// D4G_CustomerImpl::~D4G_CustomerImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
D4G_CustomerImpl::~D4G_CustomerImpl()
{
}

//----------------------------------------------------------------------------------
// D4G_CustomerImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int D4G_CustomerImpl::initializeClass()
{
	int ifail = ITK_ok;
	static bool initialized = false;

	if( !initialized )
	{
		ifail = D4G_CustomerGenImpl::initializeClass( );
		if ( ifail == ITK_ok )
		{
			initialized = true;
		}
	}
	return ifail;
}


/**
 * Getter for a Tag Array Property
 * Returns all objects that this object is related to via TC_DrawingOf Relation.
 * @param values - Parameter value
 * @param isNull - Returns true for an array element if the parameter value at that location is null
 * @return - Status. 0 if successful
 */
int  D4G_CustomerImpl::getD4g_CustomerRequestsBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const
{
	int status = ITK_ok;
	// Get object tag
	tag_t thisTag = this->getD4G_Customer()->getTag();

	// Get primary objects for D4G_CustomerCaseRel Relations where this object is secondary and return them
	ITK_LOG(get_primary_for_relation(thisTag, "D4G_CustomerCaseRel", "ANY", values));
	if (status==ITK_ok){
		isNull = std::vector<int>(values.size(), FALSE);
	}
	return status;
}

