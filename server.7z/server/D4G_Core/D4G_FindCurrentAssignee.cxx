/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_FindCurrentAssignee
    - A getter method override which returns a comma separated list of all
    current Assignees on Tasks of the associated workflow.

 ===============================================================================*/

#include <D4G_Core/D4G_FindCurrentAssignee.hxx>

#include <tccore/aom.h>
#include <tccore/aom_prop.h>

#include <ItkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>

using std::string;
using std::vector;
using std::set;
#define PROP_LENGTH 256

int RecursiveCollect( tag_t tasktag, set<string> & Assignees );

int D4G_FindCurrentAssignee( METHOD_message_t *msg, va_list args )
{
	// Get the object tag, value, job tag and workflow tag
	(tag_t) va_arg(args, tag_t);
	char **value = va_arg(args, char**);
	tag_t objtag = msg->object_tag;
	ITK_LR(AOM_refresh(objtag, false));

	tag_t jobtag = NULLTAG;
	ITK_LR(AOM_ask_value_tag(objtag, "workflow_process", &jobtag));
	if(jobtag==NULLTAG){
		return ITK_ok;
	}
	ITK_LR(AOM_refresh(jobtag, false));

	tag_t workflowtag;
	ITK_LR(EPM_ask_root_task(jobtag, &workflowtag));
	if(workflowtag==NULLTAG){
		return ITK_ok;
	}
	ITK_LR(AOM_refresh(workflowtag, false));

	// Start the recursive colletion og assignees with the workflow tag
	set<string> Assignees;
	RecursiveCollect(workflowtag, Assignees);

	// Write resulting assignee list to a comma separated string
	vector<string> AssigneesVector(Assignees.begin(), Assignees.end());
	string CurrentAssignees = toString(AssigneesVector);

	// Cut string if too long
	int length = CurrentAssignees.size();
	if(length<PROP_LENGTH){
		length=PROP_LENGTH;
	}

	*value=MEM_string_copy(CurrentAssignees.substr(0,length).c_str());
	return ITK_ok;
}

// A recursive method that collects the assignee of a leaf task if it is Started
// and collects recursive results from all child tasks
int RecursiveCollect( tag_t tasktag, set<string> & Assignees ){
	int status = ITK_ok;

	// If task state is Started find list of assignees
	string taskstate = get_string_property(tasktag, "task_state");
	if(taskstate=="Started"){

		// If task has child tasks collects assignees from recursive calls on child tasks
		vector<tag_t> tasks = get_tags_property_vector(tasktag, "child_tasks");
		if(tasks.size()>0){
			for (int i=0; i<tasks.size(); i++){
				RecursiveCollect(tasks[i], Assignees);
			}
		} else{ // Else collect assignees from this task
			// If task type is Signoff Task collect undecided reviewers
			string tasktype = get_string_property(tasktag, "object_type");
			if(tasktype =="EPMPerformSignoffTask"){
				vector<tag_t> signoffattachments = get_tags_property_vector(tasktag, "signoff_attachments");
				for(int i=0; i<signoffattachments.size();i++){
					if( get_string_property(signoffattachments[i], "fnd0Status")=="No Decision"){
						tag_t signoff_user_id;
						ITK_CALL(AOM_ask_value_tag(signoffattachments[i],"fnd0Assignee",&signoff_user_id));
						Assignees.insert(get_string_property(signoff_user_id, "user_name"));
					}
				}
			} else{ // Else collect responsible party
				Assignees.insert(get_string_property(tasktag, "resp_party"));
			}
		}
		return true;
	}
	return false;
}
