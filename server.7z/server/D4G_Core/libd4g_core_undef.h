//@<COPYRIGHT>@
//==================================================
//Copyright $2014.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBD4G_CORE) && !defined(IPLIB)
#   error IPLIB orLIBD4G_CORE is not defined
#endif

#undef D4G_CORE_API
#undef D4G_COREEXPORT
#undef D4G_COREGLOBAL
#undef D4G_COREPRIVATE
