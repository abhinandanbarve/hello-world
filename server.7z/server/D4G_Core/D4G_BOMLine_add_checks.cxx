/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_BOMLine_add_checks
    - A BOM Line creation PreCondition that checks if a BOM Item is attached to a
    Part Revisions and if yes if the D4G_BOMItem.d4g_PartID==D4G_DanPartRevision.item_id.
    If not BOMLine creation is denied and an error is thrown.
    If yes BOM Item inherits Part Number from new parent Part.

 ===============================================================================*/
#include <D4G_Core/D4G_BOMLine_add_checks.hxx>

#include <tccore/aom.h>
#include <tccore/aom_prop.h>

#include <iostream>
#include <string>

using std::string;

#include <ITKtools.hxx>
#include <ItkCallHeader.hxx>

int D4G_BOMLine_add_checks( METHOD_message_t *msg, va_list args )
{
	int status = ITK_ok;

	// Retrieve primary object tag
	tag_t parenttag = va_arg(args, tag_t);
	tag_t primarytag = NULLTAG;
	AOM_ask_value_tag(parenttag, "bl_line_object", &primarytag);

	// Is this BOMLine being added to a D4G_DanPartRevision?
	if(is_of_type(primarytag, "D4G_DanPartRevision"))
	{
		// Collect the tag for the secondary item, if necessary collect from Revision
		tag_t itemtag = va_arg(args, tag_t);
		if(itemtag==NULLTAG){
			tag_t itemRevtag = va_arg(args, tag_t);
			if(itemRevtag!=NULLTAG){
				//9-5-2017 : Bipin : Deprecated API -"AOM_get_value_tag", replaced with "AOM_ask_value_tag"
				//ITK_LOG(AOM_get_value_tag(itemRevtag, "items_tag", &itemtag));
				ITK_LOG(AOM_ask_value_tag(itemRevtag, "items_tag", &itemtag));
			}
		}
		// Is this BOMLine for a D4G_BOMItem?
		if(itemtag!=NULLTAG && is_of_type(itemtag, "D4G_BOMItem")){
			string partnr= get_string_property(primarytag, "item_id");
			string BOMpartnr= get_string_property(itemtag, "d4g_PartID");
			// If d4g_PartID is correct do nothing. If it is wrong error. If it is empty fill with Part item_id
			if(partnr==BOMpartnr){
				return status;
			}else if (BOMpartnr==""){
				ITK_LOG(AOM_lock(itemtag));
				ITK_LOG(AOM_assign_string(itemtag, "d4g_PartID", partnr.c_str()));
				//9-5-2017 : Bipin : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
				// ITK_LOG(AOM_save(itemtag));
				ITK_LOG(AOM_save_with_extensions(itemtag));
			} else{
				string message = "BOM Item "+get_string_property(itemtag, "object_string")
											+" is locked to Part ID "+BOMpartnr
											+" and can not be added to Danfoss Part Revision "
											+get_string_property(primarytag, "object_string")+".";
				ITK_LOG(EMH_store_error_s1(EMH_severity_error,-1, message.c_str()));
				return -1;
			}
		}
	}

	return status;

}
