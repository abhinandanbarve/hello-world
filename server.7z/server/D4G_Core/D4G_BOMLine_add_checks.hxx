/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_BOMLine_add_checks
    - A BOM Line creation PreCondition that checks if a BOM Item is attached to a
    Part Revisions and if yes if the D4G_BOMItem.d4g_PartID==D4G_DanPartRevision.item_id.
    If not BOMLine creation is denied and an error is thrown.
    If yes BOM Item inherits Part Number from new parent Part.

 ===============================================================================*/
 
#ifndef D4G_BOMLINE_ADD_CHECKS_HXX
#define D4G_BOMLINE_ADD_CHECKS_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_BOMLine_add_checks(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_BOMLINE_ADD_CHECKS_HXX
