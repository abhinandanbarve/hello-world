/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_CMHasSolutionItemRelCondition
    - A relation creation PreCondition that checks if objects should be allowed
    to be related to a Change Notice Revision or Change Master Revision via
    CMHasSolutionItems Relation.
    For Change Notice the object types Part Revision and BOM Item Revision are only
    allowed if they are "Released" or if this is the first Change Notice Revision
    they are added to.
    For Change Master the object type BOM Item Revision is only allowed to be
    attached if the BOM Item Revision is for the same plant as the Change Master and
    the BOM Item Revisions item_id is not yet represented in the Change Masters
    Solution Items. Additionally the BOM Item Revision should not already be attached
    to a Change Master of the same type or, if our Change Masters type is Standard,
    to any other Change Master.
    Check is skipped if user has bypass or is specified in Preference
    D4G_users_allowed_to_modify_locked_relations.
 ===============================================================================*/

#ifndef D4G_CMHASSOLUTIONITEMRELCONDITION_HXX
#define D4G_CMHASSOLUTIONITEMRELCONDITION_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_CMHasSolutionItemRelCondition(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_CMHASSOLUTIONITEMRELCONDITION_HXX
