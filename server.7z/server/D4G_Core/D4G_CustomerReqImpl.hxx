/*==============================================================================
 Copyright (c) 2014 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Business Object D4G_CustomerReq
    - The setter method for the reference property d4g_Customer deletes all existing
    D4G_CustomerCaseRel of this D4G_CustomerReq and creates a new D4G_CustomerCaseRel
    to the specified D4G_Customer.
    - The Post Create method reads the value of the property d4g_Customer, deletes
    all existing D4G_CustomerCaseRel of this D4G_CustomerReq and creates a new
    D4G_CustomerCaseRel to the specified D4G_Customer.

 ===============================================================================*/

#ifndef DANFOSS_GLOBAL_PLM__D4G_CUSTOMERREQIMPL_HXX
#define DANFOSS_GLOBAL_PLM__D4G_CUSTOMERREQIMPL_HXX

#include <D4G_Core/D4G_CustomerReqGenImpl.hxx>

#include <D4G_Core/libd4g_core_exports.h>

#define D4G_CustomerReqPomClassName "D4G_CustomerReq"

namespace Danfoss_Global_PLM
{
   class D4G_CustomerReqImpl; 
   class D4G_CustomerReqDelegate;
}
 
class  D4G_CORE_API Danfoss_Global_PLM::D4G_CustomerReqImpl
           : public Danfoss_Global_PLM::D4G_CustomerReqGenImpl 
{
public:    

    // find method
    // static status_t find();  


   /**
    * Setter for a Tag Property
    * @param value - Value to be set for the parameter
    * @param isNull - If true, set the parameter value to null
    * @return - Status. 0 if successful
    */
    int  setD4g_CustomerBase( const tag_t &value, bool isNull );


   /**
    * desc for createPost
    * @param creInput - Description for the Create Input
    * @return - return desc for createPost
    */
    int  createPostBase( Teamcenter::CreateInput *creInput );

protected:
    // Constructor for a D4G_CustomerReq
    explicit D4G_CustomerReqImpl( D4G_CustomerReq& busObj );

    // Destructor
    ~D4G_CustomerReqImpl();


private:
    // Default Constructor for the class
    D4G_CustomerReqImpl();
    
    // Private default constructor. We do not want this class instantiated without the business object passed in.
    D4G_CustomerReqImpl( const D4G_CustomerReqImpl& );

    // Copy constructor
    D4G_CustomerReqImpl& operator=( const D4G_CustomerReqImpl& );

    // Method to initialize this Class
    static int initializeClass();

    //static data
    friend class Danfoss_Global_PLM::D4G_CustomerReqDelegate;

};

#include <D4G_Core/libd4g_core_undef.h>
#endif // DANFOSS_GLOBAL_PLM__D4G_CUSTOMERREQIMPL_HXX
