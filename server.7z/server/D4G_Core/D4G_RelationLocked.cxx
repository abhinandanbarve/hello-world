/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_RelationLocked
 	 - A relation deletion and creation PreCondition that checks
 	 if user has bypass or is specified in Preference
 	 D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/
#include <D4G_Core/D4G_RelationLocked.hxx>

#include <tc/emh.h>
#include <metaframework/CreateInput.hxx>
#include <tccore/grm.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <sa/site.h>

#include <vector>

#include <itkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <D4G_ErrorCodes.hxx>

using namespace std;

int D4G_RelationLocked( METHOD_message_t *msg, va_list args )
{
	// Allow only if user is privileged
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){return ITK_ok;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_relations")){return ITK_ok;}

	// If user is not privileged error out
	ITK_LR(EMH_store_error(EMH_severity_error,RELATION_LOCKED));
	return RELATION_LOCKED;
}
