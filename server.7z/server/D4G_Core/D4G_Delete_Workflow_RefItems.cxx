//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*========================================================================================================================
Module  		: D4G_Delete_Workflow_RefItems

Description		: contains the extension code for deleting the item references from workflow task .


Date            Name      Task Id      Description of Change
-------------------------------------------------------------------------------------------------------------------------
15-Jun-2017    Bhargav      3851        Deletes the reference of the DanPart Revision from the workflow task on deleting the schedule from
                                        the Danpart revision  schedules folder
========================================================================================================================*/


/***************************************************************************************
*Function Name   : D4G_Delete_Workflow_RefItems
*Extension on    : IMAN_Delete operation of the "CMHasWorkBreakDown" relation
*Extension Point : Pre_action
*Extension Name  : D4G_Delete_workflow_Items
*Dll name	     : libD4G_core
*Library Name	 : D4G_Core
*Input Parameters: va_list args --- tag of the relation between danfoss part rev and schedule 
*Return Value	 : int ifail -- return status

/* History
*--------------------------------------------------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              						Description
*
* 15-06-2017	        Bhargav 		    3851(Issue 2)        Deletes the reference of the DanPart Revision from the workflow task on
																 deleting the schedule from the Danpart revision  schedules folder
* 31-07-2017			Bhargav					3851			 Modified the logic of getting the references of schedule objects .
* 26-07-2017		    Bhargav					3851			 Modified the logic to include vendor parts
****************************************************************************************************************************/

#include <D4G_Core/D4G_Delete_Workflow_RefItems.hxx>
#include <constants.hxx>
#include <epm/epm.h>
#include <ItkCallHeader.hxx>


int D4G_Delete_Workflow_RefItems( METHOD_message_t * msg, va_list args )
{

	int 	   iRefCount					   = 0;
	int 	   iCount					       = 0;
	int 	   iNum							   = 0;
	int  	   iWorkFlowCount 				   = 0;
	int		   iPrefCount					   = 0;
	int		   iValCount					   = 0;
	int*	   iLevels						   = NULL;
	int 	   status 					       = ITK_ok;

	char*      cpRelationName                  = NULL;
	char*      cpPrimeObjectName               = NULL;
	char*      cpSecObjectName                 = NULL;
	char*      cpRefObjectName                 = NULL;
	char**	   cppRelations					   = NULL;
	char**	   cppPrefValue		    		   = NULL;




	tag_t       tPrimaryObject                  = NULLTAG;
	tag_t       tSecondaryObject                = NULLTAG;
	tag_t       trelationTag               	    = NULLTAG;
	tag_t       tpriTypeTag                     = NULLTAG;
	tag_t       tsecTypeTag                     = NULLTAG;
	tag_t		tRefTypeTag						= NULLTAG;
	tag_t*      tRefTag                     	= NULLTAG;
	tag_t*      tWorkFlowTag                    = NULLTAG;


    msg=0;
	va_list copyArgs;
	va_copy(copyArgs,args);

	//getting the relation tag between the dan part revision and the schedule
	trelationTag      = va_arg( copyArgs, tag_t );

	va_end( copyArgs );

	// asking for the primary object tag (dan part revision).
	ITK_LOG(GRM_ask_primary	(trelationTag,&tPrimaryObject));

	//asking for the secondary object tag (schedule)
	ITK_LOG(GRM_ask_secondary(trelationTag,&tSecondaryObject));

	//asking the relation name between schedule and danfoss part revision
	ITK_LOG(AOM_ask_name( trelationTag ,&cpRelationName));

	//asking the type tag for the primary object i.e dan part revision
	ITK_LOG(TCTYPE_ask_object_type(tPrimaryObject,&tpriTypeTag));

	//asking the name of primary object type(eg:D4G_DanPartRevision)
	ITK_LOG(TCTYPE_ask_name2(tpriTypeTag,&cpPrimeObjectName));

	//asking the type tag for the secondary object i.e schedule
	ITK_LOG(TCTYPE_ask_object_type(tSecondaryObject,&tsecTypeTag));

	//asking the name of secondary object type (D4G_PPAPSched)
	ITK_LOG(TCTYPE_ask_name2(tsecTypeTag,&cpSecObjectName));
	
	//getting the count of the preference values of 'D4G_Attach_PartsAs_Reference' preference
	ITK_LOG(PREF_ask_value_count ( ATTACH_PARTS_AS_REF_PREF_NAME, &iPrefCount));

	if (iPrefCount > 0)
	{
		//getting the values from 'D4G_Attach_PartsAs_Reference' preference.It consists of names of different schedule task

		ITK_LOG(PREF_ask_char_values ( ATTACH_PARTS_AS_REF_PREF_NAME, &iPrefCount, &cppPrefValue));

	}

	for(iValCount=0;iValCount<iPrefCount;iValCount++)
	{
		//checking whether the primary object & secondary object is of type D4G_DanPartRevision & D4G_PPAPSched are not
		if((tc_strcmp(cppPrefValue[iValCount],cpPrimeObjectName)==0)&&(tc_strcmp(D4G_PPAPSCHED,cpSecObjectName)==0))
		{

		//getting the tags for the references of the secondary objects
		ITK_LOG(WSOM_where_referenced(tSecondaryObject,1,&iRefCount,&iLevels,&tRefTag,&cppRelations));

		for(iCount=0;iCount<iRefCount;iCount++)
		{
			//asking the type of the referenced object
			ITK_LOG(TCTYPE_ask_object_type(tRefTag[iCount],&tRefTypeTag));

			//getting the type name of all the references of the schedule

			ITK_LOG(TCTYPE_ask_name2(tRefTypeTag,&cpRefObjectName));

			//comparing the reference name with the D4G_PPAPTask
			if (tc_strcmp(cpRefObjectName,D4G_PPAPTASK) == 0)
			{

				//getting the tags for the workflows of scheduke task
				ITK_LOG(AOM_ask_value_tags (tRefTag[iCount],AllWORKFLOWS,&iWorkFlowCount,&tWorkFlowTag));

				for(iNum=0;iNum<iWorkFlowCount;iNum++)
				{

					if(tWorkFlowTag[iNum]!=NULLTAG)
					{
						//if workflow tag is existing then remove the dan part revision attachment
						 EPM_remove_attachments	( tWorkFlowTag[iNum],1,&tPrimaryObject );
					}
				}
			}

		}
	}
	}

	SAFE_SM_FREE(cpRelationName);
	SAFE_SM_FREE(cpPrimeObjectName);
	SAFE_SM_FREE(cpSecObjectName);
	SAFE_SM_FREE(tRefTag);
	SAFE_SM_FREE(cppPrefValue);
	SAFE_SM_FREE(tWorkFlowTag);
	SAFE_SM_FREE(cpRefObjectName);
	SAFE_SM_FREE(iLevels);
	SAFE_SM_FREE(cppRelations);

 return status;



}
