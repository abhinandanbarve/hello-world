/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Jan-J�rn Sommer

 Description:    contains the implementation for the Extension D4G_Check_Delete_Schedule_Started
 	 - A relation deletion PreCondition that checks if PPAP Schedules can be removed
 	 from Danfoss Part Revisions. If the PPAP Schedules are "not started" relation
 	 deletion is denied.
 	 Check is skipped if user has bypass or is specified in Preference
 	 D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/
#ifndef D4G_CHECK_DELETE_SCHEDULE_STARTED_HXX
#define D4G_CHECK_DELETE_SCHEDULE_STARTED_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_Check_Delete_Schedule_Started(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_CHECK_DELETE_SCHEDULE_STARTED_HXX
