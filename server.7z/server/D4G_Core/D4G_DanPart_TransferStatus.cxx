/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Jan-J�rn Sommer

 Description:    contains the implementation for the Extension D4G_DanPart_TransferStatus
    - A setter method override, that only allows the setting of a new value if
    no Revision has been transfered to SAP. Users with bypass or those specified in
    the preference D4G_users_allowed_to_modify_locked_properties can override.

 ===============================================================================*/

#include <D4G_Core/D4G_DanPart_TransferStatus.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <string>

#include <ItkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <D4G_ErrorCodes.hxx>

using std::string;
int D4G_DanPart_TransferStatus( METHOD_message_t *msg, va_list args )
{
	// Check if user is privileged
	bool privileged = false;
	logical hasBypass;
	AM__ask_application_bypass(&hasBypass);
	if(hasBypass){privileged = true;}
	ITK_ask_bypass(&hasBypass);
	if(hasBypass){privileged = true;}
	if(check_user_against_pref("D4G_users_allowed_to_modify_locked_properties")){privileged = true;}

	int result = ITK_ok;

	// Get object tag and property name
	tag_t objtag= msg->object_tag;
	string propname = msg->prop_name;

	// Skip all checks if user is privileged
	if(!privileged){
		/*get all Revisions*/
		std::vector<tag_t> revisions =get_tags_property_vector(objtag, "revision_list");
		for(int i=0; i<revisions.size(); i++){
			/*get d4g_transferred*/
			bool transferred = get_bool_property(revisions[i],"d4g_transferred");
			/*if Revision was transferred store error and return -1*/
			if(transferred){
				ITK_LR(EMH_store_error_s2(EMH_severity_error,PROPERTY_LOCKED_BY_TRANSFER,
						get_property_display_name(objtag, propname).c_str(),
						get_string_property(objtag, "object_string").c_str()));
				result = PROPERTY_LOCKED_BY_TRANSFER;
				break;
			}
		}
	}

	// If allowed set property to value
	if (result==ITK_ok){
		(void*) va_arg(args, tag_t);
		string value(va_arg(args, char*));
		ITK_LR(AOM_assign_string(objtag, propname.c_str(), value.c_str()));
	}
	return result;
}
