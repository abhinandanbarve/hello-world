/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_testRuns
    - A getter method override which returns all objects that this object
    is related to via D4G_TestContRel Relation.

 ===============================================================================*/

#include <D4G_Core/D4G_testRuns.hxx>
#include <itkCallHeader.hxx>
#include <tccore/grm.h>

#include <iostream>

int D4G_testRuns( METHOD_message_t *msg, va_list args )
{
	// Get object tag and values
	(tag_t) va_arg(args, tag_t);
	int *count = va_arg(args, int*);
	tag_t **values = va_arg(args, tag_t**);
	tag_t obj_tag = NULLTAG;
	METHOD_PROP_MESSAGE_OBJECT(msg, obj_tag);

	// Get primary objects of D4G_TestContRel relation with our object as secondary and return them
	tag_t relationTypeTag;
	ITK_LR(GRM_find_relation_type("D4G_TestContRel", &relationTypeTag));
	ITK_LR(GRM_list_primary_objects_only(obj_tag, relationTypeTag, count, values));

	return ITK_ok;

}
