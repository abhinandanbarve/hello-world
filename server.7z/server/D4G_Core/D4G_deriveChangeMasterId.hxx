/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_deriveChangemasterId
    - A createPost action on CMImplements relation create that derives a new
    item_id for a D4G_ChangeMaster if a D4G_ChangeNoticeRevision is being attached
    to a D4G_ChangeMasterRevision.
    The new derived item_id for the Change Masteris the item_id of the
    Change Notice with the prefix CN replaced by CM and a 3 digit running number
    appended.
    The old item_id of the Change Master is stored in d4g_storeditemid.

 ===============================================================================*/

#ifndef D4G_DERIVECHANGEMASTERID_HXX
#define D4G_DERIVECHANGEMASTERID_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_deriveChangeMasterId(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_DERIVECHANGEMASTERID_HXX
