/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Sven Simonsen

 Description:    contains the implementation for the Extension D4G_Designation_SynchOrFail
    - A relation creation PreCondition that checks if Design Revisions should be
    allowed to be attached to Danfoss Part Revisions via TC_Is_Represented_By
    relation. If Design Designation and Part Designation have a mismatch relation
    creation is denied. If Design Designation is empty it is set to Part Designation.
    Check is skipped if user has bypass or is specified in Preference
    D4G_users_allowed_to_modify_locked_relations.

 ===============================================================================*/
#ifndef D4G_DESIGNATION_SYNCHORFAIL_HXX
#define D4G_DESIGNATION_SYNCHORFAIL_HXX
#include <tccore/method.h>
#include <D4G_Core/libd4g_core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern D4G_CORE_API int D4G_Designation_SynchOrFail(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <D4G_Core/libd4g_core_undef.h>
                
#endif  // D4G_DESIGNATION_SYNCHORFAIL_HXX
