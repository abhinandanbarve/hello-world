/*==============================================================================
 Copyright (c) 2016 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core
 Author  : Ravikiran Choudhari

 Description:    This extension is used to update the list of Parts to which Process document is attached.
 	 	 	 	 Issue-2837
 	 	 	 	 This extension is added on "Documented By" relationship object on  GRM_create operation which update d4g_PartsString property on
 	 	 	 	 process document once it is attached to Danfoss Part.



 ===============================================================================*/

#include <D4G_Core/D4G_AddReferencedParts.hxx>
#include <ug_va_copy.h>
#include <ITKCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <mld/logging/Logger.hxx>

static std::string loggerName = "Danfoss.D4G_Core.D4G_AddReferencedParts";
static Teamcenter::Logging::Logger *logger = Teamcenter::Logging::Logger::getLogger(loggerName);

int D4G_AddReferencedParts( METHOD_message_t *msg, va_list args )
{
	logger->debug("[DANFOSS][D4G_Core][D4G_AddReferencedParts][D4G_AddReferencedParts] - Primary is CN");
	tag_t	primary_tag = NULLTAG;
	tag_t	secondary_tag = NULLTAG;
	va_list     copyArgs;

	// Get the parameters from the ITEM_save message
	va_copy(copyArgs, args);
	primary_tag = va_arg(copyArgs, tag_t);
	secondary_tag = va_arg(copyArgs, tag_t);
	va_end(copyArgs);	
	
	char* pszItemID = NULL;
	char* pszPartsString = NULL;

	if(is_of_type(primary_tag,"D4G_DanPartRevision") && is_of_type(secondary_tag,"D4G_ProcessDocRevision"))
	{
		logger->debug("[DANFOSS][D4G_Core][D4G_AddReferencedParts][D4G_AddReferencedParts] - Primary is CN");

		ITK_LR(AOM_ask_value_string(primary_tag, "item_id", &pszItemID));
		ITK_LR(AOM_ask_value_string(secondary_tag, "d4g_PartsString", &pszPartsString));

		std::string pszPartCompare = pszPartsString;
		std::string pszPartAll = "";
		std::string pszCheckID = "";
		if(pszPartsString!=NULL && strlen(pszPartsString) != 0)
		{
			pszCheckID = pszItemID;
			if(pszPartCompare.find(pszCheckID) != std::string::npos)
			{
				pszPartAll= pszPartsString;
			}else{
				pszPartAll = pszPartCompare + "," + pszCheckID;
			}

		}else {
			pszPartAll = pszItemID;
		}
		char* pszPart = (char*) MEM_alloc(CHARSIZE*sizeof(char));
		strcpy(pszPart, pszPartAll.c_str());

		// Take bypass and with bypass fill the property d4g_PartsString on secondary object
		logical current;
		AM__ask_application_bypass(&current);
		set_bypass(true);
		ITK_LR(AOM_lock(secondary_tag));
		ITK_LR(AOM_set_value_string(secondary_tag, "d4g_PartsString", pszPart));			
		ITK_LR(AOM_save_without_extensions(secondary_tag));
		ITK_LR(AOM_unlock(secondary_tag));
		set_bypass(current);
		if(pszPart != NULL)
		{
			if(strlen(pszPart) != 0)
			{
				SAFE_SM_FREE(pszPart);			
			}
		}
	}
	logger->debug("[DANFOSS][D4G_Core][D4G_AddReferencedParts][D4G_AddReferencedParts] - Exiting the method");
	return 0;
}
