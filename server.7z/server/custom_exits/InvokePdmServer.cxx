/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_custom_exits
 Author  : Sven Simonsen

 Description:    contains the implementation for the function D4G_invoke_pdm_server
 	 	 	 	 wich overrides USER_invoke_pdm_server.
    - A method that, once invoked, moves all PDFs attached as IMAN_manifestation
     under a Revision over to IMAN_Rendering instead and relates all
     Release Statuses of the Revision to these PDFs.

 ===============================================================================*/

#include <tccore/item.h>                /* for NULLTAG */
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>

#include <string>
#include <vector>

using std::string;
using std::vector;

#include <ItkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>

#define D4G_DISPATCHER_REL_STATUS 9001

/*--------------------------------------------------------------------------------------------------------*/


extern int D4G_invoke_pdm_server( int * decision, va_list args){

	int status = ITK_ok;
	/**********  va_list for USER_invoke_pdm_server ********/
	int input_code = va_arg(args, int);
	string input_string (va_arg(args, char *));
	//int * output_code = va_arg(args, int *);
	//char ** output_string = va_arg(args, char **);
	/*******************************************************/
	switch (input_code){

	// Moves all PDFs attached as IMAN_manifestation over to IMAN_Rendering instead
	// and relates all Release Statuses of the Revision to these PDFs
	case D4G_DISPATCHER_REL_STATUS: {
		// Take bypass to edit locked relations
		bool current = set_bypass(true);

		// Read item_id and revid from inputstring to find revision tag
		vector<string> inputs = split_to_vector_nonempty(input_string, ";");
		string searchstring("item_id="+inputs[0]);
		int n_items;
		tag_t * item_tags;
		ITK_LOG(ITEM_find_item_revs_by_string_and_revid(searchstring.c_str(), inputs[1].c_str(), &n_items, &item_tags));

		// If not exactly one match error out
		if(n_items!=1){
			TC_write_syslog("D4G_invoke_pdm_server", -1, "Failed to uniquely identify Revision.");
		} else{
			// Get unique Drawing Revision tag and its Release Status list and IMAN_manifestation list
			tag_t drawrevtag = item_tags[0];
			vector<tag_t> statustags = get_tags_property(drawrevtag, "release_status_list");
			vector<tag_t> manifestationtags = get_tags_property(drawrevtag, "IMAN_manifestation");

			// Get the tag of the IMAN_manifestation Relation Type
			tag_t relationManiTag;
			ITK_LOG(GRM_find_relation_type("IMAN_manifestation",&relationManiTag));

			// Find an delete all IMAN_manifestation Relations under our Drawing Revision
			// where the secondary object is a PDF Dataset
			int count;
			tag_t * relations;
			ITK_LOG(GRM_list_relations(drawrevtag,NULLTAG,relationManiTag,NULLTAG,&count,&relations));
			for(int i=0;i<count;i++){
				tag_t secondary=NULLTAG;
				ITK_LOG(AOM_ask_value_tag(relations[i],"secondary_object",&secondary));
				if(is_of_type(secondary,"PDF")){
					ITK_LOG(GRM_delete_relation(relations[i]));
				}
			}

			// Get the tag of the IMAN_Rendering Relation Type
			tag_t relRendTag;
			ITK_LOG(GRM_find_relation_type("IMAN_Rendering",&relRendTag));

			// Attach every PDF Dataset that was formerly attached under our Drawing Revision
			// as IMAN_manifestation with a new IMAN_Rendering Relation
			tag_t relation;
			for (int i=0;i<manifestationtags.size();i++){
				if(is_of_type(manifestationtags[i],"PDF")){
					ITK_LOG(GRM_create_relation(drawrevtag, manifestationtags[i], relRendTag, NULLTAG, &relation));
					ITK_LOG(GRM_save_relation(relation));
				}
			}

			// Add all Release Statuses from the Drawing Revision to the newly re-attached PDFs
			for (int i=0; i< manifestationtags.size();i++){
				if(is_of_type(manifestationtags[i],"PDF")){
					ITK_LOG(AOM_lock(manifestationtags[i]));
					ITK_LOG(AOM_assign_tags(manifestationtags[i], "release_status_list", statustags.size(), &statustags[0]));
					//10-5-2017 : Robert : Deprecated API -"AOM_save", replaced with "AOM_save_with_extensions"
					//ITK_LOG(AOM_save(manifestationtags[i]));
					ITK_LOG(AOM_save_with_extensions(manifestationtags[i]));
				}
			}
		}
		SAFE_SM_FREE(item_tags);
		set_bypass(current);
		break;
	}
	}
	return status;
}
