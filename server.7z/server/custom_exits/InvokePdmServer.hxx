/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_custom_exits
 Author  : Sven Simonsen

 Description:    contains the implementation for the function D4G_invoke_pdm_server
 	 	 	 	 wich overrides USER_invoke_pdm_server.
    - A method that, once invoked, moves all PDFs attached as IMAN_manifestation
     under a Revision over to IMAN_Rendering instead and relates all
     Release Statuses of the Revision to these PDFs.

 ===============================================================================*/

#ifndef INVOKEPDMSERVER_HXX_
#define INVOKEPDMSERVER_HXX_

int D4G_invoke_pdm_server( int * decision, va_list args);


#endif /* INVOKEPDMSERVER_HXX_ */
