/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_custom_exits
 Author  : Sven Simonsen

 Description:    contains the registration calls for D4G_custom_exits callbacks

 ===============================================================================*/

//10-5-2017 : Robert : Deprecated function "tc/tc.h" replaced with "<tcinit/tcinit.h> & <tc/tc_startup.h>"
//#include <tc/tc.h>
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tccore/custom.h>
#include <server_exits/user_server_exits.h>
#include <user_exits/user_exits.h>
#include <ict/ict_userservice.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <epm/epm_toolkit_tc_utils.h>

#include <iostream>
#include <string>

#include <ItkCallHeader.hxx>
#include <custom_exits/RevisionId.hxx>
#include <custom_exits/InvokePDMServer.hxx>
using namespace std;

string version = "V0.6";

extern "C" {

/*extern DLLAPI int D4G_register_methods(int* decision, va_list args)
{
	(void*) args;
	int status = ITK_ok;
	char* function_name = "";

	cout << "\nRegistering custom methods\n";

	function_name = "D4G_change_task_status";
	int input_args[2] = {USERARG_TAG_TYPE, USERARG_STRING_TYPE };
	ITK_LOG(USERSERVICE_register_method(
			function_name,
			(USER_function_t) D4G_ChangeTaskStatus,
			2,
			input_args,
			USERARG_VOID_TYPE));
 *decision = ALL_CUSTOMIZATIONS;
	if(!status){
		cout << "\t Registered " << function_name << ".\n";
	} else{
		cout << "\t Failed to register " << function_name << ".\n";
	}

	return status;
}*/

extern DLLAPI int libD4G_custom_exits_register_callbacks()
{
	int status = ITK_ok;
	string loadmsg("Loading custom exit library <D4G_custom_exits> "+version+" ("+__DATE__+" "+__TIME__+")");
	cout <<loadmsg<<"\n";
	TC_write_syslog(loadmsg.c_str());

	/*	ITK_LOG(CUSTOM_register_exit("libD4G_custom_exits", "USERSERVICE_register_methods",
			(CUSTOM_EXIT_ftn_t) D4G_register_methods));
	if(status!=ITK_ok){return status;}*/

	ITK_LOG(CUSTOM_register_exit("libD4G_custom_exits", "USER_new_revision_id",
			(CUSTOM_EXIT_ftn_t) D4G_new_revision_id));

	ITK_LOG(CUSTOM_register_exit("libD4G_custom_exits", "USER_invoke_pdm_server",
			(CUSTOM_EXIT_ftn_t) D4G_invoke_pdm_server));

	return status;
}

} /* EXTERN_C */
