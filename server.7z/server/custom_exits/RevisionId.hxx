/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_custom_exits
 Author  : Sven Simonsen

 Description:    contains the implementation for the function D4G_new_revision_id
 	 	 	 	 wich overrides USER_new_revision_id.

 ===============================================================================*/

#ifndef REVISIONID_HXX_
#define REVISIONID_HXX_

int D4G_new_revision_id( int* decision, va_list args);


#endif /* REVISIONID_HXX_ */
