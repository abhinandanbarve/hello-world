/*==============================================================================
 Copyright (c) 2015 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_custom_exits
 Author  : Sven Simonsen

 Description:    contains the implementation for the function D4G_new_revision_id
 	 	 	 	 wich overrides USER_new_revision_id.

 ===============================================================================*/

#include <tccore/item.h>                /* for NULLTAG */
#include <tccore/item_errors.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <user_exits/user_exit_msg.h>
#include <publication/dist_user_exits.h>
#include <tccore/tctype.h>
#include <itk/bmf.h>
#include <tie/tie_errors.h>

#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

#include <ItkCallHeader.hxx>
#include <cToolbox.hxx>
#include <ITKtools.hxx>

/*--------------------------------------------------------------------------------------------------------*/

/*
 *    Parses a Revision Id and splits it into major and/or minor revision id's.
 *    The format for the Revision Id must be AA...nn (0-many uppercase letters followed by  0 or 2 digits)
 *
 *    Parameters:
 *        string rev:          A string representing the Revision ID to be parsed
 *
 *        string* major:       The major revision part of the provided Revison Id
 *                             An empty string is returned if there is no major revision
 *
 *        string* minor:       The minor revision part of the provided Revison Id
 *                             An empty string is returned if there is no minor revision
 *
 *    Returns:
 *        0    if the provided Revision Id can be split into major and/or minor revisions.
 *        1    otherwise. In this case both major and minor are empty strings.
 */
int getMajorMinorRevision(string rev, string* major, string* minor) {
	*major="";
	*minor="";

	int result = 0;

	// determine number of uppercase letters from the beginning of the string
	int pos=0;
	while(pos<rev.size() && 'A'<=rev[pos] && rev[pos]<='Z'){
		pos++;
	}

	int pos2=pos;
	while(pos<rev.size() && pos2<rev.size() && '0'<=rev[pos2] && rev[pos2]<='9'){
		pos2++;
	}

	// check for major revision only
	if(pos>0 && pos==rev.size()){
		*major = rev.substr(0,pos);
	}
	// check for major and minor revision
	else if (pos>0 && pos2==rev.size()){
		*major = rev.substr(0,pos);
		*minor = rev.substr(pos,pos2-pos);
	}
	// check for minor revision only
	else if (pos==0 && pos2>0 && pos2==rev.size()){
		*minor = rev.substr(0,pos2);
	}
	// else format isn't recognized
	else {
		result = 1;
	}

	return result;
}

/*
 *    Compares two Revision Id's based on a major/minor revision scheme.
 *    If either revision id's doesn't follow the expected scheme, i.e. it doesn't
 *    have a major or minor part, a normal string compare is done.
 *
 *    Parameters:
 *        string rev1          The first Revision Id for the comparison
 *        string rev2          The second Revision Id for the comparison
 *
 *    Returns:
 *       <0    if rev1 is lower than rev2
 *        0    if rev1 is identical to rev2
 *       >0    if rev1 is higher than rev2
 */
int compareMajorMinorRevisions(string rev1, string rev2)
{
	string minorRev1 = "";
	string minorRev2 = "";
	string majorRev1 = "";
	string majorRev2 = "";

	int result = 0;

	// check if both rev1 and rev2 has major/minor revisions
	if (getMajorMinorRevision(rev1, &majorRev1, &minorRev1)==0 &&
			getMajorMinorRevision(rev2, &majorRev2, &minorRev2)==0) {

		// compare major revisions
		if (majorRev1.size()==majorRev2.size()) {
			result = majorRev1.compare(majorRev2);
		} else {
			result = majorRev1.size()>majorRev2.size() ? 1 : -1;
		}
		// if major revisions are equal, compare minor revisions as ints
		if (result == 0){
			if (minorRev1.size()>0 && minorRev2.size()==0){
				result =1;
			} else if (minorRev1.size()==0 && minorRev2.size()>0){
				result =-1;
			} else {
				int iminor1=stoi(minorRev1);
				int iminor2=stoi(minorRev2);
				result = iminor1>iminor2 ? 1 : -1;
			}
		}

	} else {
		result = rev1.compare(rev2);
	}

	return result;
}

/*
 *
 *    Generate a new revision id following the scheme:
 *    01,02,03,...
 *    A,A01,A02,...
 *    B,B01,B02,...
 *
 *    The preference D4G_users_allowed_to_modify_assigned_revision_id decides if the new Revision ID
 *    is modifiable in the creation window or not.
 *
 *    Parameters:
 *        tag_t item_tag:      A tag which provides the Item for which we are to
 *                             generate a new Rev Id. May be a NULLTAG if a new
 *                             revision is requested.
 *
 *        tag_t item_type:     The tag of the Item Type for which a new revision
 *                             is to be generated.
 *
 *        int  *mod:           A boolean value specifying if the system user
 *                             has the right to modify (TRUE) the value. Else
 *                             attempts to change the returned string (FALSE)
 *                             will be prevented at the user interface.
 *
 *        char **id            A char. string containing the new revision id.
 *
 */
int D4G_new_revision_id( int* decision, va_list args)
{
	int status = ITK_ok;
	*decision = ONLY_CURRENT_CUSTOMIZATION;
	tag_t item_tag = va_arg(args, tag_t);
	tag_t item_type = va_arg(args, tag_t);
	logical* mod = va_arg(args, logical*);
	char** id = va_arg(args, char**);

	bool modifiable = check_user_against_pref("D4G_users_allowed_to_modify_assigned_revision_id");

	// Find out if type is Part
	bool isTypePart = false;
	tag_t partTypeTag;
	ITK_LOG(TCTYPE_find_type("Part", NULL, &partTypeTag));
	if(status==ITK_ok){
		ITK_LOG(TCTYPE_is_type_of(item_type, partTypeTag, &isTypePart));
	}

	// Find out if type is Document
	bool isTypeDocument = false;
	tag_t documentTypeTag;
	ITK_LOG(TCTYPE_find_type("D4G_DanDocument", NULL, &documentTypeTag));
	if(status==ITK_ok){
		ITK_LOG(TCTYPE_is_type_of(item_type, documentTypeTag, &isTypeDocument));
	}

	// Check for item_tag being NULLTAG, meaning this is a new item that requests initial revision id
	if(item_tag==NULLTAG){
		if (isTypePart){//If Part is new start with revision ID "A"
			string newId = "A";
			*id = (char*) MEM_alloc(sizeof(char)*(newId.size()+1));
			strcpy(*id, newId.c_str());
		} else {// For other new items use OOTB revision ID. Checks OOTB pref ITEM_first_rev_id for initial value
			ITK_LOG(ITEM_new_revision_id(item_tag, item_type, mod, id));
		}
	} else { // New revision id for an existing item with revisions
		if (isTypePart){// use OOTB revision ID
			ITK_LOG(ITEM_new_revision_id(item_tag, item_type, mod, id));
		} else if(isTypeDocument){
			// Use OOTB revision ID generation first
			ITK_LOG(ITEM_new_revision_id(item_tag, item_type, mod, id));

			// Check if created revID has format AA... and if yes replace it with 01
			string newId=*id;
			string major="";
			string minor="";
			getMajorMinorRevision(newId, &major, &minor);
			if (major.size()>0 && minor.size()==0) { // found major revision but no minor
				newId="01";
				*id = (char*) MEM_alloc(sizeof(char)*(newId.size()+1));
				strcpy(*id, newId.c_str());
			}
		} else {
			//Revision increment using minor/major revision logic
			//01->02, A->A01, B37->B38

			//Find the highest existing revision id
			vector<tag_t> revisions = get_tags_property_vector(item_tag, "revision_list");
			string highestRevId = "00";
			string revId;
			for(int i=0; i<revisions.size();i++){
				revId = get_string_property(revisions[i], "item_revision_id");
				if(compareMajorMinorRevisions(revId, highestRevId)>0){
					highestRevId=revId;
				}
			}

			// Get major and minor parts of the highest revision id
			string major="";
			string minor="";
			getMajorMinorRevision(highestRevId, &major, &minor);

			//check if highestRevId only has a major revision, and if yes start minor revisions
			if (major.size()>0 && minor.size()==0) {
				string newId=highestRevId+"01";
				*id = (char*) MEM_alloc(sizeof(char)*(newId.size()+1));
				strcpy(*id, newId.c_str());
			}
			//check if highestRevId has a minor revision, and if yes increment this id
			else if (minor.size()>0) {
				int iminor= stoi(minor);
				std::ostringstream oss;
				oss.str("");
				oss << std::setw(minor.length()) << std::setfill('0') << iminor+1;

				string newId = major+oss.str();
				*id = (char*) MEM_alloc(sizeof(char)*(newId.size()+1));
				strcpy(*id, newId.c_str());
			}

			if(*id==NULL){//No accepted id format found. Using OOTB revision id.
				ITK_LOG(ITEM_new_revision_id(item_tag, item_type, mod, id));
			}
		}
	}
	*mod = modifiable;
	return status;
}

