/******************************************************************************
* Filename         :  D4G_Mass_Utilities_Functions.hxx
* Description      :
*
*
* ENVIRONMENT      :   C, C++, ITK
* FUNCTION LIST    :

*
* History
*------------------------------------------------------------------------------
* Date             Name           Description of Change
* 28-Jun-2017      Rohit          Initial Creation
* -----------------------------------------------------------------------------
*
*****************************************************************************/

#ifndef D4G_MASS_UTILITIES_FUNCTIONS
#define D4G_MASS_UTILITIES_FUNCTIONS

#include <epm/epm.h>
#include <epm/epm.h>
#include <tc/emh.h>
#include <tc/preferences.h>
#include <bom/bom.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <tc/tc_util.h>
#include <sa/user.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/project.h>
#include <tcinit/tcinit.h>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <set>
#include <sstream>
#include <vector>
#include <time.h>
#include <stdio.h>
#include <tc/iman.h>
#include <epm/epm.h>
#include <algorithm>
#include <string>
#include <pom/pom/pom.h>
#include <stdio.h>
#include <tccore/imantype.h>
#include <tc/preferences.h>
#include <tccore/grm.h>
#include <sa/sa.h>
#include <sa/am.h>
#include <lov/lov.h>
#include <epm/epm_task_template_itk.h>
#include <tc/emh.h>
#include <form/form.h>
#include <property/prop.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <tc/envelope.h>
#include "tc/tc.h"
#include "pom/pom/pom.h"
#include "sa/role.h"
#include "epm/signoff.h"
#include "sa/groupmember.h"
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <bom/bom.h>
#include <tie/tie.h>
#include <pom/enq/enq.h>
#include <sa/user.h>
#include <tccore/tctype.h>
#include <fclasses/tc_date.h>
#include <property/nr.h>
#include <sa/user.h>
#include <tccore/custom.h>
#include <epm/epm_toolkit_iman_utils.h>
#include <textsrv/textserver.h>
#include <vector>
#include "cfm/cfm.h"
#include "constants/constants.h"
#include <sys/timeb.h>
#include <fclasses/tc_math.h>
#include <fclasses/iman_math.h>
#include <math.h>
#include <map>
#include <fclasses/tc_math.h>
#include <ItkCallHeader.hxx>

#ifdef __cplusplus
extern "C"{
#endif

	extern int AM__set_application_bypass(logical bypass);
	extern int AM__ask_application_bypass(logical* bypass);
	extern void POM_AM__set_application_bypass( bool b );

#ifdef __cplusplus
}
#endif

#define SEPERATOR   "\\"



/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.... */
#define D4G_FREE(p) {\
	if ( p != NULL ) {\
	MEM_free(p);\
	p = NULL;\
	}\
}

/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define D4G_FREE_ARRAY(p, count) {\
	int i = 0;\
	if ( p != NULL ) {\
	for(i = 0; i < count; i++) {\
	if(p[i] != NULL) {\
	MEM_free(p[i]);\
	p[i] = NULL;\
	}\
	}\
	MEM_free(p);\
	p = NULL;\
	}\
}


using namespace std;

#ifdef  __cplusplus

extern "C" {

#endif

#ifdef _WIN32
#include <io.h>
#include <tchar.h>
#else
#include <dirent.h>
#include <unistd.h>
#endif

#ifdef  __cplusplus

}

#endif


const std::string ITEM_ID					 = "item_id";
const std::string BL_ITEM_ID				 = "bl_item_item_id";

#define  FORMAT_TEXT                         "TEXT"
#define  REF_TEXT                            "Text"
#define  DATASET                             "Dataset"
#define  REFERENCE_ITEMS_REL                 "CMReferences"
#define  SOLUTION_ITEM_REL                   "CMHasSolutionItem"
#define  DANFOSS_BOMITEMREV                  "D4G_BOMItemRevision"
#define  TEMP_DIR                            "TC_SHARED_MEMORY_DIR"
#define  CMIMPLEMENTS                        "CMImplements"
#define  CHANGE_REQ_REV                      "D4G_ChangeReqRevision"
#define  REMOVE_STATUS                       "Remove status"
#define  READY_FOR_MMU                       "D4G_ReadyForMMU"
#define  PROBLEM_ITEM_REL                    "CMHasProblemItem"
#define  CREDENTIAL_BASE              		 515140
#define  INVALID_GRP                  		 (CREDENTIAL_BASE + 2)
#define  INVALID_USER                 		 (CREDENTIAL_BASE + 3)
#define  INVALID_PWD                  		 (CREDENTIAL_BASE + 4)
#define  PASS_FILE_PATH                 	 "\\security\\mmu_user.txt"

#define  PART_NUMBER                  		 "Part Number"
#define  BOM_QUERY_NAME               		 "Danfoss BOM..."
#define  FROM_PART                    		 "From_Part"
#define  D4G_PARTID                   		 "d4g_PartID"
#define  TO_PART              	      		 "To_Part"
#define  BOM_ITEM                     		 "BOM_Item"

#define  GRP_NOT_MATCHED              		 "Group_Not_Matched"
#define  BOMITEM_SPECIFIED_CSV        		 "Number of BOM IDs specified in CSV file = "
#define  PROBLEM_BOMITEMS_FOUND       		 "Number of problem BOM Items detected = "
#define  BOMITEMS_PLANTS_FOUND        		 "Number of plants detected = "
#define  BOMITEMS_FOR_REPLACEMENT     		 "Number of BOM Items ready for replacements = "
#define  NUMBER_CN_CREATED            		 "Number of CNs created = "
#define  NUMBER_CM_CREATED            		 "Number of CMs created = "

#define  ERROR_CHECK_LOG                     "Error: Check log file attached to CR Revision with Reference Items relation."
#define  CHECK_LOG_FILE                      "Log file is attached to CR Revision with Reference Items relation."
#define  OBJECT_NAME                         "object_name"
#define  CHANGE_NOTICE                       "D4G_ChangeNotice"
#define  PROBLEM_ITEMS                       "problem_items"
#define  PLANT_REL                           "D4G_PartPlantRel"
#define  ITEM_REV                            "ItemRevision"
#define  PLANT_ATT                           "d4g_Plant"
#define  CHANGE_SPECIALIST_2                 "ChangeSpecialist2"
#define  DANFOSS_PARTREV                     "D4G_DanPartRevision"
#define  CHANGE_MASTER                       "D4G_ChangeMaster"
#define  OBJECT_STRING                       "object_string"
#define  PROCESS_LIST                        "process_stage_list"
#define  CHANGE_NOTICE_REV                   "D4G_ChangeNoticeRevision"
#define  CHANGE_MASTER_REV                   "D4G_ChangeMasterRevision"
#define  LAB_OFFICE_ATTR                     "d4g_labOffice"
#define  CM_REVISION                         "D4G_ChangeMasterRevision"
#define  CHANGE_TYPE_ATTR                    "d4g_ChangeType"
#define  STANDARD                            "Standard"
#define  REVISION                            "revision"
#define  OBSOLETE                     		 "Obsolete"
#define  PARTS_SPECIFIED_CSV                 "Total no of parts specified in .CSV file = "
#define  PROBLEM_PARTS_FOUND                 "Number of problem parts detected = "
#define  PLANTS_FOUND                        "Number of Plants detected = "
#define  PARTS_FOR_OBSOLETE                  "Number of parts ready for Obsoletion = "
#define  ITEM_REV_ID                         "item_revision_id"
#define  PS_CHILDREN                         "ps_children"

__declspec(dllexport) int createRelationChangeObjects(tag_t tChangeObject,tag_t tsecObject,tag_t tRelation,vector<string>& vecStoreLogs,int& iErrorCount);
__declspec(dllexport) int createRelation(vector<tag_t> vecsolutionItemLists,int iReviseIndex,tag_t tagChangeReqRev,std::string strNewObjecttype,vector<string>& vecStoreLogs,int& iErrorCount);
__declspec(dllexport) int getCurrentTime( date_t* theTime );
__declspec(dllexport) int isInstanceOfClass( std::string szClassName, const tag_t& tInstance, bool& bInstance );
__declspec(dllexport) int setParticipants(tag_t selectedCR,tag_t& tParticipant);
__declspec(dllexport) int createChangeMasterforParts(tag_t tselectedCR,vector<tag_t> vecPartFoundList,vector<tag_t>& vecChangeMasterLists,vector<string>& vecStoreLogs,int& iErrorCount,int& iPlantCount,std::string strOperation,string strMaxPrefName);
__declspec(dllexport) int createRelationChangeNoticeMaster(vector<tag_t> vecChangeNoticeLists,vector<tag_t> vecChangeMasterLists,vector<string>& vecStoreLogs,int& iErrorCount);
__declspec(dllexport) int createChangeObject(tag_t tselectedCR,std::string strPlantName,std::string strNewObjectName,std::string strNewObjecttype,tag_t& tagChangeReqRev,vector<string>& vecStoreLogs,int& iErrorCount,std::string strOperation);
__declspec(dllexport) int createAttachLogDataset( char*  cDatasetName,char*  cDatasetDesc, char*  cDatasetType,char*  cFormatName,char*  cDatasetRefName,char*  cReferenceName,
	char*  cRelationTypeName,AE_reference_type_t ref_type,tag_t  tagRevTag,tag_t* tagNew_dataset,vector<std::string>& vecStoreLogs,int& iErrorCount );
__declspec(dllexport) int sendUserNotification(tag_t tUser_Tag,char*  cMailSub,const char* cMailBody);

#endif
