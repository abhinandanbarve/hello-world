/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_MASS_2014_06_SOAMASSUPDATE_IMPL_HXX 
#define TEAMCENTER_SERVICES_MASS_2014_06_SOAMASSUPDATE_IMPL_HXX


#include <soamassupdate1406.hxx>

#include <Mass_exports.h>



namespace D4G
{
    namespace Soa
    {
        namespace Mass
        {
            namespace _2014_06
            {
                class SoaMassUpdateImpl;
            }
        }
    }
}


class SOAMASS_API D4G::Soa::Mass::_2014_06::SoaMassUpdateImpl : public D4G::Soa::Mass::_2014_06::SoaMassUpdate

{
public:

    virtual SoaMassUpdateImpl::SoaMassUpdateReturn soaMassMassUpdateOperation ( const BusinessObjectRef<Teamcenter::BusinessObject>& selectedCRRev, const std::vector< std::string >& bomItemsList, const std::vector< std::string >& fromPartsList, const std::vector< std::string >& toPartsList, const std::string& isValidateExecute, const std::vector< BusinessObjectRef<Teamcenter::BusinessObject> >& tagBomItemsList );

};

#define  FROM_PART                    "From_Part"
#define  TO_PART              	      "To_Part"
#define  BOM_ITEM                     "BOM_Item"
#define  D4G_PARTID                   "d4g_PartID"
#define  GRP_NOT_MATCHED              "Group_Not_Matched"

int check_From_To_Parts(vector<string> vecPartsList,vector<string>& vecRetunInfoList);
int check_BomItems(vector<string> vecBomItemList,vector<string>& vecItemsFoundList,vector<tag_t>& vecBomItemsTagFoundList);
int massUpdate_checkBomItemsGroup(vector<tag_t> vecBomItemsFoundList,vector<string>& vecItemsGroupFoundList,vector<tag_t>& vecBomItemsTagGroupFoundList);

#include <Mass_undef.h>
#endif
