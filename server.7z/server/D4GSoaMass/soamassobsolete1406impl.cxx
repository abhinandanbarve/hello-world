/*----------------------------------------------------------------------------------------------------------------------------
* Filename         :    soamassobsolete1406impl.cxx
* Description      :    This function is used to mass obsolete various parts and Bom Items.
* Module           :    libd4gsoamass.dll
* Since            :    release
*
* ENVIRONMENT      :    C++, ITK
*  Note:
*
* FUNCTION LIST    :    int create_POM_enquiry_find_parts(vector<std::string> partsListFromCSV,vector<tag_t>& vecPartFoundList,vector<std::string>& vecPartItemIdFoundList);
*
* History
*----------------------------------------------------------------------------------------------------------------------------
* Date             Name              Company      Description of Change
* 29-11-16    		Rahul Yadav       Siemens      Initial Code for Mass Obsolete
*
* ---------------------------------------------------------------------------------------------------------------------------
*
***********************************************************************************/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <soamassobsolete1406impl.hxx>
#include <iostream>
using namespace std;


using namespace D4G::Soa::Mass::_2014_06;
using namespace Teamcenter::Soa::Server;
int iPlantCreate =0;
int iPartsInCSVFile = 0;
int iProblemParts = 0;
int iPartsOfObsoletion =0;
std::vector <string> vecStoreLogs;



/***************************************************************************************
* Function Name    : soaMassUpdateOperation
* Description      : This function is a called in precondition on revise of S_PUA & S_DUA to check if revision has status "Closed" if yes then dont allow to revise

*
* REQUIRED HEADERS : soamassobsolete1406impl.hxx
* INPUT PARAMS     : selectedCR   -- Selected CR from Teamcenter
*                    inputFromSoa -- list of input arguments to decide Validation or Execute
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :
*
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date             Name              Company      Description of Change
* 29-11-16    		Rahul Yadav       Siemens      Initial Code for Mass Obsolete
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

SoaMassObsoleteImpl::SoaMassObsoleteReturn SoaMassObsoleteImpl::soaMassUpdateOperation ( const BusinessObjectRef<Teamcenter::BusinessObject>& selectedCR, const std::vector< std::string >& partsListFromCSV, const std::string& validationInput, const std::vector< BusinessObjectRef<Teamcenter::BusinessObject> >& tagPartList )
{
	// TODO implement operation
	int    status                   		= ITK_ok;

	std::vector< std::string >              vecAllLines;
	std::vector< tag_t >                    vecPartFoundList;
	std::vector< std::string >              vecPartItemIdFoundList;
	std::vector< std::string >              vecRetunInfoList;
	std::vector< std::string >              vecInputFromSoa;

	SoaMassObsoleteReturn                   soaMassReturn;

	try
	{
		if(partsListFromCSV.size() > 0 &&  tagPartList.size() == 0  && tc_strcmp( validationInput.c_str(), VALIDATION ) == 0)
		{
			vecPartFoundList.clear();
			vecRetunInfoList.clear();

			create_POM_enquiry_find_parts(partsListFromCSV,vecPartFoundList,vecPartItemIdFoundList);

			if(vecPartItemIdFoundList.size() != partsListFromCSV.size())
			{
				for(int index=0;index < partsListFromCSV.size();index++)
				{
					if (!(std::find(vecPartItemIdFoundList.begin(), vecPartItemIdFoundList.end(), partsListFromCSV.at( index ).c_str()) != vecPartItemIdFoundList.end() ))
					{

						vecRetunInfoList.push_back( partsListFromCSV.at( index ).c_str() );
					}
				}
			}

			if(vecRetunInfoList.size() > 0)
			{
				for( int iCount = 0; iCount < vecRetunInfoList.size(); iCount++ )
				{
					soaMassReturn.returnFromMassObsolete.push_back( vecRetunInfoList.at( iCount ).c_str());
				}

			}else
			{
				for( int iCount = 0; iCount < vecPartFoundList.size(); iCount++ )
				{
					soaMassReturn.returnPartsTagFromValidation.push_back( vecPartFoundList.at( iCount ));
				}
				soaMassReturn.returnFromMassObsolete.push_back( VALIDATION_COMPLETED);

			}

		}


	}catch( ... )
	{
		ITK_set_bypass(false);
	}

	return soaMassReturn;
	// TODO implement operation
}

/***************************************************************************************
* Function Name    : create_POM_enquiry_find_parts
* Description      : This function creates POM Enquiry to find parts list.

*
* REQUIRED HEADERS : soamassobsolete1406impl.hxx
* INPUT PARAMS     : selectedCR   -- Selected CR from Teamcenter
*                    inputFromSoa -- list of input arguments to decide Validation or Execute
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        : 1) Create one POM Enquiry and give entries from csv file as input.
*                    2) Execute the enquiry and add the result in output vectors.
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date             Name              Company      Description of Change
* 29-11-16    		Rahul Yadav       Siemens      Initial Code for Mass Obsolete
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

int create_POM_enquiry_find_parts(vector<std::string> partsListFromCSV,vector<tag_t>& vecPartFoundList,vector<std::string>& vecPartItemIdFoundList)
{
	int    status                   = ITK_ok;

	try{

		ITK_LOG( POM_enquiry_create( "enq" ) ) ;
		ITK_LOG(POM_enquiry_create_class_alias( "enq", "Item", true, "enq_revision" ) ) ;
		ITK_LOG(POM_enquiry_set_distinct( "enq", true ) ) ;

		int iType = 1 ;
		const char** cpTypevalues = ( const char** ) MEM_alloc( iType * sizeof( char* ) ) ;
		cpTypevalues[ 0 ] = MEM_string_copy( "D4G_DanPart" ) ;
		ITK_LOG(POM_enquiry_set_string_value( "enq", "val1", iType, cpTypevalues, POM_enquiry_bind_value ) ) ;

		for( int i = 0 ; i < iType ; i ++ )
		{
			MEM_free( ( void* ) cpTypevalues[ i ] ) ;
		}
		MEM_free( cpTypevalues ) ;

		ITK_LOG(POM_enquiry_set_attr_expr( "enq", "e1", "enq_revision", "object_type", POM_enquiry_equal, "val1" ) ) ;

		{
			int iInputParts = partsListFromCSV.size();
			const char** cpInputPartValues = ( const char** ) MEM_alloc( iInputParts * sizeof( char* ) ) ;
			for(int index = 0; index<partsListFromCSV.size();index++)
			{
				cpInputPartValues[ index ] = MEM_string_copy(partsListFromCSV.at(index ).c_str()) ;
			}

			ITK_LOG(POM_enquiry_set_string_value( "enq", "val2", iInputParts, cpInputPartValues, POM_enquiry_bind_value ) ) ;

			for( int i = 0 ; i < iInputParts ; i ++ )
			{
				MEM_free( ( void* ) cpInputPartValues[ i ] ) ;
			}
			MEM_free( cpInputPartValues ) ;
		}
		ITK_LOG(POM_enquiry_set_attr_expr( "enq", "e2", "enq_revision", "item_id", POM_enquiry_in, "val2" ) ) ;
		ITK_LOG(POM_enquiry_set_expr( "enq", "(e1.e2)", "e1", POM_enquiry_and, "e2" ) ) ;

		int iOutput = 2 ;
		const char** cpOutputValues = ( const char** ) MEM_alloc( iOutput * sizeof( char* ) ) ;
		cpOutputValues[ 0 ] = MEM_string_copy( "puid" ) ;
		cpOutputValues[ 1 ] = MEM_string_copy( "item_id" ) ;
		ITK_LOG(POM_enquiry_add_select_attrs( "enq", "enq_revision", iOutput, cpOutputValues ) ) ;

		for( int i = 0 ; i < iOutput ; i ++ )
		{
			MEM_free( ( void* ) cpOutputValues[ i ] ) ;
		}

		ITK_LOG(POM_enquiry_set_where_expr( "enq", "(e1.e2)" ) ) ;

		int iTotalRows = 0 ;
		int iTotalCols = 0 ;

		void** *queryResult = NULL ;
		ITK_LOG(POM_enquiry_execute( "enq", &iTotalRows, &iTotalCols, &queryResult ) ) ;

		TC_write_syslog( "found --> n_rows=%d, n_cols=%d\n", iTotalRows, iTotalCols ) ;

		ITK_LOG(POM_enquiry_delete( "enq" ) ) ;

		for( int inx = 0; inx < iTotalRows; inx++ )
		{
			// Item Tag and Item ID
			tag_t tItemTag = *( tag_t* )( queryResult[inx][0] );
			char* itemId = ( char* )( queryResult[inx][1] );

			vecPartFoundList.push_back(tItemTag);
			vecPartItemIdFoundList.push_back(itemId);

		}

	}catch( ... )
	{
		ITK_LOG(POM_enquiry_delete( "enq" ) ) ;

	}

	return status;

}

