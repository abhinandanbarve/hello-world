/* 
 /*
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_MASS_2014_06_SOAMASSOBSOLETE_IMPL_HXX 
#define TEAMCENTER_SERVICES_MASS_2014_06_SOAMASSOBSOLETE_IMPL_HXX

#include <stdio.h>
#include <soamassobsolete1406.hxx>
#include <tc/iman.h>
#include <epm/epm.h>
#include <tccore/item.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <algorithm>
#include <string>
#include <tccore/project.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_date.h>
#include <pom/pom/pom.h>
#include <stdio.h>
#include <tccore/imantype.h>
#include <tc/preferences.h>
#include <tccore/grm.h>
#include <sa/sa.h>
#include <sa/am.h>
#include <lov/lov.h>
#include <epm/epm_task_template_itk.h>
#include <tc/emh.h>
#include <form/form.h>
#include <property/prop.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <tc/envelope.h>
#include "tc/tc.h"
#include "pom/pom/pom.h"
#include "sa/role.h"
#include "epm/signoff.h"
#include "sa/groupmember.h"
#include <tccoreext/gde.h>
#include <tccore/part.h>
#include <ItkCallHeader.hxx>
#include <tc/tc_util.h>
#include <itk/bmf.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <bom/bom.h>
#include <tie/tie.h>
#include <pom/enq/enq.h>
#include <sa/user.h>
#include <tccore/tctype.h>
#include <fclasses/tc_date.h>
#include <property/nr.h>
#include <sa/user.h>
#include <tccore/custom.h>
#include <epm/epm_toolkit_iman_utils.h>
#include <textsrv/textserver.h>
#include <vector>
#include "cfm/cfm.h"
#include "constants/constants.h"
#include <sys/timeb.h>
#include <fclasses/tc_math.h>
#include <fclasses/iman_math.h>
#include <math.h>
#include <fclasses/tc_math.h>
#include <iostream>
#include <sstream>
#include <string>
#include <epm/epm_toolkit_tc_utils.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <iostream>
#include <sstream>
#include <string>
#include <epm/epm_toolkit_tc_utils.h>
#include <epm/epm_toolkit_tc_utils.h>

#ifdef __cplusplus
extern "C"{
#endif

extern int AM__set_application_bypass(logical bypass);
extern int AM__ask_application_bypass(logical* bypass);
extern void POM_AM__set_application_bypass( bool b );

#ifdef __cplusplus
}
#endif

#define  VALIDATION                          "validation"
#define  OBJECT_STRING                       "object_string"
#define  VALIDATION_COMPLETED                "Validation Completed."

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.... */
#define D4G_FREE(p) {\
    if ( p != NULL ) {\
        MEM_free(p);\
        p = NULL;\
    }\
}

/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define D4G_FREE_ARRAY(p, count) {\
      int i = 0;\
   if ( p != NULL ) {\
        for(i = 0; i < count; i++) {\
            if(p[i] != NULL) {\
                MEM_free(p[i]);\
                p[i] = NULL;\
            }\
        }\
        MEM_free(p);\
        p = NULL;\
    }\
}

#include <Mass_exports.h>
namespace D4G
{
    namespace Soa
    {
        namespace Mass
        {
            namespace _2014_06
            {
                class SoaMassObsoleteImpl;
            }
        }
    }
}


class SOAMASS_API D4G::Soa::Mass::_2014_06::SoaMassObsoleteImpl : public D4G::Soa::Mass::_2014_06::SoaMassObsolete

{
public:

    virtual SoaMassObsoleteImpl::SoaMassObsoleteReturn soaMassUpdateOperation ( const BusinessObjectRef<Teamcenter::BusinessObject>& selectedCR, const std::vector< std::string >& partsListFromCSV, const std::string& validationInput, const std::vector< BusinessObjectRef<Teamcenter::BusinessObject> >& tagPartList );

};

int create_POM_enquiry_find_parts(vector<std::string> partsListFromCSV,vector<tag_t>& vecPartFoundList,vector<std::string>& vecPartItemIdFoundList);

#include <Mass_undef.h>
#endif
