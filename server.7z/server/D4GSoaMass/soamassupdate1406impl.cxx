/*----------------------------------------------------------------------------------------------------------------------------
* Filename         :    soamassupdate1406impl.cxx
* Description      :    This function is used to mass update various parts and Bom Items.
* Module           :    libd4gsoamass.dll
* Since            :    release
*
* ENVIRONMENT      :    C++, ITK
*  Note:
*
* FUNCTION LIST    :    int check_From_To_Parts(vector<string> vecPartsList,vector<string>& vecRetunInfoList);
int check_BomItems(vector<string> vecBomItemList,vector<string>& vecItemsFoundList,vector<tag_t>& vecBomItemsTagFoundList);
int massUpdate_checkBomItemsGroup(vector<tag_t> vecBomItemsFoundList,vector<string>& vecItemsGroupFoundList,vector<tag_t>& vecBomItemsTagGroupFoundList);
*
* History
*----------------------------------------------------------------------------------------------------------------------------
* Date              Name              Company      Description of Change
* 29-11-16    		Rahul Yadav       Siemens      Initial Code for Mass Obsolete
* 27-06-17			Rohit Ghundiyal	  Siemens	   Put execute code in separate utility
* ---------------------------------------------------------------------------------------------------------------------------
*
***********************************************************************************/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif
#include <iostream>
#include <soamassupdate1406impl.hxx>
#include <soamassobsolete1406impl.hxx>

using namespace D4G::Soa::Mass::_2014_06;
using namespace Teamcenter::Soa::Server;
using namespace std;

int iMuPlantCreate =0;
int iMuPartsInCSVFile = 0;
int iMuProblemParts = 0;
int iMuPartsOfObsoletion =0;
std::vector <string> vecMassStoreLogs;


/***************************************************************************************
* Function Name    : soaMassMassUpdateOperation
* Description      : This function gets called from RAC and validate if Items are found in TC. If not found returns the list of items not found in TC.
* 					  If all items are found then return list of Items tag to RAC and provide tag list of exist Items in TC in next SOA call.This function call diffrent
* 					  functions to process list of Items and eventually returns the result to RAC.
*
* REQUIRED HEADERS : soamassupdate1406.hxx
*
* INPUT PARAMS     :  selectedCRRev            	      -- Selected CR from Client
*                     bomItemsList            		  -- Bom Item IDs from RAC
*                     fromPartsList                   -- From Parts list from RAC
*                     toPartsList                     -- TO Parts list from RAC
*                     isValidateExecute               -- to check f its Validation step or Execute step
*                     tagBomItemsList                 -- Tag BOM Items List for Execute
*
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :   1) Check if To and From Parts exist in TC. If does not send error message back to Client.
*                      2) Check if All BOM Items are found in TC. If not send error message back to Client.
*                      3) If all Items are found. Call different function to process Mass Mass Update.
*                      4) After data Processing send Success result back to Client.
*
*
*
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date             Name              Company      Description of Change
* 01-03-16    		Rahul Yadav       Siemens      Initial Code for Mass Mass Update
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

SoaMassUpdateImpl::SoaMassUpdateReturn SoaMassUpdateImpl::soaMassMassUpdateOperation ( const BusinessObjectRef<Teamcenter::BusinessObject>& selectedCRRev, const std::vector< std::string >& bomItemsList, const std::vector< std::string >& fromPartsList, const std::vector< std::string >& toPartsList, const std::string& isValidateExecute, const std::vector< BusinessObjectRef<Teamcenter::BusinessObject> >& tagBomItemsList )
{
	// TODO implement operation
	int status = ITK_ok;

	SoaMassUpdateReturn                   soaMassUpdateReturn;
	std::vector< std::string >            vecRetunInfoList;
	std::vector< std::string >            vecItemsFoundList;
	std::vector< std::string >            vecItemsGroupFoundList;
	std::vector< std::string >            vecGroupNotMatchedList;
	std::vector <tag_t>                   vecBomItemsTagFoundList;
	std::vector <tag_t>                   vecBomItemsTagGroupFoundList;

	bool isValidationFailed               = false;

	try
	{
		if(tagBomItemsList.size() == 0 && selectedCRRev !=  NULLTAG && tc_strcmp(isValidateExecute.c_str(),VALIDATION) == 0)
		{

			vecRetunInfoList.clear();
			vecBomItemsTagFoundList.clear();

			if(fromPartsList.size() > 0)
			{
				std::vector <tag_t>                     vecFromPartFoundList;
				std::vector <string>                    vecFromPartItemIdFoundList;


				create_POM_enquiry_find_parts(fromPartsList,vecFromPartFoundList,vecFromPartItemIdFoundList);

				if(vecFromPartItemIdFoundList.size() != fromPartsList.size())
				{
					for(int index=0;index < fromPartsList.size();index++)
					{
						if (!(std::find(vecFromPartItemIdFoundList.begin(), vecFromPartItemIdFoundList.end(), fromPartsList.at( index ).c_str()) != vecFromPartItemIdFoundList.end() ))
						{

							vecRetunInfoList.push_back( fromPartsList.at( index ).c_str() );
						}
					}
				}


				if(vecRetunInfoList.size() > 0)
				{

					isValidationFailed = true;
					vecRetunInfoList.push_back(FROM_PART);
					for( int iCount = 0; iCount < vecRetunInfoList.size(); iCount++ )
					{
						soaMassUpdateReturn.returnFromMassUpdate.push_back( vecRetunInfoList.at( iCount ).c_str());
					}
				}
			}

			if(toPartsList.size() > 0 && !(isValidationFailed))
			{
				std::vector <tag_t>                     vecToPartFoundList;
				std::vector <string>                    vecToPartItemIdFoundList;

				create_POM_enquiry_find_parts(toPartsList,vecToPartFoundList,vecToPartItemIdFoundList);

				if(vecToPartItemIdFoundList.size() != toPartsList.size())
				{
					for(int index=0;index < toPartsList.size();index++)
					{
						if (!(std::find(vecToPartItemIdFoundList.begin(), vecToPartItemIdFoundList.end(), toPartsList.at( index ).c_str()) != vecToPartItemIdFoundList.end() ))
						{

							vecRetunInfoList.push_back( toPartsList.at( index ).c_str() );
						}
					}
				}


				if(vecRetunInfoList.size() > 0)
				{
					isValidationFailed = true;
					vecRetunInfoList.push_back(TO_PART);
					for( int iCount = 0; iCount < vecRetunInfoList.size(); iCount++ )
					{
						soaMassUpdateReturn.returnFromMassUpdate.push_back( vecRetunInfoList.at( iCount ).c_str());
					}

				}
			}

			if(bomItemsList.size() > 0 && !(isValidationFailed))
			{
				check_BomItems(bomItemsList,vecItemsFoundList,vecBomItemsTagFoundList);

				if(vecItemsFoundList.size() > 0 && vecBomItemsTagFoundList.size() > 0)
				{
					for(int index=0;index < bomItemsList.size();index++)
					{
						if (!(std::find(vecItemsFoundList.begin(), vecItemsFoundList.end(), bomItemsList.at( index ).c_str()) != vecItemsFoundList.end() ))
						{
							vecRetunInfoList.push_back( bomItemsList.at( index ).c_str() );
						}
					}
				}else
				{
					for(int index=0;index < bomItemsList.size();index++)
					{
						if (!(std::find(vecItemsFoundList.begin(), vecItemsFoundList.end(), bomItemsList.at( index ).c_str()) != vecItemsFoundList.end() ))
						{
							vecRetunInfoList.push_back( bomItemsList.at( index ).c_str() );
						}
					}

				}

				if(vecRetunInfoList.size() > 0)
				{
					vecRetunInfoList.push_back(BOM_ITEM);
					for( int iCount = 0; iCount < vecRetunInfoList.size(); iCount++ )
					{
						soaMassUpdateReturn.returnFromMassUpdate.push_back( vecRetunInfoList.at( iCount ).c_str());
					}
				}else
				{
					if(vecBomItemsTagFoundList.size() > 0)
					{
						massUpdate_checkBomItemsGroup(vecBomItemsTagFoundList,vecItemsGroupFoundList,vecBomItemsTagGroupFoundList);

						if(vecBomItemsTagGroupFoundList.size() > 0)
						{
							for( int index = 0; index < vecBomItemsTagFoundList.size(); index++ )
							{

								if (!(std::find(vecBomItemsTagGroupFoundList.begin(), vecBomItemsTagGroupFoundList.end(), vecBomItemsTagFoundList.at( index )) != vecBomItemsTagGroupFoundList.end() ))
								{
									char* pcObjectString = NULL;
									ITK_LOG(AOM_ask_value_string(vecBomItemsTagFoundList.at( index ) , OBJECT_STRING, &pcObjectString ) );
									vecRetunInfoList.push_back( pcObjectString );
									D4G_FREE(pcObjectString);
								}
							}
						}else
						{
							for( int index = 0; index < vecBomItemsTagFoundList.size(); index++ )
							{
								char* pcObjectString = NULL;
								ITK_LOG(AOM_ask_value_string(vecBomItemsTagFoundList.at( index ) , OBJECT_STRING, &pcObjectString ) );
								vecRetunInfoList.push_back( pcObjectString );
								D4G_FREE(pcObjectString);
							}

						}

						if(vecRetunInfoList.size() > 0)
						{
							vecRetunInfoList.push_back(GRP_NOT_MATCHED);
							for( int iCount = 0; iCount < vecRetunInfoList.size(); iCount++ )
							{
								soaMassUpdateReturn.returnFromMassUpdate.push_back( vecRetunInfoList.at( iCount ).c_str());
							}
						}else
						{
							for( int iCount = 0; iCount < vecBomItemsTagFoundList.size(); iCount++ )
							{
								soaMassUpdateReturn.retunBomItemsTagFromValidation.push_back( vecBomItemsTagFoundList.at( iCount ));
							}
						}
					}
				}
			}

		}
	}catch(...)
	{

	}

	return soaMassUpdateReturn;
}

/***************************************************************************************
* Function Name    : check_BomItems
* Description      : This function is a called to check if Bom Items exist in TC or not. POM enquiry is used to check Bom Items exist or not.
* 					  Bom Item IDs are provided in one go to check ID in TC.
*
* REQUIRED HEADERS : soamassupdate1406.hxx
* INPUT PARAMS     : vecBomItemList   -- Input part List
*                    vecItemsFoundList -- Output all ids which are found
*                    vecBomItemsTagFoundList --  Output all tags which are found
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :    1) Create POM_enquiry
* 						2) Query D4G_BOMItem Class
*						3) Provide input all Bom items from CSV file
*						4) return tags and ids of object found
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date             Name              Company      Description of Change
* 01-03-16    		Rahul Yadav       Siemens      Initial Code for Mass Obsolete
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

int check_BomItems(vector<string> vecBomItemList,vector<string>& vecItemsFoundList,vector<tag_t>& vecBomItemsTagFoundList)
{
	int    status                   = ITK_ok;

	try
	{

		ITK_LOG( POM_enquiry_create( "bom_enq" ) ) ;
		ITK_LOG(POM_enquiry_set_distinct( "bom_enq", true ) ) ;

		int iInputParts = vecBomItemList.size();

		const char** cpInputPartValues = ( const char** ) MEM_alloc( iInputParts * sizeof( char* ) ) ;
		for(int index = 0; index<vecBomItemList.size();index++)
		{
			cpInputPartValues[ index ] = MEM_string_copy(vecBomItemList.at(index ).c_str()) ;

		}

		ITK_LOG(POM_enquiry_set_string_value( "bom_enq", "val2", iInputParts, cpInputPartValues, POM_enquiry_bind_value ));



		for( int i = 0 ; i < iInputParts ; i ++ )
		{
			MEM_free( ( void* ) cpInputPartValues[ i ] ) ;
		}
		MEM_free( cpInputPartValues ) ;

		ITK_LOG(POM_enquiry_set_attr_expr( "bom_enq", "e2", "D4G_BOMItem", "d4g_PartID", POM_enquiry_in, "val2" ) ) ;

		int iOutput = 2 ;
		const char** cpOutputValues = ( const char** ) MEM_alloc( iOutput * sizeof( char* ) ) ;
		cpOutputValues[ 0 ] = MEM_string_copy( "puid" ) ;
		cpOutputValues[ 1 ] = MEM_string_copy( "d4g_PartID" ) ;
		ITK_LOG(POM_enquiry_add_select_attrs( "bom_enq", "D4G_BOMItem", iOutput, cpOutputValues ) ) ;

		for( int i = 0 ; i < iOutput ; i ++ )
		{
			MEM_free( ( void* ) cpOutputValues[ i ] ) ;
		}

		ITK_LOG(POM_enquiry_set_where_expr( "bom_enq", "e2" ) ) ;

		int iTotalRows = 0 ;
		int iTotalCols = 0 ;
		void** *queryResult = NULL ;

		ITK_LOG(POM_enquiry_execute( "bom_enq", &iTotalRows, &iTotalCols, &queryResult ) ) ;
		TC_write_syslog( "found --> n_rows=%d, n_cols=%d\n", iTotalRows, iTotalCols ) ;

		ITK_LOG(POM_enquiry_delete( "bom_enq" ) ) ;

		for( int inx = 0; inx < iTotalRows; inx++ )
		{				// ChildItem ChildRev creation_date object_type Child_ItemID Child_RevID
			tag_t tItemTag = *( tag_t* )( queryResult[inx][0] );
			char* itemId = ( char* )( queryResult[inx][1] );
			vecBomItemsTagFoundList.push_back(tItemTag);

			if(vecItemsFoundList.size() > 0 && !(std::find(vecItemsFoundList.begin(), vecItemsFoundList.end(), itemId) != vecItemsFoundList.end() ))
			{
				vecItemsFoundList.push_back(itemId);
			}else
			{
				vecItemsFoundList.push_back(itemId);
			}

		}

	}catch(...)
	{
		ITK_LOG(POM_enquiry_delete( "bom_enq" ) ) ;
	}

	return status;
}

/***************************************************************************************
* Function Name    : massUpdate_checkBomItemsGroup
* Description      : This function is a called to check group match with Login User.POM enquiry is used to check group is matched.
* 					  Bom Item IDs are provided in one go to check ID in TC.
*
* REQUIRED HEADERS : soamassupdate1406.hxx
* INPUT PARAMS     : vecBomItemList   -- Input part List
*                    vecItemsGroupFoundList -- Output all ids which are found
*                    vecBomItemsTagGroupFoundList --  Output all tags which are found
*
* RETURN VALUE     :int : 0/error code
* GLOBALS USED     :
* FUNCTIONS CALLED :
*
* ALGORITHM        :    1) Create POM_enquiry
* 						2) Query D4G_BOMItem Class
*						3) Provide input all Bom items tags from previous query
*						4) return tags and ids of object found
* NOTES            :
*
*
* History
*--------------------------------------------------------------------------------------------------------------------------------
* Date             Name              Company      Description of Change
* 01-03-16    		Rahul Yadav       Siemens      Initial Code for Mass Obsolete
*
*---------------------------------------------------------------------------------------------------------------------------------
*
***************************************************************************************/

int massUpdate_checkBomItemsGroup(vector<tag_t> vecBomItemsFoundList,vector<string>& vecItemsGroupFoundList,vector<tag_t>& vecBomItemsTagGroupFoundList)
{
	int    status                      = ITK_ok;
	tag_t* tBomItems                    = NULLTAG;
	tag_t  tGroupMember         		= NULLTAG;
	tag_t  tGroup               		= NULLTAG;


	try
	{
		//check the current group
		//get the current groupmember
		ITK_LOG( SA_ask_current_groupmember( &tGroupMember ) );
		if( tGroupMember != NULL )
		{	//get the group of the current groupmember
			ITK_LOG( SA_ask_groupmember_group( tGroupMember, &tGroup ) );
		}

		ITK_LOG( POM_enquiry_create( "group_enq" ) ) ;
		ITK_LOG(POM_enquiry_set_distinct( "group_enq", true ) ) ;


		int iInputBomItems = vecBomItemsFoundList.size();

		tBomItems = ( tag_t* )MEM_alloc( sizeof( tag_t ) * vecBomItemsFoundList.size() );
		for( int i = 0; i < vecBomItemsFoundList.size(); i++ )
		{
			tBomItems[i] = vecBomItemsFoundList[i];
		}

		ITK_LOG(POM_enquiry_set_tag_value( "group_enq", "val2", iInputBomItems, tBomItems, POM_enquiry_bind_value ) ) ;

		MEM_free(tBomItems);

		ITK_LOG(POM_enquiry_set_attr_expr( "group_enq", "e2", "D4G_BOMItem", "puid", POM_enquiry_in, "val2" ) ) ;

		ITK_LOG(POM_enquiry_set_tag_value( "group_enq", "val3", 1, &tGroup, POM_enquiry_bind_value ) ) ;

		ITK_LOG(POM_enquiry_set_attr_expr( "group_enq", "e3", "D4G_BOMItem", "owning_group", POM_enquiry_equal, "val3" ) ) ;

		ITK_LOG(POM_enquiry_set_expr( "group_enq", "(e2.e3)", "e2", POM_enquiry_and, "e3" ) ) ;

		int iOutput = 2 ;
		const char** cpOutputValues = ( const char** ) MEM_alloc( iOutput * sizeof( char* ) ) ;
		cpOutputValues[ 0 ] = MEM_string_copy( "puid" ) ;
		cpOutputValues[ 1 ] = MEM_string_copy( "d4g_PartID" ) ;
		ITK_LOG(POM_enquiry_add_select_attrs( "group_enq", "D4G_BOMItem", iOutput, cpOutputValues ) ) ;

		for( int i = 0 ; i < iOutput ; i ++ )
		{
			MEM_free( ( void* ) cpOutputValues[ i ] ) ;
		}

		ITK_LOG(POM_enquiry_set_where_expr( "group_enq", "(e2.e3)" ) ) ;

		int iTotalRows = 0 ;
		int iTotalCols = 0 ;
		void** *queryResult = NULL ;

		ITK_LOG(POM_enquiry_execute( "group_enq", &iTotalRows, &iTotalCols, &queryResult ) ) ;
		TC_write_syslog( "found --> n_rows=%d, n_cols=%d\n", iTotalRows, iTotalCols ) ;

		ITK_LOG(POM_enquiry_delete( "group_enq" ) ) ;

		for( int inx = 0; inx < iTotalRows; inx++ )
		{
			tag_t tItemTag = *( tag_t* )( queryResult[inx][0] );
			char* itemId = ( char* )( queryResult[inx][1] );
			vecBomItemsTagGroupFoundList.push_back(tItemTag);
			vecItemsGroupFoundList.push_back(itemId);

		}

	}catch(...)
	{
		ITK_LOG(POM_enquiry_delete( "group_enq" ) ) ;
	}


	return status;
}

