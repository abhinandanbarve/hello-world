/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <connector1305impl.hxx>

#include <string>

using std::string;
using std::cout;

using namespace D4G::Soa::Core::_2013_05;
using namespace Teamcenter::Soa::Server;

string ConnectorImpl::core ( const string& inputMessage )
{
    cout<<"Welcome to the D4G_Core Connector function. Input Message was "<<inputMessage<<".\n";
    return "This is the return message for the D4G_Core Connector function.";
}



