/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_CORE_2013_05_CONNECTOR_IMPL_HXX 
#define TEAMCENTER_SERVICES_CORE_2013_05_CONNECTOR_IMPL_HXX


#include <connector1305.hxx>

#include <Core_exports.h>

namespace D4G
{
    namespace Soa
    {
        namespace Core
        {
            namespace _2013_05
            {
                class ConnectorImpl;
            }
        }
    }
}


class SOACORE_API D4G::Soa::Core::_2013_05::ConnectorImpl : public D4G::Soa::Core::_2013_05::Connector

{
public:

    virtual std::string core ( const std::string& inputMessage );


};

#include <Core_undef.h>
#endif
