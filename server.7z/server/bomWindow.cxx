/*
 * bomWindow.cxx
 *
 *  Created on: Feb 22, 2016
 *      Author: infodba
 */
#include <ItkCallHeader.hxx>
#include <bom/bom.h>
#include <ps/ps.h>
#include <constants.hxx>
#include <ITKTools.hxx>
#include <bomWindow.hxx>

/*
 *@see header file for explanation
 */
bomWindow::~bomWindow(){
	int status;
	ITK_LOG(BOM_close_window(window));
}

tag_t  bomWindow::getWindowTag(){
	return window;
}

tag_t bomWindow::getTopLine(){
	return topLine;
}

/*
 *@see header file for explanation
 */
bomWindow::bomWindow(tag_t object,std::string viewType){
	if(is_of_type(object,ITEM_REVISION)){
		tag_t bvr=get_bvr_from_revision(object,viewType);
		window;
		topLine;
		create_bom_window(bvr,&window,&topLine);
	} else if(is_of_type(object,BOM_VIEW_REVISION)){
		window;
		topLine;
		create_bom_window(object,&window,&topLine);
	}
}

/*
 *@see header file for explanation
 */
void bomWindow::setRevisionRule(std::string revisionRule){
	set_revision_rule(this->getWindowTag(),revisionRule);
}

