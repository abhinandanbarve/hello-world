/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_UPDATEPROPERTY_2016_05_UPDATEPROPERTYSERVICE_IMPL_HXX 
#define TEAMCENTER_SERVICES_UPDATEPROPERTY_2016_05_UPDATEPROPERTYSERVICE_IMPL_HXX


#include <updatepropertyservice1605.hxx>

#include <UpdateProperty_exports.h>

namespace D4G
{
    namespace Soa
    {
        namespace UpdateProperty
        {
            namespace _2016_05
            {
                class UpdatePropertyServiceImpl;
            }
        }
    }
}


class SOAUPDATEPROPERTY_API D4G::Soa::UpdateProperty::_2016_05::UpdatePropertyServiceImpl : public D4G::Soa::UpdateProperty::_2016_05::UpdatePropertyService

{
public:

    virtual std::string updatePropertyOperation ( const std::vector< BusinessObjectRef<Teamcenter::BusinessObject> >& vSelectedComponents, const std::vector< std::string >& vPropertyNewValues );


};

#include <UpdateProperty_undef.h>
#endif
