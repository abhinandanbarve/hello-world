/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>

#include <ITKtools.hxx>
#include <constants.hxx>

#include <updatepropertyservice1605impl.hxx>

using namespace D4G::Soa::UpdateProperty::_2016_05;
using namespace Teamcenter::Soa::Server;

/*********************************************************************************************************************/
/*
/*  Function Name:      updatePropertyOperation
/*  Program ID:         pdatepropertyservice1605impl.cxx
/*  Description:        This function is called while saving the values from Map Replacement part
 * 					    which internally updates the "Replaced By" property of Obsolete parts
/*  Input Parameters:   vSelectedComponents  -- vector of Dan Part Business object where property needs to be updated
 *                      vPropertyNewValues   -- vector of property values
/*  Return Value: 		string
/*
/* History
*------------------------------------------------------------------------------
*   Date         		  Name			     Task Id              Description
*
* 19-07-2017	 Mohammed Minam Nakhuda 	   3547              Initial Creation
*
*************************************************************************************************************************/

std::string UpdatePropertyServiceImpl::updatePropertyOperation ( const std::vector< BusinessObjectRef<Teamcenter::BusinessObject> >& vSelectedComponents, const std::vector< std::string >& vPropertyNewValues )
{
    // TODO implement operation

	try {
	int iBypass = AM__set_application_bypass(true);

		for(int objCount=0;objCount<vSelectedComponents.size();objCount++)
			{
				tag_t 	tSolutionItem 				= NULLTAG;
				tag_t 	tSolutionItemTypeTag   		= NULLTAG;
				tag_t	tReplacedByID				= NULLTAG;
				tag_t	tSolutionItemClassID		= NULLTAG;

				char*	cpSolutionItemType_class	= NULL;

	            tSolutionItem = vSelectedComponents[objCount];

	            TCTYPE_ask_object_type(tSolutionItem,&tSolutionItemTypeTag);

	            TCTYPE_ask_class_name2(tSolutionItemTypeTag, &cpSolutionItemType_class );

	            POM_attr_id_of_attr( D4G_REPLACED_BY , cpSolutionItemType_class, &tReplacedByID );

	            POM_unload_instances( 1, &tSolutionItem );

	            POM_class_id_of_class( cpSolutionItemType_class, &tSolutionItemClassID );

	            POM_load_instances( 1, &tSolutionItem, tSolutionItemClassID, POM_modify_lock );

	            POM_set_attr_string ( 1, &tSolutionItem, tReplacedByID, vPropertyNewValues[objCount].c_str() );

	            POM_save_instances( 1, &tSolutionItem, TRUE );

	            POM_refresh_instances(1, &tSolutionItem, NULLTAG, POM_no_lock);

	            MEM_free(cpSolutionItemType_class);
	       }

		iBypass = AM__set_application_bypass(false);
	}
	catch ( ... ) {
		AM__set_application_bypass(false);
	}

		return "success";
}



