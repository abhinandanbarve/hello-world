/*==============================================================================
 Copyright (c) 2014 Danfoss Power Solutions
 Unpublished - All Rights Reserved
 ===============================================================================

 Module  : D4G_Core

 Description:    contains the implementation of the D4G_EPM_Handlers
 	 	 	 	 and registration calls for said handlers.

 ===============================================================================*/

#ifndef D4G_ERRORCODES_HXX
#define D4G_ERRORCODES_HXX

#define UE_WRONG_TYPE (EMH_USER_error_base + 91)
#define UE_EXCLUSIVE_ARGS (EMH_USER_error_base + 97)
#define UE_MISSING_ARG (EMH_USER_error_base + 98)
#define UE_WRONG_VALUE (EMH_USER_error_base + 99)
#define UE_PROP_VALUE_NR (EMH_USER_error_base + 100)
#define UE_ILLEGAL_REVID (EMH_USER_error_base + 101)
#define UE_TYPE_NO_PROP (EMH_USER_error_base + 102)
#define UE_TO_FROM_NR (EMH_USER_error_base + 103)
#define CHECK_PROPERTY (EMH_USER_error_base + 104)
#define CHECK_STATUS (EMH_USER_error_base + 105)
#define CHECK_MILESTONES (EMH_USER_error_base + 106)
#define CHECK_WAS_APPROVED (EMH_USER_error_base + 107)
#define CHECK_COMMON_START_DATE (EMH_USER_error_base + 108)
#define CHECK_MATCHONE (EMH_USER_error_base + 110)
#define CHECK_NOTMATCHALL (EMH_USER_error_base + 111)
#define CHECK_MATCHNONE (EMH_USER_error_base + 112)
#define CHECK_REVGROUP (EMH_USER_error_base + 113)
#define CHECK_ONEREVGROUP (EMH_USER_error_base + 114)
#define CHECK_ALLBUTONEREVGROUP (EMH_USER_error_base + 115)
#define CHECK_NOREVGROUP (EMH_USER_error_base + 116)
#define WRONG_PLANT (EMH_USER_error_base + 117)
#define PART_CONTAINED_IN_BOM (EMH_USER_error_base + 118)
#define BOM_CONTAINS_OBSOLETE (EMH_USER_error_base + 119)
#define BOM_CONTAINS_PRODUCTION_RELEVANT (EMH_USER_error_base + 120)
#define PART_IS_PRODUCTION_REVELEVANT_IN_BOM (EMH_USER_error_base + 121)
#define PART_BOM_PASTE_ERROR_OBSOLETE (EMH_USER_error_base + 122)
#define CHECK_RELATION (EMH_USER_error_base + 123)
#define RELATION_LOCKED (EMH_USER_error_base + 126)
#define PROPERTY_LOCKED (EMH_USER_error_base + 127)
#define PROPERTY_LOCKED_BY_REPRESENTEDBY (EMH_USER_error_base + 128)
#define PROPERTY_LOCKED_BY_TRANSFER (EMH_USER_error_base + 129)
#define RELATIONDEL_LOCKED_BY_TRANSFER (EMH_USER_error_base + 130)
#define RELATIONDEL_LOCKED_BY_STATUS (EMH_USER_error_base + 132)
#define RELATIONCREATE_LOCKED_BY_STATUS (EMH_USER_error_base + 133)
#define CMHASSOLUTIONITEM_LOW_STATUS (EMH_USER_error_base + 134)
#define CMHASSOLUTIONITEM_PLANT_MISMATCH (EMH_USER_error_base + 135)
#define CMHASSOLUTIONITEM_CM_TWO_REVS (EMH_USER_error_base + 136)
#define CMHASSOLUTIONITEM_TWO_CMS (EMH_USER_error_base + 137)
#define CMHASSOLUTIONITEM_TWO_CMS_TYPE (EMH_USER_error_base + 138)
#define HAS_COMMENTS (EMH_USER_error_base + 139)
#define Validate_Map_Replacement_Part (EMH_USER_error_base + 140)
#define CMHASSOLUTIONITEM_MISSING (EMH_USER_error_base + 141)
#define CREATE_RELATION_OBSOLETE (EMH_USER_error_base + 142)
#define DELETE_RELATION_OBSOLETE (EMH_USER_error_base + 143)
#define ALT_BOM_EXIST (EMH_USER_error_base + 144)
#define OWNING_GROUP (EMH_USER_error_base + 145)
#endif  // D4G_ERRORCODES_HXX
