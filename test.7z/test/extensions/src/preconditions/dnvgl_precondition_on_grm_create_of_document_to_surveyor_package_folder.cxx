
/**
* \file dnvgl_precondition_on_grm_create_of_document_to_surveyor_package_folder.cxx
**/
#include "dnvgl_extensions.h"

/**
* \file dnvgl_precondition_on_grm_create_of_document_to_surveyor_package_folder.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_precondition_on_grm_create_of_document_to_surveyor_package_folder_execute( va_list localArgs )
{
	int             iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{		
		tag_t       tPrimaryObj		= NULLTAG;
		tag_t       tSecondayObj	= NULLTAG;
		
		tPrimaryObj   = va_arg(localArgs, tag_t);
		tSecondayObj  = va_arg(localArgs, tag_t); 

		if( tPrimaryObj != NULLTAG && tSecondayObj != NULLTAG )
		{
			tag_t tPrimaryProj = NULLTAG;

			//Get project tag from primary object.
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tPrimaryObj, AP4_PROJECT_BACKPOINTER, &tPrimaryProj ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tSecondaryProj = NULLTAG;

			//Get project tag from secondary object.
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tSecondayObj, AP4_PROJECT_BACKPOINTER, &tSecondaryProj ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tPrimaryProj != NULLTAG && tSecondaryProj != NULLTAG && tPrimaryProj != tSecondaryProj )
			{
				char* cpPriProjObjName = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tPrimaryProj, OBJECT_NAME, &cpPriProjObjName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				char* cpSecProjObjName = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSecondaryProj, OBJECT_NAME, &cpSecProjObjName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				iStatus = ERROR_919163;
				DNVGL_TRACE_CALL( EMH_store_error_s2( EMH_severity_error, ERROR_919163, cpSecProjObjName, cpPriProjObjName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
