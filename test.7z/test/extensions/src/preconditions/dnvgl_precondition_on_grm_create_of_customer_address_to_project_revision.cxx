/**
* \file dnvgl_precondition_on_grm_create_of_customer_address_to_project_revision.cxx
* \ingroup libAP4_dnvgl_extensions
* \verbatim
\par Description:
This file  contains the precondition for checking following conditions before attaching customer address to project revision.
- Address being attached to project revision should be an addresss of the customer which is already attached to the project revision.
- Address being attached should be an active address. Inactive or deleted addresses are not allowed to be attached.
- Type of the address is verified before attaching to the project revision. Invoice type is allowed for invoice address, office type for office address and shipping type for shipping address.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 08-Aug-2016   Sanjay Sah   	      Initial Creation
* 11-Nov-2016   Nikhilesh Khatra      Added new conditions to validate type and status of address
*--------------------------------------------------------------------------------
*/

#include "dnvgl_extensions.h"

/**
* \file dnvgl_ap4_project_struct_relation_operations.cxx
* \par  Description :
Precondition to validate
- whether address belongs to same customer which is attached to project revision
- status is active
- and correct type of address is being used
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   localArgs    list of arguments which contain the primary object, secondary object and relation tag.
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_precondition_on_grm_create_of_customer_address_to_project_revision_execute( va_list localArgs )
{
	int             iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tPrimaryObj		= NULLTAG;
		tag_t       tSecondayObj	= NULLTAG;
		tag_t       tRelationType	= NULLTAG;

		logical     lpPrimaryObj    = false;
		logical     lpSecondaryObj  = false;
		logical     lpRelationType  = false;

		tPrimaryObj   = va_arg(localArgs, tag_t);
		tSecondayObj  = va_arg(localArgs, tag_t); 
		tRelationType = va_arg(localArgs, tag_t);

		if( tPrimaryObj != NULLTAG && tSecondayObj != NULLTAG && tRelationType != NULLTAG )
		{
			iStatus = POM_is_tag_valid( tPrimaryObj,     &lpPrimaryObj   );
			iStatus = POM_is_tag_valid( tSecondayObj,    &lpSecondaryObj );
			iStatus = POM_is_tag_valid( tRelationType,   &lpRelationType );

			tag_t   	    custOffAddTag 	    = NULLTAG;	
			tag_t   	    custInvoiceAddTag 	= NULLTAG;	
			tag_t   	    custShippingAddTag 	= NULLTAG;	
			tag_t           tProjCustomerRelTag     = NULLTAG;   

			//Get the relation type tag for AP4_ProjectCustomer relation.
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_CUSTOMER, &tProjCustomerRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			int  	tCount = 0;
			tag_t * tSecObjectTags = NULLTAG;

			//Get the customer which is attached to the project revision by AP4_ProjectCustomer relation.
			DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tPrimaryObj, tProjCustomerRelTag, &tCount, &tSecObjectTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//If no customers exist then address attachment to project revision is not allowed.
			if( tCount == 0 )
			{
				iStatus = ERROR_919105;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			//Get the relation type tag of AP4_CustomerAddress
			tag_t tProjCustomeAddressRelTag = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_CUSTOMER_ADDRESS, &tProjCustomeAddressRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Check if there is a relation between the customer which is attached to project revision and the address which is being tried to attached to project revision.
			tag_t tRelationTag = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation( tSecObjectTags[0], tSecondayObj, tProjCustomeAddressRelTag, &tRelationTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//If address does not belong to the customer which is attached to the project revision then throw error.
			if( tRelationTag == NULLTAG )
			{
				iStatus = ERROR_919106;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			char	*cpObjectType	 = NULL		;
			char	*cpAddressStatus	 = NULL		;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSecondayObj, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;


			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_ADDRESS ) == 0 )
			{
				//Get the status of the address being attached.
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSecondayObj, AP4_DNV_STATUS, &cpAddressStatus ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//If the status is not active then throw an error.
				if( tc_strcmp( cpAddressStatus, ACTIVE ) != 0 )
				{
					iStatus = ERROR_919129;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}	

			char	*cpRelName	 = NULL;
			char	*cpAddressType	 = NULL;

			//Get the relation name.
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_name2( tRelationType, &cpRelName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSecondayObj, AP4_ADDRESS_TYPE, &cpAddressType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpRelName != NULL && cpAddressType != NULL )
			{
				if( tc_strcmp( cpRelName, AP4_CUSTOMER_INVOICE_ADDRESS ) == 0 && tc_strcmp( cpAddressType, INVOICE ) != 0 )
				{				
					iStatus = ERROR_919130;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}	

				else if( tc_strcmp( cpRelName, AP4_CUSTOMER_OFFICE_ADDRESS ) == 0 && tc_strcmp( cpAddressType, OFFICE ) != 0 )
				{				
					iStatus = ERROR_919131;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;			
				}	

				else if( tc_strcmp( cpRelName, AP4_CUSTOMER_SHIPPING_ADDRESS ) == 0 && tc_strcmp( cpAddressType, POSTAL ) != 0 )
				{
					iStatus = ERROR_919132;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}