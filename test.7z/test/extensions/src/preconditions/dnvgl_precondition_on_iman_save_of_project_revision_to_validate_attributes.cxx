
/**
* \file dnvgl_precondition_on_iman_save_of_to_ap4_ProjectRevision_validate_endDate_greater_than_startDate.cxx
**/
#include "dnvgl_extensions.h"

/**
* \file dnvgl_ap4_project_struct_relation_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_precondition_on_iman_save_of_project_revision_to_validate_attributes_execute( va_list localArgs )
{
	int             iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{		
		tag_t		tProjectRevTag		=	NULLTAG					;		
		date_t		dStartDateVal		=	NULLDATE				;
		date_t		dEndDateVal			=	NULLDATE				;

		tProjectRevTag		=	va_arg(localArgs, tag_t);

		DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_date	( tProjectRevTag, AP4_START_DATE, &dStartDateVal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_date	( tProjectRevTag, AP4_ESTIMATED_END_DATE, &dEndDateVal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( ( DATE_IS_NULL( dStartDateVal ) ) && ( !DATE_IS_NULL( dEndDateVal ) ) )
		{
			iStatus = ERROR_919107;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else if( ( !DATE_IS_NULL( dStartDateVal ) ) && ( DATE_IS_NULL( dEndDateVal ) ) )
		{
			iStatus = ERROR_919108;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else if( !( ( DATE_IS_NULL( dStartDateVal ) ) && ( DATE_IS_NULL( dEndDateVal ) ) ) )
		{
			int	result	= 0;
			result =  dnvgl_compare_dates(dEndDateVal, dStartDateVal , true);
			if( result <= 0 )
			{
				//If end date is less than start date, we assume the start date is corrent and we proceed with the end date = start date + 7 days.
				DNVGL_TRACE_CALL( iStatus = dnvg_add_days_to_date( dStartDateVal,7,&dEndDateVal ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS

				DNVGL_TRACE_CALL ( iStatus = AOM_set_value_date( tProjectRevTag, AP4_ESTIMATED_END_DATE, dEndDateVal ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}	
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}



