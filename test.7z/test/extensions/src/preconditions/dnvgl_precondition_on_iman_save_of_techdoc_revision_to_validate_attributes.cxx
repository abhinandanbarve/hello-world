/**
* \file dnvgl_precondition_on_iman_save_of_techdoc_revision_to_validate_attributes.h
* \ingroup libAP4_dnvgl_extensions
* \verbatim
\par Description:
Pre condition on IMAN save of technical document revision to validate attributes.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 10-Jan-2017   Vinay Kudari       Initial Creation
*--------------------------------------------------------------------------------
*/
#include "dnvgl_extensions.h"

/**
* \file dnvgl_precondition_on_iman_save_of_techdoc_revision_to_validate_attributes.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_precondition_on_iman_save_of_techdoc_revision_to_validate_attributes_execute( va_list localArgs )
{
	int             iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tTechDocRev = NULLTAG;
		char* cpDocStatus = NULL;
		char* cpStatusRemark = NULL;

		tTechDocRev = va_arg(localArgs, tag_t);

		
		DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_string( tTechDocRev, AP4_DOCUMENT_STATUS, &cpDocStatus ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_string( tTechDocRev, AP4_STATUS_REMARK, &cpStatusRemark ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if(tc_strcmp(cpDocStatus, DOCUMENT_STATUS_AC) == 0  || tc_strcmp(cpDocStatus, DOCUMENT_STATUS_NP ) == 0 && tc_strcmp(cpStatusRemark,"") == 0)
		{
			iStatus = ERROR_919156;		
		}

	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}