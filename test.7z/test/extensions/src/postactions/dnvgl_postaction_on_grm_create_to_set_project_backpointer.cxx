/**
* \file dnvgl_postaction_on_grm_create_to_set_project_backpointer.cxx
* \ingroup libAP4_dnvgl_extensions

\par Description:
This file  contains the functions which are called on postaction of grm_create of relation business objects to set project backpointer value.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

* \par Owner:
* Sakshi Mathur
*
* \par History:
 \verbatim
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 18-April-2017   Sakshi Mathur	      Initial Creation
*--------------------------------------------------------------------------------
\endverbatim
*/

#include "dnvgl_extensions.h"


/**
*\ingroup libAP4_dnvgl_common
* \par  Description : 
* \verbatim
This function is called on postaction of grm_create of objects to set backpointer value.
\endverbatim     
* \param[in]    localArgs    argument list of grm_create
*
* \par Algorithm: Get the Primary object and secondary object.
*				  Check if Primary object is Project Revision.
*				  If it's project revision then set it on the attribute named ap4_project_backpointer on the secondary object.
*				  If it's not project reivision then get the value of attribute named ap4_project_backpointer on primary object 
*				  and place the same on secondary object.
*				 
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
* \par History:
 \verbatim
 *--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 18-April-2017   Sakshi Mathur	      Initial Creation
*--------------------------------------------------------------------------------
\endverbatim
*/

int dnvgl_postaction_on_grm_create_to_set_project_backpointer_execute(va_list localArgs)
{
	int             iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tPrimaryObj				= NULLTAG;
		tag_t       tSecondayObj			= NULLTAG;
		tag_t		tObjectType			    = NULLTAG;
		tag_t		tProjRevType		    = NULLTAG;
		tag_t		tProjectbackpointer		= NULLTAG;
		logical	    lIsValidType		    = false;
		logical		lIslocked				= false;

		tPrimaryObj   = va_arg(localArgs, tag_t);
		tSecondayObj  = va_arg(localArgs, tag_t);

		//To check Primary object type
		DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tPrimaryObj, &tObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// To find the tag of custom AP4_ProjectRevision
		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_PROJECT_REVISION, AP4_PROJECT_REVISION, &tProjRevType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//To check whether Primary object is custom AP4_ProjectRevision or not 
		DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tProjRevType, &lIsValidType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		// Check if object is already locked
		DNVGL_TRACE_CALL( iStatus = POM_modifiable	(tSecondayObj,&lIslocked) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if (!lIslocked)
		{
			// Lock the secondary object
			DNVGL_TRACE_CALL (  iStatus = AOM_refresh(tSecondayObj,1) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		//If Primary object is ap4_project_revision
		if( lIsValidType )
		{
			// Set primary object i.e. Project Revision on attribute named project backpointer
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tSecondayObj, AP4_PROJECT_BACKPOINTER, tPrimaryObj ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		//If Primary object is other then ap4_project_revision
		else
		{
			// Get the value present in attribute named project backpointer
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag(tPrimaryObj, AP4_PROJECT_BACKPOINTER, &tProjectbackpointer ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// Set the value on attribute named project backpointer
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tSecondayObj, AP4_PROJECT_BACKPOINTER, tProjectbackpointer ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		// Save the secondary object
		DNVGL_TRACE_CALL( iStatus = AOM_save(tSecondayObj ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if (!lIslocked)
		{
		// Unlock the object
		DNVGL_TRACE_CALL ( iStatus = AOM_refresh(tSecondayObj,0 ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

	}
	
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}