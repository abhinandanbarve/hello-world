/**
* \file dnvgl_postaction_on_grm_create_of_hasparticipant_to_update_tcproject.cpp.cxx
* \ingroup libAP4_dnvgl_extensions
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_ProjectStructRelation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 30-May-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_extensions.h"


/**
* \file dnvgl_ap4_project_struct_relation_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_postaction_on_item_deep_copy_of_ap4_project_revision_to_copy_project_execute(va_list localArgs)
{
	int             iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tProjectRevTag			= NULLTAG;
		char*		operation				= NULL;
		tag_t		tSourceProjectRevTag	= NULLTAG;		

		tProjectRevTag   = va_arg(localArgs, tag_t);
		operation  = va_arg(localArgs, char*); 
		tSourceProjectRevTag  = va_arg(localArgs, tag_t);

		if( tc_strcmp( operation, "SaveAs" ) == 0 )
		{
			DNVGL_TRACE_CALL( iStatus = copy_from_project( &tProjectRevTag, &tSourceProjectRevTag, true ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}