#include "dnvgl_extensions.h"

int dnvgl_postaction_on_iman_save_of_ap4_project_revision_to_update_in_affinitas_execute(va_list localArgs)
{
	int  iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tProjectRev		= NULLTAG;
		logical     isNew			= false;		

		tProjectRev		= va_arg(localArgs, tag_t);
		isNew			= va_arg(localArgs, logical);

		if( isNew )
		{
			char *      cpProjectStage = NULL; 
			char *      cpAffinitasNumber = NULL; 

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRev, AP4_AFFINITAS_NUMBER, &cpAffinitasNumber ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRev, AP4_PROJECT_STAGE, &cpProjectStage ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpProjectStage != NULL && cpAffinitasNumber != NULL)
			{
				if( ( tc_strlen( cpAffinitasNumber ) > 0) && ( tc_strcmp( cpProjectStage, OPPORTUNITY ) == 0 ) )
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_create_or_update_opportunity( &tProjectRev ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}
		}				
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}