#include "dnvgl_extensions.h"

int dnvgl_postaction_on_iman_save_of_project_customer_to_attach_addresses_execute(va_list localArgs)
{
	int  iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tRelation		= NULLTAG;
		logical     isNew			= false;
		int iCount					= 0;
		tag_t * tpSeconadry			= NULLTAG;

		tRelation		= va_arg( localArgs, tag_t );
		isNew			= va_arg( localArgs, logical );

		if( isNew )
		{
			tag_t       tPrimaryObj			= NULLTAG;
			tag_t       tSecondayObj		= NULLTAG;
			tag_t		*tpCustomerContact	= NULL   ;

			DNVGL_TRACE_CALL( iStatus = GRM_ask_primary( tRelation, &tPrimaryObj ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = GRM_ask_secondary( tRelation, &tSecondayObj ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t  	tCustContactRelation	= NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_CUSTOMER_POINT_OF_CONTACT, &tCustContactRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			int    iNoOfCustomer	= 0;
			tag_t* tCustContact		= NULL;
			DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tSecondayObj, tCustContactRelation, &iNoOfCustomer, &tCustContact ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( iNoOfCustomer == 1 )
			{
				tag_t  	tProjCustContType	= NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_CUSTOMER_CONTACT, &tProjCustContType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t	tRelationTag = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tPrimaryObj, *tCustContact , tProjCustContType, NULLTAG, &tRelationTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelationTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tRelationTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			tag_t tCustAddressRelation = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_CUSTOMER_ADDRESS, &tCustAddressRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			int iCount = 0;
			tag_t* tSecObjects = NULL;
			DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tSecondayObj, tCustAddressRelation, &iCount, &tSecObjects ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			int iInvoiceAddrCount = 0;
			int iOfficeAddrCount = 0;
			int iShippingAddrCount = 0;

			tag_t tInvoiceAddress = NULLTAG;
			tag_t tOfficeAddress = NULLTAG;
			tag_t tShippingAddress = NULLTAG;

			for( int i=0; i<iCount; i++ )
			{
				char* cpAddressType = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSecObjects[i], AP4_ADDRESS_TYPE, &cpAddressType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				char* cpAddressStatus = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSecObjects[i], AP4_DNV_STATUS, &cpAddressStatus ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpAddressStatus != NULL && tc_strcmp( cpAddressStatus, ACTIVE ) == 0 )
				{
					if( tc_strcmp( cpAddressType, INVOICE ) == 0 )
					{
						iInvoiceAddrCount++;
						tInvoiceAddress = tSecObjects[i];
					}
					else if( tc_strcmp( cpAddressType, OFFICE ) == 0 )
					{
						iOfficeAddrCount++;
						tOfficeAddress = tSecObjects[i];
					}
					else if( tc_strcmp( cpAddressType, POSTAL ) == 0 )
					{
						iShippingAddrCount++;
						tShippingAddress = tSecObjects[i];
					}
				}
			}

			if( iInvoiceAddrCount == 1 )
			{
				tag_t tInvoiceAddressRelation = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_CUSTOMER_INVOICE_ADDRESS, &tInvoiceAddressRelation ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tPrimaryObj, tInvoiceAddressRelation,&iCount, &tpSeconadry ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( iCount == 0 )
				{

					tag_t tRelation = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tPrimaryObj, tInvoiceAddress, tInvoiceAddressRelation, NULLTAG, &tRelation ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelation ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}

			if( iOfficeAddrCount == 1 )
			{
				tag_t tOfficeAddressRelation = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_CUSTOMER_OFFICE_ADDRESS, &tOfficeAddressRelation ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tPrimaryObj, tOfficeAddressRelation,&iCount, &tpSeconadry ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( iCount == 0 )
				{
					tag_t tRelation = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tPrimaryObj, tOfficeAddress, tOfficeAddressRelation, NULLTAG, &tRelation ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelation ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}

			if( iShippingAddrCount == 1 )
			{
				tag_t tShippingAddressRelation = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_CUSTOMER_SHIPPING_ADDRESS, &tShippingAddressRelation ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tPrimaryObj, tShippingAddressRelation,&iCount, &tpSeconadry ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( iCount == 0 )
				{

					tag_t tRelation = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tPrimaryObj, tShippingAddress, tShippingAddressRelation, NULLTAG, &tRelation ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelation ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}