#include "dnvgl_extensions.h"

int dnvgl_postaction_on_iman_save_of_trackable_relation_to_update_attributes_execute( va_list localArgs )
{
	int             iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tRelation		= NULLTAG;
		logical     isNew			= false;

		char*		cpUserName			= NULL;
		tag_t		tUserTag			= NULL;
		
		tRelation		= va_arg( localArgs, tag_t );
		isNew			= va_arg( localArgs, logical );

		if( !isNew )
		{
			DNVGL_TRACE_CALL( iStatus = POM_get_user( &cpUserName, &tUserTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tRelation, 1 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tRelation, AP4_LAST_MOD_BY, cpUserName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			date_t dCurrDate = NULLDATE;
			dnvgl_get_current_date_time( &dCurrDate );

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( tRelation, AP4_LAST_MOD_DATE, dCurrDate ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( tRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tRelation, 0 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}