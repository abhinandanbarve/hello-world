/**
* \file dnvgl_postaction_on_iman_save_of_ap4_project_revision_to_copy_project.cxx
* \ingroup libAP4_dnvgl_extensions
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_ProjectStructRelation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 30-May-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_extensions.h"


/**
* \file dnvgl_ap4_project_struct_relation_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_postaction_on_iman_save_of_ap4_project_revision_to_copy_project_execute(va_list localArgs)
{
	int             iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tProjectRevTag		= NULLTAG;
		logical     isNew				= false;		

		tProjectRevTag		= va_arg(localArgs, tag_t);
		isNew				= va_arg(localArgs, logical); 

		if( isNew )
		{
			DNVGL_TRACE_CALL( iStatus = copy_from_project( &tProjectRevTag, NULL, false ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			DNVGL_TRACE_CALL( iStatus = update_msa_tsa_attribute( &tProjectRevTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
				
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int copy_from_project( tag_t *tProjectRevTag, tag_t *tBasedOnProjectRevTag, logical lIsSaveAsOperation )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	
	try
	{
		//Set project properties.		
		DNVGL_TRACE_CALL( iStatus = update_attributes( tProjectRevTag, lIsSaveAsOperation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get the item tag from the project revision tag.
		tag_t tProjectItemTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( *tProjectRevTag, &tProjectItemTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Check if the BasedOnProjectRevTag is not null and a valid tag. If its valid means its a saveas case. Hence copy folder and schedules from this project revision.
		if( tBasedOnProjectRevTag != NULL && *tBasedOnProjectRevTag != NULLTAG )
		{
			//Copy the folders from the based on project item.
			DNVGL_TRACE_CALL( iStatus = dnvgl_copy_project( tProjectRevTag, tBasedOnProjectRevTag, lIsSaveAsOperation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Copy the Participant Types from the based on project item.
			DNVGL_TRACE_CALL( iStatus = dnvgl_copy_participants( *tProjectRevTag, *tBasedOnProjectRevTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Copy the schedule and attached to the newly created project revision.
			DNVGL_TRACE_CALL( iStatus = copy_and_attach_schedule( tProjectRevTag, tBasedOnProjectRevTag, NULL ) );									
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			//If based on revision tag is null, it means its a create use case.
			//Get the schedule template id and project template id from the project item tag.
			if( tProjectItemTag != NULLTAG )
			{
				char* pProjectTemplateID = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectItemTag, AP4_PROJECT_TEMPLATE_ID, &pProjectTemplateID ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t tProjectTemplateTag = NULLTAG;
				//If project template id value is present, then use this template to copy folders from.
				if( pProjectTemplateID != NULL && tc_strlen( pProjectTemplateID ) > 0 )
				{					
					DNVGL_TRACE_CALL( iStatus = ITEM_find_item( pProjectTemplateID, &tProjectTemplateTag ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( tProjectTemplateTag != NULLTAG )
					{
						tag_t tProjectTemplateRevTag = NULLTAG;
						DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tProjectTemplateTag, &tProjectTemplateRevTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						//Copy the folders from the project template.
						DNVGL_TRACE_CALL( iStatus = dnvgl_copy_project( tProjectRevTag, &tProjectTemplateRevTag, lIsSaveAsOperation ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;					
					}
				}

				char* pScheduleTemplateID = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectItemTag, AP4_SCHEDULE_TEMPLATE_ID, &pScheduleTemplateID ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//If schedule template id value is present, then use this schedule template to copy from.
				if( pScheduleTemplateID != NULL && tc_strlen( pScheduleTemplateID ) > 0 )
				{
					tag_t tScheduleTag = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = dnvgl_find_schedule( pScheduleTemplateID, &tScheduleTag) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( tScheduleTag != NULLTAG )
					{							
						DNVGL_TRACE_CALL( iStatus = copy_and_attach_schedule( tProjectRevTag, NULL, &tScheduleTag ) );						
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}
				else 
				{
					if( tProjectTemplateTag != NULLTAG )
					{
						tag_t tProjectTemplateRevTag = NULLTAG;
						DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tProjectTemplateTag, &tProjectTemplateRevTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						//Copy the schedule and attached to the newly created project revision.
						DNVGL_TRACE_CALL( iStatus = copy_and_attach_schedule( tProjectRevTag, &tProjectTemplateRevTag, NULL ) );									
						DNVGL_LOG_ERROR_AND_THROW_STATUS;						
					}
				}
			}
		}

		//Create a TC project for the corresponding AP4_Project.
		tag_t tTCProject = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = dnvgl_create_tcproject( tProjectItemTag, &tTCProject ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tTCProject != NULLTAG )
		{
			tag_t tGrpMember = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = SA_ask_current_groupmember( &tGrpMember ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tUser = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = SA_ask_groupmember_user( tGrpMember, &tUser ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Assign logged in user group member to the TC project as team administrator.
			DNVGL_TRACE_CALL( iStatus = PROJ_assign_team_members( tTCProject, 1, &tGrpMember, 1, &tUser, 0, NULL ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = PROJ_assign_objects( 1, &tTCProject, 1, &tProjectItemTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		
		tag_t tOtherGroupMemberTag = NULLTAG;
		std::vector <tag_t> vGroupMembers ; 
		DNVGL_TRACE_CALL( iStatus = dnvgl_assign_participants( tProjectRevTag, &vGroupMembers) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( !(vGroupMembers.empty()) && tTCProject != NULLTAG )
		{
			for(int i = 0 ; i<vGroupMembers.size() ; i++)
			{
				bool bFlag = false;
				if( i == 0 )
				{
					bFlag = true;
				}
			DNVGL_TRACE_CALL( iStatus = dnvgl_add_user_to_tcproject( tTCProject, vGroupMembers[i], false ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}

	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_postaction_on_iman_save_of_ap4_project_revision_to_copy_project.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int copy_and_attach_schedule( tag_t *tProjectRevTag, tag_t *tProjectTemplateRevTag, tag_t* tScheduleTag )
{

	
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tScheduleToBeCopiedTag = NULLTAG;
		if( tScheduleTag != NULL && *tScheduleTag != NULLTAG )
		{
			tScheduleToBeCopiedTag = *tScheduleTag;
		}
		else
		{
			tag_t tProjectScheduleRelationType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_SCHEDULE_RELATION, &tProjectScheduleRelationType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Get the schedule attached to the based on project revision.
			int iCount = 0;
			tag_t* tSecondaryObjs = NULL;
			DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( *tProjectTemplateRevTag, tProjectScheduleRelationType, &iCount, &tSecondaryObjs ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( iCount == 1 )
			{
				tScheduleToBeCopiedTag = tSecondaryObjs[0];
			}
		}
		if( tScheduleToBeCopiedTag != NULLTAG )
		{
			tag_t tNewScheduleTag = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = dnvgl_copy_schedule( &tScheduleToBeCopiedTag, &tNewScheduleTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;		

			if( tNewScheduleTag != NULLTAG )
			{
				char* pProjectRevObjName = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tProjectRevTag, OBJECT_NAME, &pProjectRevObjName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tNewScheduleTag, OBJECT_NAME, pProjectRevObjName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t tAttrID = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = POM_attr_id_of_attr( AP4_START_DATE, AP4_PROJECT_REVISION, &tAttrID ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				date_t dStartDateOfProjectRev = NULLDATE;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( *tProjectRevTag, AP4_START_DATE, &dStartDateOfProjectRev ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				date_t dEndDateOfProjectRev = NULLDATE;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( *tProjectRevTag, AP4_ESTIMATED_END_DATE, &dEndDateOfProjectRev ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				
				//Shift the schedule only if the start date is not empty.
				if( !DATE_IS_NULL( dStartDateOfProjectRev ) )
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_shift_schedule( tNewScheduleTag, dStartDateOfProjectRev, dEndDateOfProjectRev  ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}			

				tag_t tProjectScheduleRelationType = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_SCHEDULE_RELATION, &tProjectScheduleRelationType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tNewScheduleTag, 1 ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t tNewRelation = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_create_relation( *tProjectRevTag, tNewScheduleTag, tProjectScheduleRelationType, NULLTAG, &tNewRelation ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tNewRelation ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tNewScheduleTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tNewScheduleTag, 0 ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}		
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_postaction_on_iman_save_of_ap4_project_revision_to_copy_project.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int update_attributes( tag_t *tProjectRev, logical lIsSaveAsOperation )
{
	int iStatus				= ITK_ok;
	tag_t* tLOVs			= NULL;
	char** cpLovValues		= NULL;

	DNVGL_TRACE_ENTER();
	try
	{

		char* pProjectStage = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tProjectRev, AP4_PROJECT_STAGE, &pProjectStage ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t dCreationDate = NULLDATE;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( *tProjectRev, CREATION_DATE, &dCreationDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t grpMemberTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = SA_ask_current_groupmember( &grpMemberTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t userTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = SA_ask_groupmember_user( grpMemberTag, &userTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* pPersonName = NULL;
		DNVGL_TRACE_CALL( iStatus = SA_ask_user_person_name2( userTag, &pPersonName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( !lIsSaveAsOperation )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tProjectRev, 1 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		}

		if( tc_strcmp( pProjectStage, LEAD ) == 0 )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tProjectRev, AP4_PROJECT_STATUS_CODE, LEAD ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tProjectRev, AP4_LEAD_CREATED_BY, pPersonName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( *tProjectRev, AP4_LEAD_CREATION_DATE, dCreationDate ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;				
		}
		else if( tc_strcmp( pProjectStage, OPPORTUNITY ) == 0 )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tProjectRev, AP4_OPPORTUNITY_CREATED_BY, pPersonName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( *tProjectRev, AP4_OPPORTUNITY_CREATE_DATE, dCreationDate ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else if( tc_strcmp( pProjectStage, BIDDING ) == 0 )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tProjectRev, AP4_PROJECT_STATUS_CODE, BIDDING ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else if( tc_strcmp( pProjectStage, PROJECT ) == 0 )
		{			
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tProjectRev, AP4_PROJECT_STATUS_CODE, ACTIVE_PROJECT ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;			

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tProjectRev, AP4_PROJECT_CREATED_BY, pPersonName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( *tProjectRev, AP4_PROJECT_CREATION_DATE, dCreationDate ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			
			//Set local project value to default value i.e. 0 
			DNVGL_TRACE_CALL ( iStatus = AOM_set_value_double ( *tProjectRev , AP4_LOCAL_PROJECT_VALUE , 0 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS
		}

		//Set the project start date as current date.
		char* cpCurrentDate = NULL;
		DNVGL_TRACE_CALL( iStatus = ITK_ask_default_date_format	( &cpCurrentDate ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		logical lIsValid = false;
		date_t dCurrentDate = NULLDATE;
		DNVGL_TRACE_CALL( iStatus = DATE_string_to_date_t( cpCurrentDate, &lIsValid, &dCurrentDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		struct timeb timebuffer ;
		ftime( &timebuffer ) ;

		time_t tt = timebuffer.time ;
		struct tm *ptm = localtime( &tt ) ;
		
		dCurrentDate.hour = ptm -> tm_hour = 8;
		dCurrentDate.minute = ptm -> tm_min = 0 ;
		dCurrentDate.second = ptm -> tm_sec = 0 ;

		if( lIsValid )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( *tProjectRev, AP4_START_DATE, dCurrentDate ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			date_t dEndDate = NULLDATE;
			DNVGL_TRACE_CALL( iStatus = dnvg_add_days_to_date( dCurrentDate, 7, &dEndDate ) );

	       struct timeb timebuffer ;
		   ftime( &timebuffer ) ;

		   time_t tt = timebuffer.time ;
		   struct tm *ptm = localtime( &tt ) ;
		
		   dEndDate.hour = ptm -> tm_hour = 17;
		   dEndDate.minute = ptm -> tm_min = 0 ;
		   dEndDate.second = ptm -> tm_sec = 0 ;

			if( !DATE_IS_NULL( dEndDate ) )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( *tProjectRev, AP4_ESTIMATED_END_DATE, dEndDate ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}

		//Set default currency code on project revision.
		tag_t tPerson = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = SA_ask_user_person( userTag, &tPerson ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* cpCurrLegalEntityCode = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tPerson, AP4_CURR_CODE_LEGAL_ENTITY, &cpCurrLegalEntityCode ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iLovCount = 0;		
		DNVGL_TRACE_CALL( iStatus = LOV_find( AP4_CURRENCYCODES_LOV, &iLovCount, &tLOVs ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iValueCount = 0;		
		DNVGL_TRACE_CALL( iStatus = LOV_ask_values_string( tLOVs[0], &iValueCount, &cpLovValues ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		logical lLovValueFound = false;
		for( int i = 0; i < iValueCount; i++ )
		{
			if( tc_strcmp( cpCurrLegalEntityCode, cpLovValues[i] ) == 0 )
			{
				lLovValueFound = true;
				break;
			}
		}

		if( lLovValueFound )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tProjectRev, AP4_CURRENCY_CODE, cpCurrLegalEntityCode ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tProjectRev, AP4_CURRENCY_CODE, NOK ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_save( *tProjectRev ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( !lIsSaveAsOperation )
		{		
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tProjectRev, 0 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tLOVs );
	DNVGL_MEM_FREE( cpLovValues );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


int  dnvgl_copy_participants(tag_t tProjectRev,tag_t tBasedOnProjectRevTag)
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
    char* cpParticipantType[] = {AP4_CUSTOMER,AP4_DISCIPLINELEAD,AP4_DOCUMENTCONTROLLER,AP4_INTERNALVERIFIER,AP4_PROJECTCONTROLLER,AP4_PROJECTTEAMMEMBER,AP4_SUBCONTRACTOR,AP4_SURVEYOR };

	try
	{  
		//looping for the participant Types
		for(int i=0; i<8; i++)
		{
			tag_t   tParticipantType = NULLTAG;
			int	  iParticipantCount   = 0;
			tag_t*  tParticipantlist    = {NULLTAG} ;  

			DNVGL_TRACE_CALL( iStatus = EPM_get_participanttype( cpParticipantType[i], &tParticipantType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL ( iStatus = ITEM_rev_ask_participants( tBasedOnProjectRevTag, tParticipantType, &iParticipantCount, &tParticipantlist ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

		  if(iParticipantCount >0)
		  { 
			  DNVGL_TRACE_CALL ( iStatus = ITEM_rev_set_participants(tProjectRev,iParticipantCount,tParticipantlist) );
			  DNVGL_LOG_ERROR_AND_THROW_STATUS;
		  }
		}
		 
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_postaction_on_iman_save_of_ap4_project_revision_to_copy_project.cxx
* \par  Description :
This function updates the msa and tsa rate of the project based on the selected service code.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   tProjectRev    Project revision
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int update_msa_tsa_attribute( tag_t* tProjectRev )
{
	int iStatus = ITK_ok;
	char** cpTsaRates = NULL;
	try
	{
		DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tProjectRev, 1 ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		char* cpServiceCode = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tProjectRev, AP4_SERVICE_CODE, &cpServiceCode ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double dMsaRate;
		DNVGL_TRACE_CALL( iStatus = PREF_ask_double_value( AP4_MSARATE_SERVICECODE, 0, &dMsaRate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		int iCount = 0;
		DNVGL_TRACE_CALL( iStatus = PREF_ask_char_values( AP4_TSARATE_SERVICECODE, &iCount, &cpTsaRates ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double dTsaRate;
		for( int i=0; i<iCount; i++ )
		{
			std::vector<std::string> vResult;
			dnvgl_split( cpTsaRates[i], '|', vResult );
			if( vResult.size() == 2 && tc_strcmp( vResult[0].c_str(), cpServiceCode ) == 0 )
			{
				dTsaRate = stod( vResult[1] );
				break;
			}
		}

		double dMsaTsaRate = dMsaRate + dTsaRate;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_double( *tProjectRev, AP4_MSA_TSA_RATE, dMsaTsaRate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( *tProjectRev ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tProjectRev, 0 ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( cpTsaRates );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}