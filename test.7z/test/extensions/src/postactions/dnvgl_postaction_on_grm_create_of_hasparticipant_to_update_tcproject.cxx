/**
* \file dnvgl_postaction_on_grm_create_of_hasparticipant_to_update_tcproject.cpp.cxx
* \ingroup libAP4_dnvgl_extensions
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_ProjectStructRelation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 30-May-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_extensions.h"


/**
* \file dnvgl_ap4_project_struct_relation_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_postaction_on_grm_create_of_hasparticipant_to_update_tcproject_execute(va_list localArgs)
{
	int             iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tPrimaryObj		= NULLTAG;
		tag_t       tSecondayObj	= NULLTAG;
		tag_t       tRelationType	= NULLTAG;
		tag_t       tUserData    	= NULLTAG;
		tag_t*      tnewRelation	= NULLTAG;
		tag_t		tAssignee		= NULLTAG;
		tag_t       tUser			= NULLTAG;
		logical     lpPrimaryObj    = false;
		logical     lpSecondaryObj  = false;
		logical     lpRelationType  = false;
		logical     lpUserDataObj  = false;
		logical     lpRelationObj  = false;

		tPrimaryObj   = va_arg(localArgs, tag_t);
		tSecondayObj  = va_arg(localArgs, tag_t); 
		tRelationType = va_arg(localArgs, tag_t);
		tUserData     = va_arg(localArgs, tag_t);
		tnewRelation  = va_arg(localArgs, tag_t*);

		if( tPrimaryObj != NULLTAG && tSecondayObj != NULLTAG && tRelationType != NULLTAG )
		{
			iStatus = POM_is_tag_valid( tPrimaryObj,     &lpPrimaryObj   );
			iStatus = POM_is_tag_valid( tSecondayObj,    &lpSecondaryObj );
			iStatus = POM_is_tag_valid( tRelationType,   &lpRelationType );
			iStatus = POM_is_tag_valid( tUserData,       &lpUserDataObj  );
			iStatus = POM_is_tag_valid( tnewRelation[0], &lpRelationObj  );

			if( lpPrimaryObj && lpSecondaryObj && lpRelationType )
			{
				tag_t tPrimaryObjItem = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tPrimaryObj, &tPrimaryObjItem ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t tTcProjectTag = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = dnvgl_get_tcproject( tPrimaryObjItem, &tTcProjectTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( tTcProjectTag != NULLTAG )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tSecondayObj, ASSIGNEE, &tAssignee ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = dnvgl_add_user_to_tcproject( tTcProjectTag, tAssignee, false ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}