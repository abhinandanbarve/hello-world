
/**
* \file dnvgl_postaction_on_iman_save_of_scheduletask_to_attach_workflow.cxx
**/
#include "dnvgl_extensions.h"

/**
* \file dnvgl_postaction_on_iman_save_of_scheduletask_to_attach_workflow.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_postaction_on_iman_save_of_scheduletask_to_attach_workflow_execute( va_list localArgs )
{
	int             iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{		
		tag_t tScheduleTask	= NULLTAG;		
		tScheduleTask = va_arg( localArgs, tag_t );

		if( tScheduleTask != NULLTAG )
		{
			char* cpScheduleTaskType = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tScheduleTask, AP4_SCHEDULE_TASK_TYPE, &cpScheduleTaskType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tc_strcmp( cpScheduleTaskType, SURVEYOR_TASK ) == 0 )
			{
				tag_t tWorkflowTemplate = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tScheduleTask, WORKFLOW_TEMPLATE, &tWorkflowTemplate ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Set the workflow template on the schedule task only if its not set.
				if( tWorkflowTemplate == NULLTAG )
				{
					tag_t tProcessTemplate = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = EPM_find_process_template( SEND_TO_SURVEYOR, &tProcessTemplate ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					

					if( tProcessTemplate != NULLTAG )
					{
						tag_t tSchedule = NULLTAG;
						int numTasksUpdated = 0 ;
						tag_t *updatedTasks = NULL;
						char *pcUID = "";

						DNVGL_TRACE_CALL( ITK__convert_tag_to_uid (tProcessTemplate,&pcUID));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					    ObjectUpdateContainer_t updateAttributes;						
						updateAttributes.object = tScheduleTask;
						updateAttributes.updatesSize = 2;
						
						updateAttributes.updates[0].attrName = "workflow_trigger_type";
						updateAttributes.updates[0].attrType = 4;
						updateAttributes.updates[0].attrValue = "2";

						updateAttributes.updates[1].attrName = "workflow_template";
						updateAttributes.updates[1].attrValue = pcUID;
						updateAttributes.updates[1].attrType = 8;

						DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tScheduleTask, "schedule_tag", &tSchedule ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;


						DNVGL_TRACE_CALL( iStatus = AOM_refresh( tSchedule, true ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
							DNVGL_TRACE_CALL( iStatus = AOM_refresh( tScheduleTask, true ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = RES_checkout2( tSchedule, "SCHMGT_update_tasks_non_interactive", NULL, NULL, RES_EXCLUSIVE_RESERVE ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS; 

					    DNVGL_TRACE_CALL( iStatus = SCHMGT_update_tasks_non_interactive( tSchedule, 1, &updateAttributes, &numTasksUpdated, &updatedTasks ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
						if (numTasksUpdated>0 && updatedTasks != NULL)
						{
							DNVGL_TRACE_CALL( iStatus = AOM_save( tSchedule ) );
					     	DNVGL_LOG_ERROR_AND_THROW_STATUS;
							DNVGL_TRACE_CALL( iStatus = AOM_save( tScheduleTask ) );
					     	DNVGL_LOG_ERROR_AND_THROW_STATUS;
							DNVGL_MEM_FREE (updatedTasks);
						}
						DNVGL_TRACE_CALL( iStatus = RES_checkin( tSchedule ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}
			}
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
