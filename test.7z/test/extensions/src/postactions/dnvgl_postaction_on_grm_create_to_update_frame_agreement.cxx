/**
* \file dnvgl_postaction_on_grm_create_to_update_frame_agreement.cpp.cxx
* \ingroup libAP4_dnvgl_extensions
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_ChildActivity and Ap4_FrameAgreementsRelation relation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Gouthami M
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 30-May-2016   Gouthami M	          Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_extensions.h"

/**
* \file dnvgl_postaction_on_grm_create_to_update_frame_agreement.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_postaction_on_grm_create_to_update_frame_agreement(va_list localArgs)
{
	int         iStatus							= ITK_ok;
	char*       cpPrimaryObjType				= NULL;
	char*       cpSecondayObjType				= NULL;
	tag_t	    tSecondayObjRev					= NULLTAG;
	tag_t*		tpSecondaryFrameAgreeRev		= NULLTAG;
	tag_t*		tpPrimaryFrameAgreeRev			= NULLTAG;
	tag_t*		tpSecondaryChildActivityProj	= NULLTAG;
	tag_t		tSecondaryChildActivityRev		= NULLTAG;
	tag_t*		tpSecondaryChildFrameAgreeRev	= NULLTAG;
	tag_t		tFrameRelationType				= NULLTAG;
	logical     lIsMainProject;
	int			iPrimayFrameAgreeCnt			=0;
	int			iSecndryFrameAgreeCnt			=0;
	int			iChildActivityCnt				=0;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tPrimaryObj					= NULLTAG;
		tag_t       tSecondayObj				= NULLTAG;
		tag_t       tRelation					= NULLTAG;
		
		tPrimaryObj   = va_arg(localArgs, tag_t);
		tSecondayObj  = va_arg(localArgs, tag_t); 
		tRelation	  = va_arg(localArgs, tag_t);

		if( tPrimaryObj != NULLTAG && tSecondayObj != NULLTAG )
		{
			
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tPrimaryObj, OBJECT_TYPE, &cpPrimaryObjType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSecondayObj, OBJECT_TYPE, &cpSecondayObjType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	    DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_FRAMEAGREEMENTSRELATION, &tFrameRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//check for primary object AP4_ProjectRevision
		if( tc_strcmp( cpPrimaryObjType, AP4_PROJECT_REVISION ) == 0 )
		{
				//check for secondary object AP4_PROJECT
				if( tc_strcmp( cpSecondayObjType, AP4_PROJECT ) == 0 )
				{
					//Get Latest revision from secondaryobject AP4_project
					DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tSecondayObj, &tSecondayObjRev ) );
					DNVGL_LOG_ERROR_AND_RETURN;

					//Get AP4_FrameAgreeRevision from secondary Ap4_project_revision using AP4_FRAMEAGREEMENTSRELATION
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tSecondayObjRev, AP4_FRAMEAGREEMENTSRELATION, &iSecndryFrameAgreeCnt, &tpSecondaryFrameAgreeRev ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					//Get AP4_FrameAgreeRevision from primary Ap4_project_revision using AP4_FRAMEAGREEMENTSRELATION
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tPrimaryObj, AP4_FRAMEAGREEMENTSRELATION, &iPrimayFrameAgreeCnt, &tpPrimaryFrameAgreeRev ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( tpPrimaryFrameAgreeRev != NULLTAG && iPrimayFrameAgreeCnt > 0 )
					{
						if( tpSecondaryFrameAgreeRev != NULLTAG && iSecndryFrameAgreeCnt > 0 )
						{
							//check for Primary & Secondary FrameAgreeRevisions are different
							if( tpSecondaryFrameAgreeRev[0] != tpPrimaryFrameAgreeRev[0] )
							{
								tag_t		tFrameRelation		= NULLTAG;

								DNVGL_TRACE_CALL( iStatus = GRM_find_relation( tSecondayObjRev, tpSecondaryFrameAgreeRev[0], tFrameRelationType, &tFrameRelation ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
						
								//Delete the relation
								DNVGL_TRACE_CALL( iStatus = GRM_delete_relation( tFrameRelation ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								//copy frame agreements from primary to secondary project
								DNVGL_TRACE_CALL( iStatus = dnvgl_copy_frame_agreements_to_project( tSecondayObjRev, tpPrimaryFrameAgreeRev[0], tFrameRelationType ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}
						}
						else
						{
							//copy frame agreements from primary to secondary project
							DNVGL_TRACE_CALL( iStatus = dnvgl_copy_frame_agreements_to_project( tSecondayObjRev, tpPrimaryFrameAgreeRev[0], tFrameRelationType ) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;
						}

					}
				 }
				//check for secondary object AP4_FRAMEAGREE_REVISION
				else if( tc_strcmp( cpSecondayObjType, AP4_FRAMEAGREE_REVISION ) == 0 )
				 {
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_logical( tPrimaryObj, AP4_IS_MAIN_PROJECCT , &lIsMainProject ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					
					//Check for primary object is a Main project
					if (lIsMainProject)
					{
						//Get child projects from the main project using AP4_CHILDACTIVITYRELATION
						DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tPrimaryObj, AP4_CHILDACTIVITYRELATION, &iChildActivityCnt, &tpSecondaryChildActivityProj ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( tpSecondaryChildActivityProj != NULLTAG && iChildActivityCnt > 0 )
						{ 
							//Loop to check for child projects FrameAgreements
							for ( int i = 0; i < iChildActivityCnt; i++)
							{
								//Get Latest revision from secondaryobject AP4_project
								DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tpSecondaryChildActivityProj[i], &tSecondaryChildActivityRev ) );
								DNVGL_LOG_ERROR_AND_RETURN;

								//Get AP4_FrameAgreeRevision from secondary Ap4_project_revision using AP4_FRAMEAGREEMENTSRELATION
								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tSecondaryChildActivityRev, AP4_FRAMEAGREEMENTSRELATION, &iSecndryFrameAgreeCnt, &tpSecondaryChildFrameAgreeRev ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if( tpSecondaryChildFrameAgreeRev != NULLTAG && iSecndryFrameAgreeCnt > 0 )
						    {
							//check for Primary & Secondary FrameAgreeRevisions are different
							if( tpSecondaryChildFrameAgreeRev[0] != tSecondayObj )
						    {
								tag_t		tFrameRelation		= NULLTAG;

								DNVGL_TRACE_CALL( iStatus = GRM_find_relation( tSecondaryChildActivityRev, tpSecondaryChildFrameAgreeRev[0], tFrameRelationType, &tFrameRelation ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
								
								//Delete the relation
								DNVGL_TRACE_CALL( iStatus = GRM_delete_relation( tFrameRelation ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								//copy frame agreements from primary to secondary project
								DNVGL_TRACE_CALL( iStatus = dnvgl_copy_frame_agreements_to_project( tSecondaryChildActivityRev, tSecondayObj, tFrameRelationType ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							 }
							}
						  }
						}
					}
				 }
		    }
	    }
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE(cpSecondayObjType);
	DNVGL_MEM_FREE(cpPrimaryObjType);
	DNVGL_MEM_FREE(tpSecondaryFrameAgreeRev);
	DNVGL_MEM_FREE(tpSecondaryChildActivityProj);
	DNVGL_MEM_FREE(tpSecondaryChildFrameAgreeRev);

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

//copy frame agreements from primary to secondary project
int dnvgl_copy_frame_agreements_to_project( tag_t	 tSecondayObjRev, tag_t tPrimaryFrameAgreeRev, tag_t  tFrameRelationType )
{
	int         iStatus				= ITK_ok;
	logical		lIslocked			= false;
	tag_t		tNewFrameRelation	= NULLTAG;

	DNVGL_TRACE_ENTER();
	
	try
	{
		//Check if object is already locked	
		  DNVGL_TRACE_CALL( iStatus = POM_modifiable( tSecondayObjRev, &lIslocked ) );
		  DNVGL_LOG_ERROR_AND_THROW_STATUS;

		   if (!lIslocked)
		   {
			// Lock the secondary object
			DNVGL_TRACE_CALL (  iStatus = AOM_refresh( tSecondayObjRev, 1 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		   }

			DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tSecondayObjRev, tPrimaryFrameAgreeRev, tFrameRelationType, NULLTAG, &tNewFrameRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Save relation		
			DNVGL_TRACE_CALL(iStatus = GRM_save_relation( tNewFrameRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// refresh the relation
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tNewFrameRelation, false ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// Save the secondary object
			DNVGL_TRACE_CALL( iStatus = AOM_save( tSecondayObjRev ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if (!lIslocked)
			{
			// Unlock the object
			DNVGL_TRACE_CALL ( iStatus = AOM_refresh( tSecondayObjRev, 0 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		    }

	 }
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}