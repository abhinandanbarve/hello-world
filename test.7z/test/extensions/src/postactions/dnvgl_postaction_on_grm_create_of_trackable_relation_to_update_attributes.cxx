/**
* \file dnvgl_postaction_on_grm_create_of_trackable_relation_to_update_attributes.cxx
* \ingroup libAP4_dnvgl_extensions
* \verbatim
\par Description:
This File  contains the functions which are called on postaction of grm_create of trackable relation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 15-Nov-2016   Nikhilesh Khatra	  Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_extensions.h"

/**
* \file dnvgl_postaction_on_grm_create_of_trackable_relation_to_update_attributes.cxx
* \par  Description :
This function is called on postaction of grm_create of trackable relation
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   localArgs    argument list of grm_create
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 15-Nov-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

int dnvgl_postaction_on_grm_create_of_trackable_relation_to_update_attributes_execute(va_list localArgs)
{
	int		iStatus					= ITK_ok;

	int		iTargetCount			= 0;
	char	*cpObjectType			= NULL;
	char	*cpApsId     			= NULL;
	char	*cpApsTitle				= NULL;
	char	*cpCurrencyCode			= NULL;
	char	*cpClientName			= NULL;
	char	*cpCostCenter			= NULL;
	char	*cpDatasetName			= NULL;
	char*	cpCheckedClientName		= NULL;
	char*	cpCheckedApsTitle		= NULL;
	char*   cpCheckedExcelFilePath	= NULL;
	double  dMsaTsaRate				= 0;
	double  dLocalProjValue			= 0;
	char*	cpServiceCode			= NULL;
	char*	cpFrameAgreementName	= NULL;
	char*	cpFrameAgreementNumber	= NULL;
	char	*cpDateFormat			= NULL;
	char	*cpEstimatedStartDate	= NULL;
	char	*cpEstimatedEndDate		= NULL;
	date_t	dtEstimatedStartDate	= NULLDATE;
	date_t	dtEstimatedEndDate		= NULLDATE;

	tag_t   tRootTaskTag			= NULLTAG  ;
	tag_t	*tpTargetTags			= NULL;
	tag_t   tDocRevTag				= NULLTAG;
	boolean bIsTempFolderCreated	= false ;
	std::string strTempFolderPath	= "";
	char *      reference_name		= NULL;
	tag_t	tStructRelTag			=  NULLTAG;
	tag_t*	tpRelatedTags			=  {NULLTAG} ;
	int		iObjectCount			= 0;
	char *  cpOriginalFileName		= NULL;
	char * 	cpLoggedInUserName		= NULL ;
	tag_t 	tLoggedInUserTag		= NULLTAG  ;
	tag_t   tOwnerTag				= NULLTAG;
	char* cpCustomerDNVGLID			= NULL;
	OfficeInterop::ExcelCppService *excelCppObj	= NULL	;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tPrimaryObj			= NULLTAG;
		tag_t       tSecondayObj		= NULLTAG;
		tag_t       tRelationType		= NULLTAG;
		tag_t       tUserData			= NULLTAG;
		tag_t*		tRelation			= NULLTAG;

		char*		cpUserName			= NULL;
		tag_t		tUserTag			= NULL;

		tPrimaryObj		= va_arg(localArgs, tag_t);
		tSecondayObj	= va_arg(localArgs, tag_t);
		tRelationType	= va_arg(localArgs, tag_t);
		tUserData		= va_arg(localArgs, tag_t);
		tRelation		= va_arg(localArgs, tag_t*);		

		DNVGL_TRACE_CALL( iStatus = POM_get_user( &cpUserName, &tUserTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tRelation, AP4_CREATED_BY, cpUserName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* dCurrentDate = NULL;
		DNVGL_TRACE_CALL( iStatus = ITK_ask_default_date_format	( &dCurrentDate ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t dCurrDate = NULLDATE;
		logical lIsValid = false;
		DNVGL_TRACE_CALL( iStatus = DATE_string_to_date_t( dCurrentDate, &lIsValid, &dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( *tRelation, AP4_RELATION_CREATION_DATE, dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Code for updating procalc : starts
		tag_t	tFolderTag	  = tPrimaryObj;
		tag_t	tDocTag	= tSecondayObj;
		tag_t tPrimaryTypeTag = NULLTAG; 
		tag_t tSecondaryTypeTag = NULLTAG; 
		bool bIsInstance      = false;
		bool bIsWorkspaceObj  = false;
		tag_t tInputObjectType= NULLTAG;
		tag_t tSecObjectType= NULLTAG;

		DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( AP4_PROJECT_FOLDER , &tPrimaryTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( WORKSPACE_OBJECT , &tSecondaryTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_class_of_instance( tDocTag, &tSecObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_is_descendant( tSecondaryTypeTag, tSecObjectType, &bIsWorkspaceObj) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( bIsWorkspaceObj && tFolderTag != NULLTAG &&  tDocTag != NULLTAG && tPrimaryTypeTag != NULLTAG )
		{
			DNVGL_TRACE_CALL( iStatus = POM_class_of_instance(tFolderTag, &tInputObjectType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = POM_is_descendant( tPrimaryTypeTag, tInputObjectType, &bIsInstance) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tDocTag, OBJECT_TYPE, &cpObjectType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		if(bIsInstance && cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_CTR_DOCUMENT ) == 0 )
		{
			DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tDocTag, &tDocRevTag ) );
			DNVGL_LOG_ERROR_AND_RETURN;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tDocRevTag, OWNING_USER, &tOwnerTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = POM_get_user( &cpLoggedInUserName , &tLoggedInUserTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if(tOwnerTag == tLoggedInUserTag)
			{
				//Get excel dataset tag : starts
				tag_t tExcelDatasetTag = NULLTAG ;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION , &tStructRelTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tDocRevTag,tStructRelTag,&iObjectCount,&tpRelatedTags ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for ( int index = 0; index < iObjectCount; index++ )
				{						
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpObjectType != NULL && tc_strcmp( cpObjectType, MSEXCELX_DATASET ) == 0 )
					{
						tExcelDatasetTag = tpRelatedTags[index];
						break;
					}	
				}
				DNVGL_MEM_FREE(tpRelatedTags);
				//Get excel dataset tag : ends

				if( tExcelDatasetTag != NULLTAG )					
				{
					//create temp folder : starts
					const char* cpTempPath;
					cpTempPath = getenv (TEMP_ENV_VAR);

					strTempFolderPath= cpTempPath;
					strTempFolderPath.append("\\");
					std::string strDirName;
					char * timeStamp;
					DNVGL_current_get_time_stamp(DATE_FORMAT_STR_FOOTER, &timeStamp);
					strDirName = timeStamp;
					strTempFolderPath.append(strDirName);

					DNVGL_TRACE_CALL( iStatus = _mkdir(strTempFolderPath.c_str()) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					bIsTempFolderCreated = true ;

					//create temp folder : ends

					//Export the attached excel : starts

					AE_reference_type_t       reference_type;
					tag_t      referenced_object ;

					DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tExcelDatasetTag , 0 , &reference_name , &reference_type , &referenced_object ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(referenced_object, ORIGINAL_FILE_NAME, &cpOriginalFileName) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					std::string strExcelFilePath = strTempFolderPath;
					strExcelFilePath.append("\\");
					strExcelFilePath.append(cpOriginalFileName);  

					DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tExcelDatasetTag , reference_name , strExcelFilePath.c_str() ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					//Export the attached excel : ends

					tag_t	tProjectRevTag		=  NULLTAG;
					DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tFolderTag , AP4_PROJECT_BACKPOINTER , &tProjectRevTag ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					//Get project attribute : starts
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRevTag , ITEM_ID, &cpApsId) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRevTag , OBJECT_NAME , &cpApsTitle) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRevTag , AP4_CURRENCY_CODE , &cpCurrencyCode) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRevTag , AP4_COST_CENTER , &cpCostCenter) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tProjectRevTag , AP4_MSA_TSA_RATE , &dMsaTsaRate) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRevTag , AP4_SERVICE_CODE , &cpServiceCode) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRevTag , AP4_FRAMEAGREEMENTNAME , &cpFrameAgreementName) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRevTag , AP4_FRAMEAGREEMENTNUMBER, &cpFrameAgreementNumber) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRevTag , AP4_DNV_CUSTOMER_ID, &cpCustomerDNVGLID) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = ITK_ask_default_date_format( &cpDateFormat ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				
						
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( tProjectRevTag , AP4_START_DATE, &dtEstimatedStartDate) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL( iStatus = DATE_date_to_string( dtEstimatedStartDate, DATE_FORMAT_STR_FOOTER, &cpEstimatedStartDate ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					
						
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( tProjectRevTag , AP4_ESTIMATED_END_DATE , &dtEstimatedEndDate) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL( iStatus = DATE_date_to_string( dtEstimatedEndDate, DATE_FORMAT_STR_FOOTER, &cpEstimatedEndDate) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tProjectRevTag , AP4_LOCAL_PROJECT_VALUE , &dLocalProjValue) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					
					//Get project attribute : ends

					//Get customer attribute : starts
					tag_t tCustomerTag = NULLTAG ;
					DNVGL_TRACE_CALL( iStatus =  GRM_find_relation_type( AP4_PROJECT_CUSTOMER ,&tStructRelTag ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tProjectRevTag,tStructRelTag,&iObjectCount,&tpRelatedTags ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					for ( int index = 0; index < iObjectCount; index++ )
					{						
						DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_MDMCUSTOMER ) == 0 )
						{
							tCustomerTag = tpRelatedTags[index];
							break;
						}	
					}
					DNVGL_MEM_FREE(tpRelatedTags);
					if(tCustomerTag!= NULLTAG)
					{
						DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCustomerTag , OBJECT_NAME , &cpClientName) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}

					//Get customer attribute : ends
					// excel update : starts
					//  path encoding modified for the file name when the it contains German language characters 
				
					NLS_internal_to_external(strExcelFilePath.c_str(), &cpCheckedExcelFilePath);
					
					DNVGL_TRACE_CALL( iStatus = dnvgl_create_excelinterop_object( excelCppObj,cpCheckedExcelFilePath ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					int iUpdate = excelCppObj->ProcalcUpdateCellWSharedString("Set-Up","F6",cpApsId);

					if( iUpdate == 0 )
					{
						NLS_internal_to_external( cpApsTitle , &cpCheckedApsTitle );
						excelCppObj->UpdateCellWSharedString( "Set-Up", "B4", cpCheckedApsTitle );
						if( cpCurrencyCode != NULL && ! ( tc_strcmp( cpCurrencyCode, "" ) == 0 ) )
						{
							excelCppObj->UpdateCellWSharedString("Set-Up","B7",cpCurrencyCode);
						}
						if( cpClientName != NULL && ! ( tc_strcmp( cpClientName, "" ) == 0 ) )
						{
							NLS_internal_to_external( cpClientName , &cpCheckedClientName );
							excelCppObj->UpdateCellWSharedString("Set-Up","B3",cpCheckedClientName);
						}
						//Changes for updating Q93 cell in procalc excel with cost center number
						if( cpCostCenter != NULL && ! ( tc_strcmp( cpCostCenter, "" ) == 0 ) )
						{
							excelCppObj->UnprotectSheet("Set-Up");
							excelCppObj->UpdateCellWSharedString("Set-Up","Q93",cpCostCenter);
							excelCppObj->ProtectSheet("Set-Up");
						}
						if(dMsaTsaRate != 0)
						{
							// required to add precision and percentage sign before adding to ProCalc Document because B6 field requires Percentage of TSA MSA feild
							stringstream ssMsaTsaRate;
							dMsaTsaRate = dMsaTsaRate * 10000;
							ssMsaTsaRate<<dMsaTsaRate;
							string strMsaTsaRate = ssMsaTsaRate.str();
							if(strMsaTsaRate.c_str() != NULL && !(tc_strcmp( strMsaTsaRate.c_str(), "" ) == 0 ) )
							{
								excelCppObj->UnprotectSheet("Set-Up");
								excelCppObj->UpdateCellWSharedString("Set-Up","AA93",strMsaTsaRate.c_str());
								excelCppObj->ProtectSheet("Set-Up");
							}
						}
						if( cpServiceCode != NULL && ! ( tc_strcmp( cpServiceCode, "" ) == 0 ) )
						{
							excelCppObj->UnprotectSheet("Set-Up");
							excelCppObj->UpdateCellWSharedString("Set-Up","R93",cpServiceCode);
							excelCppObj->ProtectSheet("Set-Up");
						}
						if( cpFrameAgreementName != NULL && ! ( tc_strcmp( cpFrameAgreementName, "" ) == 0 ) )
						{
							excelCppObj->UnprotectSheet("Set-Up");
							excelCppObj->UpdateCellWSharedString("Set-Up","V93",cpFrameAgreementName);
							excelCppObj->ProtectSheet("Set-Up");
						}
						if( cpFrameAgreementNumber != NULL && ! ( tc_strcmp( cpFrameAgreementNumber, "" ) == 0 ) )
						{
							excelCppObj->UnprotectSheet("Set-Up");
							excelCppObj->UpdateCellWSharedString("Set-Up","U93",cpFrameAgreementNumber);
							excelCppObj->ProtectSheet("Set-Up");
						}

						if( cpEstimatedStartDate!= NULL && ! ( tc_strcmp( cpEstimatedStartDate, "" ) == 0 ) )
						{
							excelCppObj->UnprotectSheet("Set-Up");
							excelCppObj->UpdateCellWSharedString("Set-Up","W93",cpEstimatedStartDate);
							excelCppObj->ProtectSheet("Set-Up");
						}
						if( cpEstimatedEndDate!= NULL && ! ( tc_strcmp( cpEstimatedEndDate, "" ) == 0 ) )
						{
							excelCppObj->UnprotectSheet("Set-Up");
							excelCppObj->UpdateCellWSharedString("Set-Up","X93",cpEstimatedEndDate);
							excelCppObj->ProtectSheet("Set-Up");
						}
						if( cpCustomerDNVGLID!= NULL && ! ( tc_strcmp( cpCustomerDNVGLID, "" ) == 0 ) )
						{
							excelCppObj->UnprotectSheet("Set-Up");
							excelCppObj->UpdateCellWSharedString("Set-Up","Z93",cpCustomerDNVGLID);
							excelCppObj->ProtectSheet("Set-Up");
						}
						if( dLocalProjValue != 0   )
						{
							string strLocalProjValue = to_string(dLocalProjValue);
							if( strLocalProjValue.c_str() != NULL && ! ( tc_strcmp( strLocalProjValue.c_str(), "" ) == 0 ) )
							{
								excelCppObj->UnprotectSheet("Set-Up");
								excelCppObj->UpdateCellWSharedString("Set-Up","Y93", strLocalProjValue.c_str() );
								excelCppObj->ProtectSheet("Set-Up");
							}
						}
						// excel update : starts
						// Remove old excel reference : strats
						DNVGL_TRACE_CALL( iStatus = AOM_lock( tExcelDatasetTag) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus =  AE_remove_dataset_named_ref_by_tag2 ( tExcelDatasetTag,reference_name,referenced_object ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_save( tExcelDatasetTag ) ) ;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_refresh( tExcelDatasetTag, false ) ) ;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
						// Remove old excel reference : ends

						tag_t tDatasetTypeTag = NULLTAG ;
						DNVGL_TRACE_CALL( iStatus = AE_find_datasettype2( MSEXCELX_DATASET , &tDatasetTypeTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						char** cpRefList = NULL;
						char* cpRefName = NULL;
						int    iRefCount = 0;
						DNVGL_TRACE_CALL( iStatus = AE_ask_datasettype_refs (tDatasetTypeTag, &iRefCount, &cpRefList) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
						//Setting reference name for dataset creation e.g. setting "word" for docx type fo file
						cpRefName = cpRefList[0];
						MEM_free (cpRefList);

						// attach updated excel reference : starts
						DNVGL_TRACE_CALL( iStatus = AOM_lock( tExcelDatasetTag) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AE_import_named_ref(	tExcelDatasetTag, // datasetTag
							cpRefName, // referenceName
							strExcelFilePath.c_str(), // osFullPathName
							NULL, // newFileName
							SS_BINARY ) ) ; // fileTypeFlag
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_save( tExcelDatasetTag ) ) ;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_refresh( tExcelDatasetTag, false ) ) ;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						// attach updated excel reference : ends
					}
				}
			}				
		}
		// Code for updating procalc : ends
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE(reference_name);
	DNVGL_MEM_FREE(tpTargetTags);
	DNVGL_MEM_FREE(tpRelatedTags);
	DNVGL_MEM_FREE(cpObjectType);
	DNVGL_MEM_FREE(cpOriginalFileName);
	DNVGL_MEM_FREE(cpApsId);
	DNVGL_MEM_FREE(cpApsTitle);
	DNVGL_MEM_FREE(cpCheckedApsTitle);
	DNVGL_MEM_FREE(cpCheckedClientName);
	DNVGL_MEM_FREE(cpCheckedExcelFilePath);
	DNVGL_MEM_FREE(cpCurrencyCode);
	DNVGL_MEM_FREE(cpClientName);
	DNVGL_MEM_FREE(cpLoggedInUserName);
	DNVGL_MEM_FREE(cpCostCenter);
	free(excelCppObj);

	if(bIsTempFolderCreated){
		std::string strTempFolderDeleteCmd = "" ;

		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );	

	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

