/**
* \file dnvgl_postaction_on_grm_create_of_hasparticipant_to_update_tcproject.cpp.cxx
* \ingroup libAP4_dnvgl_extensions
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_ProjectStructRelation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 30-May-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_extensions.h"

/**
* \file dnvgl_ap4_project_struct_relation_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_preaction_on_iman_delete_of_hasparticipant_to_update_tcproject_execute(va_list localArgs)
{
	int         iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{		
		char*       cpFunctionName	= "AP4_preaction_on_iman_delete_of_hasparticipant_to_update_tcproject_execute";
		char*       cpMsgName		= "update_tcproject";
		char*		cpItemRevType	= NULL;
		tag_t       tPrimaryObj		= NULLTAG;
		tag_t       tSecondayObj	= NULLTAG;
		tag_t       tRelationType	= NULLTAG;
		tag_t		tAssignee		= NULLTAG;
		tag_t       tUser			= NULLTAG;

		DNVGL_TRACE_ENTER();

		tRelationType     = va_arg(localArgs, tag_t);

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tRelationType, PRIMARY_OBJECT, &tPrimaryObj ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tRelationType, SECONDARY_OBJECT, &tSecondayObj ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tSecondayObj, ASSIGNEE, &tAssignee ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tPrimaryObjItem = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tPrimaryObj, &tPrimaryObjItem ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		tag_t tcProject = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = dnvgl_get_tcproject( tPrimaryObjItem, &tcProject ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		DNVGL_TRACE_CALL( iStatus = dnvgl_remove_user_from_tcproject( tcProject, tAssignee ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Now lets upldate .. attribute of project revision
		std::vector<DNVGL_ProjectRevisionParticipant_t> allPctInfos;
		DNVGL_TRACE_CALL( iStatus = get_all_participants(tPrimaryObj, allPctInfos) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::set<tag_t> userSet;
		std::vector<DNVGL_ProjectRevisionParticipant_t>::iterator itr = allPctInfos.begin();
		while(itr != allPctInfos.end())
		{
			tag_t tmpGrpMemberTag = itr->groupMember;
			if(tmpGrpMemberTag != tAssignee) // skipping if we found current group member
			{
				userSet.insert(itr->user);
			}
			itr++;
		}

		std::vector<tag_t> userVector(userSet.begin(), userSet.end()); 
		DNVGL_TRACE_CALL( iStatus = AOM_refresh ( tPrimaryObj, 1 ) );

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tPrimaryObj, AP4_PROJ_MEMBERS, (int) userVector.size(), &userVector[0] ) );
		DNVGL_TRACE_CALL( iStatus = AOM_save( tPrimaryObj ) );
		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tPrimaryObj, 0 ) );

	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
