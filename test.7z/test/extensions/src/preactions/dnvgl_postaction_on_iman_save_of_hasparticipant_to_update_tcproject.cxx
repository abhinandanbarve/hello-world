
/**
* \file dnvgl_preaction_on_iman_save_of_hasparticipant_to_update_tcproject.cxx
**/
#include "dnvgl_extensions.h"

/**
* \file dnvgl_ap4_project_struct_relation_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_postaction_on_iman_save_of_hasparticipant_to_update_tcproject( va_list localArgs )
{
	int iStatus = ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		AM__set_application_bypass( true );
		POM_AM__set_application_bypass( true );

		tag_t tHasParticipantRelTag	= va_arg(localArgs, tag_t);

		tag_t tPrimaryObj = NULLTAG;
		tag_t tSecondayObj = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tHasParticipantRelTag, PRIMARY_OBJECT, &tPrimaryObj ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tHasParticipantRelTag, SECONDARY_OBJECT, &tSecondayObj ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tPrimaryObjItem = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tPrimaryObj, &tPrimaryObjItem ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tTcProjectTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = dnvgl_get_tcproject( tPrimaryObjItem, &tTcProjectTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tTcProjectTag != NULLTAG )
		{
			// Now lets upldate .. attribute of project revision
			std::vector<DNVGL_ProjectRevisionParticipant_t> allPctInfos;
			DNVGL_TRACE_CALL( iStatus = get_all_participants(tPrimaryObj, allPctInfos) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// to update AP4_ProjectRevision member attribute
			std::set<tag_t> userSet;
			std::vector<DNVGL_ProjectRevisionParticipant_t>::iterator itr = allPctInfos.begin();

			std::set<tag_t> membersSet;
			std::set<tag_t> teamAdminsSet;
			std::set<tag_t> privilegdMembersSet;

			while(itr != allPctInfos.end())
			{
				membersSet.insert(itr->groupMember);
				std::string pctType = itr->participantType;
				if(pctType.compare( AP4_PROJECTMANAGER ) == 0 || pctType.compare( AP4_BIDMANAGER ) == 0 )
				{
					teamAdminsSet.insert( itr->user );
				}
				else
				{
					privilegdMembersSet.insert( itr->user );
				}

				// adding user tag in set, to be used for member attribute of project revision
				userSet.insert(itr->user);				
				itr++;
			}

			// TC_Project needs atlease 1 team admin. If we dont find any team admin yet, lets add tc_project owning user at team admin
			tag_t tcProjOwner = NULLTAG;
			tag_t tcProjGroup = NULLTAG;
			AOM_ask_owner(tTcProjectTag, &tcProjOwner);
			AOM_ask_group(tTcProjectTag, &tcProjGroup);

			tag_t* tGrpMember = NULL;
			int iCount = 0;
			SA_find_groupmembers(tcProjOwner, tcProjGroup, &iCount, &tGrpMember);

			if(tGrpMember != NULL)
			{
				membersSet.insert(tGrpMember[0]);
				teamAdminsSet.insert(tcProjOwner);
				// free the memory
			    DNVGL_MEM_FREE(tGrpMember);
			}

			// Now lets update ap4_proj_members attribute of project revision
			std::vector<tag_t> userVector(userSet.begin(), userSet.end());

			logical lWasLockedBefore = false;
			DNVGL_TRACE_CALL( iStatus = POM_modifiable( tPrimaryObj, &lWasLockedBefore ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !lWasLockedBefore )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_refresh ( tPrimaryObj, 1 ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tPrimaryObj, AP4_PROJ_MEMBERS, (int) userVector.size(), &userVector[0] ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = AOM_save( tPrimaryObj ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !lWasLockedBefore )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tPrimaryObj, 0 ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			// Now lets assign new team to TC project
			if(membersSet.size() > 0)
			{
				std::vector<tag_t> members(membersSet.begin(), membersSet.end());
				std::vector<tag_t> teamAdmins(teamAdminsSet.begin(), teamAdminsSet.end());
				std::vector<tag_t> privilegdMembers(privilegdMembersSet.begin(), privilegdMembersSet.end());
				
				DNVGL_TRACE_CALL( iStatus = PROJ_assign_team_members( tTcProjectTag, (int) members.size(), &members[0], (int) teamAdmins.size(), &teamAdmins[0],  (int) privilegdMembers.size(), &privilegdMembers[0]) );
				DNVGL_TRACE_CALL( iStatus = AOM_save( tTcProjectTag ) );
				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tTcProjectTag, 0 ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );

	AM__set_application_bypass( false );
	POM_AM__set_application_bypass( false );

	return iStatus;
}

