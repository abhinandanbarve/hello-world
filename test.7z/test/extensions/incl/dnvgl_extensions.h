/**
* \file dnvgl_extensions.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for all the extensions.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 26-May-2016   Vinay Kudari      Initial Creation
* 19-April-2017 Sakshi Mathur	  Req 911/ticket/47 : Post action on ABA business objects to set project backpointer 
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_EXTENSIONS_H
# define DNVGL_EXTENSIONS_H

#include "dnvgl_schedule_handling.h"
#include "dnvgl_project_handling.h"
#include "dnvgl_tcproject_handling.h"
#include "dnvgl_utils.h"
#include "dnvgl_affinitas_services.h"
#include <openxml/OfficeInterop.h>

#ifdef __cplusplus
extern "C" {
#endif
	/**Pre-Conditions**/
	//Pre condition to validate attributes on technical document revision before saving it.
	DNVGLCOMEXP int dnvgl_precondition_on_iman_save_of_techdoc_revision_to_validate_attributes_execute( va_list localArgs );

	//Extension to check a condition that the address being attached .
	DNVGLCOMEXP int dnvgl_precondition_on_grm_create_of_customer_address_to_project_revision_execute( va_list localArgs );

	//Extension to validate attributes on project revision before saving it.
	DNVGLCOMEXP int dnvgl_precondition_on_iman_save_of_project_revision_to_validate_attributes_execute( va_list localArgs );

	//Extension to validate whether document and surveyor package belong to same project before creating relation.
	DNVGLCOMEXP int dnvgl_precondition_on_grm_create_of_document_to_surveyor_package_folder_execute( va_list localArgs );

	/**Pre-Actions**/
	//Extension to update TC project on deletion of HasParticipant relation.
	DNVGLCOMEXP int dnvgl_preaction_on_iman_delete_of_hasparticipant_to_update_tcproject_execute( va_list localArgs );

	/**Post-Actions**/	
	//Extension to copy project folders, schedule from template project and to create TC project.
	DNVGLCOMEXP int dnvgl_postaction_on_iman_save_of_ap4_project_revision_to_copy_project_execute( va_list localArgs );

	////Extension to copy project folders, schedule from existing project and to create TC project.
	DNVGLCOMEXP int dnvgl_postaction_on_item_deep_copy_of_ap4_project_revision_to_copy_project_execute(va_list localArgs);

	//Extension to update TC project on creation of HasParticipant relation.
	DNVGLCOMEXP int dnvgl_postaction_on_grm_create_of_hasparticipant_to_update_tcproject_execute( va_list localArgs );	

	//Extension to update opportunity in affinitas as soon as it is updated in teamcenter.
	DNVGLCOMEXP int dnvgl_postaction_on_iman_save_of_ap4_project_revision_to_update_in_affinitas_execute( va_list localArgs );

	//Extension to update the custom attributes on creation of all the instances of AP4_TrackableRelation i.e. all the custom relations.
	DNVGLCOMEXP int dnvgl_postaction_on_grm_create_of_trackable_relation_to_update_attributes_execute( va_list localArgs );
	
	//Extension to update the custom attributes on save of all the instances of AP4_TrackableRelation i.e. all the custom relations.
	DNVGLCOMEXP int dnvgl_postaction_on_iman_save_of_trackable_relation_to_update_attributes_execute( va_list localArgs );

	//Extension to attach addresses to project revision when customer is being attached to project revision.
	DNVGLCOMEXP int dnvgl_postaction_on_iman_save_of_project_customer_to_attach_addresses_execute( va_list localArgs );	
	
	//Extension to update TC project on creation of HasParticipant relation.
	DNVGLCOMEXP int dnvgl_postaction_on_iman_save_of_hasparticipant_to_update_tcproject( va_list localArgs );

	//Extension to attach workflow to schedule task on save of schedule task.
	DNVGLCOMEXP int dnvgl_postaction_on_iman_save_of_scheduletask_to_attach_workflow_execute( va_list localArgs );

	//Generic Extension to set project backpointer value
	DNVGLCOMEXP int dnvgl_postaction_on_grm_create_to_set_project_backpointer_execute( va_list localArgs );

	//Generic Extension to update frame agreement
	DNVGLCOMEXP int dnvgl_postaction_on_grm_create_to_update_frame_agreement( va_list localArgs );


	//Common functions to be used within extensions.
	//Function which will call copy project related functions.
	int copy_from_project( tag_t *tProjectRevTag, tag_t *tBasedOnProjectRevTag, logical lIsSaveAsOperation );

	//Copy the schedule from the project revision and attach it to new project revision.
	int copy_and_attach_schedule( tag_t *tProjectRevTag, tag_t *tProjectTemplateRevTag, tag_t* tScheduleTag );

	//Copy the Participant Types from the based on project item.
	int dnvgl_copy_participants(tag_t tProjectRevTag,tag_t tBasedOnProjectRevTag );

	//Update attributes of project revision.
	int update_attributes( tag_t *tProjectRevTag, logical lIsSaveAsOperation );

	//Update msa tsa rate of project revision.
	int update_msa_tsa_attribute( tag_t* tProjectRev );

	//Copy frame agreements from primary to secondary project
	int dnvgl_copy_frame_agreements_to_project( tag_t tSecondayObjRev, tag_t tPrimaryFrameAgreeRev, tag_t tFrameRelationType );


#ifdef __cplusplus
}
#endif

#endif //DNVGL_EXTENSIONS_H