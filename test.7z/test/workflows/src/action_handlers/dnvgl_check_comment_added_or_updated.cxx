/**
* \file dnvgl_check_comment_added_or_updated.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This file will check if any comment under document revision are updated.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Durga D
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 09-Dec-2016   Srushti Hanjage       Initial creation.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

using namespace std;

int dnvgl_check_comment_added_or_updated( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok;
	int		iTargetCount	 = 0		;
	char	*cpObjectType	 = NULL		;

	tag_t   tRootTaskTag     = NULLTAG  ;
	tag_t	*tpTargetTags	 = NULL		;
	tag_t   tTargetObjTag	 = NULLTAG  ;
	tag_t   tRelationType    = NULLTAG	;
	tag_t  *pptSecondaryObjects= NULLTAG;
	tag_t  *pptRelationObjects=NULLTAG	;
	int		iSecondaryCount	 = NULL		;	 
	logical isModified		 = false;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tCurrentTask = msg.task;
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObjTag = tpTargetTags[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_TECH_DOC_REVISION ) == 0 )
			{
				DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tTargetObjTag , AP4_COMMENT_CHAIN_RELATION , AP4_COMMENT_CHAIN, &pptSecondaryObjects, &pptRelationObjects, &iSecondaryCount) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for ( int index = 0; index < iSecondaryCount; index++ )
				{	

					DNVGL_TRACE_CALL( iStatus = dnvgl_check_comment_updated( pptSecondaryObjects[index], isModified ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					// If any comment is modified then result will be true.
					if(isModified)
					{
						break;
					}
				}
			}
		}
		if(isModified)
		{
			DNVGL_TRACE_CALL( iStatus = EPM_set_condition_task_result(tCurrentTask,EPM_RESULT_TRUE ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			DNVGL_TRACE_CALL( iStatus = EPM_set_condition_task_result(tCurrentTask,EPM_RESULT_FALSE ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE( cpObjectType );
	DNVGL_MEM_FREE( tpTargetTags );
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_check_comment_updated( tag_t &tCommentChain, logical &isModified)
{
	int	   iStatus           =  ITK_ok  ;
	char   *cpCommentType	 =	NULL	;
	tag_t  tLastModUser		 =	NULLTAG ;
	tag_t  tCretedUser		 =	NULLTAG ;
	char   *tLastModUserID	 =	NULL	;
	char   *cpCreatedUserID	 =	NULL	;
	int	   iCount			 = NULL		;
	tag_t  *tComments		 = NULLTAG	;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tCommentChain, AP4_COMMENTS, &iCount, &tComments ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iCount; i++)
		{
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tComments[i]  , AP4_COMMENT_TYPE , &cpCommentType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//C- Comment, R- Reply
			if(cpCommentType != NULL && (tc_strcmp( cpCommentType, COMMENT_TYPE_COMMENT ) == 0 ))
			{
				DNVGL_TRACE_CALL( iStatus = AOM_get_value_tag(tComments[i], AP4_LAST_UPDATED_BY, &tLastModUser) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus =AOM_get_value_tag(tComments[i], OWNING_USER, &tCretedUser) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( tLastModUser != NULLTAG )
				{
	
					DNVGL_TRACE_CALL( iStatus = POM_ask_user_id(tLastModUser, &tLastModUserID) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				DNVGL_TRACE_CALL( iStatus = POM_ask_user_id(tCretedUser, &cpCreatedUserID) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( tLastModUserID != NULL && cpCreatedUserID != NULL && strcmp(tLastModUserID,cpCreatedUserID)!=0 )
				{
					// If the modified user and creation user are different then that comment is has been updated.
					isModified = true ;
					break;
				}
			}
		}		
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE( cpCommentType );
	DNVGL_MEM_FREE( tLastModUserID );
	DNVGL_MEM_FREE( cpCreatedUserID );
	DNVGL_MEM_FREE( tComments );
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}