#include "dnvgl_workflows.h"

int dnvgl_create_project_user( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok;
	tag_t	tRootTaskTag     = NULLTAG  ;

	DNVGL_TRACE_ENTER();
	try
	{
		int			iTargetCount					= 0		   ;
		int			iReferenceCount					= 0		   ;
		int			iGrpCount						= 0		   ;
		int 		n_instances						= 0		   ;

		logical		lIncludeInactive				= false	   ;

		char		*cpUserName						= NULL     ;
		char		*cpObjectType					= NULL	   ;
		char		*cpRequestType					= NULL	   ;
		char*		personFirstName					= NULL     ;
		char*		personLastName					= NULL     ;			
		char*		userPassId						= NULL     ;
		char 		*a_name							= NULL	   ;
		char 		a_name1						    = NULL     ;

		tag_t		tVolumeTag						= NULLTAG  ;
		tag_t		tGMTag							= NULLTAG  ;
		tag_t		tUseTag							= NULLTAG  ;
		tag_t  		tUser							= NULLTAG  ;		
		tag_t		*tpTargetTags					= NULLTAG  ;
		tag_t		*tpReferenceTags				= NULLTAG  ;
		tag_t		*tProjectRevTag					= NULL	   ;
		tag_t		tTargetObjTag					= NULLTAG  ;
		tag_t		tReferenceObjTag				= NULLTAG  ;
		tag_t		tProjMgrGroupTag				= NULLTAG  ;
		tag_t		tPersonTag						= NULLTAG  ;
		tag_t		tUserTag						= NULLTAG  ;
		tag_t		tGroupTag						= NULLTAG  ;
		tag_t*		tGrpMemberTags					= NULLTAG  ;
		tag_t		t_relation						= NULLTAG  ;
		tag_t		tProjectScheduleRelationType	= NULLTAG  ;
		tag_t* 		instances						= NULLTAG  ;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_reference_attachment, &iReferenceCount, &tpReferenceTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Get the AP4_ProjectRevision object
		for( int i = 0; i < iReferenceCount; i++ )
		{
			tReferenceObjTag = tpReferenceTags[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tReferenceObjTag, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_PROJECT_REVISION ) == 0 )
			{
				tProjectRevTag = &tReferenceObjTag;
				break;
			}
		}

		for( int i = 0; i < iTargetCount; i++ )
		{
			DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2( tpTargetTags[i], &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_REQUEST_FORM_OBJECT ) == 0 )
			{
				tTargetObjTag = tpTargetTags[i];
			}

			if( tProjectRevTag == NULL && cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_PROJECT_REVISION ) == 0 )
			{
				tProjectRevTag = &tpTargetTags[i];			
			}
		}

		if( tTargetObjTag != NULLTAG && tProjectRevTag != NULLTAG )
		{
			DNVGL_TRACE_CALL( iStatus = SA_find_group( CUSTOMER_GROUP, &tGroupTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, AP4_USER_FIRST_NAME, &personFirstName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, AP4_USER_LAST_NAME, &personLastName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			std::string sPersonFullName = "";
			sPersonFullName.append( personFirstName );
			sPersonFullName.append( "," );
			sPersonFullName.append( personLastName );


			DNVGL_TRACE_CALL( iStatus = SA_create_person( sPersonFullName.c_str(), &tPersonTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( tPersonTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, AP4_EMAIL_ID, &userPassId ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = SA_create_user( userPassId, sPersonFullName.c_str(), userPassId, &tUserTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = SA_set_user_login_group( tUserTag, tGroupTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = SA_set_os_user_name( tUserTag, userPassId ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( tUserTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t roleTag		 = NULLTAG ;
			tag_t participantTypeTag = NULLTAG ;

			char *			strType			= NULL;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, AP4_REQUEST_TYPE, &cpRequestType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpRequestType, SUBCONTRACTOR ) == 0 )
			{
				DNVGL_TRACE_CALL( iStatus = SA_find_role( SUB_CONTRACTOR, &roleTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				int iNoOfGrpMembers = 0;
				tag_t* tMemberTags = NULL;
				DNVGL_TRACE_CALL( iStatus = SA_extent_active_groupmember( &iNoOfGrpMembers, &tMemberTags ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for( int i=0; i<iNoOfGrpMembers; i++ )
				{
					tag_t tMemberUserTag = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = SA_ask_groupmember_user( tMemberTags[i], &tMemberUserTag ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( tMemberUserTag == tUserTag )
					{
						DNVGL_TRACE_CALL( iStatus = AOM_refresh( tMemberTags[i], true ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = SA_set_groupmember_role( tMemberTags[i], roleTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_save( tMemberTags[i] ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_refresh( tMemberTags[i], false ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						break;
					}
				}

				DNVGL_TRACE_CALL( iStatus = EPM_get_participanttype( AP4_SUBCONTRACTOR, &participantTypeTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				DNVGL_TRACE_CALL( iStatus = EPM_get_participanttype( AP4_CUSTOMER, &participantTypeTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}				

			/*
			DNVGL_TRACE_CALL( iStatus = VM_extent( &n_instances, &instances ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			*/

			// Assign the newly created user to the project revision as a sub-contractor participant
			DNVGL_TRACE_CALL( iStatus =  SA_find_all_groupmember_by_user( tUserTag , lIncludeInactive , &iGrpCount , &tGrpMemberTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t projMgrParticipant = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = EPM_create_participant( tGrpMemberTags[0], participantTypeTag, &projMgrParticipant ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = ITEM_rev_add_participant( *tProjectRevTag, projMgrParticipant ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// Create a folder below the project revision named Subcontractor documents
			if( cpObjectType != NULL && tc_strcmp( cpRequestType, SUBCONTRACTOR ) == 0 )
			{
				tag_t tProjectStructureRelationType = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_STRUCTURE_RELATION, &tProjectStructureRelationType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Get the structure attached to the based on project revision.
				int iCount = 0;
				GRM_relation_t* tSecondaryObjs = {NULLTAG};
				GRM_list_secondary_objects( *tProjectRevTag, tProjectStructureRelationType, &iCount, &tSecondaryObjs ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for ( int index = 0; index < iCount; index++ )
				{
					//Get the type of related object tag.
					WSOM_ask_object_type2( tSecondaryObjs[index].secondary, &strType );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( strType != NULL && tc_strcmp( strType, AP4_DOCUMENT_REGISTER ) == 0 )
					{
						tag_t tStuctureToBeCopiedTag = NULLTAG;
						tStuctureToBeCopiedTag = tSecondaryObjs[index].secondary;

						tag_t type_tag = NULLTAG;
						tag_t boTag = NULLTAG;
						tag_t createInputTag = NULLTAG;
						const char *name = "Subcontractor Documents";
						DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type ( AP4_SUBCONTRACTORFOLDER, AP4_SUBCONTRACTORFOLDER, &type_tag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input (	type_tag, &createInputTag )	);
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = TCTYPE_set_create_display_value	( createInputTag, OBJECT_NAME, 1, &name ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( createInputTag, &boTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = dnvgl_change_ownership( boTag, userPassId, CUSTOMER_GROUP ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_save( boTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tStuctureToBeCopiedTag, boTag, tProjectStructureRelationType, NULLTAG, &t_relation ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_refresh( t_relation, true ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						//Save relation	
						DNVGL_TRACE_CALL( iStatus = GRM_save_relation( t_relation ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_refresh( t_relation, false ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}
			}
		}
	}
	catch( ... )
	{
		EPM_set_task_result( msg.task, "EPM_RESULT_Unable_to_complete" );
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}