/**
* \file dnvgl_convert_word_to_pdf.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This action handler converts the word file to pdf.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari 
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 23-Mar-2017   Vinay Kudari	      Initial creation.
*--------------------------------------------------------------------------------
*/
#include "dnvgl_workflows.h"
#include <openxml/OfficeInterop.h>
using namespace std;

/**
* \file dnvgl_convert_word_to_pdf.cxx
* \par  Description :
This function get the word file from the target document revision and convert it to pdf and attach it back to the document revision.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 23-Mar-2017   Vinay Kudari	      Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_convert_word_to_pdf( EPM_action_message_t msg )
{
	int iStatus					= ITK_ok;
	tag_t	*tpTargetTags		= NULL;

	DNVGL_TRACE_ENTER();
	try
	{
		int		iTargetCount	 = 0		;
		char	*cpObjectType	 = NULL		;
		tag_t   tRootTaskTag     = NULLTAG  ;		

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get all the target attachments from the workflow task.
		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Loop through all the target attachments.
		for( int i=0; i<iTargetCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpTargetTags[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tDocRevType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_DOCUMENT_REVISION, AP4_DOCUMENT_REVISION, &tDocRevType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tDocRevType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Convert to pdf will be carried out only for those targets which are instances of AP4_DocumentRevision and its children instances.
			if( bIsValidType )
			{
				tag_t* tpSecondaryObjs = NULL;
				tag_t* tpRelationObjs = NULL;
				int iSecObjCount = 0;
				
				//Get all the MSWordX datasets attached to the document revision by TC_Attaches relation.
				DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tpTargetTags[i], TC_ATTACHES_RELATION, MSWORDX_DATASET, &tpSecondaryObjs, &tpRelationObjs, &iSecObjCount ) );	
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for( int inx = 0; inx < iSecObjCount; inx++ )
				{
					tag_t tpPdfDataset = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = dnvgl_generate_pdf( &tpSecondaryObjs[inx], &tpPdfDataset ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = dnvgl_attach_pdf( &tpTargetTags[i], &tpPdfDataset ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				DNVGL_MEM_FREE( tpSecondaryObjs );
				DNVGL_MEM_FREE( tpRelationObjs );
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpTargetTags );

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_convert_word_to_pdf.cxx
* \par  Description :
This function will generate pdf dataset for the given word dataset.
* \verbatim
\endverbatim     
* \param[in]		tpWordDataset		    Word dataset
* \param[out]		tpPdfDataset		    PDF dataset
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 23-Mar-2017   Vinay Kudari	      Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_generate_pdf( tag_t* tpWordDataset, tag_t* tpPdfDataset )
{
	int iStatus = ITK_ok;
	bool bIsTempFolderCreated = false;
	string strTempFolderPath = "";
	OfficeInterop::WordCppService *wordCppObj	= NULL	;
	try
	{
		char *cpReferenceName = NULL;
		AE_reference_type_t aeReferenceType;
		tag_t tRefObject = NULLTAG;

		DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( *tpWordDataset , 0 , &cpReferenceName , &aeReferenceType , &tRefObject ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* cpOriginalFileName = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tRefObject, ORIGINAL_FILE_NAME , &cpOriginalFileName) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* timestamp = NULL;
		DNVGL_TRACE_CALL( iStatus = DNVGL_current_get_time_stamp( DATE_FORMAT_STR_FOOTER, &timestamp ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Create a temporary folder in %temp%
		const char* cpTempPath;
		cpTempPath = getenv (TEMP_ENV_VAR);
		string dirTimeStamp = timestamp;
		strTempFolderPath = cpTempPath;
		strTempFolderPath.append("\\");
		strTempFolderPath.append(dirTimeStamp);

		DNVGL_TRACE_CALL( iStatus = _mkdir( strTempFolderPath.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		bIsTempFolderCreated = true;
										
		string strWordFilePath= strTempFolderPath;
		strWordFilePath.append("\\");
		strWordFilePath.append(cpOriginalFileName); 

		//Export the named reference of the word dataset to the temporary folder.
		DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( *tpWordDataset, cpReferenceName, strWordFilePath.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get the word file converted to PDF using office interop services.
		char* cpErrMessage  = NULL;
		char* cpPdfFilePath  = NULL;

		DNVGL_TRACE_CALL( iStatus = dnvgl_create_wordinterop_object(wordCppObj,strWordFilePath.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		iStatus = wordCppObj->SaveAsPDF( &cpPdfFilePath, &cpErrMessage );

		//Check if the pdf conversion was successfull or not.
		if( iStatus != ITK_ok )
		{
			TC_write_syslog("\n Interop Caused following error = %s",cpErrMessage);						
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		//Create a PDF dataset for the newly created PDF.
		tag_t tDatasetType = NULLTAG ;
		DNVGL_TRACE_CALL( iStatus = AE_find_datasettype2( PDF_DATASET , &tDatasetType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* cpDatasetName = NULLTAG ;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tpWordDataset, OBJECT_NAME , &cpDatasetName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
					
		DNVGL_TRACE_CALL( iStatus = AE_create_dataset_with_id( tDatasetType, // aDatasetType
									cpDatasetName , // aDatasetName
									NULL, // aDatasetDescription
									NULL, // aDatasetId
									NULL, // aDatasetRev
									tpPdfDataset )); // aNewDataset
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AE_import_named_ref( *tpPdfDataset, // datasetTag
									PDF_REFERENCE_NAME, // referenceName
									cpPdfFilePath, // osFullPathName
									NULL, // newFileName
									SS_BINARY ) ) ; // fileTypeFlag
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( *tpPdfDataset ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}

	free(wordCppObj);
	//Delete the temporary folder	
	if( bIsTempFolderCreated )
	{
		string strTempFolderDeleteCmd = "" ;
		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );	
	}

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_convert_word_to_pdf.cxx
* \par  Description :
This function attaches the PDF dataset to the document revision by iman specification relation.
* \verbatim
\endverbatim     
* \param[in]		tpDocRev				Document revision
* \param[in]		tpPdfDataset		    PDF dataset
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 23-Mar-2017   Vinay Kudari	      Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_attach_pdf( tag_t* tpDocRev, tag_t* tpPdfDataset )
{
	int iStatus = ITK_ok;
	try
	{
		tag_t tRelationType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION, &tRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tRelation = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_create_relation( *tpDocRev, *tpPdfDataset, tRelationType, NULLTAG, &tRelation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}