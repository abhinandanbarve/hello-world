/**
* \file dnvgl_update_dates_of_tasks.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This file contains the action handler which sets the schedule task finish_date to todays date when it is closed.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Durga D
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 18-JAN-2017   Durga D               Initial creation.
*
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

int compare_dates(date_t newendDate,date_t curDate)
{
	if (newendDate.year < curDate.year)
		return -1;

	else if (newendDate.year > curDate.year)
		return 1;

	if (newendDate.year == curDate.year)
	{
		if (newendDate.month<curDate.month)
			return -1;
		else if (newendDate.month>curDate.month)
			return 1;
		else if (newendDate.day<curDate.day)
			return -1;
		else if(newendDate.day>curDate.day)
			return 1;
		else
			return 0;
	}

	return 0;
}

int dnvgl_update_dates_of_tasks( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok   ;

	tag_t		*tpTargetTags					= NULL;

	DNVGL_TRACE_ENTER();
	try
	{	
		bool        bIsValidType                    = false			;
		int         cmp                             =   0			;
		int			iTargetCount					=   0			;
		int         noOfAvailableTasks	            =	0			;
		int		    nRefFound		                =   0           ;
		int		    *nLevelFound	                =  NULL         ;
		int	        numTasksUpdated                 =   0           ;

		char	    **sReferences	                =  NULL         ;
		char        *typestring                     =  NULL         ;
		char        *scheduleObjype                 =  NULL         ;

		date_t      newendDate                      =  NULLDATE		;	
		date_t      curDate                         =  NULLDATE		;

		tag_t		tRootTaskTag					= NULLTAG		;	


		tag_t	    *tRefObjects	                = NULLTAG       ;
		tag_t       *updatedTasks                   = NULLTAG       ;

		struct timeb timebuffer ;
		ftime( &timebuffer ) ;

		time_t tt = timebuffer.time ;
		struct tm *ptm = localtime( &tt ) ;

		curDate.year = ptm -> tm_year + 1900 ;
		curDate.month = ptm -> tm_mon ;
		curDate.day = ptm -> tm_mday ;
		curDate.hour = ptm -> tm_hour ;
		curDate.minute = ptm -> tm_min ;
		curDate.second = ptm -> tm_sec ;

		int msec = timebuffer.millitm ;
		char *strDate = NULL ;
		DATE_date_to_string( curDate, "%Y-%m-%d %H:%M:%S", &strDate ) ;


		//Ask the root task tag
		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Ask the attachments
		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Checking the AP4_ProjectRevision object
		for( int i = 0; i < iTargetCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpTargetTags[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tProjectRevType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_PROJECT_REVISION, AP4_PROJECT_REVISION, &tProjectRevType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tProjectRevType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( bIsValidType )
			{
				tag_t tProjectScheduleRelationType = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_SCHEDULE_RELATION, &tProjectScheduleRelationType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Get the schedule attached to the based on project revision.
				int iCount = 0;
				tag_t* tSecondaryObjs = NULL;
				DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tpTargetTags[i], tProjectScheduleRelationType, &iCount, &tSecondaryObjs ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for( int j = 0; j < iCount; j++ )
				{
					DNVGL_TRACE_CALL( iStatus = WSOM_where_referenced( tSecondaryObjs[j], 1, &nRefFound, &nLevelFound, &tRefObjects, &sReferences ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( nRefFound !=0 )
					{
						for(int refCnt=0; refCnt<nRefFound; refCnt++ )
						{
							DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2( tRefObjects[refCnt], &scheduleObjype ) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if( tc_strcmp( scheduleObjype, SCHEDULETASK ) == 0 )
							{
								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tRefObjects[refCnt], FND0TASKTYPESTRING, &typestring ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								if( tc_strcasecmp( typestring, "SS" ) != 0 && tc_strcasecmp( typestring, "S" ) != 0 )
								{
									//getting the finish date of schedule task
									DNVGL_TRACE_CALL( iStatus = AOM_get_value_date( tRefObjects[refCnt], FINISH_DATE, &newendDate ) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;	

									//comparing the dates
									DNVGL_TRACE_CALL(cmp=compare_dates(newendDate,curDate));
									DNVGL_LOG_ERROR_AND_THROW_STATUS;

									switch( cmp )
									{
									case -1:
										//finish date is earlier then todays date
										break;

									case 1: 
										//finish date is later then the todays date

										ObjectUpdateContainer_t update;

										update.object = tRefObjects[refCnt];
										update.updatesSize = 1;
										update.updates[0].attrName = FINISH_DATE;
										update.updates[0].attrType = 1;
										update.updates[0].attrValue = strDate;

										DNVGL_TRACE_CALL( iStatus = AOM_refresh( tRefObjects[refCnt], true ) );
										DNVGL_LOG_ERROR_AND_THROW_STATUS;

										DNVGL_TRACE_CALL( iStatus = RES_checkout2(tRefObjects[refCnt],"SCHMGT_update_tasks_non_interactive",NULL,NULL,RES_EXCLUSIVE_RESERVE));
										DNVGL_LOG_ERROR_AND_THROW_STATUS;

										DNVGL_TRACE_CALL( iStatus = SCHMGT_update_tasks_non_interactive( tSecondaryObjs[j], 1, &update, &numTasksUpdated, &updatedTasks ) );
										DNVGL_LOG_ERROR_AND_THROW_STATUS;

										DNVGL_TRACE_CALL( iStatus = AOM_save( tRefObjects[refCnt] ) );
										DNVGL_LOG_ERROR_AND_THROW_STATUS;

										DNVGL_TRACE_CALL( iStatus = RES_checkin(tRefObjects[refCnt]));
										DNVGL_LOG_ERROR_AND_THROW_STATUS;

										DNVGL_TRACE_CALL( iStatus = AOM_refresh(tRefObjects[refCnt], false ) );
										DNVGL_LOG_ERROR_AND_THROW_STATUS;

										break;


									case 0: 
										//finish date is same as todays date
										break;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	catch( ... )
	{
	}	

	DNVGL_MEM_FREE( tpTargetTags );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
