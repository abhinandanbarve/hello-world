/**
* \file dnvgl_create_transmittal_xml.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This File  contains the functions which are called to create xml dataset which contains transmittal document infomation
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra  
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 02-Aug-2016   Nikhilesh Khatra      Initial creation.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

using namespace std;

/**
* \file dnvgl_create_transmittal_xml.cxx
* \par  Description :
This function will create XML file for the files present in Zip dataset in Transmittal Document revision.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Get the file list present in the zip attach to transmittal document revision
b. Create the XML file
c. Create dataset for the created XML file
d. Attach the created dataset with Transmittal Document revision
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 02-Aug-2016      Nikhilesh Khatra       Initial creation.
* 10-Aug-2016      Nikhilesh Khatra       7Zip command added instead of extracting the zip to temp location.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_transmittal_xml( EPM_action_message_t msg )
{
	int	    iStatus				= ITK_ok	;
	int		iTargetCount		= 0		;
	char	*cpObjectType		= NULL		;
	char	*cpDatasetName		= NULL		;
	tag_t   tRootTaskTag		= NULLTAG  ;
	tag_t	*tpTargetTags		= NULL		;
	tag_t   tDocRevTag			= NULLTAG  ;

	string strFileDeleteCmd		= "del /f ";
	
	string strTempFolderPath = "";
	boolean bIsTempFolderCreated = false ;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for( int i=0; i<iTargetCount; i++ )
		{
			tDocRevTag = tpTargetTags[i];

			tag_t   tZipDatasetTag = NULLTAG ;
			tag_t   tXmlDatasetTag = NULLTAG ;
			tag_t	tStructRelTag	=  NULLTAG	;
			tag_t*	tpRelatedTags	=  {NULLTAG} ;
			int		iObjectCount	= 0			;	
			bool    bIsXmlDatasetExist = false;

			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION, &tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus =  GRM_list_secondary_objects_only( tDocRevTag, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

	        if(iObjectCount == 0)
			{
				iStatus = ERROR_919124;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}


			for ( int index = 0; index < iObjectCount; index++ )
			{						
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_ZIP ) == 0 )
				{
					tZipDatasetTag = tpRelatedTags[index];
					break;
				}	
			}

			if( tZipDatasetTag == NULLTAG )
			{
				iStatus = ERROR_919120;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tZipDatasetTag, OBJECT_NAME, &cpDatasetName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Get the transmittal xml dataset tag if already created : starts
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( IMAN_REFERENCE_RELATION, &tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tDocRevTag,tStructRelTag,&iObjectCount,&tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iObjectCount; index++ )
			{						
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, TEXT_DATASET ) == 0 )
				{
					tXmlDatasetTag = tpRelatedTags[index];
					bIsXmlDatasetExist = true ;
					break;
				}	
			}
			//Get the transmittal xml dataset tag if already created : ends

			//Export the attached zip to temp location
			char *		reference_name = NULL ;
			AE_reference_type_t       reference_type;
			tag_t      referenced_object = NULLTAG;

			DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tZipDatasetTag , 0 , &reference_name , &reference_type , &referenced_object ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( referenced_object == NULLTAG )
			{
				iStatus = ERROR_919121;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			//create folder in temp dir with current timestamp;
			string cpTempPath = getenv ( TEMP_ENV_VAR );

			cpTempPath.append("\\");
			char* timestamp = NULL;
			DNVGL_TRACE_CALL( iStatus = DNVGL_current_get_time_stamp(DATE_FORMAT_STR_FOOTER, &timestamp) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
			cpTempPath.append(timestamp);
		    DNVGL_TRACE_CALL( iStatus = _mkdir(cpTempPath.c_str()));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			bIsTempFolderCreated = true ; 
			strTempFolderPath = cpTempPath;

			// export zip/7z file in temp dir
			char *cpTcFileName = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(referenced_object, FILE_NAME , &cpTcFileName) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			string filePathTobeExported = cpTempPath;
			filePathTobeExported.append("\\");
			filePathTobeExported.append(cpTcFileName);

			DNVGL_TRACE_CALL( iStatus = AE_export_named_ref( tZipDatasetTag, reference_name, filePathTobeExported.c_str() ) );
		    DNVGL_LOG_ERROR_AND_THROW_STATUS;

			const char* cpTcRootEnvVar;
			cpTcRootEnvVar = getenv( TC_ROOT_ENV_VAR );

			// 7Zip command to create file list in temp txt file : start
			string strZipExePath = cpTcRootEnvVar;
			strZipExePath.append("\\bin\\7za.exe l -r ");
			strZipExePath.append(filePathTobeExported);
			//strZipExePath.append(" | FINDSTR \"[0-9].....A\\>\"") ;

			string strTempTextFilePath= cpTempPath;
			strTempTextFilePath.append("\\temp_trans_text.txt");

			string strZipFileListCmd= strZipExePath;
			strZipFileListCmd.append(">");
			strZipFileListCmd.append(strTempTextFilePath);

			TC_write_syslog("\nCreate Transmittal XML :: Executing 7z command : %s\n", strZipFileListCmd.c_str());

			DNVGL_TRACE_CALL( iStatus = system(strZipFileListCmd.c_str()) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			// 7Zip command to create file list in temp txt file : ends

			string  strXmlDatasetName	= TRANSMITTAL_XML_DATASET_NAME ;
			vector<string> vFiles;
			string strTempXmlFilePath = cpTempPath;
			strTempXmlFilePath.append("\\");
			strTempXmlFilePath.append("Transmittal_xml");
			strTempXmlFilePath.append(".txt");

			strFileDeleteCmd.append( strTempXmlFilePath.c_str() );

			DNVGL_TRACE_CALL( iStatus = dnvgl_transmittal_xml_creation_from_files(strTempXmlFilePath.c_str(), strTempTextFilePath.c_str()) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Dataset creation starts		
			// file import as dataset
			tag_t tDatasetTypeTag = NULLTAG ;
			DNVGL_TRACE_CALL( iStatus = AE_find_datasettype2( TEXT_DATASET , &tDatasetTypeTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char** cpRefList = NULL;
			char* cpRefName = NULL;
			int    iRefCount = 0   ;
			DNVGL_TRACE_CALL( iStatus = AE_ask_datasettype_refs (tDatasetTypeTag, &iRefCount, &cpRefList) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			//Setting reference name for dataset creation e.g. setting "word" for docx type fo file
			cpRefName = cpRefList[0];
			MEM_free (cpRefList);

			if(tXmlDatasetTag == NULL)
			{
				DNVGL_TRACE_CALL( iStatus = AE_create_dataset_with_id(	tDatasetTypeTag, // aDatasetType
					strXmlDatasetName.c_str(), // aDatasetName
					NULL, // aDatasetDescription
					NULL, // aDatasetId
					NULL, // aDatasetRev
					&tXmlDatasetTag )); // aNewDataset
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else{
				//remove old one
				char *  	reference_name =NULL;
				AE_reference_type_t   	reference_type;
				tag_t  	referenced_object ;
				DNVGL_TRACE_CALL( iStatus = AOM_lock( tXmlDatasetTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tXmlDatasetTag,0,&reference_name,	&reference_type,&referenced_object));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;


				DNVGL_TRACE_CALL( iStatus =  AE_remove_dataset_named_ref_by_tag2 	( tXmlDatasetTag,reference_name,referenced_object));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tXmlDatasetTag ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			DNVGL_TRACE_CALL( iStatus = AOM_lock( tXmlDatasetTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AE_import_named_ref(	tXmlDatasetTag, // datasetTag
				cpRefName, // referenceName
				strTempXmlFilePath.c_str(), // osFullPathName
				NULL, // newFileName
				SS_TEXT ) ) ; // fileTypeFlag
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( tXmlDatasetTag ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tXmlDatasetTag, false ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Dataset  creation ends

			//Attach to doc rev starts
			if( !bIsXmlDatasetExist )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_lock( tDocRevTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_lock( tXmlDatasetTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t	tDatasetRelationTypetag		= NULLTAG;
				tag_t	tDatasetRelationTag			= NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( IMAN_REFERENCE_RELATION , &tDatasetRelationTypetag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tDocRevTag,tXmlDatasetTag,tDatasetRelationTypetag,NULLTAG,&tDatasetRelationTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				//Save relation		
				DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tDatasetRelationTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tXmlDatasetTag ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL(  iStatus = AOM_save( tDocRevTag )) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			//Attach to doc rev ends

			//Delete the temp xml file and temp folder.
			// NOTE: purposefully ignoring system errors
			//system( strTempFolderDeleteCmd.c_str() );
			//DNVGL_LOG_ERROR;
		}
	}
	catch( ... )
	{
		
	}

	//Delete the folder	
	if(bIsTempFolderCreated){
		string strTempFolderDeleteCmd = "" ;

		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		//DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );	

	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}