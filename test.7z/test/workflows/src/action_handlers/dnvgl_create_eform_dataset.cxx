/**
* \file dnvgl_create_eform_dataset.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This file contains the action handler which fetches the eform template for the current document.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Durga D
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 08-Jul-2016   Vinay Kudari          Initial creation.
* 12-Dec-2016   Vinay Kudari          Support for all the newly added document types. Hence allow all the children of AP4_ProjDocumentRevision.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

int dnvgl_create_eform_dataset( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		int		iTargetCount	 = 0		;

		char	*cpObjectType	 = NULL		;

		tag_t   tRootTaskTag     = NULLTAG  ;
		tag_t	*tpTargetTags	 = NULL		;
		tag_t   tDatasetTag      = NULLTAG  ;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpTargetTags[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tDocRevType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_PROJECT_DOC_REVISION, AP4_PROJECT_DOC_REVISION, &tDocRevType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tDocRevType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( bIsValidType )
			{
				DNVGL_TRACE_CALL( iStatus = dnvgl_eform_service( tpTargetTags[i], &tDatasetTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;				
			}
		}

		DNVGL_MEM_FREE( tpTargetTags );
	}
	catch( ... )
	{
		
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

