/**
* \file dnvgl_check_comment_added_or_updated.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This file will check if any comment under document revision are updated.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Durga D
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 09-Dec-2016   Srushti Hanjage       Initial creation.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

using namespace std;

/**
* \file dnvgl_add_signoff_user.cxx
* \par  Description :
This function will assign user based on object type and task type.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Get handler argument object type and task type.
b. Based on argument get assignee from Comment chain (Get all chains from (technical document or Activity) and pick any chain to get current assignee
or get Project manager from project revision.
c. Based on task assign user.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 12-Jan-2017      Nikhilesh Khatra       Initial creation.
* 19-Apr-2017      Nikhilesh Khatra       Changes added for Activity
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_add_signoff_user( EPM_action_message_t msg )
{
	int	    iStatus				= ITK_ok	;
	int		iTargetCount		= 0			;
	int		iSecondaryCount		= 0			;	 
	int     iSignOffCount		= 0			;          
	int		iTaskType			= 0			;
	int		iObjType			= 0			;
	int		iParticipantCount   = 0			;
	tag_t   tRootTaskTag		= NULLTAG	;
	tag_t   tTargetObjTag		= NULLTAG	;
	tag_t   tRelationType		= NULLTAG	;
	tag_t   tCurrAssigneeTag	= NULLTAG	;
	tag_t   tProjectRevTag		= NULLTAG	;
	tag_t   tProjectMngTag		= NULLTAG	;
	tag_t   tWorkflowInitUser	= NULLTAG	;
	tag_t*	tpTargetTags		= {NULLTAG} ;
	tag_t*	tpSecondaryObjects	= {NULLTAG} ;
	tag_t*	tpRelationObjects	= {NULLTAG} ;
	tag_t*  tpSignoffs			= {NULLTAG} ;          
	tag_t*  tParticipantTags    = {NULLTAG} ;     
	logical isModified			= false		;
	tag_t* tpCurrentReviewers	= NULL		;

	char*		cpObjectType	= NULL	    ;
	char*		cpArgValue		= NULL		;
	char*		cpTypeArg		= NULL		;
	char*		cpValue			= NULL		;
	std::string sAttachmentType = ""		;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tCurrentTask = msg.task;
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Read the handler arguments.
		while( ( cpArgValue = TC_next_argument( msg.arguments ) ) != NULL )
		{
			iStatus = ITK_ask_argument_named_value( cpArgValue, &cpTypeArg, &cpValue );
			if( cpValue != NULL )
			{
				if( strcmp( cpTypeArg, TASK_TYPE ) == 0 )
				{
					sAttachmentType = cpValue ;

					if( tc_strcasecmp( sAttachmentType.c_str(), ACKNOWLEGDE_TASK ) == 0 )
					{
						iTaskType = 1 ;
					}
					else if( tc_strcasecmp( sAttachmentType.c_str(), DO_TASK ) == 0 )
					{
						iTaskType = 2 ;
					}
					else
					{
						iStatus = ERROR_919152;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}	
				else if( strcmp( cpTypeArg, OBJECT_TYPE ) == 0 )
				{
					sAttachmentType = cpValue ;

					if( tc_strcasecmp( sAttachmentType.c_str(), AP4_PROJECT_REVISION ) == 0 )
					{
						iObjType = 1 ;
					}
					else if( tc_strcasecmp( sAttachmentType.c_str(), AP4_TECH_DOC_REVISION ) == 0 )
					{
						iObjType = 2 ;
					}
					else if( tc_strcasecmp( sAttachmentType.c_str(), AP4_SURVEYORPACKAGEFOLDER ) == 0 )
					{
						iObjType = 3 ;
					}
					else if( tc_strcasecmp( sAttachmentType.c_str(), AP4_ACTIVITYREVISION ) == 0 )
					{
						iObjType = 4 ;
					}
					else
					{
						iStatus = ERROR_919153;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}	
			}
		}

		if( iObjType == 0 || iTaskType == 0)
		{
			iStatus = ERROR_919135;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObjTag = tpTargetTags[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_TECH_DOC_REVISION ) == 0 )
			{
				if( iObjType == 2 )
				{
					DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tTargetObjTag , AP4_COMMENT_CHAIN_RELATION , AP4_COMMENT_CHAIN, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tRootTaskTag, FND0WORKFLOWINITIATOR, &tWorkflowInitUser ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					for( int iSecCount = 0; i < iSecondaryCount; iSecCount++ )
					{
						bool bInternalRemark = true;
						DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_logical( tpSecondaryObjects[iSecCount], AP4_INTERNAL_REMARK, &bInternalRemark ));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( !bInternalRemark )
						{
							DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tpSecondaryObjects[iSecCount], AP4_CURRENT_ASSIGNEE, &tCurrAssigneeTag ));
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if(tWorkflowInitUser != tCurrAssigneeTag)
							{
								break;
							}
						}					
					}
				}
				else if( iObjType == 1 )
				{
					//Get project revision from tech doc revision
					DNVGL_TRACE_CALL(iStatus = dnvg_get_project_rev_from_tech_doc_rev( tTargetObjTag ,&tProjectRevTag) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					tag_t tProjMgrTypeTag = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = EPM_get_participanttype( AP4_PROJECTMANAGER, &tProjMgrTypeTag ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL ( iStatus = ITEM_rev_ask_participants( tProjectRevTag, tProjMgrTypeTag, &iParticipantCount, &tParticipantTags ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( iParticipantCount>0 )
					{
						tProjectMngTag = tParticipantTags[0];

						DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tProjectMngTag, FND0_ASSIGNEE_USER, &tCurrAssigneeTag ));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}
			}
			else if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_SURVEYORPACKAGEFOLDER ) == 0 && iObjType == 3 )
			{
				tag_t tOwningUser = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_owner( tTargetObjTag, &tOwningUser ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tCurrAssigneeTag = tOwningUser;
			}
			// changes for ABA(Activity based approval)
			else if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_ACTIVITYREVISION ) == 0 )
			{
				if( iObjType == 4 )
				{
					tag_t tCommentChainAssignee = NULLTAG;

					DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_chains_for_activity(tTargetObjTag, &tpSecondaryObjects, &iSecondaryCount, NULL) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					for( int iSecCount = 0; i < iSecondaryCount; iSecCount++ )
					{	
						DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tpSecondaryObjects[iSecCount], AP4_CURRENT_ASSIGNEE, &tCommentChainAssignee ));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if(tWorkflowInitUser != tCommentChainAssignee)
						{
							tCurrAssigneeTag = tCommentChainAssignee ;
							break;
						}
					}
				}

				else if( iObjType == 1 )
				{
					//Get project revision from Activity revision					
					DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tTargetObjTag, AP4_PROJECT_BACKPOINTER , &tProjectRevTag ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					tag_t tProjMgrTypeTag = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = EPM_get_participanttype( AP4_PROJECTMANAGER, &tProjMgrTypeTag ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL ( iStatus = ITEM_rev_ask_participants( tProjectRevTag, tProjMgrTypeTag, &iParticipantCount, &tParticipantTags ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( iParticipantCount>0 )
					{
						tProjectMngTag = tParticipantTags[0];

						DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tProjectMngTag, FND0_ASSIGNEE_USER, &tCurrAssigneeTag ));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}
			}
			// changes for ABA(Activity based approval)

			if( tCurrAssigneeTag != NULLTAG )
			{
				//Assign user to acknowledge task or do task : starts
				logical lWasLockedBefore = false;
				DNVGL_TRACE_CALL( iStatus = POM_modifiable( tCurrentTask, &lWasLockedBefore ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( !lWasLockedBefore )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCurrentTask, true ) ) ;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				if( iTaskType == 1 )
				{					
					DNVGL_TRACE_CALL( iStatus = EPM_create_adhoc_signoff( tCurrentTask, tCurrAssigneeTag, &iSignOffCount, &tpSignoffs ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
				else
				{
					DNVGL_TRACE_CALL( iStatus = EPM_assign_responsible_party( tCurrentTask, tCurrAssigneeTag ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				DNVGL_TRACE_CALL( iStatus = AOM_save( tCurrentTask ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( !lWasLockedBefore )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCurrentTask, false ) ) ;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				//Assign user to acknowledge task or do task : ends
				break;
			}
			else
			{
				//Need to throw customer error : no User found to assign task
				iStatus = ERROR_919155;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE( cpObjectType );
	DNVGL_MEM_FREE( tpTargetTags );
	DNVGL_MEM_FREE( tpRelationObjects );
	DNVGL_MEM_FREE( tpSecondaryObjects );
	DNVGL_MEM_FREE( tpSignoffs );
	DNVGL_MEM_FREE( tpCurrentReviewers );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

