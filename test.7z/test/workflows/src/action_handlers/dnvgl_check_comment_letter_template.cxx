/**
* \file dnvgl_check_comment_letter_template.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This File  contains the functions which are called to check existance of comment letter template. 
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra  
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 11-Jan-2017   Nikhilesh Khatra      Initial creation.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

using namespace std;

/**
* \file dnvgl_check_comment_letter_template.cxx
* \par  Description :
This function will check existance of comment letter template.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Get Tech doc revision from root task.
b. Get Project revision from tech doc revision.
c. Get Admin folder from Project revision.
d. Get Comment letter template from Admin folder.
e. If comment letter template exists set EPM_RESULT_TRUE
f. Else set EPM_RESULT_FALSE
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 11-Jan-2017      Nikhilesh Khatra       Initial creation.
* 19-Apr-2017      Nikhilesh Khatra       Changes added for Activity
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_check_comment_letter_template( EPM_action_message_t msg )
{
	int	    iStatus				= ITK_ok	;
	int		iTargetCount		= 0			;
	int		iSecondaryCount		= 0			;	
	char	*cpObjectType		= NULL		;
	char	*cpDocumentType		= NULL		;
	tag_t   tRootTaskTag		= NULLTAG  ;
	tag_t   tTargetRevTag		= NULLTAG	;
	tag_t   tProjectRevTag		= NULLTAG	;
	tag_t   tAdminFolderTag		= NULLTAG	;

	logical isCommTempExist		= false		;
	tag_t*  tpTargetTags		= {NULLTAG} ;
	tag_t*  tpSecondaryObjects	= {NULLTAG} ;
	tag_t*  tpRelationObjects	= {NULLTAG} ;

	std::map<tag_t, std::vector<tag_t>> mActivityCommentChains ;  
	tag_t * tpTechDocRevs				 = NULLTAG		;
	int    iTechDocRevCount              = 0			;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tCurrentTask = msg.task;
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get root task
		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get target objects
		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetRevTag = tpTargetTags[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetRevTag, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_TECH_DOC_REVISION ) == 0 )
			{
				//Get project revision from tech doc revision
				DNVGL_TRACE_CALL(iStatus = dnvg_get_project_rev_from_tech_doc_rev( tTargetRevTag ,&tProjectRevTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tProjectRevTag , AP4_PROJECT_STRUCTURE_RELATION , AP4_GOVERNING_DOCUMENT, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if(iSecondaryCount == 0)
				{
					//need to throw error that admin folder is not exists.
					iStatus = ERROR_919142;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
				else
				{
					tAdminFolderTag = tpSecondaryObjects[0]; 
				}
				//Get the admin folder : ends

				//Get the comment letter template from Admin folder : starts
				tag_t   tCommTemplateTag	 = NULLTAG  ;
				tag_t   tCommTemplateRevTag  = NULLTAG  ;

				bool bIsCommTemplateFound = false ;
				DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tAdminFolderTag , AP4_DOCUMENT_RELATION , AP4_MANAGEMENT, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for ( int index = 0; index < iSecondaryCount; index++ )
				{								
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpSecondaryObjects[index], AP4_TEMPLATETYPE, &cpDocumentType ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpDocumentType != NULL && tc_strcmp( cpDocumentType, MANA_COMMLETTERTEMPLATE ) == 0 )
					{
						isCommTempExist = true ;				
						break ;
					}	
				}
			}
			// changes for ABA(Activity based approval)
			else if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_ACTIVITYREVISION ) == 0 )
			{
				//Get project revision from Activity revision
				DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tTargetRevTag, AP4_PROJECT_BACKPOINTER , &tProjectRevTag ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tProjectRevTag , AP4_PROJECT_STRUCTURE_RELATION , AP4_GOVERNING_DOCUMENT, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if(iSecondaryCount == 0)
				{
					//need to throw error that admin folder is not exists.
					iStatus = ERROR_919142;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
				else
				{
					tAdminFolderTag = tpSecondaryObjects[0]; 
				}
				//Get the admin folder : ends

				//Get the comment letter template from Admin folder : starts
				tag_t   tCommTemplateTag	 = NULLTAG  ;
				tag_t   tCommTemplateRevTag  = NULLTAG  ;

				bool bIsCommTemplateFound = false ;
				DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tAdminFolderTag , AP4_DOCUMENT_RELATION , AP4_MANAGEMENT, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for ( int index = 0; index < iSecondaryCount; index++ )
				{								
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpSecondaryObjects[index], AP4_TEMPLATETYPE, &cpDocumentType ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpDocumentType != NULL && tc_strcmp( cpDocumentType, MANA_COMMLETTERTEMPLATE ) == 0 )
					{
						isCommTempExist = true ;				
						break ;
					}	
				}
			}
			// changes for ABA(Activity based approval)
		}
		//Set EPM Condition task result
		if(isCommTempExist)
		{
			DNVGL_TRACE_CALL( iStatus = EPM_set_condition_task_result(tCurrentTask,EPM_RESULT_TRUE ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			DNVGL_TRACE_CALL( iStatus = EPM_set_condition_task_result(tCurrentTask,EPM_RESULT_FALSE ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE( cpObjectType );
	DNVGL_MEM_FREE( tpTargetTags );
	DNVGL_MEM_FREE( tpSecondaryObjects );
	DNVGL_MEM_FREE( tpRelationObjects );
	DNVGL_MEM_FREE( cpDocumentType );
	DNVGL_MEM_FREE( tpTechDocRevs );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
