#include "dnvgl_workflows.h"
#define _LOAD_FROM_EXTERNAL
#include "dnvgl_notification_services.h"
#undef _LOAD_FROM_EXTERNAL

using namespace std;

//! Brief description, helper function to create a row. The key value displayed bold and the value will be present as italic.
void appendRow(string *str_to_append, string key, char *value) {
	if (value != NULL && tc_strlen(value) != 0) {
		str_to_append->append("<em>");
		str_to_append->append(key);
		str_to_append->append("</em>: ");
		str_to_append->append(value);
		str_to_append->append("<br/>");
	}
};

/** Note: This function returns a pointer to a substring of the original string.
If the given string was allocated dynamically, the caller must not overwrite
that pointer with the returned value, since the original pointer must be
deallocated using the same allocator with which it was allocated.  The return
value must NOT be deallocated using free() etc. 
Source: http://stackoverflow.com/questions/122616/how-do-i-trim-leading-trailing-whitespace-in-a-standard-way */
char *trimwhitespace(char *str)
{
	char *end;

	// Trim leading space
	while(isspace((unsigned char)*str)) str++;

	if(*str == 0)  // All spaces?
		return str;

	// Trim trailing space
	end = str + strlen(str) - 1;
	while(end > str && isspace((unsigned char)*end)) end--;

	// Write new null terminator
	*(end+1) = 0;

	return str;
}

/** Brief description, the action handler get parameter -recipient and this function convert all recipients to email and store to sNotification. */
void parse_email(EPM_action_message_t *msg, /**< (I) The related Task */
				 dnvgl_notification *sNotification, /**< (I) Data structure to fill for the notification service */ 
				 char *stringWithRecipient /**< (I) String with all recipient. E.g. $PROJECT_MANAGER, $OWNER, simon.koennecke@piterion.com*/
				 ) {

					 char *ptr;
					 string query = "";
					 ptr = strtok(stringWithRecipient, ",");
					 while (ptr != NULL) {
						 ptr = trimwhitespace(ptr);
						 if (ptr[0] == '$') {
							 query += ptr;
							 query += ", ";
							 DNVGL_TRACE_DGB( ("Variable %s", ptr) );
						 } else {
							 DNVGL_TRACE_DGB( ("Email %s", ptr) );
							 sNotification->recipients.push_back(ptr);
						 }
						 ptr = strtok(NULL, ",");
					 }

					 //If is no var in stringWithRecipient then skip the the last part.
					 if (query.size() == 0) {
						 return;
					 }

					 int 	member_count;
					 tag_t  *members;
					 int 	rp_count;
					 tag_t 	*rps;
					 DNVGL_TRACE_DGB( ("Query participants %s", query.c_str()) );
					 EPM_get_participants (query.c_str(), msg->task, &member_count, &members, &rp_count, &rps, false);	

					 DNVGL_TRACE_DGB( ("member_count %d", member_count) );
					 DNVGL_TRACE_DGB( ("rp_count %d", rp_count) );
					 DNVGL_TRACE_DGB( ("rps %d", rps) );
					 char *cpObjectType;
					 tag_t line_type_tag = NULLTAG;
					 if (member_count > 0) {

						 for (int i=0; i < member_count; i++) {
							 AOM_ask_value_tag(members[i], "user", &line_type_tag);
							 EPM_get_user_email_addr(line_type_tag, &cpObjectType);
							 sNotification->recipients.push_back(cpObjectType);
							 DNVGL_MEM_FREE(cpObjectType);
						 }
					 }
					 if (rp_count > 0) {
						 char *cpObjectType;
						 for (int i=0; i < rp_count; i++) {
							 AOM_ask_value_tag(rps[i], "user", &line_type_tag);
							 EPM_get_user_email_addr(line_type_tag, &cpObjectType);
							 DNVGL_TRACE_DGB( ("Email %s", cpObjectType) );
							 sNotification->recipients.push_back(cpObjectType);
							 DNVGL_MEM_FREE(cpObjectType);
						 }
					 }

					 DNVGL_MEM_FREE(members);
					 DNVGL_MEM_FREE(rps);

}

/** A action handler for Teamcenter workflow. The handler sends a email via My DNV GL Portal */
int dnvgl_notify( EPM_action_message_t msg /*< Current Task*/)
{
	int	    iStatus          = ITK_ok;

	DNVGL_TRACE_ENTER();

	dnvgl_notification sNotification;
	// Parse Arguments from current Task
	try
	{
		char* cpArgValue = NULL;
		char* cpTypeArg = NULL;
		char* cpValue = NULL;

		// Read the arguments
		while( ( cpArgValue = TC_next_argument( msg.arguments ) ) != NULL )
		{
			iStatus = ITK_ask_argument_named_value( cpArgValue, &cpTypeArg, &cpValue );
			if( cpValue != NULL )
			{
				if( strcmp( cpTypeArg, "to" ) == 0 || strcmp( cpTypeArg, "recipient" ) == 0 )
				{
					DNVGL_TRACE_DGB( ("recipient %s", cpValue) );
					parse_email(&msg, &sNotification, cpValue);
				}
				else if   ( strcmp( cpTypeArg, "channelid" ) == 0 )
				{
					DNVGL_TRACE_DGB( ("channelid %s", cpValue) );
					sNotification.channel_id.assign( cpValue );                                                        

				}
				else if   ( strcmp( cpTypeArg, "channel" ) == 0 )
				{
					DNVGL_TRACE_DGB( ("channel %s", cpValue) );
					sNotification.channel_name.assign( cpValue );                                                        

				}
				else if    ( strcmp( cpTypeArg, "subject" ) == 0)
				{
					DNVGL_TRACE_DGB( ("subject %s", cpValue) );
					sNotification.subject.assign( cpValue );

				}
				else if    ( strcmp( cpTypeArg, "BODY" ) == 0 || strcmp( cpTypeArg, "comment" ) == 0)
				{
					DNVGL_TRACE_DGB( ("comment %s", cpValue) );
					sNotification.comment.assign( cpValue );                                                             

				}
				else if    ( strcmp( cpTypeArg, "attachment" ) == 0)
				{
					DNVGL_TRACE_DGB( ("attachment %s", cpValue) );
					sNotification.attachment.assign( cpValue );                                                             

				}
				else if    ( strcmp( cpTypeArg, "url" ) == 0 )
				{
					DNVGL_TRACE_DGB( ("url %s", cpValue) );
					sNotification.url.assign( cpValue );                                                             

				}
				else if    ( strcmp( cpTypeArg, "service" ) == 0 )
				{
					DNVGL_TRACE_DGB( ("service %s", cpValue) );
					sNotification.service.assign( cpValue );                                                             

				}
			}
			DNVGL_MEM_FREE(cpValue);
			DNVGL_MEM_FREE(cpTypeArg);
		}

	}
	catch( ... )
	{
	}

	//Create and append task overview to message body
	/* E. g.:
	Overview:
	Current Task: 	Review and Approve Proposal(Proposal Review) 
	Process Name: 	ss123 
	Due Date: 	None 
	Comments: 	Please review the attached proposal 
	Instructions: 	perform signoffs. 
	*/
	try {
		char	*cpObjectType	 = NULL;
		char	*uid			 = NULL;

		//Set link to current task
		DNVGL_TRACE_CALL( POM_tag_to_uid(msg.task, &uid));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		if (uid != NULL) {
			sNotification.links_id.push_back(uid);
			sNotification.links_name.push_back("Task");
			DNVGL_MEM_FREE(uid);
		}


		string overview = "<br/><br/><strong>Overview</strong><br/>";

		//Set task title
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( msg.task, OBJECT_NAME, &cpObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		appendRow(&overview, "Current Task", cpObjectType);
		DNVGL_MEM_FREE(cpObjectType);

		//Set process name
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( msg.task, "job_name", &cpObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		appendRow(&overview, "Process name", cpObjectType);
		DNVGL_MEM_FREE(cpObjectType);

		//Set process name
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( msg.task, "ap4_process_desc", &cpObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		appendRow(&overview, "Process description", cpObjectType);
		DNVGL_MEM_FREE(cpObjectType);

		//Set due date
		date_t cpObjectDate;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( msg.task, "due_date", &cpObjectDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		ITK_date_to_string(cpObjectDate, &cpObjectType);
		appendRow(&overview, "Due Date", cpObjectType);
		DNVGL_MEM_FREE(cpObjectType);

		//Set comments
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( msg.task, "comments", &cpObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		appendRow(&overview, "Comments", cpObjectType);
		DNVGL_MEM_FREE(cpObjectType);

		//Set Instructions
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( msg.task, "current_desc", &cpObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		appendRow(&overview, "Instructions", cpObjectType);
		DNVGL_MEM_FREE(cpObjectType);
		

		char **ary = NULL;
		int iProps = 0;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_prop_names( msg.task, &iProps, &ary ) );
		
		for (int i=0; i < iProps; i++) {
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( msg.task, ary[i], &cpObjectType ) );
			DNVGL_TRACE_DGB( ("task prob %s = %s",  ary[i], cpObjectType) );
		}


		//Append the overview to message
		sNotification.comment.append(overview);
	} catch(...) {

	}

	//!< All Signoff user should received an email as well
	try {
		int		iTargetCount	 = 0		;
		int		iPropCount		 = 0		;

		char	*cpObjectType	 = NULL		;

		tag_t	*tpTargetTags	 = NULL		;
		tag_t   tTargetObjTag	 = NULLTAG  ;
		tag_t   tMembereObjTag	 = NULLTAG  ;
		tag_t   *tMembersObjTag	 = NULLTAG  ;
		tag_t   tUserObjTag		 = NULLTAG  ;

		SIGNOFF_TYPE_t signoffType = SIGNOFF_UNDEFINED;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get all signoff attachment of the task
		//Make sure that the EPM-inherit task will fetch all signoff object from previous task
		//by adding the parameter -task $PREVIOUS, -attachment signoffs
		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments(  msg.task, EPM_signoff_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObjTag = tpTargetTags[i];
			//Get signoff member
			DNVGL_TRACE_CALL( iStatus = EPM_ask_signoff_member( tTargetObjTag, &tMembereObjTag, &signoffType ) );
			if (signoffType == SIGNOFF_GROUPMEMBER) {//member can be a Group Member object
				AOM_ask_value_tag(tMembereObjTag, "user", &tUserObjTag);
				EPM_get_user_email_addr(tUserObjTag, &cpObjectType);
				DNVGL_TRACE_DGB( ("EPM_ask_signoff_member => user => Email %s", cpObjectType) );
				sNotification.recipients.push_back(cpObjectType);
			} else if (signoffType ==  SIGNOFF_RESOURCEPOOL) {//member can be a resource pool object
				DNVGL_TRACE_CALL( iStatus = EPM_ask_resource_pool_subscribers(tMembereObjTag, &iPropCount, &tMembersObjTag));
				DNVGL_TRACE_DGB( ("EPM_ask_signoff_member => user => SIGNOFF_RESOURCEPOOL => count => %d", iPropCount) );
				for (int s = 0; s < iPropCount; s++) { //Add all subscribed user to email
					DNVGL_TRACE_CALL( iStatus = EPM_get_user_email_addr(tMembersObjTag[s], &cpObjectType));
					DNVGL_TRACE_DGB( ("EPM_ask_signoff_member => EPM_ask_resource_pool_subscribers => Email %s", cpObjectType) );
					sNotification.recipients.push_back(cpObjectType);
				}
			}
			DNVGL_MEM_FREE( tMembersObjTag );
			DNVGL_MEM_FREE( cpObjectType );
		}

		DNVGL_MEM_FREE( tpTargetTags );
	}
	catch( ... )
	{
	}

	//Create and append links to message body
	try {
		int		iTargetCount	 = 0		;

		char	*uid			 = NULL		;
		char	*cpObjectName	 = NULL		;
				
		tag_t   tRootTaskTag     = NULLTAG  ;
		tag_t	*tpTargetTags	 = NULL		;
		tag_t   tTargetObjTag	 = NULLTAG  ;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObjTag = tpTargetTags[i];

			uid  = NULL;
			DNVGL_TRACE_CALL( POM_tag_to_uid(tTargetObjTag, &uid));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			if (uid != NULL) {
				sNotification.links_id.push_back(uid);
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, OBJECT_NAME, &cpObjectName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				sNotification.links_name.push_back(cpObjectName);
				DNVGL_MEM_FREE(cpObjectName);
			}
			DNVGL_MEM_FREE(uid);
		}

		DNVGL_MEM_FREE(tpTargetTags);
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_CALL( dnvgl_mydnvgl_notification(&sNotification));

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}