#include "dnvgl_workflows.h"

int dnvgl_update_created_by_attribute( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		int		iTargetCount	 = 0		;

		char    *cpUserName		 = NULL     ;
		char	*cpObjectType	 = NULL		;
		char	*cpPrefName      = NULL		;

		tag_t  	tUser			 = NULLTAG	;
		tag_t   tRootTaskTag     = NULLTAG  ;
		tag_t	*tpTargetTags	 = NULL		;
		tag_t   tTargetObjTag	 = NULLTAG  ;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		dnvgl_get_handler_opts( msg.arguments, CONVERT_TO, &cpPrefName, NULL );

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObjTag = tpTargetTags[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_PROJECT_REVISION ) == 0 )
			{
				if( cpPrefName != NULL && !tc_strcmp( cpPrefName, "" ) == 0 )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tTargetObjTag, true ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = POM_get_user( &cpUserName, &tUser ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( tc_strcmp( cpPrefName, OPPORTUNITY ) == 0)
					{
						DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tTargetObjTag, AP4_OPPORTUNITY_CREATED_BY, cpUserName ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
					else if( tc_strcmp( cpPrefName, BIDDING ) == 0 )
					{
						//TODO:
					}
					else if( tc_strcmp( cpPrefName, PROJECT ) == 0 )
					{
						DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tTargetObjTag, AP4_PROJECT_CREATED_BY, cpUserName ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}

					DNVGL_TRACE_CALL( iStatus = AOM_save ( tTargetObjTag ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tTargetObjTag, false ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}
		}

	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}