/**
* \file dnvgl_check_surveyor_checklist_template.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This contains the action handler which performs a check for surveyor checklist template in surveyor package folder. 
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari  
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 06-Apr-2017   Vinay Kudari          Initial creation.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

using namespace std;

/**
* \file dnvgl_check_surveyor_checklist_template.cxx
* \par  Description :
This function will check existance of surveyor checklist template with the surveyor package folder.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Get all the target attachments from root task.
b. Process surveyor package folders only from the target attachments.
c. Get secondary objects of type AP4_Deliverable attached to surveyor package folder by AP4_SUCTemplateRelation.
d. Verify if word file is attached to the latest revision of Ap4_Deliverable
e. If AP_Deliverable is not found then set the result of condition task to EPM_RESULT_FALSE else it will be true.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 06-Apr-2017   Vinay Kudari          Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_check_surveyor_checklist_template( EPM_action_message_t msg )
{
	int	    iStatus				= ITK_ok	;
	
	tag_t* tpTargets = NULL;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tCurrentTask = msg.task;
		logical lSurveyorChecklistTemplateExists = false;
		
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get root task
		tag_t   tRootTask = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTask ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get target objects
		int iTargetCount = 0;
		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTask, EPM_target_attachment, &iTargetCount, &tpTargets ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for( int i=0; i<iTargetCount; i++ )
		{
			char* cpObjectType = NULL;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpTargets[i], OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_SURVEYORPACKAGEFOLDER ) == 0 )
			{
				//Get AP4_Deliverable objects attached to surveyor package folder by AP4_SUCTemplateRelation.
				vector<tag_t> vSecObjs;
				DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type( tpTargets[i] , AP4_SUCTEMPLATERELATION, AP4_DELIVERABLE, vSecObjs ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( vSecObjs.size() == 1 )
				{
					//Get the latest revision from the AP4_Deliverable item.
					tag_t tDeliverableRev = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( vSecObjs.at(0), &tDeliverableRev ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					//Check if the word dataset exists with the surveyor checklist template.
					vector<tag_t> vWordDatasets;
					DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type( tDeliverableRev , TC_ATTACHES_RELATION, MSWORDX_DATASET, vWordDatasets ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( vWordDatasets.size() == 1 )
					{
						AE_reference_type_t refType;
						tag_t tRefObj = NULLTAG;
						DNVGL_TRACE_CALL( iStatus = AE_ask_dataset_named_ref2( vWordDatasets.at(0), "word", &refType, &tRefObj ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( tRefObj != NULLTAG )
						{
							//If the dataset and its named reference exists then it means surveyor checklist template exists.
							lSurveyorChecklistTemplateExists = true;
						}
					}
					vWordDatasets.clear();
				}
				vSecObjs.clear();
			}
		}

		//Set EPM Condition task result
		if( lSurveyorChecklistTemplateExists )
		{
			DNVGL_TRACE_CALL( iStatus = EPM_set_condition_task_result( tCurrentTask, EPM_RESULT_TRUE ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			DNVGL_TRACE_CALL( iStatus = EPM_set_condition_task_result( tCurrentTask, EPM_RESULT_FALSE ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpTargets );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
