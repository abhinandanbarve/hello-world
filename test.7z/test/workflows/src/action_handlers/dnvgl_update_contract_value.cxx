/**
* \file dnvgl_update_contract_value.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This file contains the action handler which updates the project revision  property ap4_local_project_value.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Durga D
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 28-Jan-2016   Durga D               Initial creation.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

int dnvgl_update_contract_value( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok   ;	

	tag_t		*tpTargets						= NULL;
	tag_t       *tpTagList                        = NULL;

	DNVGL_TRACE_ENTER();
	try
	{		
		int			iTargetCount					= 0;
		int         noOfAvailableTasks	            = 0;

		tag_t		tRootTask						= NULLTAG;

		//Ask the root task tag
		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTask ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Ask the attachments
		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTask, EPM_target_attachment, &iTargetCount, &tpTargets ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Checking the AP4_ProjectRevision object
		for( int i = 0; i < iTargetCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpTargets[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tDocRevType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_PROJECT_REVISION, AP4_PROJECT_REVISION, &tDocRevType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tDocRevType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( bIsValidType )
			{

				double dContractValue=0;
				//getting the contract value from projectrevision 
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tpTargets[i], AP4_LOCAL_PROJECT_VALUE, &dContractValue ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//getting the scheduletasks from projectrevision 
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tpTargets[i], AP4_SCHEDULE_TASKS, &noOfAvailableTasks, &tpTagList ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				double dTotalRevenue=0;
				if( noOfAvailableTasks != 0 )
				{
					for( int taskcnt=0; taskcnt<noOfAvailableTasks; taskcnt++ )
					{	
						double dRevenue = NULL;

						//getting the ap4_revenue of schedule task
						DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tpTagList[taskcnt], AP4_REVENUE, &dRevenue ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;	

						dTotalRevenue = dTotalRevenue + dRevenue;
					}
                }
			    if(dContractValue<dTotalRevenue)
				{
					DNVGL_TRACE_CALL(  iStatus = AOM_refresh( tpTargets[i],true ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					//setting the ap4_local_project_value of project revision
					DNVGL_TRACE_CALL( iStatus = AOM_set_value_double( tpTargets[i], AP4_LOCAL_PROJECT_VALUE, dTotalRevenue ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_save( tpTargets[i] ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL(  iStatus = AOM_refresh( tpTargets[i], false ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}
		}

		
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpTargets );
	DNVGL_MEM_FREE( tpTagList );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}