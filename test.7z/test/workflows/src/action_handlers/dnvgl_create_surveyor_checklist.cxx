/**
* \file dnvgl_create_surveyor_checklist.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This File  contains the functions which are called to create surveyor checklist
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Chetan Kekade  
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 23-Mar-2017   Chetan Kekade		  Initial creation.
*--------------------------------------------------------------------------------
*/
#include "dnvgl_workflows.h"
#include <openxml/OfficeInterop.h>
using namespace std;

/**
* \file dnvgl_create_surveyor_checklist.cxx
* \par  Description :
This function will create comment letter with bookmarks value and commentary table.
It will attach comment letter to comment letter document.
* \verbatim
\endverbatim     
* \param[in]		tSurveyorPkg			Surveyor Package tag
* \param[out]		tDeliverableTmpl		Surveyor Template Tag
* \param[out]		tSCTmplDataset		    Surveyor Template dataset tag
* \par Algorithm:
* \verbatim  
a. Checks for the Surveyor Template attached to Surveyor Package
b. Get the Surveyor Template and the Template dataset tag
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 25-Mar-2017      Chetan Kekade		  Initial creation.
*------------------------------------------------------------------------------
*/
int dnvgl_get_surveyor_template( tag_t tSurveyorPkg,tag_t* tDeliverableTmpl, tag_t* tSCTmplDataset)
{
	int	iStatus	= ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		std::vector<tag_t> vSecObject ;
		//Get the Surveyor Template attached by relation
		DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type( tSurveyorPkg, AP4_SUCTEMPLATERELATION, AP4_DELIVERABLE, vSecObject ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//If Surveyor template found then save it to temp directory
		if(!vSecObject.empty() && vSecObject.size() == 1)
		{

			*tDeliverableTmpl = vSecObject[0];
			//Get the doc tag from doc rev
			tag_t   tDeliverableTmplRev	 = NULLTAG  ;
			DNVGL_TRACE_CALL ( iStatus = ITEM_ask_latest_rev( *tDeliverableTmpl, &tDeliverableTmplRev) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tTCAttachesRel = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION , &tTCAttachesRel ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			int		iObjectCount  = 0;
			tag_t*	tpRelatedTags = NULLTAG;
			DNVGL_TRACE_CALL( iStatus =  GRM_list_secondary_objects_only( tDeliverableTmplRev, tTCAttachesRel, &iObjectCount, &tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t   tFolderTag	 = NULLTAG  ;
			for ( int index = 0; index < iObjectCount; index++ )
			{						
				char* cpObjectType = NULL;

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, MSWORDX_DATASET ) == 0 )
				{
					*tSCTmplDataset = tpRelatedTags[index];
					break ;
				}	
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}
/**
* \file dnvgl_create_comment_letter.cxx
* \par  Description :
This function will create comment letter with bookmarks value and commentary table.
It will attach comment letter to comment letter document.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Checks for the Surveyor Template 
b. get Surveyor checklist , if not prersent create new
c. get the Surveyor template file to Temp location
d. Create input for comment letter generation
e. Generate comment letter with commentary table
f. Protect comment letter with password(UID of technical document)
g. Attach surveyor checklist document to latest Surveyor Checklist revision
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 23-Mar-2017      Chetan Kekade       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

int dnvgl_create_surveyor_checklist( EPM_action_message_t msg )
{
	int		iStatus				= ITK_ok;
	int		iTargetCount		= 0;
	char*	cpReferenceName		= NULL;
	char*	cpOriginalFileName	= NULL;
	tag_t	tSurveyorPackage	= NULLTAG;
	tag_t	tRootTask			= NULLTAG;
	tag_t	tTmplWordDataset	= NULLTAG;
	tag_t   tRefObject			= NULLTAG;
	tag_t*	tpTargetTags		= NULLTAG;
	bool	isSUCTemplate		= false;	
	bool	bIsTempFolderCreated = false;
	string  strTempFolderPath	= "";
	tag_t	tDeliverableTmpl	= NULLTAG;
	tag_t   tTemplateDataset	= NULLTAG;
	tag_t	tSurveyorCheklistRev= NULLTAG;
	std::vector<tag_t> vTechDocRevs ;
	std::string	strEformWordFilePath;
	AE_reference_type_t       aeReferenceType;
	OfficeInterop::WordCppService *wordCppObj	= NULL	;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTask ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTask, EPM_target_attachment, &iTargetCount, &tpTargetTags) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpTargetTags[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tSurveyorPackageType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_SURVEYORPACKAGEFOLDER, AP4_SURVEYORPACKAGEFOLDER, &tSurveyorPackageType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tSurveyorPackageType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !bIsValidType )
			{
				continue;
			}
			//Get the Surveyor template
			tSurveyorPackage = tpTargetTags[i];
			DNVGL_TRACE_CALL( iStatus = dnvgl_get_surveyor_template( tSurveyorPackage, &tDeliverableTmpl, &tTmplWordDataset )  );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			if( tDeliverableTmpl != NULL && tTmplWordDataset != NULLTAG )
			{
				// get the latest Surveyor cheklist revision
				tag_t tSurveyorCheklistRev = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = dnvgl_get_working_surveyor_checklist( tSurveyorPackage, tDeliverableTmpl, &tSurveyorCheklistRev )  );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//create temp folder 
				const char* cpTempPath;
				cpTempPath = getenv( TEMP_ENV_VAR );
				char*  timestamp = NULL;
				string dirTimeStamp;

				DNVGL_TRACE_CALL( iStatus = DNVGL_current_get_time_stamp( DATE_FORMAT_STR_FOOTER, &timestamp ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				dirTimeStamp = timestamp;
				strTempFolderPath = cpTempPath ;
				strTempFolderPath.append("\\");
				strTempFolderPath.append(dirTimeStamp);

				DNVGL_TRACE_CALL( iStatus = _mkdir( strTempFolderPath.c_str() ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Export the attached word to temp location
				DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2( tTmplWordDataset, 0, &cpReferenceName, &aeReferenceType, &tRefObject ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tRefObject, ORIGINAL_FILE_NAME , &cpOriginalFileName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				
				std::string strOriginalName = cpOriginalFileName;
				bIsTempFolderCreated = true ; 
				strEformWordFilePath= strTempFolderPath;
				strEformWordFilePath.append("\\");
				
				char cDelimiter  = '.';
				std::string strExtension = strOriginalName.substr(strOriginalName.find(cDelimiter), strOriginalName.size());
				if( !DNVGL_IS_STRING_EMPTY(strExtension.c_str()) )
				{	
					strEformWordFilePath.append(SURVEYOR_CHEKLIST_NAME);
					strEformWordFilePath.append(strExtension); 
				}
				else
				{
					strEformWordFilePath.append(cpOriginalFileName); 
				}

				DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tTmplWordDataset, cpReferenceName, strEformWordFilePath.c_str()));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				std::vector<tag_t> vTechDocs ;
				DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type( tSurveyorPackage, AP4_FOLDER_DOCUMENT_RELATION, AP4_TECH_DOCUMENT, vTechDocs ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//convert techdoc to techDocRev
				for(int i=0;i<vTechDocs.size();i++)
				{
					tag_t tTempRev = NULLTAG; 
					DNVGL_TRACE_CALL( iStatus =  ITEM_ask_latest_rev( vTechDocs[i],&tTempRev) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					vTechDocRevs.push_back(tTempRev);
				}
				char* cpEditableMessage  = NULL;
				std::vector<std::string> vEditableBookmarks ;
				//Featch comment data from doc rev tag
				std::vector<std::vector<std::string>> vCommentChainForInterop;
				std::vector<std::vector<std::string>> vDocDataForInterop ;
				int iTableCount = 0 ;

				DNVGL_TRACE_CALL( iStatus =  dnvgl_get_input_for_comment_letter( vTechDocRevs, false, SURVEYOR, vCommentChainForInterop, vDocDataForInterop, iTableCount) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				char * cpDocumentType = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tDeliverableTmpl, AP4_TEMPLATETYPE, &cpDocumentType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				char * cpDocumentCategory = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tDeliverableTmpl, AP4_VERSION, &cpDocumentCategory ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				// if AP4_EFORM_TEMPLATE_CATEGORY attribute is not filled, lets replace it with NA.
				cpDocumentCategory = DNVGL_IS_STRING_EMPTY(cpDocumentCategory) ? "NA" : cpDocumentCategory;

				tag_t tDatasetTag = NULLTAG;
				std::string strEformID;
				std::string cpEformDocType;
				std::string cpDatasetType;

				DNVGL_TRACE_CALL( iStatus = dnvgl_get_eform_dataset_info( cpDocumentType, cpDocumentCategory, strEformID, cpEformDocType, cpDatasetType, &tDatasetTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				std::vector<std::string> vTableBookmarks ;
				DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_letter_bookmarks( DNVGL_COMMENT_LETTER_TABLE_BOOKMAKRS, strEformID.c_str(), vTableBookmarks ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = dnvgl_create_wordinterop_object(wordCppObj,strEformWordFilePath.c_str()) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				char* cpCreateMessage  = NULL;
				iStatus = wordCppObj->CreateCommentTable( vTableBookmarks[0].c_str() ,vCommentChainForInterop, vDocDataForInterop, iTableCount, true, &cpCreateMessage );

				if( iStatus!=0 )
				{
					//Need to add custom error
					TC_write_syslog("\n Interop Caused following error = %s",cpCreateMessage);
					iStatus = ERROR_919139;
					EMH_store_error_s1(EMH_severity_error,ERROR_919139,cpCreateMessage);
					DNVGL_LOG_ERROR_AND_THROW_STATUS ;
				}

				tag_t tTCAttachesRel = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION , &tTCAttachesRel ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				int		iObjectCount  = 0;
				tag_t*	tpRelatedTags = NULLTAG;
				DNVGL_TRACE_CALL( iStatus =  GRM_list_secondary_objects_only( tSurveyorCheklistRev, tTCAttachesRel, &iObjectCount, &tpRelatedTags ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t   tFolderTag	= NULLTAG;
				tag_t	tWordDataset= NULLTAG;
				bool isDatasetExists = false;
				for ( int index = 0; index < iObjectCount; index++ )
				{						
					char* cpObjectType = NULL;

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpObjectType != NULL && tc_strcmp( cpObjectType, MSWORDX_DATASET ) == 0 )
					{
						tWordDataset = tpRelatedTags[index];
						isDatasetExists = true;
						break ;
					}	
				}

				char * cpSCheklistUID = NULL;
				DNVGL_TRACE_CALL( ITK__convert_tag_to_uid( tSurveyorCheklistRev, &cpSCheklistUID ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				char* cpProtectMessage  = NULL;
				iStatus = wordCppObj->ApplyDocumentProtection(cpSCheklistUID, &cpProtectMessage);

				if( iStatus != 0 )
				{
					//Need to add custom error
					TC_write_syslog("\n Interop Caused following error = %s",cpProtectMessage);
					iStatus = ERROR_919140;
					EMH_store_error_s1(EMH_severity_error,ERROR_919140,cpProtectMessage);
					DNVGL_LOG_ERROR_AND_THROW_STATUS ;
				}

				// file import as dataset
				tag_t tDatasetType = NULLTAG ;
				DNVGL_TRACE_CALL( iStatus = AE_find_datasettype2( MSWORDX_DATASET , &tDatasetType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				char** cpRefList = NULL;
				char* cpRefName = NULL;
				int    iRefCount = 0   ;
				DNVGL_TRACE_CALL( iStatus = AE_ask_datasettype_refs( tDatasetType, &iRefCount, &cpRefList) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				//Setting reference name for dataset creation e.g. setting "word" for docx type fo file
				cpRefName = cpRefList[0];
				MEM_free (cpRefList);

				if(tWordDataset == NULL)
				{
					DNVGL_TRACE_CALL( iStatus = AE_create_dataset_with_id(	tDatasetType, SURVEYOR_CHEKLIST_NAME , NULL, NULL, NULL, &tWordDataset ) ); 
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
				else
				{
					//remove old one
					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tWordDataset, true ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2( tWordDataset ,0 ,&cpReferenceName ,&aeReferenceType ,&tRefObject));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus =  AE_remove_dataset_named_ref_by_tag2 ( tWordDataset,cpReferenceName,tRefObject ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_save( tWordDataset ) ) ;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tWordDataset, false ) ) ;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				DNVGL_TRACE_CALL( iStatus = AOM_lock( tWordDataset) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AE_import_named_ref( tWordDataset, cpRefName, strEformWordFilePath.c_str(), NULL, SS_BINARY ) ) ; 
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tWordDataset ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tWordDataset, false ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( !isDatasetExists )
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation( tSurveyorCheklistRev, tWordDataset, TC_ATTACHES_RELATION) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
				//Attach to surveyor Checklist 
				if( tWordDataset != NULLTAG && tSurveyorCheklistRev != NULLTAG )
				{
					tag_t tReleaseStatus = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = RELSTAT_create_release_status( AP4_ISSUED, &tReleaseStatus ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = RELSTAT_add_release_status( tReleaseStatus, 1, &tSurveyorCheklistRev, true ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}
		}
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE( cpReferenceName );
	free(wordCppObj);

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_create_surveyor_checklist.cxx
* \par  Description :
This function will get the Surveyor Checklist revision.
* \verbatim
\endverbatim     
* \param[in]   tSurveyorPkg				Input Surveyor Package Folder
* \param[out]  tSurveyorCheckListRev	Surveyor checklist latest revision
* \par Algorithm:
* \verbatim  
a. Get Surveyor Checklist from Surveyor Package
b. If Surveyor Checklist does not exists , create new Surveyor Checklist attach to Sorveyor Package
c. If present then , get the latest working Surveyor Checklist revision.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name					   Description of Change
* 04-Apr-2017      Chetan Kekade	       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_get_working_surveyor_checklist(tag_t tSurveyorPkg,tag_t tDeliverableTmpl, tag_t* tSurveyorCheckListRev)
{
	int		iStatus					= ITK_ok	;
	tag_t*  pptSecondaryObjects		= NULL		;
	tag_t*  pptRelationObjects		= NULL		;
	int     iSecondaryCount			= NULL		;
	tag_t   tAdminFolder			= NULLTAG	;

	DNVGL_TRACE_ENTER();
	try{
		//Get the Surveyor Checklist from Surveyor Packege if exists otherwise create new Surveyor checklist: starts
		tag_t   tSCheklist = NULLTAG  ;
		tag_t   tSCheklistRev = NULLTAG  ;
		tag_t   tSCheklistRevLatest	= NULLTAG  ;
		tag_t   tDoc= NULLTAG  ;
		std::vector<tag_t> vSCheckList;
		DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type( tSurveyorPkg , AP4_SURVEYOR_CHEKLST_RELATION, AP4_DELIVERABLE, vSCheckList ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Create new comment letter if count is 0 
		if( vSCheckList.empty() || vSCheckList.size() == 0)
		{
			tag_t   tCreateInput	= NULLTAG			;
			tag_t   tSCheklistType	= NULLTAG			;
			const char	*cpSCheklistName	= SURVEYOR_CHEKLIST_NAME ;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_DELIVERABLE, AP4_DELIVERABLE, &tSCheklistType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tSCheklistType, &tCreateInput) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_set_create_display_value(tCreateInput, OBJECT_NAME , 1, &cpSCheklistName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// Needs to get the Compulsory attributes for Delieverable like template type and version from delieverable template.
			char * cpTemplateType = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tDeliverableTmpl, AP4_TEMPLATETYPE , &cpTemplateType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			const char * ccpTemplateType = cpTemplateType;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_set_create_display_value( tCreateInput, AP4_TEMPLATETYPE , 1, &ccpTemplateType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char * cpVersion = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tDeliverableTmpl, AP4_VERSION, &cpVersion) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			const char * ccpVersion = cpVersion;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_set_create_display_value( tCreateInput, AP4_VERSION , 1, &ccpVersion ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus =TCTYPE_create_object ( tCreateInput , &tSCheklist) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(  iStatus = AOM_save( tSCheklist )) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tSCheklist, false ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation( tSurveyorPkg, tSCheklist, AP4_SURVEYOR_CHEKLST_RELATION) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tSCheklist , &tSCheklistRevLatest) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			*tSurveyorCheckListRev = tSCheklistRevLatest;
		}
		else
		{
			//if comment letter exists get the latest working revision 
			tSCheklist = vSCheckList[0]; 
			DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tSCheklist , &tSCheklistRev) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;	

			tag_t *refTag = NULLTAG ;
			int iRefcount = NULLTAG ;
			bool bIsReleased = false ;
			DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tags( tSCheklistRev, RELEASE_STATUS_LIST, &iRefcount, &refTag ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iRefcount; index++ )
			{						
				char* cpReleaseStatus = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( refTag[index], OBJECT_NAME, &cpReleaseStatus ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;	

				if( cpReleaseStatus != NULL && tc_strcmp( cpReleaseStatus, AP4_ISSUED ) == 0 )
				{
					//Create new revision if latest revision is released
					DNVGL_TRACE_CALL( iStatus = ITEM_copy_rev( tSCheklistRev , NULL , &tSCheklistRevLatest) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;	

					DNVGL_TRACE_CALL( iStatus = AOM_save( tSCheklistRevLatest ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tSCheklistRevLatest, false ) ) ;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					bIsReleased = true ;
					break ;
				}	
			}

			if(bIsReleased)
			{
				*tSurveyorCheckListRev = tSCheklistRevLatest;		
			}
			else
			{
				*tSurveyorCheckListRev = tSCheklistRev;
			}
		}
		//Get the comment letter from tech doc if exists otherwise create comment letter: ends
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE(pptSecondaryObjects);
	DNVGL_MEM_FREE(pptRelationObjects);

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}
