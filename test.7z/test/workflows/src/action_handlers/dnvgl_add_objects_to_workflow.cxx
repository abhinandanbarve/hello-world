/**
* \file dnvgl_add_objects_to_workflow.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This file contains the action handler which adds the project revision to the workflow as target or reference based on the passed argument.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Durga D
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 14-Nov-2016   Durga D               Initial creation.
* 12-Dec-2016   Vinay Kudari          Support for all the newly added document types. Hence allow all the children of AP4_DocumentRevision.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

int dnvgl_add_objects_to_workflow( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok   ;	

	DNVGL_TRACE_ENTER();
	try
	{		
		int			iTargetCount					= 0		   ;
		int         iCount                           = 0        ;
		int         iAttachment                      = 0        ;

		char*		cpObjectType					= NULL	   ;
		char*		cpArgValue						= NULL		;
		char*		cpTypeArg						= NULL		;
		char*		cpValue							= NULL		;

		std::string sAttachmentType;

		tag_t		tRootTaskTag					= NULLTAG  ;
		tag_t       *tPrimaryObjects                = NULL;
		tag_t       tProjectRev                     = NULLTAG;
		tag_t       tRelationtype                   = NULLTAG  ;
		tag_t       tItem                           = NULLTAG  ;
		tag_t		*tpTargetTags					= NULL;

		//Clear the error stack.
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Read the handler arguments.
		while( ( cpArgValue = TC_next_argument( msg.arguments ) ) != NULL )
		{
			iStatus = ITK_ask_argument_named_value( cpArgValue, &cpTypeArg, &cpValue );
			if( cpValue != NULL )
			{
				if( strcmp( cpTypeArg, ATTACHMENT_TYPE ) == 0 )
				{
					sAttachmentType.assign( cpValue );

					if( tc_strcasecmp( sAttachmentType.c_str(), "reference" ) == 0 )
					{
						iAttachment = EPM_reference_attachment;
					}
					else if( tc_strcasecmp( sAttachmentType.c_str(), "target" ) == 0 )
					{
						iAttachment = EPM_target_attachment;
					}
					else
					{
						iStatus = ERROR_919134;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}				
			}
		}

		if( iAttachment == 0 )
		{
			iStatus = ERROR_919135;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		//Ask the root task tag
		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Ask the attachments
		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Checking the AP4_ProjectDocRevision object
		for( int i = 0; i < iTargetCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpTargetTags[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tDocRevType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_DOCUMENT_REVISION, AP4_DOCUMENT_REVISION, &tDocRevType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tDocRevType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( bIsValidType )
			{
				DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tpTargetTags[i], &tItem ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Relation b/n projectdoc item and Governing Documents
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_DOCUMENT_RELATION, &tRelationtype ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Lists the Governing Documents Folder
				DNVGL_TRACE_CALL( iStatus = GRM_list_primary_objects_only( tItem, tRelationtype, &iCount, &tPrimaryObjects ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//ap4_project_backpointer property contains the AP4_ProjectRevision Tag
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tPrimaryObjects[0], AP4_PROJECT_BACKPOINTER, &tProjectRev ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Attachs the AP4_ProjectRevision as Target or Reference to the workflow
				DNVGL_TRACE_CALL( iStatus = EPM_add_attachments( tRootTaskTag, 1, &tProjectRev, &iAttachment ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				break;
			}
		}

		DNVGL_MEM_FREE( tpTargetTags );
		DNVGL_MEM_FREE( tPrimaryObjects );
	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}