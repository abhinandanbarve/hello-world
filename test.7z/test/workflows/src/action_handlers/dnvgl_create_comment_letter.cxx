/**
* \file dnvgl_create_comment_letter.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This File  contains the functions which are called to create comment letter 
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra  
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 30-Nov-2016   Nikhilesh Khatra      Initial creation.
*--------------------------------------------------------------------------------
*/
#include "dnvgl_workflows.h"
using namespace std;

/**
* \file dnvgl_create_comment_letter.cxx
* \par  Description :
This function will create comment letter with bookmarks value and commentary table.
It will attach comment letter to comment letter document.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Import the comment letter template to temp location
b. Update bookmark values in comment letter using mapping dataset for comment letter
c. Get all the comment chain associated with document revision
d. Create input for comment letter generation
e. Generate comment letter with commentary table
f. Protect comment letter with password(UID of technical document)
g. Attach comment letter to comment letter revision
h. Attach comment letter revision to technical document revision
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 30-Nov-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_comment_letter( EPM_action_message_t msg )
{
	int	    iStatus					= ITK_ok	;
	int		iTargetCount			= 0			;
	int		iObjectCount			= 0			;	
	char	*cpObjectType			= NULL		;
	char	*cpDatasetName			= NULL		;
	char    *cpReferenceName		= NULL		;
	char    *cpOriginalFileName		= NULL		;
	char	*cpDocRevUID			= NULL		;
	char	*cpIsFinal				= NULL		;
	char	*cpDocumentType			= NULL		;
	char	*cpDocumentCategory		= NULL		;
	char	*cpTemplateVersion		= NULL		;
	tag_t   tRootTaskTag			= NULLTAG   ;
	tag_t	*tpTargetTags			= NULL		;
	tag_t   tDocRevTag				= NULLTAG	;
	tag_t   tRefObjectTag			= NULLTAG	;
	tag_t   tWordTemplateDatasetTag = NULLTAG	;
	tag_t   tWordDatasetTag         = NULLTAG	;
	tag_t	tStructRelTag	        = NULLTAG	;
	tag_t*	tpRelatedTags	        = {NULLTAG} ;
	AE_reference_type_t       aeReferenceType;
	string strTempFolderPath = "";
	boolean bIsTempFolderCreated = false ;
	bool    bIsWordDatasetExist = false;
	OfficeInterop::WordCppService *eFormObj		= NULL	;
	OfficeInterop::WordCppService *wordCppObj	= NULL	;
	DNVGL_TRACE_ENTER();
	try
	{
		AM__set_application_bypass( true );
		POM_AM__set_application_bypass( true );

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task(msg.task, &tRootTaskTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments(tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( dnvgl_get_handler_opts( msg.arguments, IS_FINAL, &cpIsFinal, NULL ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpTargetTags[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tDocRevType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_TECH_DOC_REVISION, AP4_TECH_DOC_REVISION, &tDocRevType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tDocRevType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !bIsValidType )
			{
				continue;
			}

			tDocRevTag = tpTargetTags[i];

			//Get the doc tag from doc rev
			tag_t   tDocTag	 = NULLTAG  ;
			DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tDocRevTag, &tDocTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tPrimaryTypeTag = NULLTAG;  
			DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( AP4_PROJECT_FOLDER , &tPrimaryTypeTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_DOCUMENT_RELATION , &tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(iStatus =  GRM_list_primary_objects_only( tDocTag, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t   tFolderTag	 = NULLTAG  ;
			for ( int index = 0; index < iObjectCount; index++ )
			{			
				bool bIsInstance = false;
				tag_t tInputObjectType = NULLTAG;

				DNVGL_TRACE_CALL( iStatus = POM_class_of_instance(tpRelatedTags[index], &tInputObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = POM_is_descendant( tPrimaryTypeTag, tInputObjectType, &bIsInstance) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( bIsInstance )
				{									
					tFolderTag = tpRelatedTags[index];
					break;
				}			
			}

			tag_t   tProjectRevTag	 = NULLTAG  ;
			if(tFolderTag != NULLTAG)
			{
				DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tFolderTag, AP4_PROJECT_BACKPOINTER , &tProjectRevTag ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				//need to throw error that doc is not attached to any folder
				iStatus = ERROR_919137;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			//Get the word dataset template from Comment letter template
			DNVGL_TRACE_CALL ( iStatus = dnvgl_get_comment_template_dataset( tProjectRevTag, &cpTemplateVersion, &tWordTemplateDatasetTag ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tCommentRevLatestTag = NULLTAG;
			DNVGL_TRACE_CALL ( iStatus = dnvgl_get_working_comment_letter_revision( tDocRevTag,cpTemplateVersion, &tCommentRevLatestTag ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Get the comment letter dataset from tech doc rev if exists: starts
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION , &tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus =  GRM_list_secondary_objects_only( tCommentRevLatestTag ,tStructRelTag,&iObjectCount,&tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iObjectCount; index++ )
			{						
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, MSWORDX_DATASET ) == 0 )
				{
					tWordDatasetTag = tpRelatedTags[index];
					bIsWordDatasetExist = true ;
					break ;
				}	
			}
			//Get the comment letter dataset from tech doc rev if exists: ends

			//Export the attached word to temp location
			DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tWordTemplateDatasetTag , 0 , &cpReferenceName , &aeReferenceType , &tRefObjectTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tRefObjectTag, ORIGINAL_FILE_NAME , &cpOriginalFileName) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			const char* cpTempPath;
			cpTempPath = getenv (TEMP_ENV_VAR);

			char*       timestamp = NULL;
			string dirTimeStamp;

			DNVGL_TRACE_CALL( iStatus = DNVGL_current_get_time_stamp(DATE_FORMAT_STR_FOOTER,&timestamp) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			dirTimeStamp = timestamp;
			//delFolderPath = strExcelFilePath;
			strTempFolderPath = cpTempPath ;
			strTempFolderPath.append("\\");
			strTempFolderPath.append(dirTimeStamp);

			DNVGL_TRACE_CALL( iStatus = _mkdir( strTempFolderPath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//temp folder for eform output
			string strTempEformFolderPath= strTempFolderPath;
			strTempEformFolderPath.append("\\");
			strTempEformFolderPath.append( "eForm" ); 

			DNVGL_TRACE_CALL( iStatus = _mkdir( strTempEformFolderPath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			string strEformWordFilePath= strTempEformFolderPath;
			strEformWordFilePath.append("\\");
			strEformWordFilePath.append(cpOriginalFileName); 

			bIsTempFolderCreated = true ; 
			string strWordFilePath= strTempFolderPath;
			strWordFilePath.append("\\");
			strWordFilePath.append(cpOriginalFileName); 

			DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tWordTemplateDatasetTag,cpReferenceName,strWordFilePath.c_str()));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( ITK__convert_tag_to_uid( tDocRevTag, &cpDocRevUID ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tCommLetter = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tCommentRevLatestTag, &tCommLetter ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommLetter, AP4_TEMPLATETYPE, &cpDocumentType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommLetter, AP4_VERSION, &cpDocumentCategory ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tDatasetTag = NULLTAG;
			std::string strEformID;
			std::string strEformDocType;
			std::string strDatasetType;

			DNVGL_TRACE_CALL( iStatus = dnvgl_get_eform_dataset_info( cpDocumentType, cpDocumentCategory, strEformID, strEformDocType, strDatasetType, &tDatasetTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			std::vector<std::string> vTableBookmarks ;
			DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_letter_bookmarks( DNVGL_COMMENT_LETTER_TABLE_BOOKMAKRS, strEformID.c_str(), vTableBookmarks ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			string strDrawingBookmark  ;
			if( vTableBookmarks.size() == 2 )
			{
				strDrawingBookmark = vTableBookmarks[1] ;
			}
			else
			{
				strDrawingBookmark = "" ;
			}


			//efrom call
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_wordinterop_object(wordCppObj,strWordFilePath.c_str()) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			string strEncodedWordData ;
			char* cpEncodeDataMsg  = NULL;
			iStatus= wordCppObj->GetEncodedData(strEncodedWordData, &cpEncodeDataMsg);

			std::vector<tag_t> vTechDocs;
			vTechDocs.push_back(tDocRevTag);
			//Update bookmarks
			DNVGL_TRACE_CALL( iStatus = dnvgl_update_bookmarks_from_eform(vTechDocs, tCommentRevLatestTag, strEncodedWordData, strEformWordFilePath, strTempFolderPath, strDrawingBookmark) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//convert feteched data which can be input for createCommentTable
			bool bIsFinal = false ;
			if(cpIsFinal != NULL && (tc_strcmp( cpIsFinal, "true" ) == 0))
			{
				bIsFinal = true ;
			}

			char* cpEditableMessage  = NULL;
			std::vector<std::string> vEditableBookmarks ;
			//Featch comment data from doc rev tag
			std::vector<std::vector<std::string>> vCommentChainForInterop;
			std::vector<std::vector<std::string>> vDocDataForInterop ;
			int iTableCount = 0 ;

			//vTechDocs.push_back(tDocRevTag);

			DNVGL_TRACE_CALL( iStatus =  dnvgl_get_input_for_comment_letter( vTechDocs, bIsFinal, cpTemplateVersion, vCommentChainForInterop, vDocDataForInterop, iTableCount) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//OfficeInterop::WordCppService obj( strEformWordFilePath.c_str() );
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_wordinterop_object( eFormObj,strEformWordFilePath.c_str()) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char* cpCreateMessage  = NULL;
			iStatus = eFormObj->CreateCommentTable( vTableBookmarks[0].c_str() ,vCommentChainForInterop, vDocDataForInterop, iTableCount, bIsFinal, &cpCreateMessage );

			if( iStatus!=0 )
			{
				//Need to add custom error
				TC_write_syslog("\n Interop Caused following error = %s",cpCreateMessage);
				iStatus = ERROR_919139;
				EMH_store_error_s1(EMH_severity_error,ERROR_919139,cpCreateMessage);
				DNVGL_LOG_ERROR_AND_THROW_STATUS ;
			}

			DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_letter_bookmarks( DNVGL_COMMENT_LETTER_EDITABLE_BOOKMAKRS, strEformID.c_str(), vEditableBookmarks ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			iStatus = eFormObj->MakeBookmarksEditable(vEditableBookmarks, &cpEditableMessage);

			if( iStatus!=0 )
			{
				//Need to add custom error
				TC_write_syslog("\n Interop Caused following error = %s",cpEditableMessage);
				iStatus = ERROR_919160;
				EMH_store_error_s1(EMH_severity_error,ERROR_919160,cpEditableMessage);
				DNVGL_LOG_ERROR_AND_THROW_STATUS ;
			}

			char* cpProtectMessage  = NULL;
			iStatus = eFormObj->ApplyDocumentProtection(cpDocRevUID, &cpProtectMessage);

			if( iStatus!=0 )
			{
				//Need to add custom error
				TC_write_syslog("\n Interop Caused following error = %s",cpProtectMessage);
				iStatus = ERROR_919140;
				EMH_store_error_s1(EMH_severity_error,ERROR_919140,cpProtectMessage);
				DNVGL_LOG_ERROR_AND_THROW_STATUS ;
			}

			// file import as dataset
			tag_t tDatasetTypeTag = NULLTAG ;
			DNVGL_TRACE_CALL( iStatus = AE_find_datasettype2( MSWORDX_DATASET , &tDatasetTypeTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char** cpRefList = NULL;
			char* cpRefName = NULL;
			int    iRefCount = 0   ;
			DNVGL_TRACE_CALL( iStatus = AE_ask_datasettype_refs (tDatasetTypeTag, &iRefCount, &cpRefList) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			//Setting reference name for dataset creation e.g. setting "word" for docx type fo file
			cpRefName = cpRefList[0];
			MEM_free (cpRefList);

			char* cpWordDatasetName = COMMENT_LETTER ;

			if( tc_strcmp( TRN_TEXT, cpTemplateVersion ) == 0 )
			{
				cpWordDatasetName  =  TRN_NAME;
			}

			if(tWordDatasetTag == NULL)
			{
				DNVGL_TRACE_CALL( iStatus = AE_create_dataset_with_id(	tDatasetTypeTag, // aDatasetType
					cpWordDatasetName, // aDatasetName
					NULL, // aDatasetDescription
					NULL, // aDatasetId
					NULL, // aDatasetRev
					&tWordDatasetTag )); // aNewDataset
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				//remove old one

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tWordDatasetTag, true ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tWordDatasetTag ,0 ,&cpReferenceName ,&aeReferenceType ,&tRefObjectTag));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus =  AE_remove_dataset_named_ref_by_tag2 ( tWordDatasetTag,cpReferenceName,tRefObjectTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tWordDatasetTag ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tWordDatasetTag, false ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			DNVGL_TRACE_CALL( iStatus = AOM_lock( tWordDatasetTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AE_import_named_ref(	tWordDatasetTag, // datasetTag
				cpRefName, // referenceName
				strEformWordFilePath.c_str(), // osFullPathName
				NULL, // newFileName
				SS_BINARY ) ) ; // fileTypeFlag
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( tWordDatasetTag ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tWordDatasetTag, false ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Dataset  creation ends

			//Attach to doc rev starts
			if(!bIsWordDatasetExist)
			{
				DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation( tCommentRevLatestTag, tWordDatasetTag, TC_ATTACHES_RELATION) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			if( bIsFinal )
			{
				tag_t tReleaseStatus = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = RELSTAT_create_release_status( AP4_ISSUED, &tReleaseStatus ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = RELSTAT_add_release_status( tReleaseStatus, 1, &tCommentRevLatestTag, true ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch( ... )
	{
	}
	//Free memory
	DNVGL_MEM_FREE(cpReferenceName);
	DNVGL_MEM_FREE(tpTargetTags);
	DNVGL_MEM_FREE(tpRelatedTags);
	DNVGL_MEM_FREE(cpObjectType);
	DNVGL_MEM_FREE(cpOriginalFileName);
	DNVGL_MEM_FREE(cpDatasetName);
	DNVGL_MEM_FREE(cpDocRevUID);
	DNVGL_MEM_FREE(cpDocumentType);
	DNVGL_MEM_FREE(cpDocumentCategory);
	DNVGL_MEM_FREE(cpTemplateVersion);
	free(wordCppObj);
	free(eFormObj);

	//Delete the folder	
	if(bIsTempFolderCreated)
	{
		string strTempFolderDeleteCmd = "" ;

		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );	
	}

	AM__set_application_bypass( false );
	POM_AM__set_application_bypass( false );

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}



/**
* \file dnvgl_create_comment_letter.cxx
* \par  Description :
This function will get the comment letter template dataset.
* \verbatim
\endverbatim     
* \param[in]   tProjectRevTag					Project revision
* \param[out]  tpCommentTempDatasetTag			Word dataset
* \par Algorithm:
* \verbatim  
a. Goto Admin folder from project revision by project structure relation
b. Get Comment Letter Template and from template get latest revision
c. Get Word dataset from Comment letter template revision
d. Return Word dataset

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 14-Dec-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_get_comment_template_dataset(tag_t tProjectRevTag, char** cpTemplateVesion, tag_t* tpCommentTempDatasetTag){

	int		iStatus					= ITK_ok	;
	tag_t*  pptSecondaryObjects		= NULL		;
	tag_t*  pptRelationObjects		= NULL		;
	int     iSecondaryCount			= NULL		;
	tag_t   tAdminFolderTag			= NULLTAG	;
	char*   cpDocumentType			= NULL		;
	DNVGL_TRACE_ENTER();

	try{
		//Get the admin folder by AP4_PROJECT_STRUCTURE_RELATION relation : starts
		DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tProjectRevTag , AP4_PROJECT_STRUCTURE_RELATION , AP4_GOVERNING_DOCUMENT, &pptSecondaryObjects, &pptRelationObjects, &iSecondaryCount) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if(iSecondaryCount == 0)
		{
			//need to throw error that admin folder is not exists.
			iStatus = ERROR_919142;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			tAdminFolderTag = pptSecondaryObjects[0]; 
		}
		//Get the admin folder : ends

		//Get the comment letter template from Admin folder : starts
		tag_t   tCommTemplateTag	 = NULLTAG  ;
		tag_t   tCommTemplateRevTag  = NULLTAG  ;

		bool bIsCommTemplateFound = false ;
		DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tAdminFolderTag , AP4_DOCUMENT_RELATION , AP4_MANAGEMENT, &pptSecondaryObjects, &pptRelationObjects, &iSecondaryCount) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for ( int index = 0; index < iSecondaryCount; index++ )
		{								
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( pptSecondaryObjects[index], AP4_TEMPLATETYPE, &cpDocumentType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpDocumentType != NULL && tc_strcmp( cpDocumentType, MANA_COMMLETTERTEMPLATE ) == 0 )
			{
				bIsCommTemplateFound = true ;
				tCommTemplateTag = pptSecondaryObjects[index]; 

				DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev(tCommTemplateTag , &tCommTemplateRevTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;	
				break ;
			}	
		}

		if( !bIsCommTemplateFound )
		{
			//need to throw error that comment letter template is not attached
			iStatus = ERROR_919141;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommTemplateTag, AP4_VERSION, cpTemplateVesion ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		//Get the comment letter template from Admin folder :ends

		//Get the template dataset from project rev : starts
		DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tCommTemplateRevTag , TC_ATTACHES_RELATION , MSWORDX_DATASET, &pptSecondaryObjects, &pptRelationObjects, &iSecondaryCount) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if(iSecondaryCount == 0)
		{
			//need to throw error that comment letter template dataset is not attached
			iStatus = ERROR_919138;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			* tpCommentTempDatasetTag = pptSecondaryObjects[0]; 
		}
		//Get the template dataset from project rev : ends
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE(pptSecondaryObjects);
	DNVGL_MEM_FREE(pptRelationObjects);
	DNVGL_MEM_FREE( cpDocumentType );

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_create_comment_letter.cxx
* \par  Description :
This function will get the comment letter template dataset.
* \verbatim
\endverbatim     
* \param[in]   tDocRevTag					Input technical document revision
* \param[out]  tpCommentRevLatestTag		Comment Revision latest tag
* \par Algorithm:
* \verbatim  
a. Get Comment Letter object from Tech doc
b. If comment letter does not exists , create new Comment letter attach to tech doc
c. Attach new comment letter rev to tech doc rev 
d. Return Word dataset

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 14-Dec-2016      Nikhilesh Khatra       Initial creation.
* 27-Apr-2017      Nikhilesh Khatra       Replace AP4_CommLetter with AP4_Deliverable.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_get_working_comment_letter_revision(tag_t tDocRevTag, const char	*cpVersion, tag_t* tpCommentRevLatestTag){

	int		iStatus					= ITK_ok	;
	tag_t*  pptSecondaryObjects		= NULL		;
	tag_t*  pptRelationObjects		= NULL		;
	int     iSecondaryCount			= NULL		;
	tag_t   tAdminFolderTag			= NULLTAG	;
	char*   cpDocumentType			= NULL		;
	char*   cpCommLetterVersion		= NULL		;

	DNVGL_TRACE_ENTER();

	try{
		//Get the comment letter from tech doc if exists otherwise create comment letter: starts
		tag_t   tCommentTag				= NULLTAG  ;
		tag_t   tCommentRevTag			= NULLTAG  ;
		tag_t   tCommentRevLatestTag	= NULLTAG  ;
		tag_t   tDocTag					= NULLTAG  ;
		bool	bIsCommLetterFound		= false	   ;
		DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tDocRevTag, &tDocTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tDocTag , AP4_COMMENTLETTERRELATION , AP4_DELIVERABLE, &pptSecondaryObjects, &pptRelationObjects, &iSecondaryCount) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for ( int index = 0; index < iSecondaryCount; index++ )
		{								
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( pptSecondaryObjects[index], AP4_TEMPLATETYPE, &cpDocumentType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( pptSecondaryObjects[index], AP4_VERSION, &cpCommLetterVersion ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpDocumentType != NULL && tc_strcmp( cpDocumentType, DELI_COMMLETTER ) == 0 && tc_strcmp( cpCommLetterVersion, cpVersion ) == 0 )
			{
				bIsCommLetterFound = true ;
				tCommentTag = pptSecondaryObjects[index]; 

				DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tCommentTag , &tCommentRevTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;	
				break ;
			}	
		}
		//Create new comment letter if count is 0 
		if( !bIsCommLetterFound )
		{
			tag_t   tCreatedInputTag			= NULLTAG				;
			tag_t   tCommentTypeTag				= NULLTAG				;
			const char	*cpCommentObjectName	= COMMENT_LETTER_NAME	;
			const char	*cpTemplateType			= DELI_COMMLETTER		;

			if( tc_strcmp( TRN_TEXT, cpVersion ) == 0 )
			{
				cpCommentObjectName  =  TRN_NAME;
			}
			else if( tc_strcmp( VAR_TEXT, cpVersion ) == 0 )
			{
				cpCommentObjectName  =  VAR_NAME;
			}
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_DELIVERABLE, AP4_DELIVERABLE, &tCommentTypeTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tCommentTypeTag, &tCreatedInputTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_set_create_display_value(tCreatedInputTag , OBJECT_NAME , 1, &cpCommentObjectName) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_set_create_display_value(tCreatedInputTag , AP4_TEMPLATETYPE , 1, &cpTemplateType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_set_create_display_value(tCreatedInputTag , AP4_VERSION , 1, &cpVersion) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus =TCTYPE_create_object ( tCreatedInputTag , &tCommentTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(  iStatus = AOM_save( tCommentTag )) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCommentTag, false ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation( tDocTag, tCommentTag, AP4_COMMENTLETTERRELATION ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tCommentTag , &tCommentRevTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation( tDocRevTag, tCommentRevTag, AP4_COMMENTLETTERRELATION ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			*tpCommentRevLatestTag = tCommentRevTag ;
		}
		else
		{
			tag_t *refTag = NULLTAG ;
			int iRefcount = NULLTAG ;
			bool bIsReleased = false ;
			DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tags( tCommentRevTag, RELEASE_STATUS_LIST, &iRefcount, &refTag ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( iRefcount>0 )
			{
				//Create new revision if latest revision is released
				DNVGL_TRACE_CALL( iStatus = ITEM_copy_rev( tCommentRevTag , NULL , &tCommentRevLatestTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;	

				DNVGL_TRACE_CALL( iStatus = AOM_save( tCommentRevLatestTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCommentRevLatestTag, false ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation( tDocRevTag, tCommentRevLatestTag, AP4_COMMENTLETTERRELATION ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				bIsReleased = true ;
			}	

			if(bIsReleased)
			{
				*tpCommentRevLatestTag = tCommentRevLatestTag ;		
			}
			else
			{
				*tpCommentRevLatestTag = tCommentRevTag ;
			}
		}
		//Get the comment letter from tech doc if exists otherwise create comment letter: ends
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE(pptSecondaryObjects);
	DNVGL_MEM_FREE(pptRelationObjects);
	DNVGL_MEM_FREE(cpDocumentType);

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_create_comment_letter.cxx
* \par  Description :
This function will update bookmarks in comment letter.
* \verbatim 
\endverbatim     
* \param[in]   tDocRevTag					Input technical document revision
* \param[in]   tCommLetterRev				Comment letter revision
* \param[in]   strEncodedWordData		    Word encoded data
* \param[in]   strEformWordFilePath		    Comment letter word file path 
* \param[in]   strTempFolderPath		    Temp folder path
* \param[in]   strDrawingTableBookmark		Drawing bookmark
* \par Algorithm:
* \verbatim  
a. Get Comment Letter mapping dataset
b. Get attribute mapping list from mapping dataset
c. Fetch values from TC for mapping list
d. Create eForm request
e. Call eForm service

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 14-Mar-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_update_bookmarks_from_eform(std::vector<tag_t> vDocRevs, tag_t tCommLetterRev,string strEncodedWordData, string strEformWordFilePath, string strTempFolderPath, string strDrawingTableBookmark){

	int		iStatus					= ITK_ok	;
	tag_t*  pptSecondaryObjects		= NULL		;
	tag_t*  pptRelationObjects		= NULL		;
	int     iSecondaryCount			= NULL		;
	tag_t   tDatasetTag				= NULLTAG	;

	char * cpDocumentType			= NULL		;
	char * cpDocumentCategory		= NULL		;

	DNVGL_TRACE_ENTER();

	try{
		tag_t tCommLetter = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tCommLetterRev, &tCommLetter ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommLetter, AP4_TEMPLATETYPE, &cpDocumentType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommLetter, AP4_VERSION, &cpDocumentCategory ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tDatasetTag = NULLTAG;
		std::string cpEformID;
		std::string cpEformDocType;
		std::string cpDatasetType;

		DNVGL_TRACE_CALL( iStatus = dnvgl_get_eform_dataset_info( cpDocumentType, cpDocumentCategory, cpEformID, cpEformDocType, cpDatasetType, &tDatasetTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tDatasetTag != NULL && tDatasetTag != NULLTAG )
		{
			std::vector<std::string> vData;
			DNVGL_TRACE_CALL( iStatus = dnvgl_read_mapping_dataset( tDatasetTag ,strTempFolderPath ,vData ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// create request xml
			tinyxml2::XMLDocument xmlRequest;

			DNVGL_TRACE_CALL( iStatus = dnvgl_get_request_xml( vDocRevs[0], vData, xmlRequest ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//XML replace value of "NEWELEMENT.DELETE" with "<delete></delete>": start
			tinyxml2::XMLPrinter printer;
			xmlRequest.Print( &printer );
			std::string xmlString = printer.CStr();

			string strDeleteMapping = DELETE_MAPPING_VALUE ;
			string strDeleteTag     = DELETE_TAG		   ;
			size_t deleteMappingPos = 0;

			while( ( deleteMappingPos = xmlString.find(strDeleteMapping, deleteMappingPos)) != std::string::npos ) {
				xmlString.replace(deleteMappingPos, strDeleteMapping.length(), strDeleteTag);
				deleteMappingPos += strDeleteTag.length();
			}

			tinyxml2::XMLDocument replacedXmlReq;
			tinyxml2::XMLError xmlError= replacedXmlReq.Parse(xmlString.c_str());
			//XML replace value of "NEWELEMENT.DELETE" with "<delete></delete>": ends

			if(xmlError != tinyxml2::XML_SUCCESS)
			{
				TC_write_syslog("\n Interop Caused following error = %s",xmlError);
				iStatus = ERROR_919168;
				EMH_store_error( EMH_severity_error, ERROR_919168 );
				DNVGL_LOG_ERROR_AND_THROW_STATUS ;
			}
			//XML replace valuer of : end

			//Add document as input to request xml : starts
			tinyxml2::XMLElement *docElement = replacedXmlReq.NewElement( DOCUMENT_TAG );
			docElement->SetText(strEncodedWordData.c_str());

			string strInstuction = INSTRUCTION_TAG ;
			DNVGL_TRACE_CALL( iStatus = dnvgl_add_xml_element(replacedXmlReq, docElement, strInstuction) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			//Add document as input to request xml : ends

			//vDocRevs.push_back(tTechDocRev);
			if (strDrawingTableBookmark.compare("") != 0)
			{
				tinyxml2::XMLNode *tableNode = nullptr;
				string strTextElements= TEXTELEMENTS_TAG ;

				DNVGL_TRACE_CALL( iStatus = dnvgl_create_document_table_node(vDocRevs, strDrawingTableBookmark, replacedXmlReq, &tableNode) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = dnvgl_add_xml_element(replacedXmlReq, tableNode, strTextElements) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			DNVGL_TRACE_CALL( iStatus = dnvgl_eform_service_call( cpEformID, cpEformDocType, strEformWordFilePath, replacedXmlReq ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE(cpDocumentType);
	DNVGL_MEM_FREE(cpDocumentCategory);

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_create_comment_letter.cxx
* \par  Description :
This function will update bookmarks in comment letter.
* \verbatim 
\endverbatim     
* \param[in]   vDocRevs						Input technical document revision
* \param[in]   strDrawingTableBookmark		Drawing bookmark
* \param[in]   doc							Eform Request
* \param[out]  newNode						New node 

* \par Algorithm:
* \verbatim  
a. Iterate on each tech doc rev
b. Create row structure for every tech doc rev
c. Create table structure

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 24-Mar-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_document_table_node(std::vector<tag_t> &vDocRevs, string strDrawingTableBookmark, tinyxml2::XMLDocument &doc, tinyxml2::XMLNode **newNode)
{
	int		iStatus					= ITK_ok	;

	tag_t   tTechDoc				= NULLTAG	;
	tag_t   tTechDocRev				= NULLTAG	;

	char* cpCusDocNo				= NULL		;
	char* cpCusDocRevNo				= NULL		;
	char* cpTechDocId				= NULL		;
	char* cpTechDocRevName			= NULL		;
	char* cpDocStatusCode			= NULL		;
	char* cpDocStatus				= NULL		;

	std::vector<std::string> vDocRevAttribute ;
	DNVGL_TRACE_ENTER();

	try{
		*newNode = doc.NewElement("Text");

		tinyxml2::XMLElement * bookmarkElement = doc.NewElement( BOOKMARK_TAG );
		bookmarkElement->SetText(strDrawingTableBookmark.c_str());

		tinyxml2::XMLElement* valueElement = doc.NewElement( VALUE_TAG );
		valueElement->SetAttribute(TYPE_ATTRIBUTE,TABLE_ATTRIBUTE_VALUE);

		tinyxml2::XMLElement* tableElement = doc.NewElement( TABLE_TAG );

		for(int docSize =0; docSize<vDocRevs.size(); docSize++){
			vDocRevAttribute.clear();

			tinyxml2::XMLElement* rowElement = doc.NewElement( ROW_TAG );		

			tTechDocRev = vDocRevs[docSize];

			DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tTechDocRev, &tTechDoc ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_UIF_ask_value(tTechDoc, AP4_CUSTOMER_DOC_NO, &cpCusDocNo));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_UIF_ask_value(tTechDocRev, AP4_CUSTOMER_DOC_REV_NO, &cpCusDocRevNo));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_UIF_ask_value(tTechDoc, ITEM_ID, &cpTechDocId));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_UIF_ask_value(tTechDocRev, OBJECT_NAME, &cpTechDocRevName));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_UIF_ask_value(tTechDocRev, AP4_DOCUMENT_STATUS_CODE, &cpDocStatusCode));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_UIF_ask_value(tTechDocRev, AP4_DOCUMENT_STATUS, &cpDocStatus));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			vDocRevAttribute.push_back(cpCusDocNo);
			vDocRevAttribute.push_back(cpCusDocRevNo);
			vDocRevAttribute.push_back(cpTechDocId);
			vDocRevAttribute.push_back(cpTechDocRevName);
			vDocRevAttribute.push_back(cpDocStatusCode);
			vDocRevAttribute.push_back(cpDocStatus);

			for(int attrSize =0; attrSize<vDocRevAttribute.size(); attrSize++){
				tinyxml2::XMLElement* dataElement = doc.NewElement( DATA_TAG );	
				dataElement->SetText(vDocRevAttribute[attrSize].c_str());
				rowElement->LinkEndChild( dataElement );
			}
			tableElement->LinkEndChild( rowElement );
		}
		valueElement->LinkEndChild( tableElement );

		(*newNode)->InsertFirstChild(bookmarkElement);
		(*newNode)->LinkEndChild( valueElement );
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE(cpCusDocNo);
	DNVGL_MEM_FREE(cpCusDocRevNo);	
	DNVGL_MEM_FREE(cpTechDocId);	
	DNVGL_MEM_FREE(cpTechDocRevName);	
	DNVGL_MEM_FREE(cpDocStatusCode);	
	DNVGL_MEM_FREE(cpDocStatus);

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_create_comment_letter.cxx
* \par  Description :
This function will create input vector for creating commentary table.
* \verbatim
\endverbatim     
* \param[in]   vDocRevs							Input vector of technical document revision
* \param[in]   bIsFinal							Cooment letter is final or draft 
* \param[in]   objectType					    Object type
* \param[out]  vCommentChainForInterop			Vector with the all require commentary object
* \param[out]  vDocDataForInterop				Vector with the all require technical document attributes
* \param[out]  iTableCount						Table count in comment letter
* \par Algorithm:
* \verbatim  
a. Get all the comment chain associated with all the document revision 
b. Put verifird and external type of commentary object in out put vector
c. Return comment chain vetor

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 14-Dec-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

int dnvgl_get_input_for_comment_letter(std::vector<tag_t> vDocRevs, bool bIsFinal, std::string objectType, std::vector<std::vector<std::string>> &vCommentChainForInterop, std::vector<std::vector<std::string>> &vDocDataForInterop, int &iTableCount){

	int		iStatus					= ITK_ok	;
	int     iSecondaryCount			= 0			;
	int     iCommentCount			= 0			;
	char*	cpInternalVerification	= NULL		;
	char*	cpCommentStatus			= NULL		;
	char*	cpPage					= NULL		;
	char*	cpSection				= NULL		;
	char*	cpOwningUser			= NULL		;
	char*	cpDocName				= NULL		;
	char*	cpDocId					= NULL		;
	char*	cpDocRevId				= NULL		;
	char*	cpRichtext				= NULL		;
	char*	cpCommentaryName		= NULL		;
	char*	cpCommentDate			= NULL		;
	char*	cpCommentChainIndicator = NULL		;
	char*	cpCommentIndicator		= NULL		;

	tag_t*  tpSecondaryObjects		= NULL		;
	tag_t*  tpRelationObjects		= NULL		;
	tag_t*  tpComments				= NULL		;
	tag_t	tOwningUser				= NULL		;

	logical  lInternalRemark		= false		;
	date_t   dCommentDate			= NULLDATE	;
	std::vector< CommentChain > commentChain	;
	std::vector<std::string>         vTempDocAttribute ;
	std::vector<std::pair<tag_t, int>> vCommentChain ;
	bool     bIsChainAddedForTechDoc= false		;
	DNVGL_TRACE_ENTER();
	try{

		for( int idocSize = 0; idocSize < vDocRevs.size(); idocSize++ )
		{
			tag_t tCurrentDocRev =  vDocRevs[idocSize] ;
			bIsChainAddedForTechDoc = false ;
			if( tCurrentDocRev!= NULLTAG )			
			{
				vTempDocAttribute.clear();
				//Get All type of commentary object attached with tech doc rev
				DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tCurrentDocRev , AP4_COMMENT_CHAIN_RELATION , AP4_COMMENT_CHAIN, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCurrentDocRev , OBJECT_NAME , &cpDocName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if ((cpDocName == NULL) || (tc_strlen(cpDocName) < 1))
				{
					cpDocName = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
					tc_strcpy(cpDocName, "") ;
				}

				tag_t   tDocTag	 = NULLTAG  ;
				DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tCurrentDocRev, &tDocTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tDocTag , AP4_CUSTOMER_DOC_NO , &cpDocId) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if ((cpDocId == NULL) || (tc_strlen(cpDocId) < 1))
				{
					cpDocId = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
					tc_strcpy(cpDocId, "") ;
				}

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCurrentDocRev , AP4_CUSTOMER_DOC_REV_NO , &cpDocRevId) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if ((cpDocRevId == NULL) || (tc_strlen(cpDocRevId) < 1))
				{
					cpDocRevId = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
					tc_strcpy(cpDocRevId, "") ;
				}

				vTempDocAttribute.push_back(DOCUMENT_NAME);
				vTempDocAttribute.push_back(cpDocName);
				vTempDocAttribute.push_back(DOCUMENT_NO);
				vTempDocAttribute.push_back(cpDocId);
				vTempDocAttribute.push_back(DOCUMENT_REV);
				vTempDocAttribute.push_back(cpDocRevId);

				std::vector<std::string> vAttribute ;


				vCommentChain.clear();
				for( int icommChainLen = 0; icommChainLen < iSecondaryCount; icommChainLen++ )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_logical(tpSecondaryObjects[icommChainLen] , AP4_INTERNAL_REMARK , &lInternalRemark) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if(lInternalRemark)
					{
						continue ;
					}	

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpSecondaryObjects[icommChainLen] , AP4_STATUS , &cpCommentStatus) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpCommentStatus != NULL && tc_strcmp( cpCommentStatus, DRAFT_STATUS ) == 0 )
					{
						continue ;
					}

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpSecondaryObjects[icommChainLen] , AP4_PAGE , &cpPage) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					int iPageNo = std::stoi( cpPage ) ; 

					vCommentChain.push_back(std::pair<tag_t,int>( tpSecondaryObjects[icommChainLen], iPageNo ) );
				}

				if( tc_strcmp( TRN_TEXT, objectType.c_str() ) == 0)
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_comment_chains_for_trn( vCommentChain ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
				else
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_sort_comment_chain_by_page( vCommentChain ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}


				for( int icommChainLen = 0; icommChainLen < vCommentChain.size(); icommChainLen++ )
				{
					if( vCommentChain[icommChainLen].first==3 || vCommentChain[icommChainLen].first==4 || vCommentChain[icommChainLen].first==5)
					{
						//section indicator
						vAttribute.clear();
						vAttribute.push_back(std::to_string (vCommentChain[icommChainLen].first));
						vAttribute.push_back("");
						vAttribute.push_back("");
						vAttribute.push_back("");
						vAttribute.push_back("");
						vAttribute.push_back("");
						vAttribute.push_back("");
						vAttribute.push_back("");
						vAttribute.push_back("");
						vAttribute.push_back("");
						vAttribute.push_back("");
						vAttribute.push_back("");
						vCommentChainForInterop.push_back(vAttribute);
						continue;
					}
					// SURVEYOR changes : starts
					if( tc_strcmp( SURVEYOR, objectType.c_str() ) == 0)
					{
						char * cpClosedBy= NULL;
						DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(vCommentChain[icommChainLen].first , AP4_ACTION_RESPONSIBLE , &cpClosedBy) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( cpClosedBy != NULL && tc_strcmp( SURVEYOR, cpClosedBy ) != 0 )
						{
							continue;
						}
					}
					// SURVEYOR changes : ends

					/*DNVGL_TRACE_CALL( iStatus = AOM_ask_value_logical(vCommentChain[icommChainLen].first , AP4_INTERNAL_REMARK , &lInternalRemark) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if(lInternalRemark)
					{
					continue ;
					}	

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( vCommentChain[icommChainLen].first , AP4_STATUS , &cpCommentStatus) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpCommentStatus != NULL && tc_strcmp( cpCommentStatus, DRAFT_STATUS ) == 0 )
					{
					continue ;
					}*/

					char * cpCommentChainUID = NULL ;
					DNVGL_TRACE_CALL( ITK__convert_tag_to_uid( vCommentChain[icommChainLen].first, &cpCommentChainUID ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( vCommentChain[icommChainLen].first, AP4_COMMENTS, &iCommentCount, &tpComments ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( vCommentChain[icommChainLen].first , AP4_COMMENT_ID , &cpCommentChainIndicator) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if ((cpCommentChainIndicator == NULL) || (tc_strlen(cpCommentChainIndicator) < 1))
					{
						cpCommentChainIndicator = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
						tc_strcpy(cpCommentChainIndicator, "") ;
					}

					for( int iCommLen = 0; iCommLen < iCommentCount; iCommLen++ )
					{
						vAttribute.clear();
						tag_t tCommTag= tpComments[iCommLen] ;

						if( tCommTag != NULLTAG )
						{
							char * cpCommentType   = NULL ;

							string strCommentaryType = REPLY_TEXT ;
							//Fetch require properties from commentary object (Comment/Reply) : Starts
							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCommTag , AP4_COMMENT_TYPE , &cpCommentType) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if( cpCommentType != NULL && tc_strcmp( cpCommentType, COMMENT_TYPE_COMMENT ) == 0 )
							{
								//Comments should be verified, if not skip that comment chain
								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCommTag , AP4_INT_VERIFICATION_DONE , &cpInternalVerification) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								if( ( !bIsFinal && cpInternalVerification != NULL && tc_strcmp( cpInternalVerification, REJECTED_STATE ) == 0 ) ||
									( bIsFinal && cpInternalVerification != NULL && tc_strcmp( cpInternalVerification, ISSUED_STATE ) != 0 ) )
								{
									break ;
								}
								strCommentaryType = COMMENT_TEXT ;

								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(tCommTag , AP4_PUBLISHED_DATE , &dCommentDate) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}
							else if( cpCommentType != NULL && tc_strcmp( cpCommentType, COMMENT_TYPE_REPLY ) == 0 )
							{				
								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(tCommTag , CREATION_DATE , &dCommentDate) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}

							if( !DATE_IS_NULL( dCommentDate ) )
							{
								DNVGL_TRACE_CALL( iStatus = DATE_date_to_string( dCommentDate, DATE_FORMAT_COMMENT_LETTER, &cpCommentDate ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;						
							}
							else{
								cpCommentDate = (char *) MEM_alloc((int) (tc_strlen(NOT_ISSUED) + 1) * sizeof(char));
								tc_strcpy(cpCommentDate, NOT_ISSUED) ;			
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag(tCommTag, OWNING_USER, &tOwningUser) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if( tOwningUser != NULLTAG )
							{
								logical 	lVerdict = false;

								DNVGL_TRACE_CALL( iStatus = POM_is_loaded( tOwningUser, &lVerdict ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								if(!lVerdict)
								{
									tag_t 	tClassId = NULLTAG ;
									DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( USER, &tClassId ) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;

									DNVGL_TRACE_CALL( iStatus = POM_load_instances( 1, &tOwningUser, tClassId, POM_no_lock ) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;
								}
								DNVGL_TRACE_CALL( iStatus = POM_ask_user_name(tOwningUser, &cpOwningUser) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCommTag , OBJECT_NAME , &cpCommentaryName) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpCommentaryName == NULL) || (tc_strlen(cpCommentaryName) < 1))
							{
								cpCommentaryName = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpCommentaryName, "") ;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCommTag , AP4_RICH_TEXT , &cpRichtext) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpRichtext == NULL) || (tc_strlen(cpRichtext) < 1))
							{
								cpRichtext = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpRichtext, "") ;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( vCommentChain[icommChainLen].first , AP4_STATUS , &cpCommentStatus) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpCommentStatus == NULL) || (tc_strlen(cpCommentStatus) < 1))
							{
								cpCommentStatus = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpCommentStatus, "") ;
							}
							string strChainEndIndicator = "0";
							if(iCommLen == iCommentCount-1)
							{
								strChainEndIndicator = "1";
								iTableCount++;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( vCommentChain[icommChainLen].first , AP4_SECTION , &cpSection) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpSection == NULL) || (tc_strlen(cpSection) < 1))
							{
								cpSection = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpSection, "") ;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( vCommentChain[icommChainLen].first , AP4_PAGE , &cpPage) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpPage == NULL) || (tc_strlen(cpPage) < 1))
							{
								cpPage = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpPage, "") ;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommTag, AP4_COMMENT_SEQ_ID, &cpCommentIndicator) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpCommentIndicator == NULL) || (tc_strlen(cpCommentIndicator) < 1))
							{
								cpCommentIndicator = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpCommentIndicator, "") ;
							}
							//Fetch require properties from commentary object (Comment/Reply) : end

							//Push properties in vector
							vAttribute.push_back(strChainEndIndicator);
							vAttribute.push_back(cpCommentChainUID);
							vAttribute.push_back(strCommentaryType);
							vAttribute.push_back(cpCommentStatus);
							vAttribute.push_back(cpCommentaryName);
							vAttribute.push_back(cpSection);
							vAttribute.push_back(cpPage);
							vAttribute.push_back(cpCommentDate);
							vAttribute.push_back(cpOwningUser);
							vAttribute.push_back(cpRichtext);
							vAttribute.push_back(cpCommentChainIndicator);
							vAttribute.push_back(cpCommentIndicator);
							//push each commentary object into outer vetor
							vCommentChainForInterop.push_back(vAttribute);
							if(!bIsChainAddedForTechDoc)
							{
								bIsChainAddedForTechDoc= true ;
							}
						}
					}
				}

				if( bIsChainAddedForTechDoc )
				{
					vDocDataForInterop.push_back(vTempDocAttribute);

					//Document end indicator
					vAttribute.clear();
					vAttribute.push_back("2");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vCommentChainForInterop.push_back(vAttribute);
					//Document end indicator
				}
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( cpInternalVerification );
	DNVGL_MEM_FREE( tpSecondaryObjects );
	DNVGL_MEM_FREE( tpRelationObjects );
	DNVGL_MEM_FREE( tpComments );
	DNVGL_MEM_FREE(cpCommentStatus);
	DNVGL_MEM_FREE(cpDocId);
	DNVGL_MEM_FREE(cpDocName);
	DNVGL_MEM_FREE(cpDocRevId);
	DNVGL_MEM_FREE(cpCommentaryName);
	DNVGL_MEM_FREE(cpRichtext);	
	DNVGL_MEM_FREE(cpSection);	
	DNVGL_MEM_FREE(cpPage);	
	DNVGL_MEM_FREE(cpOwningUser);	
	DNVGL_MEM_FREE(cpCommentDate);
	DNVGL_MEM_FREE(cpCommentChainIndicator);	
	DNVGL_MEM_FREE(cpCommentIndicator);

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_create_comment_letter.cxx
* \par  Description :
This function will create input vector of comment chains for TRN tempalte.
* \verbatim
\endverbatim     
* \param[in]   vCommentChain		Input vector which contains all the comment chains

* \par Algorithm:
* \verbatim  
a.Get all the external issued comment chains.
b.Divide them in to surveyor comment chains and non-surveyor comment chains based on To be closed by.
c.In the non-surveyor comment chains divide them into Action required and Important note.
d.Sort all the divided comment chains based on page no

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 22-May-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_comment_chains_for_trn(std::vector<std::pair<tag_t, int>> &vCommentChain )
{
	int		iStatus					= ITK_ok	;

	char * cpClosedBy				= NULL		;
	char* cpChainType				= NULL		;
	std::vector<std::pair<tag_t, int>> vSurveyorCommentChain ;
	std::vector<std::pair<tag_t, int>> vArCommentChain		 ;
	std::vector<std::pair<tag_t, int>> vInCommentChain		 ;

	DNVGL_TRACE_ENTER();

	try{
		for( int icommChainLen = 0; icommChainLen < vCommentChain.size(); icommChainLen++ )
		{	
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(vCommentChain[icommChainLen].first , AP4_ACTION_RESPONSIBLE , &cpClosedBy) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpClosedBy != NULL && tc_strcmp( SURVEYOR, cpClosedBy ) == 0 )
			{
				vSurveyorCommentChain.push_back( std::pair<tag_t,int>( vCommentChain[icommChainLen].first,vCommentChain[icommChainLen].second ) );
			}
			else{
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( vCommentChain[icommChainLen].first , AP4_CHAIN_TYPE , &cpChainType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpChainType != NULL && tc_strcmp( cpChainType, ACTION_REQUIRED ) == 0 )
				{
					vArCommentChain.push_back( std::pair<tag_t,int>( vCommentChain[icommChainLen].first,vCommentChain[icommChainLen].second ) );						
				}
				else if( cpChainType != NULL &&  tc_strcmp( cpChainType, IMPORTANT_NOTE ) == 0 )
				{
					vInCommentChain.push_back( std::pair<tag_t,int>( vCommentChain[icommChainLen].first,vCommentChain[icommChainLen].second ) );
				}
			}

			DNVGL_MEM_FREE(cpClosedBy);
			DNVGL_MEM_FREE(cpChainType);
		}

		vCommentChain.clear();
		if(vSurveyorCommentChain.size()>0)
		{
			vCommentChain.push_back( std::pair<tag_t,int>( 3,3) );
			DNVGL_TRACE_CALL( iStatus = dnvgl_sort_comment_chain_by_page( vSurveyorCommentChain ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			vCommentChain.insert(vCommentChain.end(), vSurveyorCommentChain.begin(), vSurveyorCommentChain.end());
		}

		if(vArCommentChain.size()>0)
		{
			vCommentChain.push_back( std::pair<tag_t,int>( 4,4) );
			DNVGL_TRACE_CALL( iStatus = dnvgl_sort_comment_chain_by_page( vArCommentChain ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			vCommentChain.insert(vCommentChain.end(), vArCommentChain.begin(), vArCommentChain.end());
		}

		if(vInCommentChain.size()>0)
		{
			vCommentChain.push_back( std::pair<tag_t,int>( 5,5) );
			DNVGL_TRACE_CALL( iStatus = dnvgl_sort_comment_chain_by_page( vInCommentChain ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			vCommentChain.insert(vCommentChain.end(), vInCommentChain.begin(), vInCommentChain.end());
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE(cpClosedBy);
	DNVGL_MEM_FREE(cpChainType);	


	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}