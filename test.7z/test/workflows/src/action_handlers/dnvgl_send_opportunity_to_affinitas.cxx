#include "dnvgl_workflows.h"

int dnvgl_send_opportunity_to_affinitas( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		int		iTargetCount	 = 0		;

		char	*cpObjectType	 = NULL		;

		tag_t   tRootTaskTag     = NULLTAG  ;
		tag_t	*tpTargetTags	 = NULL		;
		tag_t   tTargetObjTag	 = NULLTAG  ;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObjTag = tpTargetTags[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_PROJECT_REVISION ) == 0 )
			{
				DNVGL_TRACE_CALL( iStatus = dnvgl_create_or_update_opportunity( &tTargetObjTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				// after we successfully create opportunity in affinitas, we have to set Exchange Version property
				DNVGL_TRACE_CALL( iStatus = populateExchangeVersion( tTargetObjTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int populateExchangeVersion(tag_t tTargetObjTag)
{
	int iStatus = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		// get currency code from opportunity
		// find M type exchange for this currency code
		// loop thru all and pick the latest one (based on version)
		char* curCode = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tTargetObjTag, "ap4_currency_code", &curCode) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if(curCode != NULL)
		{
			const char* rateType = "M";
			const char* ENQ_ID = "find_exchange_object";
			const char* EXCHANGE_RATES_CLASS = "AP4_ExchangeRates";
			const char * select_attrs[] = { "puid", "ap4_rate_type", "ap4_accounting_period" };

			DNVGL_TRACE_CALL( iStatus = POM_enquiry_create (ENQ_ID) ); 
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs (ENQ_ID, EXCHANGE_RATES_CLASS, 3, select_attrs) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (ENQ_ID, "input_rateType", 1, &rateType, POM_enquiry_bind_value ) ); 
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (ENQ_ID, "input_currCode", 1, (const char** ) &curCode, POM_enquiry_bind_value ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr (ENQ_ID, "expr1",	EXCHANGE_RATES_CLASS, "ap4_rate_type",	POM_enquiry_equal, "input_rateType" ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr (ENQ_ID, "expr2",	EXCHANGE_RATES_CLASS, "ap4_currency_code",	POM_enquiry_equal, "input_currCode" ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(ENQ_ID, "final_expression", "expr1", POM_enquiry_and, "expr2") ); 
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr (ENQ_ID, "final_expression") );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			int n_rows = 0;
			int n_cols = 0;
			void*** values = NULL;

			DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute (ENQ_ID, &n_rows, &n_cols, &values) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// lets loop on result
			int iCurrAccPeriod = 0;
			int iMaxAccPeriod = 0;
			char cpAccPeriodToBeSet[7] = {"\0"};

			for(int inx = 0; inx < n_rows; inx++)
			{
				char* exAccoutingPeriod  = (char*)( values[inx][2] );
				iCurrAccPeriod = atoi(exAccoutingPeriod);
				if(iCurrAccPeriod > iMaxAccPeriod )
				{
					iMaxAccPeriod = iCurrAccPeriod;
					tc_strcpy(cpAccPeriodToBeSet, exAccoutingPeriod);
				}
			}
			MEM_free(values); // free the memory allocated by POM_Enq
			DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete ( ENQ_ID) ); // lets delete pom enq
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if(tc_strlen(cpAccPeriodToBeSet) > 0)
			{
     			DNVGL_TRACE_CALL( iStatus = AOM_load( tTargetObjTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tTargetObjTag, true ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tTargetObjTag, AP4_EXCHANGE_VERSION, cpAccPeriodToBeSet) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tTargetObjTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tTargetObjTag, false ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}