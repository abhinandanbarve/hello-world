/**
* \file dnvgl_import_comments_from_comment_letter.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This File  contains the functions which are called to import comments from comment letter.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Basha G
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 20-Apr-2017   Basha G					Initial creation.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"
using namespace std;

/**
* \file dnvgl_read_excel_value.cxx
* \par  Description :
This function will read all the contents from Excel and create objects in Teamcenter
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Get the target object i.e. WVS from the task.
b. Get the Object from C#.
c. Create objects in teamcenter.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 20-Apr-2017	   Basha G				  Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_import_wvs( EPM_action_message_t msg )
{
	int	    iStatus					= ITK_ok	;
	int		iTargetCount			= 0			;
	char    *cpReferenceName		= NULL		;
	char    *cpOriginalFileName		= NULL		;	
	tag_t   tRootTaskTag			= NULLTAG   ;
	tag_t	*tpTargets   			= NULL		;
	tag_t   tWVSDocRev				= NULLTAG	;
	tag_t   tRefObjectTag			= NULLTAG	;
	tag_t   tExcelDatasetTag        = NULLTAG	;
	tag_t*  tpSecondaryObjects		= {NULLTAG} ;
	tag_t   tProjectRev				= NULLTAG   ;
	tag_t*  tpRelationObjects		= {NULLTAG} ;
	int     iSecondaryCount			= NULL		;
	tag_t   tprojectRevisionTag		= NULLTAG	;
	tag_t	tcreatedObject			= NULLTAG   ;
	tag_t	tRelationType			= NULLTAG	;
	char* cpWvsName					= NULL		;
	tag_t* tpSchedules				= NULL		;

	AE_reference_type_t       aeReferenceType;
	string strTempFolderPath = "";
	boolean bIsTempFolderCreated = false ;

	OfficeInterop::ExcelCppService *excelCppObj	= NULL	;

	DNVGL_TRACE_ENTER();
	try
	{
		//Clear the error stack.
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get the root task.
		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task(msg.task, &tRootTaskTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get all the target attachments.
		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments(tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargets) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpTargets[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tWVSDocRevType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_WVSDOCREVISION, AP4_WVSDOCREVISION, &tWVSDocRevType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tWVSDocRevType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !bIsValidType )
			{
				continue;
			}

			tWVSDocRev = tpTargets[i];

			//Get the WVS Doc from WVS doc revision.
			tag_t tWVSDoc = NULLTAG;
			DNVGL_TRACE_CALL(iStatus = ITEM_ask_item_of_rev( tWVSDocRev, &tWVSDoc ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Get the AP4_ProjectRevision from AP4_WVSDoc.
			DNVGL_TRACE_CALL(iStatus = AOM_ask_value_tag( tWVSDoc, AP4_PROJECT_BACKPOINTER, &tProjectRev ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tProjectRev == NULLTAG )
			{
				iStatus = ERROR_919173;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			int iNoOfSchedules = 0;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tProjectRev, AP4_PROJECT_SCHEDULE_RELATION , &iNoOfSchedules, &tpSchedules ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( iNoOfSchedules != 1 )
			{
				iStatus = ERROR_919174;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			//Get the name of the WVS. Same name will be used for Verification Plan.
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tWVSDocRev, OBJECT_NAME, &cpWvsName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Get WVS excel dataset from WVS doc revision.
			DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tWVSDocRev , TC_ATTACHES_RELATION , MSEXCELX_DATASET, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Throw error if no WVS excel dataset exists.
			if( iSecondaryCount == 0 )
			{
				iStatus = ERROR_919172;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			tExcelDatasetTag = tpSecondaryObjects[0];

			//Export the attached excel to temp location
			DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tExcelDatasetTag , 0 , &cpReferenceName , &aeReferenceType , &tRefObjectTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Throw error if no named reference exists.
			if( tRefObjectTag == NULLTAG )
			{
				iStatus = ERROR_919175;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			//Get the original file name of the excel.
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tRefObjectTag, ORIGINAL_FILE_NAME , &cpOriginalFileName) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			const char* cpTempPath = getenv (TEMP_ENV_VAR);

			char* timestamp = NULL;
			DNVGL_TRACE_CALL( iStatus = DNVGL_current_get_time_stamp( DATE_FORMAT_STR_FOOTER, &timestamp ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			strTempFolderPath = cpTempPath ;
			strTempFolderPath.append("\\");
			strTempFolderPath.append( timestamp );

			DNVGL_TRACE_CALL( iStatus = _mkdir( strTempFolderPath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bIsTempFolderCreated = true ; 
			string strExcelFilePath= strTempFolderPath;
			strExcelFilePath.append("\\");
			strExcelFilePath.append(cpOriginalFileName); 

			//Export the excel to temporary folder.
			DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tExcelDatasetTag, cpReferenceName, strExcelFilePath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			/*create object for c# */
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_excelinterop_object( excelCppObj, strExcelFilePath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			char* cpMessage  = NULL;
			int iErrorCode = 0;
			OfficeInterop::VerificationPlanCPP wvsObject =  excelCppObj->readWRS( strExcelFilePath.c_str(), &iErrorCode, &cpMessage );

			std::map<std::string,std::string> sItemAttributes;
			sItemAttributes[OBJECT_NAME] = cpWvsName;
			std::map<std::string,std::string> sItemRevAttributes;
			sItemRevAttributes[OBJECT_NAME] = cpWvsName;			

			//Get the relation type of AP4_DocumentRelation.
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_DOCUMENT_RELATION, &tRelationType ) );   
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Create AP4_VerifPlan 
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_aba_object( AP4_VERIFPLAN, AP4_VERIFPLANREVISION, sItemAttributes, sItemRevAttributes, tProjectRev, AP4_PROJVERIPLANRELATION, tcreatedObject ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;				

			//Create the structure.
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_wrs( wvsObject, tcreatedObject, tpSchedules[0], tProjectRev ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	//Free memory
	DNVGL_MEM_FREE(tpTargets);
	DNVGL_MEM_FREE(cpReferenceName);
	DNVGL_MEM_FREE(tpSecondaryObjects);
	DNVGL_MEM_FREE(tpRelationObjects);
	DNVGL_MEM_FREE(tpSchedules);
	free(excelCppObj);
	//Delete the folder	
	if(bIsTempFolderCreated)
	{
		string strTempFolderDeleteCmd = "" ;
		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );	
	}
	return iStatus;
}


/**
* \file dnvgl_read_excel_value.cxx
* \par  Description :
This function will read all the reply from customer letter.It will call the c# method to read all the replies from customer.
* \verbatim
\endverbatim     
* \param[in]		wvsObject					wvs Object
* \param[out]		tprimaryObject				primaryobject
* \par Algorithm:
* \verbatim  
a. Loop all the WVS object like PC and Activity.
b. Pass the objects to  dnvgl_createObject to create TC objects.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 20-Apr-2017      Basha G					Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

int dnvgl_create_wrs( OfficeInterop::VerificationPlanCPP &wvsObject,tag_t tprimaryObject, tag_t tSchedule, tag_t tProjectRev )
{
	int		iStatus						=	ITK_ok;
	try
	{
		tag_t	tpcrev_tag				    =	NULLTAG;

		std::vector<OfficeInterop::SafetyCriticalElementCPP> vecsceObject = wvsObject.getSCES();

		for (int sceCount = 0; sceCount < vecsceObject.size(); sceCount++)
		{ 
			tag_t	tsceObject				=	NULLTAG;

			tag_t	tprirev_tag				=	NULLTAG;

			OfficeInterop::SafetyCriticalElementCPP csceObject = vecsceObject[sceCount];

			DNVGL_TRACE_CALL( iStatus = ITEM_find_revision  (tprimaryObject,"A",&tprirev_tag));
			DNVGL_LOG_ERROR_AND_THROW_STATUS

				if(tprirev_tag!=NULLTAG)
				{
					/*create SC Item */
					DNVGL_TRACE_CALL( iStatus = dnvgl_create_aba_object(AP4_SCE,AP4_SCEREVISION,csceObject.getItemAttr(),csceObject.getItemRevAttr(),tprirev_tag,AP4_SCERELATION,tsceObject));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				std::vector<OfficeInterop::PerformanceCriteriaCPP> vecpcObject = vecsceObject[sceCount].getPCList();

				for (int pcObjectcount = 0; pcObjectcount < vecpcObject.size(); pcObjectcount++)
				{
					tag_t	tpcObject			    =   NULLTAG;

					tag_t	tscerev_tag				=	NULLTAG;

					OfficeInterop::PerformanceCriteriaCPP cpcObject = vecpcObject[pcObjectcount];

					DNVGL_TRACE_CALL( iStatus = ITEM_find_revision  (tsceObject,"A",&tscerev_tag));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if(tscerev_tag!=NULLTAG)
					{
						/*create AP4_PrefCriteria object*/
						DNVGL_TRACE_CALL(iStatus = dnvgl_create_aba_object(AP4_PERFCRITERIA,AP4_PERFCRITERIAREVISION,cpcObject.getItemAttr(),cpcObject.getItemRevAttr(),tscerev_tag,AP4_PERFORMANCESRANDARDS,tpcObject));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}

					std::vector<OfficeInterop::ActivityCPP> vecactivityObject = vecpcObject[pcObjectcount].getactivity();

					for (int actObjectcount = 0; actObjectcount < vecactivityObject.size(); actObjectcount++)
					{

						OfficeInterop::ActivityCPP cactivityObject = vecactivityObject[actObjectcount];

						DNVGL_TRACE_CALL( iStatus = ITEM_find_revision  (tpcObject,"A",&tpcrev_tag));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if(tpcrev_tag!=NULLTAG)
						{
							//Create activity.
							tag_t	tActivity			    =   NULLTAG;							
							DNVGL_TRACE_CALL( iStatus = dnvgl_create_aba_object( AP4_ACTIVITY_ITEM, AP4_ACTIVITYREVISION, cactivityObject.getItemAttr(), cactivityObject.getItemRevAttr(), tpcrev_tag, AP4_APPROVALACTIVITIES, tActivity ) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							//Create schedule task for each activity.
							DNVGL_TRACE_CALL( iStatus = dnvgl_create_schedule_task( tSchedule, tActivity, tProjectRev ) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;
						}
					}

				}
		}
	}
	catch( ... )
	{
	}
	return iStatus;
}


/**
* \file dnvgl_read_excel_value.cxx
* \par  Description :
This function will read all the reply from customer letter.It will call the c# method to read all the replies from customer.
* \verbatim
\endverbatim     
* \param[in]		sItemtype				Item type
* \param[in]		sItemRevtype			Item rev type
* \param[in]		sItemAttributes		    Item Attributes
* \param[in]		sItemrevAttribuest		Item Rev Attributes
* \param[in]		tprimaryObject		    Primary Object
* \param[in]		relationName			Relation Name
* \param[out]		tcreatedObject		    Created Obbject
* \par Algorithm:
* \verbatim  
a. Create new object using given type and attributes
b. Create relation between created object and primary object
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 20-Apr-2017      Basha G					Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

int dnvgl_create_aba_object(std::string sItemtype,std::string sItemRevtype,std::map<std::string,std::string> &sItemAttributes,std::map<std::string,std::string> &sItemrevAttribuest,tag_t tprimaryObject,std::string relationName,tag_t &tcreatedObject)
{
	int		iStatus				=	ITK_ok;
	try
	{
		logical lmodifiable			=	false;
		tag_t	trelationtag		=	NULLTAG;
		tag_t	trelation_type		=	NULLTAG;
		tag_t   tItemTypeTag		=	NULLTAG;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( sItemtype.c_str(), NULL, &tItemTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t   tItemCreateInput = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tItemTypeTag, &tItemCreateInput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t   tRevTypeTag  = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type(sItemRevtype.c_str(), NULL, &tRevTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t   tRevCreateInput = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tRevTypeTag, &tRevCreateInput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for (auto itemAttr = sItemAttributes.begin(); itemAttr != sItemAttributes.end(); ++itemAttr) 
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string(tItemCreateInput,itemAttr->first.c_str(), itemAttr->second.c_str()));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		for (auto itemrevattr = sItemrevAttribuest.begin(); itemrevattr != sItemrevAttribuest.end(); ++itemrevattr) 
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string(tRevCreateInput, itemrevattr->first.c_str(), itemrevattr->second.c_str()) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag(tItemCreateInput, "revision", tRevCreateInput) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tNewItem  = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( tItemCreateInput, &tNewItem) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( tNewItem ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		/*create Relation between new Item rev and primaryobject*/
		if( tNewItem != NULLTAG && !relationName.empty() && tprimaryObject != NULLTAG )
		{
			tcreatedObject = tNewItem;
			DNVGL_TRACE_CALL(iStatus = GRM_find_relation_type( relationName.c_str(), &trelation_type ) );   
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(iStatus = GRM_create_relation( tprimaryObject, tNewItem, trelation_type, NULLTAG, &trelationtag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = GRM_save_relation( trelationtag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}
	return iStatus;
}

/**
* \file dnvgl_read_excel_value.cxx
* \par  Description :
This function will read all the reply from customer letter.It will call the c# method to read all the replies from customer.
* \verbatim
\endverbatim     
* \param[in]		sItemtype				Item type
* \param[in]		sItemRevtype			Item rev type
* \param[in]		sItemAttributes		    Item Attributes
* \param[in]		sItemrevAttribuest		Item Rev Attributes
* \param[in]		tprimaryObject		    Primary Object
* \param[in]		relationName			Relation Name
* \param[out]		tcreatedObject		    Created Obbject
* \par Algorithm:
* \verbatim  
a. Create new object using given type and attributes
b. Create relation between created object and primary object
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 05-May-2017      Basha G					Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

int dnvgl_create_schedule_task(tag_t tSchedule, tag_t tActivityRev, tag_t tProjectRev )
{
	int		iStatus				=	ITK_ok;
	tag_t	 *tpCreatedTasks	=	NULL;
	tag_t	 *tpUpdatedTasks	=	NULL;
	try
	{
		tag_t tScheduleSummaryTask;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tSchedule, FND0SUMMARYTASK, &tScheduleSummaryTask ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t	 dStartDate;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( tScheduleSummaryTask, START_DATE, &dStartDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t	 dFinishDate;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( tScheduleSummaryTask, FINISH_DATE, &dFinishDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* cpObjName = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tActivityRev, OBJECT_NAME, &cpObjName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		date_t	 dProjectStartDate;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( tProjectRev, AP4_START_DATE, &dProjectStartDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t	 dProjectFinishDate;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( tProjectRev, AP4_ESTIMATED_END_DATE, &dProjectFinishDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		TaskCreateContainer_t	parentTaskCreateContainer[1];
		parentTaskCreateContainer[0].name = cpObjName;
		string description = "ScheduleTask for ";
		description.append( cpObjName );
		description.append( " activity" );
		parentTaskCreateContainer[0].desc = (char*)description.c_str();

		int	startDateResult	= 0;
		startDateResult = dnvgl_compare_dates(dProjectStartDate,dStartDate,false);

		if( startDateResult <= 0 )
		{
			parentTaskCreateContainer[0].start = dStartDate;
		}
		else{

			parentTaskCreateContainer[0].start = dProjectStartDate;
		}

		int	endDateResult	= 0;
		endDateResult = dnvgl_compare_dates(dProjectFinishDate,dFinishDate,false);

		if( endDateResult <= 0 )
		{
			parentTaskCreateContainer[0].finish = dProjectFinishDate;
		}
		else{

			parentTaskCreateContainer[0].finish = dFinishDate;
		}

		parentTaskCreateContainer[0].objectType = SCHEDULETASK;
		parentTaskCreateContainer[0].parent = tScheduleSummaryTask;
		parentTaskCreateContainer[0].prevSibling = NULLTAG;
		parentTaskCreateContainer[0].workEstimate = 480;  // 8 hrs in minutes
		parentTaskCreateContainer[0].otherAttributesSize = 0;
		parentTaskCreateContainer[0].typedAttrContSize = 0;

		int iNoOfUpdatedTasks	=	0;
		DNVGL_TRACE_CALL( iStatus = SCHMGT_create_tasks_non_interactive( tSchedule, 1 ,parentTaskCreateContainer, &tpCreatedTasks, &iNoOfUpdatedTasks, &tpUpdatedTasks ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;			

		//Create relation between schedule task and activity revision.
		if( iNoOfUpdatedTasks == 1 && tpCreatedTasks[0] != NULLTAG )
		{
			tag_t tRelationType = NULLTAG;			
			DNVGL_TRACE_CALL(iStatus = GRM_find_relation_type( AP4_ACTIVITYTASKRELATION, &tRelationType ) );   
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tRelation = NULLTAG;
			DNVGL_TRACE_CALL(iStatus = GRM_create_relation( tpCreatedTasks[0], tActivityRev, tRelationType, NULLTAG, &tRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(iStatus = GRM_save_relation( tRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpCreatedTasks );
	DNVGL_MEM_FREE( tpUpdatedTasks );

	return iStatus;
}