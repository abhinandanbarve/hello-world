/**
* \file dnvgl_add_objects_to_workflow.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This file contains the action handler which update the assignee property in comment chain based on the attribute vales ap4_status and ap4_int_verification_done.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Basha G
*
* \par History:
*--------------------------------------------------------------------------------
* Date         Name	     Description of Change
* 09-Feb-2017   Basha G               Initial creation.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

/**
* \file dnvgl_update_current_assignee.cxx
* \par  Description :
This function will change or remove current assignee based on assignee role and task type.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Get handler argument assignee role and task type.
b. Based on argument get assignee
c. Based on task assign or remove current assignee.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 10-Feb-2017      Nikhilesh Khatra       Initial creation.
* 19-Apr-2017      Nikhilesh Khatra       Changes added for Activity
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_update_current_assignee( EPM_action_message_t msg )
{

	int	    iStatus					= ITK_ok	;
	int		iTargetCount			= 0			;
	int		iTaskType				= 0			;
	int	    iSecondaryCount			= 0			;
	int		iParticipantCount		= 0			;

	char	*cpObjectType			= NULL		;
	char	*cpVerificationStatus	= NULL		;
	char	*cpArgValue				= NULL		;
	char	*cpTypeArg				= NULL		;
	char	*cpValue				= NULL		;

	tag_t   tRootTask				= NULLTAG	;
	tag_t   tTargetObj				= NULLTAG	;
	tag_t   tCommentCreatedUser		= NULLTAG	;
	tag_t	tProjectRev				= NULLTAG	;
	tag_t	tlastcomment			= NULLTAG	;
	tag_t   tCurrAssignee			= NULLTAG	;
	tag_t   tWorkflowInitUser		= NULLTAG	;

	tag_t	*tpTargets				= {NULLTAG}	;  
	tag_t	*tpParticipants			= {NULLTAG}	;  
	tag_t   *tpSecondaryObjects		= {NULLTAG}	;
	tag_t   *tpRelationObjects		= {NULLTAG}	;

	std::string sAttachmentType		= ""		;
	std::string sOperation			= ""		;
	std::string sAssigneeRole		= ""		;

	bool bIsActivity = false ; 
	DNVGL_TRACE_ENTER();
	try
	{
		AM__set_application_bypass( true );
		POM_AM__set_application_bypass( true );

		tag_t tCurrentTask = msg.task;
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Read the handler arguments.
		while( ( cpArgValue = TC_next_argument( msg.arguments ) ) != NULL )
		{
			DNVGL_TRACE_CALL( iStatus = ITK_ask_argument_named_value( cpArgValue, &cpTypeArg, &cpValue ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpValue != NULL )
			{
				if( strcmp( cpTypeArg, TASK_TYPE ) == 0 )
				{
					if( tc_strcasecmp( cpValue, ASSIGNEE_SET ) == 0 || tc_strcasecmp( cpValue, ASSIGNEE_REMOVE ) == 0)
					{
						sOperation = cpValue ;
					}		
					else
					{
						iStatus = ERROR_919152;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}	
				else if( strcmp( cpTypeArg, ASSIGNEE_ROLE ) == 0 )
				{
					if( tc_strcasecmp( cpValue, APPROVAL_ENG_ROLE ) == 0 || tc_strcasecmp( cpValue, PROJECT_MANAGER ) == 0 )
					{
						sAssigneeRole = cpValue ;
					}
					else
					{
						iStatus = ERROR_919157;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}	
			}
		}
		if(sOperation.compare("") == 0)
		{
			iStatus = ERROR_919158;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else if ( sOperation.compare(ASSIGNEE_SET) == 0 && sAssigneeRole.compare("") == 0 )
		{
			iStatus = ERROR_919159;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTask ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTask, EPM_target_attachment, &iTargetCount, &tpTargets ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObj = tpTargets[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObj, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && (tc_strcmp( cpObjectType, AP4_TECH_DOC_REVISION ) == 0 || tc_strcmp( cpObjectType, AP4_ACTIVITYREVISION ) == 0 ))
			{
				if(tc_strcmp( cpObjectType, AP4_ACTIVITYREVISION ) == 0)
				{
					bIsActivity = true ; 
				}

				if(bIsActivity)
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_chains_for_activity( tTargetObj, &tpSecondaryObjects, &iSecondaryCount, NULL) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
				else
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tTargetObj , AP4_COMMENT_CHAIN_RELATION , AP4_COMMENT_CHAIN, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				//Get Project Manager Tag 
				if( sOperation.compare( ASSIGNEE_SET ) == 0 && sAssigneeRole.compare( PROJECT_MANAGER ) == 0 )
				{
					//DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tTargetObj, AP4_PROJECT_REVISION, &tProjectRev ) );
					//DNVGL_LOG_ERROR_AND_THROW_STATUS;
					//Get project revision from tech doc revision
					if(bIsActivity)
					{
						DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tTargetObj, AP4_PROJECT_BACKPOINTER , &tProjectRev ));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
					else
					{
						DNVGL_TRACE_CALL(iStatus = dnvg_get_project_rev_from_tech_doc_rev( tTargetObj ,&tProjectRev) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}

					tag_t tProjMgrTypeTag = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = EPM_get_participanttype( AP4_PROJECTMANAGER, &tProjMgrTypeTag ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL ( iStatus = ITEM_rev_ask_participants( tProjectRev, tProjMgrTypeTag, &iParticipantCount, &tpParticipants ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if(iParticipantCount>0)
					{
						tag_t   tProjectMngTag		= NULLTAG	;
						tProjectMngTag = tpParticipants[0];

						DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tProjectMngTag, FND0_ASSIGNEE_USER, &tCurrAssignee ));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						iTaskType = 1 ;
					}
				}
				//Get Approval Engineer Tag 
				else if( sOperation.compare( ASSIGNEE_SET ) == 0 && sAssigneeRole.compare( APPROVAL_ENG_ROLE ) == 0 )
				{
					DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tRootTask, FND0WORKFLOWINITIATOR, &tWorkflowInitUser ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					iTaskType = 2;
				}
				else if( sOperation.compare( ASSIGNEE_REMOVE ) == 0 )
				{
					tCurrAssignee = NULLTAG	;
					iTaskType = 3 ;
				}

				for ( int index = 0; index < iSecondaryCount; index++ )
				{	
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tpSecondaryObjects[index], AP4_LAST_COMMENT, &tlastcomment ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tlastcomment, AP4_INT_VERIFICATION_DONE, &cpVerificationStatus ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if(iTaskType == 1 && tc_strcmp( cpVerificationStatus, VERIFIED_STATE ) == 0)
					{	
						//Assign project manager as current assignee
						DNVGL_TRACE_CALL( iStatus = dnvgl_update_comment_chain_current_assignee( tpSecondaryObjects[index], tCurrAssignee ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
					else if(iTaskType == 2)
					{	
						DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tpSecondaryObjects[index], OWNING_USER, &tCommentCreatedUser ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( tCommentCreatedUser != tWorkflowInitUser )
						{
							//Assign approval engineer as current assignee
							DNVGL_TRACE_CALL( iStatus = dnvgl_update_comment_chain_current_assignee( tpSecondaryObjects[index], tWorkflowInitUser ) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;
						}
					}
					else if(iTaskType == 3 && tc_strcmp( cpVerificationStatus, ISSUED_STATE ) == 0)
					{	
						//Remove current assignee
						DNVGL_TRACE_CALL( iStatus = dnvgl_update_comment_chain_current_assignee( tpSecondaryObjects[index], tCurrAssignee ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( cpObjectType );
	DNVGL_MEM_FREE( cpVerificationStatus );
	DNVGL_MEM_FREE( cpTypeArg );
	DNVGL_MEM_FREE( cpValue );

	DNVGL_MEM_FREE( tpTargets );
	DNVGL_MEM_FREE( tpSecondaryObjects );
	DNVGL_MEM_FREE( tpRelationObjects );
	DNVGL_MEM_FREE( tpParticipants );

	AM__set_application_bypass( false );
	POM_AM__set_application_bypass( false );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_update_current_assignee.cxx
* \par  Description :
This function will set current assignee.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Set current assignee on last comment object.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 10-Feb-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_update_comment_chain_current_assignee( tag_t &tCommentChain , tag_t &tCurrAssignee)
{
	int iStatus	= ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCommentChain, TRUE ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChain, AP4_CURRENT_ASSIGNEE, tCurrAssignee) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( tCommentChain ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCommentChain, FALSE));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{

	}	

	DNVGL_TRACE_LEAVE();
	return iStatus;
}