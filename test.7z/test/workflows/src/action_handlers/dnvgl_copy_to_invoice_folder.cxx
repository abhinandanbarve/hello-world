#include "dnvgl_workflows.h"

int dnvgl_copy_to_invoice_folder( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		char	*cpObjectType	 = NULL		;
		tag_t   tRootTaskTag     = NULLTAG  ;
		int		iTargetCount	 = 0		;
		tag_t	*tpTargetTags	 = NULL		;
		tag_t   tTargetObjTag	 = NULLTAG  ;
		tag_t   tProjectRevTag	 = NULLTAG  ;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObjTag = tpTargetTags[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// assuming there will be only one ProjetRevision attahed to process
			if( tc_strcmp( cpObjectType, AP4_PROJECT_REVISION ) == 0 )
			{
				tProjectRevTag = tTargetObjTag;
				break;				
			}
		}

		// checking for null
		if(tProjectRevTag != NULL)
		{
			tag_t*  pptSecondaryObjects		= NULL;
			tag_t*  pptRelationObjects		= NULL;
			int     piObjectCount			= NULL;

			tag_t   tGoverningDocFolder     = NULL;
			tag_t   tInvoiceFolder		    = NULL;

			DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tTargetObjTag, AP4_PROJECT_STRUCTURE_RELATION, AP4_GOVERNING_DOCUMENT, &pptSecondaryObjects, &pptRelationObjects, &piObjectCount ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// If AP4_GoverningDocumentsFolders is not present
			if( piObjectCount == 0 )
			{
				// create governing document folder
				DNVGL_TRACE_CALL( iStatus = dnvgl_create_and_attach_project_folder(tTargetObjTag, AP4_GOVERNING_DOCUMENT, &tGoverningDocFolder) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				// create InvoiceFolder
				DNVGL_TRACE_CALL( iStatus = dnvgl_create_and_attach_project_folder(tGoverningDocFolder, AP4_INVOICE_FOLDER, &tInvoiceFolder) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				tGoverningDocFolder = pptSecondaryObjects[0];
				DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tGoverningDocFolder, AP4_PROJECT_STRUCTURE_RELATION, AP4_INVOICE_FOLDER, &pptSecondaryObjects, &pptRelationObjects, &piObjectCount ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( piObjectCount == 0 )
				{
					// create InvoiceFolder
					DNVGL_TRACE_CALL( iStatus = dnvgl_create_and_attach_project_folder(tGoverningDocFolder, AP4_INVOICE_FOLDER, &tInvoiceFolder) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
				else
				{
					// assuming there would be only one Invoice Folder
					tInvoiceFolder = pptSecondaryObjects[0];
				}
			}

			// by this time, we must have invoice folder (exting or newly created), hence no need to check for null
			for(int inx = 0; inx < iTargetCount; inx++)
			{
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpTargetTags[inx], OBJECT_TYPE, &cpObjectType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if(tc_strcmp( cpObjectType, AP4_INVOICE_REVISION ) == 0)
				{
					char* cpInvoiceType = NULL;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpTargetTags[inx], AP4_INVOICE_TYPE, &cpInvoiceType ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					if( cpInvoiceType != NULL && tc_strcmp( cpInvoiceType, "Final" ) == 0 )
					{
						tag_t tRelationType = NULLTAG;
						DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_DOCUMENT_RELATION, &tRelationType ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						tag_t tInvoiceItem = NULLTAG;
						DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev(tpTargetTags[inx], &tInvoiceItem) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						tag_t	tRelationTag = NULLTAG;
						DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tInvoiceFolder, tInvoiceItem, tRelationType, NULLTAG, &tRelationTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelationTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						break;
					}
				}
			}
		}
	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


int dnvgl_create_and_attach_project_folder(tag_t tTargetObjTag, char* cpFolderType, tag_t *tGoverningDoc)
{
	int	    iStatus          = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tFolderTypeTag	= NULLTAG;
		tag_t tFolderInputTag	= NULLTAG;
		tag_t tpTemp			= NULLTAG ;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( cpFolderType, NULL, &tFolderTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tFolderTypeTag, &tFolderInputTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( tFolderInputTag, &tpTemp ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( tpTemp ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tRelationType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_STRUCTURE_RELATION, &tRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t	tRelationTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tTargetObjTag, tpTemp, tRelationType, NULLTAG, &tRelationTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelationTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		*tGoverningDoc = tpTemp;
	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

