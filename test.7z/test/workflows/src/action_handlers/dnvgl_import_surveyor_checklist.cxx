/**
* \file dnvgl_import_surveyor_checklist.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This File  contains the functions which are called to import comments from comment letter.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Chetan kekade  
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name				Description of Change
* 07-Apr-2017   Chetan kekade		Initial creation.
*--------------------------------------------------------------------------------
*/
#include "dnvgl_workflows.h"
using namespace std;

int dnvgl_import_surveyor_checklist( EPM_action_message_t msg )
{

	int	    iStatus					= ITK_ok	;
	int		iTargetCount			= 0			;	
	char    *cpReferenceName		= NULL		;
	char    *cpOriginalFileName		= NULL		;
	tag_t   tRootTask				= NULLTAG   ;
	tag_t	*tpTargetTags			= NULL		;
	tag_t   tSurveyorPkg			= NULLTAG	;
	tag_t   tSCDataset				= NULLTAG	;
	tag_t   tRefObject				= NULLTAG	;
	tag_t	tSurveyorCheklist		= NULLTAG	;
	tag_t*  tpSecondaryObjects		= {NULLTAG} ;
	tag_t*  tpRelationObjects		= {NULLTAG} ;
	int     iSecondaryCount			= NULL		;
	AE_reference_type_t       aeReferenceType;
	string strTempFolderPath = "";
	boolean bIsTempFolderCreated = false ;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task(msg.task, &tRootTask) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetCount, &tpTargetTags) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpTargetTags[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tSurveyorPackageType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_SURVEYORPACKAGEFOLDER, AP4_SURVEYORPACKAGEFOLDER, &tSurveyorPackageType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tSurveyorPackageType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !bIsValidType )
			{
				continue;
			}
			tSurveyorPkg = tpTargetTags[i];
			std::vector<tag_t> vSecObject ;
			//Get the Surveyor Template attached by relation
			DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type( tSurveyorPkg, AP4_SURVEYOR_CHEKLST_RELATION, AP4_DELIVERABLE, vSecObject ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//If Surveyor template found then save it to temp directory
			if(!vSecObject.empty() && vSecObject.size() == 1)
			{
				//Check for the latestb working revision present or not
				tSurveyorCheklist = vSecObject[0];

				//Get the doc tag from doc rev
				tag_t   tSurveyorCheklistRev = NULLTAG  ;
				DNVGL_TRACE_CALL ( iStatus = ITEM_ask_latest_rev( tSurveyorCheklist, &tSurveyorCheklistRev) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t *refTag = NULLTAG ;
				bool isReleased = false;
				int iRefcount = NULLTAG ;
				bool bIsReleased = false ;
				DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tags( tSurveyorCheklistRev, RELEASE_STATUS_LIST, &iRefcount, &refTag ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for ( int index = 0; index < iRefcount; index++ )
				{						
					char* cpReleaseStatus = NULL;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( refTag[index], OBJECT_NAME, &cpReleaseStatus ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;	

					if( cpReleaseStatus != NULL && tc_strcmp( cpReleaseStatus, AP4_ISSUED ) == 0 )
					{
						isReleased = true;
					}
				}
				if( !isReleased )
				{
					tag_t tTCAttachesRel = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION , &tTCAttachesRel ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					//Get the template dataset from project rev : starts
					DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tSurveyorCheklistRev , TC_ATTACHES_RELATION , MSWORDX_DATASET, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if(iSecondaryCount == 0)
					{
						//need to throw error that word dataset does not exist.
						iStatus = ERROR_919147;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
					else
					{
						tSCDataset = tpSecondaryObjects[0];
					}

					//Export the attached word to temp location : starts
					DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tSCDataset , 0 , &cpReferenceName , &aeReferenceType , &tRefObject ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tRefObject, ORIGINAL_FILE_NAME , &cpOriginalFileName) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					const char* cpTempPath;
					cpTempPath = getenv (TEMP_ENV_VAR);

					char*	timestamp = NULL;
					string	dirTimeStamp;

					DNVGL_TRACE_CALL( iStatus = DNVGL_current_get_time_stamp(DATE_FORMAT_STR_FOOTER,&timestamp) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					dirTimeStamp = timestamp;

					strTempFolderPath = cpTempPath ;
					strTempFolderPath.append("\\");
					strTempFolderPath.append(dirTimeStamp);

					DNVGL_TRACE_CALL( iStatus = _mkdir( strTempFolderPath.c_str() ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					bIsTempFolderCreated = true ; 
					string strWordFilePath= strTempFolderPath;
					strWordFilePath.append("\\");
					strWordFilePath.append(cpOriginalFileName); 

					DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tSCDataset,cpReferenceName,strWordFilePath.c_str()));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					//Export the attached word to temp location : ends

					char * cpDocumentType = NULL;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSurveyorCheklist, AP4_TEMPLATETYPE, &cpDocumentType ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					char * cpDocumentCategory = NULL;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSurveyorCheklist, AP4_VERSION, &cpDocumentCategory ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					tag_t tDatasetTag = NULLTAG;
					std::string strEformID;
					std::string strEformDocType;
					std::string strDatasetType;

					DNVGL_TRACE_CALL( iStatus = dnvgl_get_eform_dataset_info( cpDocumentType, cpDocumentCategory, strEformID, strEformDocType, strDatasetType, &tDatasetTag ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					std::vector<std::string> vTableBookmarks ;
					DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_letter_bookmarks( DNVGL_COMMENT_LETTER_TABLE_BOOKMAKRS, strEformID.c_str(), vTableBookmarks ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					std::vector<std::string> vReplyData ;
					//Get replies from word file
					DNVGL_TRACE_CALL( iStatus = dnvgl_get_replies_from_comment_letter( strWordFilePath, vTableBookmarks[0], vReplyData) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					//Create reply object for all replies exported from word file
					DNVGL_TRACE_CALL( iStatus = dnvgl_create_replies_from_comment_letter( vReplyData) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}
		}
	}
	catch( ... )
	{
	}
	//Free memory
	DNVGL_MEM_FREE(tpTargetTags);
	DNVGL_MEM_FREE(cpOriginalFileName);
	DNVGL_MEM_FREE(cpReferenceName);
	DNVGL_MEM_FREE(tpSecondaryObjects);
	DNVGL_MEM_FREE(tpRelationObjects);
	//Delete the folder	
	if(bIsTempFolderCreated)
	{
		string strTempFolderDeleteCmd = "" ;

		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );	
	}

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}
