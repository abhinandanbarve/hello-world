/**
* \file dnvgl_upload_transmittal_without_mdr.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This File  contains the functions which are called to create technical document 
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra  
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 02-Aug-2016   Nikhilesh Khatra      Initial creation.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

using namespace std;

/**
* \file dnvgl_upload_transmittal_without_mdr.cxx
* \par  Description :
This function will create documents in Document Register for the files present in Trasmittal document.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Get the file list present in the zip attach to transmittal document revision
b. Check if technical document is already created for the given file
c. If already created skip that file
d. If not created ,create technical document
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 02-Aug-2016      Nikhilesh Khatra       Initial creation.
* 19-Aug-2016      Nikhilesh Khatra       Document creation using attached zip and transmittal xml.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

int dnvgl_upload_transmittal( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok	;
	int		iTargetCount	 = 0		;
	char	*cpObjectType	 = NULL		;
	tag_t   tRootTaskTag     = NULLTAG  ;
	tag_t	*tpTargetTags	 = NULL		;
	tag_t   tDocRevTag	 = NULLTAG  ;
	boolean isMDRDocAttached	= false;
	string strDeleteFolderName ;
	string strDeleteCmd = "";
	string strTempFolderPath = ""		;
	boolean bIsTempFolderCreated = false ;
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for( int i=0; i<iTargetCount; i++ )
		{
			tDocRevTag = tpTargetTags[i];

			tag_t	tStructRelTag	=  NULLTAG	;
			tag_t	tItem			=  NULLTAG	;
			tag_t*	tpRelatedTags	=  {NULLTAG} ;
			int		iObjectCount	= 0			;

			char*   cpTranNo        =  NULL;

			DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev(tDocRevTag, &tItem  ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tItem,  AP4_TRANSMITTAL_NO, &cpTranNo ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if(cpTranNo == NULL || tc_strlen(cpTranNo)==0)
			{
				iStatus = ERROR_919161;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			} 

			//Get transmittal xml dataset tag : starts
			tag_t tXmlDatasetTag = NULLTAG ;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( IMAN_REFERENCE_RELATION, &tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tDocRevTag, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iObjectCount; index++ )
			{						
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpRelatedTags[index], OBJECT_TYPE, &cpObjectType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, TEXT_DATASET ) == 0 )
				{
					tXmlDatasetTag = tpRelatedTags[index];
					break;
				}	
			}
			//Get transmittal xml dataset tag  : ends

			//Throw custom error if transmittal xml not present
			if( tXmlDatasetTag == NULLTAG )
			{
				iStatus = ERROR_919117;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			// Get AP4_DocumentRegister tag starts
			//Get the doc tag from doc rev
			tag_t   tDocTag	 = NULLTAG  ;
			DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tDocRevTag, &tDocTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//AP4_DocumentRelation is your relation ,using current tag and relation get the primary tag
			tag_t	tCurrentTag		=  NULLTAG	;

			DNVGL_TRACE_CALL( GRM_find_relation_type( AP4_DOCUMENT_RELATION , &tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL(iStatus =  GRM_list_primary_objects_only( tDocTag, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iObjectCount; index++ )
			{																	
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_TRANSMITTAL_DOC) == 0 )
				{									
					tCurrentTag = tpRelatedTags[index];
					break;
				}				
			}

			//AP4_ProjectStructRelation is your relation ,using current tag and relation get the primary tag													
			DNVGL_TRACE_CALL( GRM_find_relation_type( AP4_PROJECT_STRUCTURE_RELATION, &tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL(iStatus =  GRM_list_primary_objects_only( tCurrentTag, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iObjectCount; index++ )
			{																	
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_PROJECT_REVISION) == 0 )
				{									
					tCurrentTag = tpRelatedTags[index];
					break;
				}				
			}

			//Get the AP4_DocumentRegister folder tag					
			DNVGL_TRACE_CALL( GRM_find_relation_type(AP4_PROJECT_STRUCTURE_RELATION,&tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tCurrentTag, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tDocumentRegFolder = NULLTAG;
			tag_t tGoverningDocTagFolder = NULLTAG; 
			for ( int index = 0; index < iObjectCount; index++ )
			{						
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_DOCUMENT_REGISTER ) == 0 )
				{
					tDocumentRegFolder = tpRelatedTags[index];

				}		
				else if( cpObjectType != NULL && tc_strcmp( cpObjectType , AP4_GOVERNING_DOCUMENT ) == 0 )
				{
					tGoverningDocTagFolder = tpRelatedTags[ index ];
				}
			}
			// Check the MDR Document Present or not.
			if( tGoverningDocTagFolder != NULLTAG )
			{
				DNVGL_TRACE_CALL( GRM_find_relation_type( AP4_DOCUMENT_RELATION, &tStructRelTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tGoverningDocTagFolder, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				char	*cpObjectName	 = NULL	;
				for( int index = 0; index < iObjectCount; index++ )
				{
					char* cpRelObjType = NULL;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpRelatedTags[index], OBJECT_TYPE, &cpRelObjType ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpRelObjType != NULL && tc_strcmp( cpRelObjType , AP4_MDR_DOCUMENT ) == 0 )
					{
						isMDRDocAttached = true;
						break;
					}					
				}
			}
			if( tDocumentRegFolder != NULLTAG )
			{
				//Get the exisitg doc name from AP4_DocumentRegister folder tag		
				DNVGL_TRACE_CALL( GRM_find_relation_type( AP4_DOCUMENT_RELATION, &tStructRelTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tDocumentRegFolder, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				char	*cpObjectName	 = NULL	;
				vector<string> vExistingFiles;
				map<string,tag_t> mapExistingTecDocs;
				for ( int index = 0; index < iObjectCount; index++ )
				{						
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_NAME, &cpObjectName) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					vExistingFiles.push_back(cpObjectName);	
					mapExistingTecDocs.insert(std::pair<string,tag_t>( cpObjectName,tpRelatedTags[index] ));
				}
				// Get AP4_DocumentRegister tag ends

				tag_t tDatasetTag = NULLTAG ;
				DNVGL_TRACE_CALL( GRM_find_relation_type(TC_ATTACHES_RELATION,&tStructRelTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tDocRevTag,tStructRelTag,&iObjectCount,&tpRelatedTags ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for ( int index = 0; index < iObjectCount; index++ )
				{						
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_ZIP ) == 0 )
					{
						tDatasetTag = tpRelatedTags[index];
						break;
					}	
				}

				//Export the attached zip to temp location
				char *      reference_name =NULL;
				AE_reference_type_t       reference_type;
				tag_t      referenced_object ;

				DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tDatasetTag , 0 , &reference_name , &reference_type , &referenced_object ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				char *cpOriginalFileName = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(referenced_object, ORIGINAL_FILE_NAME, &cpOriginalFileName) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				const char* cpTempPath;
				cpTempPath = getenv (TEMP_ENV_VAR);

				string strZipFilePath= cpTempPath;
				strZipFilePath.append("\\");
				string strDirName;
				char * timeStamp;
				DNVGL_current_get_time_stamp(DATE_FORMAT_STR_FOOTER, &timeStamp);
				strDirName = timeStamp;
				strZipFilePath.append(strDirName);
				DNVGL_TRACE_CALL( iStatus = _mkdir(strZipFilePath.c_str()) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				bIsTempFolderCreated = true ;
				strTempFolderPath = strZipFilePath;
				strZipFilePath.append("\\");
				strZipFilePath.append(cpOriginalFileName); 

				DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tDatasetTag,reference_name,strZipFilePath.c_str()));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Export the attached Transmittal xml : starts
				DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tXmlDatasetTag , 0 , &reference_name , &reference_type , &referenced_object ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(referenced_object, ORIGINAL_FILE_NAME, &cpOriginalFileName) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				string strXmlFilePath= cpTempPath;
				strXmlFilePath.append("\\");
				strXmlFilePath.append(strDirName);
				strXmlFilePath.append("\\");
				strXmlFilePath.append(cpOriginalFileName); 

				DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tXmlDatasetTag,reference_name,strXmlFilePath.c_str()));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				//Export the attached Transmittal xml : ends


				string strTempFilePath		= ""	;
				string  strFileExt			= ""	;
				string  strFileName			= ""	;
				string  strFileNameWithExt	= ""	;
				string  strDocName			= ""	;
				vector<string> vFiles;
				map<string,string> mTechDocAttributesMap      ;
				map<string,string> mTechDocRevAttributesMap   ;
				tag_t	tCreatedInputTag		=  NULLTAG	;

				string strUnZipFilePath= cpTempPath;
				strUnZipFilePath.append("\\");
				strUnZipFilePath.append(strDirName);
				DNVGL_TRACE_CALL( iStatus = dnvgl_get_files_name_from_zip(strZipFilePath.c_str(),strUnZipFilePath.c_str(),vFiles) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				map<string,string> mfileName ;
				DNVGL_TRACE_CALL( iStatus = dnvgl_read_transmittal_xml( strXmlFilePath.c_str(), mfileName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t * tpInputTags				  = NULLTAG;	
				tpInputTags         =(tag_t*) MEM_alloc ((int)(sizeof(tag_t)*vFiles.size()));
				int *  	iQuantities ;
				iQuantities = (int*) MEM_alloc ((int)(sizeof(int)*vFiles.size()));
				tag_t tUnassignedFolderTag = NULLTAG;

				for( int i = 0; i < vFiles.size(); i++ )
				{
					strTempFilePath = vFiles[i];
					strTempFilePath.erase(strTempFilePath.find_last_not_of("\n")+1);

					std::stringstream stream(strTempFilePath);
					while( getline(stream, strFileNameWithExt, '\\') )
					{
						//no processing required 
					}
					std::size_t dotFound = strFileNameWithExt.find_last_of(".");
					if (dotFound!=std::string::npos)
					{
						strFileName = strFileNameWithExt.substr( 0 ,  dotFound );
						strFileExt = strFileNameWithExt.substr( dotFound+1, strFileNameWithExt.length() );
					}
					else
					{
						continue;
					}

					boolean isAttached = false;

					if( isMDRDocAttached )// If MDR Document is present then 
					{
						//Attach the Dataset to the Technical document 
						for (std::map<string,string>::iterator it = mfileName.begin() ; it != mfileName.end() ; ++it)
						{
							if(tc_strcmp( it->first.c_str() , strFileNameWithExt.c_str() ) == 0 )
							{
								for (std::map<string,tag_t>::iterator it2 = mapExistingTecDocs.begin() ; it2 != mapExistingTecDocs.end() ; ++it2 )
								{
									if(tc_strcmp( it2->first.c_str() , it->second.c_str() ) == 0 )
									{
										DNVGL_TRACE_CALL ( iStatus = dnvgl_attach_dataset_to_techdoc( strTempFilePath.c_str() , it2->second ) );
										DNVGL_LOG_ERROR_AND_THROW_STATUS;
										isAttached = true;
										break;
									}
								}
							}
							if( isAttached )
							{
								break;
							}
						}
						//If the Document doesnt have found matching object_name Name 
						if( !isAttached )
						{	
							if( tUnassignedFolderTag == NULLTAG )
							{
								DNVGL_TRACE_CALL ( iStatus = dnvgl_get_unassignedfiles_folder( tDocumentRegFolder , &tUnassignedFolderTag ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}

							if( tUnassignedFolderTag != NULLTAG )
							{
								tag_t tDataset = NULLTAG;
								DNVGL_TRACE_CALL( iStatus = dnvgl_create_dataset( strTempFilePath.c_str(), &tDataset ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
								if( tDataset != NULLTAG)
								{
									DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation( tUnassignedFolderTag, tDataset, AP4_DATASETS ) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;														
								}
							}
						}
					}
					else
					{
						if (std::find(vExistingFiles.begin(), vExistingFiles.end(), strFileName) != vExistingFiles.end())
						{
							continue; // Need to skip the technical document creation to avoid duplicates 
						} 

						strDocName = mfileName[strFileNameWithExt];
						mTechDocAttributesMap.insert(std::pair<string,string>( OBJECT_NAME , strDocName ) );
						if(cpTranNo != NULL && tc_strlen(cpTranNo)>0)
						{
							mTechDocRevAttributesMap.insert(std::pair<string,string>( AP4_TRANSMITTAL_NO , cpTranNo ) );
						} 
						DNVGL_TRACE_CALL( iStatus = dnvgl_create_input_for_techdoc( mTechDocAttributesMap , mTechDocRevAttributesMap , &tCreatedInputTag ));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
						tpInputTags[i] = tCreatedInputTag ; 
						iQuantities[i]= 1;
						mTechDocAttributesMap.clear();

					}
				}

				if(!isMDRDocAttached)// If MDR Document is not present then 
				{
					int iRevisionCount = NULL ;
					tag_t * tpTectDocRevision = NULLTAG ;
					boolean bFlag = false ;
					tag_t	tNewRev = NULLTAG;

					DNVGL_TRACE_CALL( iStatus = dnvgl_create_documents ( (int)vFiles.size(), iQuantities, tpInputTags, tDocumentRegFolder));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_DOCUMENT_RELATION, &tStructRelTag ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tDocumentRegFolder, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					for ( int index = 0; index < iObjectCount; index++ ){

						DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_NAME, &cpObjectName) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
						for(int i = 0; i < vFiles.size(); i++)
						{
							strTempFilePath = vFiles[i];
							strTempFilePath.erase(strTempFilePath.find_last_not_of("\n")+1);

							std::stringstream stream(strTempFilePath);
							while( getline(stream, strFileNameWithExt, '\\') )
							{
								//no processing required 
							}
							std::size_t dotFound = strFileNameWithExt.find_last_of(".");
							if (dotFound!=std::string::npos)
							{
								strFileName = strFileNameWithExt.substr( 0 ,  dotFound );
								strFileExt = strFileNameWithExt.substr( dotFound+1, strFileNameWithExt.length() );
							}
							if ( mfileName.find(strFileNameWithExt) != mfileName.end() ) 
							{
								strDocName = mfileName[strFileNameWithExt];

								tag_t	tRelationType = NULLTAG ;
								int 	iCount = NULL ;
								tag_t * tSecondaryObjects = NULLTAG;
								if( strDocName.compare(cpObjectName) == 0 )
								{

									DNVGL_TRACE_CALL( iStatus = ITEM_list_all_revs(tpRelatedTags[index] , &iRevisionCount , &tpTectDocRevision) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;

									for( int i = 0 ; i<iRevisionCount; i++ )
									{
										char*   cpTechTranNo        =  NULL;
										DNVGL_TRACE_CALL( AOM_ask_value_string(tpTectDocRevision[i],  AP4_TRANSMITTAL_NO, &cpTechTranNo ) );
										DNVGL_LOG_ERROR_AND_THROW_STATUS;

										if(cpTranNo != NULL && tc_strlen(cpTranNo)>0 && cpTechTranNo != NULL && tc_strlen(cpTechTranNo)>0 &&  strcmp( cpTechTranNo, cpTranNo) == 0 )
										{

											DNVGL_TRACE_CALL( iStatus =  GRM_find_relation_type	(	TC_ATTACHES_RELATION, &tRelationType ) );
											DNVGL_LOG_ERROR_AND_THROW_STATUS;

											DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only(tpTectDocRevision[i], tRelationType, &iCount, &tSecondaryObjects ) );
											DNVGL_LOG_ERROR_AND_THROW_STATUS;

											if( iCount == 0 )
											{
												DNVGL_TRACE_CALL( iStatus = dnvgl_attach_dataset_to_techdoc( strTempFilePath.c_str() , tpRelatedTags[index] ));
												DNVGL_LOG_ERROR_AND_THROW_STATUS;
											}

											bFlag = TRUE;
											break;
										}
									}
									if( !bFlag )
									{
										
										DNVGL_TRACE_CALL( iStatus = dnvgl_create_latest_rev( tpTectDocRevision[iRevisionCount-1], cpTranNo, tNewRev ) );
										DNVGL_LOG_ERROR_AND_THROW_STATUS;
										DNVGL_TRACE_CALL( iStatus = dnvgl_attach_dataset_to_techdoc( strTempFilePath.c_str() , tpRelatedTags[index] ));
										DNVGL_LOG_ERROR_AND_THROW_STATUS;
									}
									bFlag = false ;
								}
							} 
						}
					}
				}
				//Delete the unziped folder				
				std::stringstream stream(strZipFilePath);
				getline(stream, strDeleteFolderName, '.') ;

				strDeleteCmd.append("\"RD ");
				strDeleteCmd.append(" /S ");
				strDeleteCmd.append(" /Q \""); 
				strDeleteCmd.append(strDeleteFolderName);
				strDeleteCmd.append("\"\"");

				//Delete folder
				DNVGL_TRACE_CALL( system( strDeleteCmd.c_str() ) );	

			}
			else
			{
				iStatus = ERROR_919118;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch( ... )
	{
	}	

	//Delete the folder	
	if( bIsTempFolderCreated )
	{
		string strTempFolderDeleteCmd = "" ;

		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_create_latest_rev(tag_t &tpRelatedTags , char *cpTranNo , tag_t tNewRevision )
{
	int	    iStatus          = ITK_ok		;
	DNVGL_TRACE_ENTER();
	try
	{	
		DNVGL_TRACE_CALL( iStatus = ITEM_copy_rev( tpRelatedTags , NULL, &tNewRevision ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if(cpTranNo != NULL && tc_strlen(cpTranNo)>0)
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tNewRevision , AP4_TRANSMITTAL_NO , cpTranNo ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		} 

		DNVGL_TRACE_CALL( iStatus = AOM_save( tNewRevision ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}