#include "dnvgl_workflows.h"
#include "dnvgl_project_handling.h"

int dnvgl_create_and_attach_invoice( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok;
	tag_t*  tParticipantlist    = {NULLTAG} ; 
	logical		lIslocked		= false;

	DNVGL_TRACE_ENTER();
	try
	{
		int		iTargetCount		= 0	;
		char*	pArgValue			= NULL;
		char*	pTypeArg			= NULL;
		char*	pValue				= NULL;
		tag_t   tParticipantType	= NULLTAG;
		int	    iParticipantCount	= 0;
	    tag_t   tParticipant		= NULLTAG;
		int     iGrpCnt				= 0;
		tag_t*	tpGroupTag			= NULLTAG;
		int     iUserCnt			= 0;
		tag_t*	tpUserTag			= NULLTAG;

		std::string sInvoiceType ;
		std::string sInvoiceName ;
		bool bAppendCounter = false ;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Read the arguments
		while( ( pArgValue = TC_next_argument( msg.arguments ) ) != NULL )
		{
			iStatus = ITK_ask_argument_named_value( pArgValue, &pTypeArg, &pValue );
			if( pValue != NULL )
			{
				if( strcmp( pTypeArg, INVOICE_TYPE ) == 0 )
				{
					sInvoiceType.assign( pValue );
				}
				else if( strcmp( pTypeArg, INVOICE_NAME ) == 0 )
				{
					sInvoiceName.assign( pValue );
				}
				else if(strcmp( pTypeArg, APPEND_COUNTER ) == 0)
				{
					char* pValue_Upper = NULL;
					tc_strupr(pValue, &pValue_Upper); // Converting to UPPER case

					bAppendCounter = ( strcmp(pValue_Upper, "TRUE") == 0 ) ? true : false;
				}
			}
		}

		// validating arguments
		if(sInvoiceType.empty() || sInvoiceName.empty() )
		{
			//return invalid  arguments error
			EMH_store_error_s1( EMH_severity_error, ERROR_919128, "DNVGL-create-and-attach-invoice" );
			iStatus = ERROR_919128;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		// read root task and attachemet type
		tag_t   tRootTaskTag     = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// create document of given type
		tag_t   tDocItemTypeTag  = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_INVOICE, NULL, &tDocItemTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t   tDocItemCreateInput = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tDocItemTypeTag, &tDocItemCreateInput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t   tDocRevTypeTag  = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type(AP4_INVOICE_REVISION, NULL, &tDocRevTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t   tDocRevCreateInput = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tDocRevTypeTag, &tDocRevCreateInput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// create object name
		if( bAppendCounter )
		{
			tag_t* attObjects = NULL;
			int iTargetCount = 0;
			DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_reference_attachment, &iTargetCount, &attObjects ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			
			sInvoiceName.append(" - ");
			sInvoiceName.append( std::to_string(iTargetCount + 1) );

			DNVGL_MEM_FREE( attObjects );
		}

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string(tDocItemCreateInput, OBJECT_NAME, sInvoiceName.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string(tDocRevCreateInput, OBJECT_NAME, sInvoiceName.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string(tDocRevCreateInput, AP4_INVOICE_TYPE, sInvoiceType.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag(tDocItemCreateInput, "revision", tDocRevCreateInput) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t* tpattObjects = NULL;
		int iTargetCnt = 0;
		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCnt, &tpattObjects ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tNewDocumentItem  = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( tDocItemCreateInput, &tNewDocumentItem) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save(tNewDocumentItem) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tNewDocumentRevision  = NULLTAG  ;
		DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tNewDocumentItem, &tNewDocumentRevision) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iAttachType = EPM_target_attachment;
		DNVGL_TRACE_CALL( iStatus = EPM_add_attachments(tRootTaskTag, 1, &tNewDocumentRevision, &iAttachType) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Change Invoice ownership to ProjectController

		DNVGL_TRACE_CALL( iStatus = EPM_get_participanttype(  AP4_PROJECTCONTROLLER, &tParticipantType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL ( iStatus = ITEM_rev_ask_participants( tpattObjects[0], tParticipantType, &iParticipantCount, &tParticipantlist ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tParticipantlist[0], FND0_ASSIGNEE_GROUP, &iGrpCnt, &tpGroupTag ) );
	    DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tParticipantlist[0], FND0_ASSIGNEE_USER, &iUserCnt, &tpUserTag ) );
	    DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_ownership(tNewDocumentRevision, tpUserTag[0], tpGroupTag[0] ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if (!lIslocked )
		{
		// Lock the  object
		 DNVGL_TRACE_CALL (  iStatus = AOM_refresh( tNewDocumentItem, 1 ) );
		 DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag(tNewDocumentItem, AP4_PROJECT_BACKPOINTER, tpattObjects[0]) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Save the  object
		DNVGL_TRACE_CALL( iStatus = AOM_save( tNewDocumentItem ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Unlock the object
		DNVGL_TRACE_CALL ( iStatus = AOM_refresh(tNewDocumentItem,0 ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}	
	DNVGL_MEM_FREE( tParticipantlist );
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}