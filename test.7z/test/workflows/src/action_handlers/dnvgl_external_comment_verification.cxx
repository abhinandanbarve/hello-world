/**
* \file dnvgl_external_comment_verification.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This file will check all external comments are verified or not.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Durga D
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 08-Dec-2016   Srushti Hanjage       Initial creation.
* 25-Jan-2017   Sanjay Sah            Modified the function to verify last comment of the comment chain object.
*--------------------------------------------------------------------------------
*/


#include "dnvgl_workflows.h"

using namespace std;

int dnvgl_external_comment_verification( EPM_action_message_t msg )
{
	int	    iStatus				= ITK_ok		;

	int		iTargetCount		= 0				;
	char	*cpObjectType		= NULL			;

	tag_t   tRootTask			= NULLTAG		;
	tag_t	*tpTargets			= NULL			;
	tag_t   tTargetObj			= NULLTAG		;
	tag_t   tRelationType		= NULLTAG		;
	logical isVerified			= TRUE			;
	tag_t*  tpSecondaryObjects	= NULLTAG		;
	tag_t*  tpRelationObjects	= NULLTAG		;
	int		iSecondaryCount	 = NULL				;	 
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tCurrentTask = msg.task;
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTask ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTask, EPM_target_attachment, &iTargetCount, &tpTargets ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObj = tpTargets[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObj, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if(cpObjectType != NULL) {

				if( tc_strcmp( cpObjectType, AP4_TECH_DOC_REVISION ) == 0 )
				{
					DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tTargetObj , AP4_COMMENT_CHAIN_RELATION , AP4_COMMENT_CHAIN, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					for ( int index = 0; index < iSecondaryCount; index++ )
					{
						DNVGL_TRACE_CALL( iStatus = dnvgl_check_comment_verified( tpSecondaryObjects[index], isVerified ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						//If any comment is not verified then the result will be false.
						if(!isVerified)
						{
							break;
						}	
					}
				}
				else if( tc_strcmp( cpObjectType, AP4_COMMENT_CHAIN ) == 0 )
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_check_comment_verified( tTargetObj, isVerified ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if(!isVerified)
					{
						break;
					}
				}
				else if( tc_strcmp( cpObjectType, AP4_ACTIVITYREVISION ) == 0 )
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_chains_for_activity( tTargetObj, &tpSecondaryObjects, &iSecondaryCount, NULL) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					for ( int index = 0; index < iSecondaryCount; index++ )
					{
						DNVGL_TRACE_CALL( iStatus = dnvgl_check_comment_verified( tpSecondaryObjects[index], isVerified ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						//If any comment is not verified then the result will be false.
						if(!isVerified)
						{
							break;
						}	
					}

					if(!isVerified)
					{
						break;
					}

				}
			}
		}
		if(isVerified)
		{
			DNVGL_TRACE_CALL( iStatus = EPM_set_condition_task_result(tCurrentTask,EPM_RESULT_TRUE ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			DNVGL_TRACE_CALL( iStatus = EPM_set_condition_task_result(tCurrentTask,EPM_RESULT_FALSE ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

		}
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE( cpObjectType );
	DNVGL_MEM_FREE( tpTargets );
	DNVGL_MEM_FREE( tpSecondaryObjects );
	DNVGL_MEM_FREE( tpSecondaryObjects );
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_check_comment_verified(tag_t &tCommentChain, logical &isVerified )
{
	int	    iStatus					= ITK_ok;
	char    *cpCommentType		    = NULL	;
	char    *cpVerificationStatus   = NULL  ;

	DNVGL_TRACE_ENTER();
	try
	{
		logical lIsInternal;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_logical( tCommentChain, AP4_INTERNAL_REMARK, &lIsInternal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//If AP4_INTERNAL_REMARK is false then the comment is 'external comment'
		if( !lIsInternal )
		{
			tag_t tLastComment = NULLTAG;
			DNVGL_TRACE_CALL(iStatus = AOM_ask_value_tag( tCommentChain, AP4_LAST_COMMENT, &tLastComment) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tLastComment, AP4_COMMENT_TYPE, &cpCommentType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//C- Comment, R- Reply
			if(cpCommentType != NULL && (tc_strcmp( cpCommentType, COMMENT_TYPE_COMMENT ) == 0 ))
			{
				//If AP4_INT_VERIFICATION_DONE is false then the comment is 'external comment'
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tLastComment, AP4_INT_VERIFICATION_DONE, &cpVerificationStatus ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Check if the comment is verified or published.
				if( tc_strcmp( cpVerificationStatus, VERIFIED_STATE ) != 0 && tc_strcmp( cpVerificationStatus, ISSUED_STATE ) != 0 )
				{
					isVerified = false;
				}
			}
		}
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE( cpCommentType );
	DNVGL_MEM_FREE( cpVerificationStatus );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}