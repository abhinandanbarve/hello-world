#include "dnvgl_workflows.h"

int dnvgl_convert_to_opportunity( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		int		iTargetCount	 = 0		;

		char	*cpObjectType	 = NULL		;

		tag_t   tRootTaskTag     = NULLTAG  ;
		tag_t	*tpTargetTags	 = NULL		;
		tag_t   tTargetObjTag	 = NULLTAG  ;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObjTag = tpTargetTags[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_PROJECT_REVISION ) == 0 )
			{
				
			}
		}
	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}