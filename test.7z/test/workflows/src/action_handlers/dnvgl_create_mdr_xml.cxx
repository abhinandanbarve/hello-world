/**
* \file dnvgl_create_mdr_xml.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This File  contains the functions which are called to create technical document 
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra  
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 08-Aug-2016   Nikhilesh Khatra      Initial creation.
*--------------------------------------------------------------------------------
*/
#include "dnvgl_workflows.h"
#include <openxml/OfficeInterop.h>
using namespace std;

/**
* \file dnvgl_create_mdr_xml.cxx
* \par  Description :
This function will create XML file for the files present in MDR excel.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Import the MDR excel to temp location
b. Read the excel data and Create the XML file
c. Create dataset for the created XML file
d. Attach the created dataset with document revision
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 08-Aug-2016      Nikhilesh Khatra       Initial creation.
* 23-Aug-2016      Nikhilesh Khatra       excel read using config xml.
* 16-Nov-2016      Prasmit Pansare        Added code to call ExcelInterop service to read excel file.
                                          Commented old code.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_mdr_xml( EPM_action_message_t msg ){
	int	    iStatus          = ITK_ok	;
	int		iTargetCount	 = 0		;
	char	*cpObjectType	 = NULL		;
	char	*cpDatasetName	 = NULL		;
	tag_t   tRootTaskTag     = NULLTAG  ;
	tag_t	*tpTargetTags	 = NULL		;
	tag_t   tDocRevTag	 = NULLTAG  ;
	//string delFolderPath;

	string strXmlFileDeleteCmd = "del /f ";
	string strConfigXmlFileDeleteCmd = "del /f ";
	string strExcelFileDeleteCmd = "del /f ";

	//string strXmlFileDeleteCmd = "RD /S ";
	//string strConfigXmlFileDeleteCmd = "RD /S ";
	//string strExcelFileDeleteCmd = "RD /S ";

	string strTempFolderPath = "";
	boolean bIsTempFolderCreated = false ;

	OfficeInterop::ExcelCppService *excelCppObj	= NULL	;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task(msg.task, &tRootTaskTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments(tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for( int i=0; i<iTargetCount; i++ )
		{
			tDocRevTag = tpTargetTags[i];

			tag_t   tExcelDatasetTag = NULLTAG ;
			tag_t   tXmlDatasetTag = NULLTAG ;
			tag_t   tConfigXmlDatasetTag = NULLTAG ;
			tag_t	tStructRelTag	=  NULLTAG	;
			tag_t*	tpRelatedTags	=  {NULLTAG} ;
			int		iObjectCount	= 0			;	
			bool    bIsXmlDatasetExist = false;
			DNVGL_TRACE_CALL( GRM_find_relation_type(TC_ATTACHES_RELATION,&tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tDocRevTag,tStructRelTag,&iObjectCount,&tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iObjectCount; index++ )
			{						
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && (tc_strcmp( cpObjectType, MSEXCEL_DATASET ) == 0 || tc_strcmp( cpObjectType, MSEXCELX_DATASET ) == 0) )
				{
					tExcelDatasetTag = tpRelatedTags[index];

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_NAME, &cpDatasetName) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					break;
				}	
			}

			if( tExcelDatasetTag == NULLTAG )
			{
				iStatus = ERROR_919169;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			//Get the mdr config xml dataset tag if already created : starts
			DNVGL_TRACE_CALL( GRM_find_relation_type(IMAN_REFERENCE_RELATION,&tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tDocRevTag,tStructRelTag,&iObjectCount,&tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iObjectCount; index++ )
			{						
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, TEXT_DATASET ) == 0 )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_NAME, &cpDatasetName) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					if(strcmp(cpDatasetName, MDR_XML_DATASET_NAME ) == 0)
					{
						tXmlDatasetTag = tpRelatedTags[index];
						bIsXmlDatasetExist = true ;
					}
					else if(strcmp(cpDatasetName, MDR_CONFIG_XML_DATASET_NAME ) == 0)
					{
						tConfigXmlDatasetTag = tpRelatedTags[index];
					}
				}	
			}
			//Get the mdr config xml dataset tag if already created : ends

			//Export the attached excel to temp location
			char *      reference_name =NULL;
			AE_reference_type_t       reference_type;
			tag_t      referenced_object ;

			DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tExcelDatasetTag , 0 , &reference_name , &reference_type , &referenced_object ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char *cpOriginalFileName = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(referenced_object, ORIGINAL_FILE_NAME , &cpOriginalFileName) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			string strFileNameWithExt = cpOriginalFileName	;
			string strFileExt = ""							;
			std::size_t dotFound = strFileNameWithExt.find_last_of(".");
			if (dotFound!=std::string::npos)
			{
				strFileExt = strFileNameWithExt.substr( dotFound+1, strFileNameWithExt.length() );

				if( strFileExt.compare( XLSX ) != 0 )
				{
					iStatus = ERROR_919162;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}	
			}

			const char* cpTempPath;
			cpTempPath = getenv (TEMP_ENV_VAR);

			char*       timestamp = NULL;
			string dirTimeStamp;
			
			DNVGL_TRACE_CALL( iStatus = DNVGL_current_get_time_stamp(DATE_FORMAT_STR_FOOTER,&timestamp) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			dirTimeStamp = timestamp;
			//delFolderPath = strExcelFilePath;
			strTempFolderPath = cpTempPath ;
			strTempFolderPath.append("\\");
			strTempFolderPath.append(dirTimeStamp);
		    DNVGL_TRACE_CALL( iStatus = _mkdir( strTempFolderPath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			bIsTempFolderCreated = true ; 
			string strExcelFilePath= strTempFolderPath;
			strExcelFilePath.append("\\");
			strExcelFilePath.append(cpOriginalFileName); 

			DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tExcelDatasetTag,reference_name,strExcelFilePath.c_str()));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Export the attached mdr config xml to temp location
			DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tConfigXmlDatasetTag , 0 , &reference_name , &reference_type , &referenced_object ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(referenced_object, ORIGINAL_FILE_NAME , &cpOriginalFileName) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			string strConfigXmlFilePath= cpTempPath;
			strConfigXmlFilePath.append("\\");
			strConfigXmlFilePath.append(dirTimeStamp);
			strConfigXmlFilePath.append("\\");
			strConfigXmlFilePath.append(cpOriginalFileName); 

			DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tConfigXmlDatasetTag,reference_name,strConfigXmlFilePath.c_str()));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			string  strXmlDatasetName	= MDR_XML_DATASET_NAME	;
			vector<string> vFiles;
			string strTempXmlFilePath = cpTempPath;
			strTempXmlFilePath.append("\\");
			strTempXmlFilePath.append(dirTimeStamp);
			strTempXmlFilePath.append("\\");
			strTempXmlFilePath.append("MDR_xml");			
			strTempXmlFilePath.append(".txt");

			/*16 Nov 2016 :Prasmit: Commented below code, migrated VB script to ExcelInterop and C#*/
			//XML creation code from excel needs to be added
			//DNVGL_TRACE_CALL( iStatus = dnvgl_read_excel (strExcelFilePath.c_str(),strConfigXmlFilePath.c_str(),strTempXmlFilePath.c_str() ) );
			//DNVGL_LOG_ERROR_AND_THROW_STATUS;
			//Dataset creation starts

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_excelinterop_object( excelCppObj, strExcelFilePath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			char* cpMessage  = NULL;
			excelCppObj->CreateMdrXml(strConfigXmlFilePath.c_str(),strTempXmlFilePath.c_str(), &cpMessage);
			if(tc_strcmp(cpMessage, "success")!=0)
			{

				TC_write_syslog("\n ExcelInterop Caused following error = %s",cpMessage);
				iStatus = ERROR_919133;
				EMH_store_error_s1(EMH_severity_error,ERROR_919133,cpMessage);
				return iStatus;
			}

			// file import as dataset
			tag_t tDatasetTypeTag = NULLTAG ;
			DNVGL_TRACE_CALL( iStatus = AE_find_datasettype2( TEXT_DATASET , &tDatasetTypeTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char** cpRefList = NULL;
			char* cpRefName = NULL;
			int    iRefCount = 0   ;
			DNVGL_TRACE_CALL( iStatus = AE_ask_datasettype_refs (tDatasetTypeTag, &iRefCount, &cpRefList) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			//Setting reference name for dataset creation e.g. setting "word" for docx type fo file
			cpRefName = cpRefList[0];
			MEM_free (cpRefList);

			if(tXmlDatasetTag == NULL)
			{
				DNVGL_TRACE_CALL( iStatus = AE_create_dataset_with_id(	tDatasetTypeTag, // aDatasetType
					strXmlDatasetName.c_str(), // aDatasetName
					NULL, // aDatasetDescription
					NULL, // aDatasetId
					NULL, // aDatasetRev
					&tXmlDatasetTag )); // aNewDataset
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else{
				//remove old one
				char *  	reference_name =NULL;
				AE_reference_type_t   	reference_type;
				tag_t  	referenced_object ;
				DNVGL_TRACE_CALL( iStatus = AOM_lock( tXmlDatasetTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tXmlDatasetTag,0,&reference_name,	&reference_type,&referenced_object));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus =  AE_remove_dataset_named_ref_by_tag2 ( tXmlDatasetTag,reference_name,referenced_object ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tXmlDatasetTag ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			DNVGL_TRACE_CALL( iStatus = AOM_lock( tXmlDatasetTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AE_import_named_ref(	tXmlDatasetTag, // datasetTag
				cpRefName, // referenceName
				strTempXmlFilePath.c_str(), // osFullPathName
				NULL, // newFileName
				SS_TEXT ) ) ; // fileTypeFlag
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( tXmlDatasetTag ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tXmlDatasetTag, false ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Dataset  creation ends

			//Attach to doc rev starts
			if(!bIsXmlDatasetExist)
			{
				DNVGL_TRACE_CALL( iStatus = AOM_lock( tDocRevTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_lock( tXmlDatasetTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t	tDatasetRelationTypetag		= NULLTAG;
				tag_t	tDatasetRelationTag			= NULLTAG;

				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( IMAN_REFERENCE_RELATION , &tDatasetRelationTypetag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tDocRevTag,tXmlDatasetTag,tDatasetRelationTypetag,NULLTAG,&tDatasetRelationTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Save relation		
				DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tDatasetRelationTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tXmlDatasetTag ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL(  iStatus = AOM_save( tDocRevTag )) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			//Attach to doc rev ends

			//Construct delete commands to delete temporary files.
			/*strXmlFileDeleteCmd.append(strTempXmlFilePath.c_str());
			strConfigXmlFileDeleteCmd.append(strConfigXmlFilePath.c_str());			
			strExcelFileDeleteCmd.append(strExcelFilePath.c_str());		*/	

			
		}
	}
	catch( ... )
	{
	}

	free(excelCppObj);

	//DNVGL_TRACE_CALL( system(strXmlFileDeleteCmd.c_str()) );
	//DNVGL_TRACE_CALL( system(strConfigXmlFileDeleteCmd.c_str()) );
	//DNVGL_TRACE_CALL( system(strExcelFileDeleteCmd.c_str()) );
	/*DNVGL_TRACE_CALL( iStatus =rmdir(delFolderPath.c_str()));
	DNVGL_LOG_ERROR_AND_THROW_STATUS;*/
	//Delete the folder	
	if(bIsTempFolderCreated){
		string strTempFolderDeleteCmd = "" ;

		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );	

	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
