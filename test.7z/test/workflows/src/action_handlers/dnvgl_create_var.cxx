/**
* \file dnvgl_create_var.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This File  contains the functions which are called to create VAR 
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra  
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 20-Apr-2017   Nikhilesh Khatra      Initial creation.
*--------------------------------------------------------------------------------
*/
#include "dnvgl_workflows.h"
#include <openxml/OfficeInterop.h>
using namespace std;

/**
* \file dnvgl_create_var.cxx
* \par  Description :
This function will create VAR with bookmarks value and commentary table.
It will attach comment letter to comment letter document.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Import the comment letter template to temp location
b. Update bookmark values in comment letter using mapping dataset for comment letter
c. Get all the comment chain associated with document revision
d. Create input for comment letter generation
e. Generate comment letter with commentary table
f. Protect comment letter with password(UID of technical document)
g. Attach comment letter to comment letter revision
h. Attach comment letter revision to technical document revision
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 20-Apr-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_var( EPM_action_message_t msg )
{
	int	    iStatus					= ITK_ok	;
	int		iTargetCount			= 0			;
	int		iObjectCount			= 0			;	
	int		iReferenceCount			= 0			;	
	int     iTechDocCount			= 0			;
	char	*cpObjectType			= NULL		;
	char	*cpDatasetName			= NULL		;
	char    *cpReferenceName		= NULL		;
	char    *cpOriginalFileName		= NULL		;
	char	*cpDocRevUID			= NULL		;
	char	*cpIsFinal				= NULL		;
	char	*cpDocumentType			= NULL		;
	char	*cpDocumentCategory		= NULL		;
	char	*cpTemplateVersion		= NULL		;
	tag_t   tRootTaskTag			= NULLTAG   ;
	tag_t	*tpTargetTags			= NULL		;
	tag_t   tActivityRev			= NULLTAG	;
	tag_t   tRefObjectTag			= NULLTAG	;
	tag_t   tWordTemplateDatasetTag = NULLTAG	;
	tag_t   tWordDatasetTag         = NULLTAG	;
	tag_t	tStructRelTag	        = NULLTAG	;
	tag_t*	tpRelatedTags	        = {NULLTAG} ;
	tag_t*	tpReferenceobj	        = {NULLTAG} ;
	tag_t*  tpTechDocRevs			= {NULLTAG} ;
	tag_t*  tpTechDocRelations		= {NULLTAG} ;

	AE_reference_type_t       aeReferenceType;
	string strTempFolderPath = "";
	boolean bIsTempFolderCreated = false ;
	bool    bIsWordDatasetExist = false;

	OfficeInterop::WordCppService *eFormObj		= NULL	;
	OfficeInterop::WordCppService *wordCppObj	= NULL	;

	DNVGL_TRACE_ENTER();
	try
	{
		AM__set_application_bypass( true );
		POM_AM__set_application_bypass( true );

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task(msg.task, &tRootTaskTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments(tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( dnvgl_get_handler_opts( msg.arguments, IS_FINAL, &cpIsFinal, NULL ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpTargetTags[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tActivityRevType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_ACTIVITYREVISION, AP4_ACTIVITYREVISION, &tActivityRevType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tActivityRevType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !bIsValidType )
			{
				continue;
			}

			tActivityRev = tpTargetTags[i];

			//Get the doc tag from doc rev
			tag_t   tActivity	 = NULLTAG  ;
			DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tActivityRev, &tActivity) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t   tProjectRevTag	 = NULLTAG  ;
			DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tActivityRev, AP4_PROJECT_BACKPOINTER , &tProjectRevTag ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Get the word dataset template from Comment letter template
			DNVGL_TRACE_CALL ( iStatus = dnvgl_get_comment_template_dataset( tProjectRevTag, &cpTemplateVersion, &tWordTemplateDatasetTag ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tCommentRevLatestTag = NULLTAG;
			DNVGL_TRACE_CALL ( iStatus = dnvgl_get_working_comment_letter_revision( tActivityRev, cpTemplateVersion, &tCommentRevLatestTag ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Get the comment letter dataset from tech doc rev if exists: starts
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION , &tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus =  GRM_list_secondary_objects_only( tCommentRevLatestTag ,tStructRelTag,&iObjectCount,&tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iObjectCount; index++ )
			{						
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, MSWORDX_DATASET ) == 0 )
				{
					tWordDatasetTag = tpRelatedTags[index];
					bIsWordDatasetExist = true ;
					break ;
				}	
			}
			//Get the comment letter dataset from tech doc rev if exists: ends

			//Export the attached word to temp location
			DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tWordTemplateDatasetTag , 0 , &cpReferenceName , &aeReferenceType , &tRefObjectTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tRefObjectTag, ORIGINAL_FILE_NAME , &cpOriginalFileName) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			const char* cpTempPath;
			cpTempPath = getenv (TEMP_ENV_VAR);

			char*       timestamp = NULL;
			string dirTimeStamp;

			DNVGL_TRACE_CALL( iStatus = DNVGL_current_get_time_stamp(DATE_FORMAT_STR_FOOTER,&timestamp) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			dirTimeStamp = timestamp;
			//delFolderPath = strExcelFilePath;
			strTempFolderPath = cpTempPath ;
			strTempFolderPath.append("\\");
			strTempFolderPath.append(dirTimeStamp);

			DNVGL_TRACE_CALL( iStatus = _mkdir( strTempFolderPath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//temp folder for eform output
			string strTempEformFolderPath= strTempFolderPath;
			strTempEformFolderPath.append("\\");
			strTempEformFolderPath.append( "eForm" ); 

			DNVGL_TRACE_CALL( iStatus = _mkdir( strTempEformFolderPath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			string strEformWordFilePath= strTempEformFolderPath;
			strEformWordFilePath.append("\\");
			strEformWordFilePath.append(cpOriginalFileName); 

			bIsTempFolderCreated = true ; 
			string strWordFilePath= strTempFolderPath;
			strWordFilePath.append("\\");
			strWordFilePath.append(cpOriginalFileName); 

			DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tWordTemplateDatasetTag,cpReferenceName,strWordFilePath.c_str()));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( ITK__convert_tag_to_uid( tActivityRev, &cpDocRevUID ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tCommLetter = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tCommentRevLatestTag, &tCommLetter ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommLetter, AP4_TEMPLATETYPE, &cpDocumentType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommLetter, AP4_VERSION, &cpDocumentCategory ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tDatasetTag = NULLTAG;
			std::string strEformID;
			std::string strEformDocType;
			std::string strDatasetType;

			DNVGL_TRACE_CALL( iStatus = dnvgl_get_eform_dataset_info( cpDocumentType, cpDocumentCategory, strEformID, strEformDocType, strDatasetType, &tDatasetTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			std::vector<std::string> vTableBookmarks ;
			DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_letter_bookmarks( DNVGL_COMMENT_LETTER_TABLE_BOOKMAKRS, strEformID.c_str(), vTableBookmarks ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( vTableBookmarks.size() != 2 )
			{
				iStatus = ERROR_919165;
				DNVGL_LOG_ERROR_AND_THROW_STATUS ;
			}

			//efrom call
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_wordinterop_object( wordCppObj,strWordFilePath.c_str()) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			string strEncodedWordData ;
			char* cpEncodeDataMsg  = NULL;
			iStatus= wordCppObj->GetEncodedData(strEncodedWordData, &cpEncodeDataMsg);

			std::vector<tag_t> vTechDocs;
			DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tActivityRev , AP4_ACTIVITYDOCRELATION , AP4_TECH_DOC_REVISION, &tpTechDocRevs, &tpTechDocRelations, &iTechDocCount) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for(int iTempRefCounnt =0 ; iTempRefCounnt<iTechDocCount; iTempRefCounnt++)
			{
				vTechDocs.push_back( tpTechDocRevs[iTempRefCounnt] ) ;
			}

			//Update bookmarks
			if( vTechDocs.size()>0 )
			{
				DNVGL_TRACE_CALL( iStatus = dnvgl_update_bookmarks_from_eform(vTechDocs, tCommentRevLatestTag, strEncodedWordData, strEformWordFilePath, strTempFolderPath, vTableBookmarks[1]) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			//convert feteched data which can be input for createCommentTable
			bool bIsFinal = false ;
			if(cpIsFinal != NULL && (tc_strcmp( cpIsFinal, "true" ) == 0))
			{
				bIsFinal = true ;
			}

			char* cpEditableMessage  = NULL;
			std::vector<std::string> vEditableBookmarks ;
			//Featch comment data from doc rev tag
			std::vector<std::vector<std::string>> vCommentChainForInterop;
			std::vector<std::vector<std::string>> vDocDataForInterop ;
			int iTableCount = 0 ;

			//vTechDocs.push_back(tDocRevTag);

			DNVGL_TRACE_CALL( iStatus =  dnvgl_get_input_for_var( tActivityRev, bIsFinal , vCommentChainForInterop, vDocDataForInterop, iTableCount) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_wordinterop_object( eFormObj,strEformWordFilePath.c_str()) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			char* cpCreateMessage  = NULL;
			iStatus = eFormObj->CreateCommentTable( vTableBookmarks[0].c_str() ,vCommentChainForInterop, vDocDataForInterop, iTableCount, bIsFinal, &cpCreateMessage );

			if( iStatus!=0 )
			{
				//Need to add custom error
				TC_write_syslog("\n Interop Caused following error = %s",cpCreateMessage);
				iStatus = ERROR_919139;
				EMH_store_error_s1(EMH_severity_error,ERROR_919139,cpCreateMessage);
				DNVGL_LOG_ERROR_AND_THROW_STATUS ;
			}

			DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_letter_bookmarks( DNVGL_COMMENT_LETTER_EDITABLE_BOOKMAKRS, strEformID.c_str(), vEditableBookmarks ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			iStatus = eFormObj->MakeBookmarksEditable(vEditableBookmarks, &cpEditableMessage);

			if( iStatus!=0 )
			{
				//Need to add custom error
				TC_write_syslog("\n Interop Caused following error = %s",cpEditableMessage);
				iStatus = ERROR_919160;
				EMH_store_error_s1(EMH_severity_error,ERROR_919160,cpEditableMessage);
				DNVGL_LOG_ERROR_AND_THROW_STATUS ;
			}

			char* cpProtectMessage  = NULL;
			iStatus = eFormObj->ApplyDocumentProtection(cpDocRevUID, &cpProtectMessage);

			if( iStatus!=0 )
			{
				//Need to add custom error
				TC_write_syslog("\n Interop Caused following error = %s",cpProtectMessage);
				iStatus = ERROR_919140;
				EMH_store_error_s1(EMH_severity_error,ERROR_919140,cpProtectMessage);
				DNVGL_LOG_ERROR_AND_THROW_STATUS ;
			}

			// file import as dataset
			tag_t tDatasetTypeTag = NULLTAG ;
			DNVGL_TRACE_CALL( iStatus = AE_find_datasettype2( MSWORDX_DATASET , &tDatasetTypeTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char** cpRefList = NULL;
			char* cpRefName = NULL;
			int    iRefCount = 0   ;
			DNVGL_TRACE_CALL( iStatus = AE_ask_datasettype_refs (tDatasetTypeTag, &iRefCount, &cpRefList) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			//Setting reference name for dataset creation e.g. setting "word" for docx type fo file
			cpRefName = cpRefList[0];
			MEM_free (cpRefList);

			if(tWordDatasetTag == NULL)
			{
				DNVGL_TRACE_CALL( iStatus = AE_create_dataset_with_id(	tDatasetTypeTag, // aDatasetType
					VAR_NAME , // aDatasetName
					NULL, // aDatasetDescription
					NULL, // aDatasetId
					NULL, // aDatasetRev
					&tWordDatasetTag )); // aNewDataset
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				//remove old one

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tWordDatasetTag, true ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tWordDatasetTag ,0 ,&cpReferenceName ,&aeReferenceType ,&tRefObjectTag));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus =  AE_remove_dataset_named_ref_by_tag2 ( tWordDatasetTag,cpReferenceName,tRefObjectTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tWordDatasetTag ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tWordDatasetTag, false ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			DNVGL_TRACE_CALL( iStatus = AOM_lock( tWordDatasetTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AE_import_named_ref(	tWordDatasetTag, // datasetTag
				cpRefName, // referenceName
				strEformWordFilePath.c_str(), // osFullPathName
				NULL, // newFileName
				SS_BINARY ) ) ; // fileTypeFlag
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( tWordDatasetTag ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tWordDatasetTag, false ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Dataset  creation ends

			//Attach to doc rev starts
			if(!bIsWordDatasetExist)
			{
				DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation( tCommentRevLatestTag, tWordDatasetTag, TC_ATTACHES_RELATION) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			if( bIsFinal )
			{
				tag_t tReleaseStatus = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = RELSTAT_create_release_status( AP4_ISSUED, &tReleaseStatus ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = RELSTAT_add_release_status( tReleaseStatus, 1, &tCommentRevLatestTag, true ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch( ... )
	{
	}
	//Free memory
	DNVGL_MEM_FREE(cpReferenceName);
	DNVGL_MEM_FREE(tpTargetTags);
	DNVGL_MEM_FREE(tpRelatedTags);
	DNVGL_MEM_FREE(cpObjectType);
	DNVGL_MEM_FREE(cpOriginalFileName);
	DNVGL_MEM_FREE(cpDatasetName);
	DNVGL_MEM_FREE(cpDocRevUID);
	DNVGL_MEM_FREE(tpReferenceobj);
	DNVGL_MEM_FREE(cpDocumentType);
	DNVGL_MEM_FREE(cpDocumentCategory);
	DNVGL_MEM_FREE(cpTemplateVersion);
	free(wordCppObj);
	free(eFormObj);

	//Delete the folder	
	if(bIsTempFolderCreated)
	{
		string strTempFolderDeleteCmd = "" ;

		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );	
	}

	AM__set_application_bypass( false );
	POM_AM__set_application_bypass( false );

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}




/**
* \file dnvgl_create_var.cxx
* \par  Description :
This function will create input vector for creating commentary table.
* \verbatim
\endverbatim     
* \param[in]   vActivityRev						Input Activity revision
* \param[in]   bIsFinal							Comment letter is final or draft 
* \param[in]   objectType					    Object type
* \param[out]  vCommentChainForInterop			Vector with the all require commentary object
* \param[out]  vDocDataForInterop				Vector with the all require technical document attributes
* \param[out]  iTableCount						Table count in comment letter
* \par Algorithm:
* \verbatim  
a. Get all the comment chain associated with Activity revision 
b. Put verifird and external type of commentary object in out put vector
c. Return comment chain vetor

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 20-Apr-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

int dnvgl_get_input_for_var(tag_t vActivityRev, bool bIsFinal, std::vector<std::vector<std::string>> &vCommentChainForInterop, std::vector<std::vector<std::string>> &vDocDataForInterop, int &iTableCount){

	int		iStatus					= ITK_ok	;
	int     iSecondaryCount			= 0			;
	int     iCommentCount			= 0			;
	char*	cpInternalVerification	= NULL		;
	char*	cpCommentStatus			= NULL		;
	char*	cpPage					= NULL		;
	char*	cpSection				= NULL		;
	char*	cpOwningUser			= NULL		;
	char*	cpDocName				= NULL		;
	char*	cpDocId					= NULL		;
	char*	cpDocRevId				= NULL		;
	char*	cpRichtext				= NULL		;
	char*	cpCommentaryName		= NULL		;
	char*	cpCommentDate			= NULL		;
	char*	cpCommentChainIndicator = NULL		;
	char*	cpCommentIndicator		= NULL		;

	//tag_t*  tpSecondaryObjects		= NULL		;
	//tag_t*  tpRelationObjects		= NULL		;
	tag_t*  tpComments				= NULL		;
	tag_t	tOwningUser				= NULL		;

	logical  lInternalRemark		= false		;
	date_t   dCommentDate			= NULLDATE	;
	std::vector< CommentChain > commentChain	;
	std::vector<std::string>         vTempDocAttribute ;
	bool     bIsChainAddedForTechDoc= false		;
	std::map<tag_t, std::vector<tag_t>> mActivityCommentChains ; 

	DNVGL_TRACE_ENTER();
	try{

		DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_chains_for_activity(vActivityRev, NULL, NULL,  &mActivityCommentChains) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int idocSize = 0 ;
		//Iterating on Techdocs
		for (std::map<tag_t, std::vector<tag_t>>::iterator it=mActivityCommentChains.begin(); it!=mActivityCommentChains.end(); ++it)
		{
			tag_t tCurrentDocRev =  it->first ;
			bIsChainAddedForTechDoc = false ;
			if( tCurrentDocRev!= NULLTAG )			
			{
				vTempDocAttribute.clear();

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCurrentDocRev , OBJECT_NAME , &cpDocName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if ((cpDocName == NULL) || (tc_strlen(cpDocName) < 1))
				{
					cpDocName = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
					tc_strcpy(cpDocName, "") ;
				}

				tag_t   tDocTag	 = NULLTAG  ;
				DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tCurrentDocRev, &tDocTag) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tDocTag , AP4_CUSTOMER_DOC_NO , &cpDocId) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if ((cpDocId == NULL) || (tc_strlen(cpDocId) < 1))
				{
					cpDocId = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
					tc_strcpy(cpDocId, "") ;
				}

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCurrentDocRev , AP4_CUSTOMER_DOC_REV_NO , &cpDocRevId) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if ((cpDocRevId == NULL) || (tc_strlen(cpDocRevId) < 1))
				{
					cpDocRevId = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
					tc_strcpy(cpDocRevId, "") ;
				}
				//Putting Techdoc attributes
				vTempDocAttribute.push_back(DOCUMENT_NAME);
				vTempDocAttribute.push_back(cpDocName);
				vTempDocAttribute.push_back(DOCUMENT_NO);
				vTempDocAttribute.push_back(cpDocId);
				vTempDocAttribute.push_back(DOCUMENT_REV);
				vTempDocAttribute.push_back(cpDocRevId);

				std::vector<std::string> vAttribute ;

				std::vector<tag_t> vCommentChains =  it->second ;
				iSecondaryCount = vCommentChains.size();
				//Iterating on Comment chains
				for( int icommChainLen = 0; icommChainLen < iSecondaryCount; icommChainLen++ )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( vCommentChains[icommChainLen] , AP4_STATUS , &cpCommentStatus) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpCommentStatus != NULL && tc_strcmp( cpCommentStatus, DRAFT_STATUS ) == 0 )
					{
						continue ;
					}

					char * cpCommentChainUID = NULL ;
					DNVGL_TRACE_CALL( ITK__convert_tag_to_uid( vCommentChains[icommChainLen], &cpCommentChainUID ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( vCommentChains[icommChainLen], AP4_COMMENTS, &iCommentCount, &tpComments ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( vCommentChains[icommChainLen] , AP4_COMMENT_ID , &cpCommentChainIndicator) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if ((cpCommentChainIndicator == NULL) || (tc_strlen(cpCommentChainIndicator) < 1))
					{
						cpCommentChainIndicator = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
						tc_strcpy(cpCommentChainIndicator, "") ;
					}

					for( int iCommLen = 0; iCommLen < iCommentCount; iCommLen++ )
					{
						vAttribute.clear();
						tag_t tCommTag= tpComments[iCommLen] ;

						if( tCommTag != NULLTAG )
						{
							char * cpCommentType   = NULL ;

							string strCommentaryType = REPLY_TEXT ;
							//Fetch require properties from commentary object (Comment/Reply) : Starts
							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCommTag , AP4_COMMENT_TYPE , &cpCommentType) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if( cpCommentType != NULL && tc_strcmp( cpCommentType, COMMENT_TYPE_COMMENT ) == 0 )
							{
								//Comments should be verified, if not skip that comment chain
								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCommTag , AP4_INT_VERIFICATION_DONE , &cpInternalVerification) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								if( ( !bIsFinal && cpInternalVerification != NULL && tc_strcmp( cpInternalVerification, REJECTED_STATE ) == 0 ) ||
									( bIsFinal && cpInternalVerification != NULL && tc_strcmp( cpInternalVerification, ISSUED_STATE ) != 0 ) )
								{
									break ;
								}
								strCommentaryType = COMMENT_TEXT ;

								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(tCommTag , AP4_PUBLISHED_DATE , &dCommentDate) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}
							else if( cpCommentType != NULL && tc_strcmp( cpCommentType, COMMENT_TYPE_REPLY ) == 0 )
							{				
								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(tCommTag , CREATION_DATE , &dCommentDate) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}

							if( !DATE_IS_NULL( dCommentDate ) )
							{
								DNVGL_TRACE_CALL( iStatus = DATE_date_to_string( dCommentDate, DATE_FORMAT_COMMENT_LETTER, &cpCommentDate ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;						
							}
							else{
								cpCommentDate = (char *) MEM_alloc((int) (tc_strlen(NOT_ISSUED) + 1) * sizeof(char));
								tc_strcpy(cpCommentDate, NOT_ISSUED) ;			
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag(tCommTag, OWNING_USER, &tOwningUser) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if( tOwningUser != NULLTAG )
							{
								logical 	lVerdict = false;

								DNVGL_TRACE_CALL( iStatus = POM_is_loaded( tOwningUser, &lVerdict ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								if(!lVerdict)
								{
									tag_t 	tClassId = NULLTAG ;
									DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( USER, &tClassId ) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;

									DNVGL_TRACE_CALL( iStatus = POM_load_instances( 1, &tOwningUser, tClassId, POM_no_lock ) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;
								}
								DNVGL_TRACE_CALL( iStatus = POM_ask_user_name(tOwningUser, &cpOwningUser) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCommTag , OBJECT_NAME , &cpCommentaryName) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpCommentaryName == NULL) || (tc_strlen(cpCommentaryName) < 1))
							{
								cpCommentaryName = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpCommentaryName, "") ;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCommTag , AP4_RICH_TEXT , &cpRichtext) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpRichtext == NULL) || (tc_strlen(cpRichtext) < 1))
							{
								cpRichtext = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpRichtext, "") ;
							}

							if ((cpCommentStatus == NULL) || (tc_strlen(cpCommentStatus) < 1))
							{
								cpCommentStatus = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpCommentStatus, "") ;
							}
							string strChainEndIndicator = "0";
							if(iCommLen == iCommentCount-1)
							{
								strChainEndIndicator = "1";
								iTableCount++;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( vCommentChains[icommChainLen] , AP4_SECTION , &cpSection) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpSection == NULL) || (tc_strlen(cpSection) < 1))
							{
								cpSection = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpSection, "") ;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( vCommentChains[icommChainLen] , AP4_PAGE , &cpPage) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpPage == NULL) || (tc_strlen(cpPage) < 1))
							{
								cpPage = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpPage, "") ;
							}

							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommTag, AP4_COMMENT_SEQ_ID, &cpCommentIndicator) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if ((cpCommentIndicator == NULL) || (tc_strlen(cpCommentIndicator) < 1))
							{
								cpCommentIndicator = (char *) MEM_alloc((int) (tc_strlen("") + 1) * sizeof(char));
								tc_strcpy(cpCommentIndicator, "") ;
							}
							//Fetch require properties from commentary object (Comment/Reply) : end

							//Push properties in vector
							vAttribute.push_back(strChainEndIndicator);
							vAttribute.push_back(cpCommentChainUID);
							vAttribute.push_back(strCommentaryType);
							vAttribute.push_back(cpCommentStatus);
							vAttribute.push_back(cpCommentaryName);
							vAttribute.push_back(cpSection);
							vAttribute.push_back(cpPage);
							vAttribute.push_back(cpCommentDate);
							vAttribute.push_back(cpOwningUser);
							vAttribute.push_back(cpRichtext);
							vAttribute.push_back(cpCommentChainIndicator);
							vAttribute.push_back(cpCommentIndicator);
							//push each commentary object into outer vetor
							vCommentChainForInterop.push_back(vAttribute);
							if(!bIsChainAddedForTechDoc)
							{
								bIsChainAddedForTechDoc= true ;
							}
						}
					}
				}

				if( bIsChainAddedForTechDoc )
				{
					vDocDataForInterop.push_back(vTempDocAttribute);

					//Document end indicator
					vAttribute.clear();
					vAttribute.push_back("2");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vAttribute.push_back("");
					vCommentChainForInterop.push_back(vAttribute);
					//Document end indicator
				}
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( cpInternalVerification );
	DNVGL_MEM_FREE( tpComments );
	DNVGL_MEM_FREE(cpCommentStatus);
	DNVGL_MEM_FREE(cpDocId);
	DNVGL_MEM_FREE(cpDocName);
	DNVGL_MEM_FREE(cpDocRevId);
	DNVGL_MEM_FREE(cpCommentaryName);
	DNVGL_MEM_FREE(cpRichtext);	
	DNVGL_MEM_FREE(cpSection);	
	DNVGL_MEM_FREE(cpPage);	
	DNVGL_MEM_FREE(cpOwningUser);	
	DNVGL_MEM_FREE(cpCommentDate);
	DNVGL_MEM_FREE(cpCommentChainIndicator);	
	DNVGL_MEM_FREE(cpCommentIndicator);

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}