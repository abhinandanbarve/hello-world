/**
* \file dnvgl_import_comments_from_comment_letter.cxx
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
This File  contains the functions which are called to import comments from comment letter.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra  
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 03-Jan-2017   Nikhilesh Khatra      Initial creation.
*--------------------------------------------------------------------------------
*/
#include "dnvgl_workflows.h"
using namespace std;

/**
* \file dnvgl_import_comments_from_comment_letter.cxx
* \par  Description :
This function will read all the reply from customer letter.It will create comment objects for the respective comment chains.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Get the target object i.e. comment letter revision from the task.
b. Get the word file from the comment letter revision tag.
c. Import the comment letter file to temp location
d. Read the word file using c# method.
e. Get the replies from the word file and their corresponding comment chain UID.
f. Create comment object(comment type is Reply) with richtext from customer and add it respective comment chain.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 03-Jan-2017      Nikhilesh Khatra       Initial creation.
* 27-Apr-2017      Nikhilesh Khatra       Replace AP4_CommLetter with AP4_Deliverable.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_import_comments_from_comment_letter( EPM_action_message_t msg )
{

	int	    iStatus					= ITK_ok	;
	int		iTargetCount			= 0			;	
	char    *cpReferenceName		= NULL		;
	char    *cpOriginalFileName		= NULL		;
	char	*cpDocumentType			= NULL		;
	char	*cpDocumentCategory		=  NULL		;
	tag_t   tRootTaskTag			= NULLTAG   ;
	tag_t	*tpTargetTags			= NULL		;
	tag_t   tCommentLetterRevTag	= NULLTAG	;
	tag_t   tRefObjectTag			= NULLTAG	;
	tag_t   tWordDatasetTag         = NULLTAG	;
	tag_t*  tpSecondaryObjects		= {NULLTAG} ;
	tag_t*  tpRelationObjects		= {NULLTAG} ;
	int     iSecondaryCount			= NULL		;
	AE_reference_type_t       aeReferenceType;
	string strTempFolderPath = "";
	boolean bIsTempFolderCreated = false ;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task(msg.task, &tRootTaskTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments(tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tCommentLetterRevTag = tpTargetTags[i];

			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tCommentLetterRevTag, &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tCommLetterRevType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_DELIVERABLEREVISION, AP4_DELIVERABLEREVISION, &tCommLetterRevType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tCommLetterRevType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !bIsValidType )
			{
				//need to throw error that AP4_DeliverableRevision is allowed
				iStatus = ERROR_919170;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			tag_t tCommLetter = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tCommentLetterRevTag, &tCommLetter ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommLetter, AP4_TEMPLATETYPE, &cpDocumentType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommLetter, AP4_VERSION, &cpDocumentCategory ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpDocumentType != NULL && tc_strcmp( cpDocumentType, DELI_COMMLETTER ) != 0 )
			{
				//need to throw error that deliverable with template type "Comment Letter" is allowed
				iStatus = ERROR_919171;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}	

			//Get the template dataset from project rev : starts
			DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tCommentLetterRevTag , TC_ATTACHES_RELATION , MSWORDX_DATASET, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if(iSecondaryCount == 0)
			{
				//need to throw error that word dataset does not exist.
				iStatus = ERROR_919147;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				tWordDatasetTag = tpSecondaryObjects[0];
			}

			//Export the attached word to temp location : starts
			DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( tWordDatasetTag , 0 , &cpReferenceName , &aeReferenceType , &tRefObjectTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tRefObjectTag, ORIGINAL_FILE_NAME , &cpOriginalFileName) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			const char* cpTempPath;
			cpTempPath = getenv (TEMP_ENV_VAR);

			char*       timestamp = NULL;
			string dirTimeStamp;

			DNVGL_TRACE_CALL( iStatus = DNVGL_current_get_time_stamp(DATE_FORMAT_STR_FOOTER,&timestamp) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			dirTimeStamp = timestamp;

			strTempFolderPath = cpTempPath ;
			strTempFolderPath.append("\\");
			strTempFolderPath.append(dirTimeStamp);

			DNVGL_TRACE_CALL( iStatus = _mkdir( strTempFolderPath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bIsTempFolderCreated = true ; 
			string strWordFilePath= strTempFolderPath;
			strWordFilePath.append("\\");
			strWordFilePath.append(cpOriginalFileName); 

			DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tWordDatasetTag,cpReferenceName,strWordFilePath.c_str()));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Export the attached word to temp location : ends
			tag_t tDatasetTag = NULLTAG;
			std::string strEformID;
			std::string strEformDocType;
			std::string strDatasetType;

			DNVGL_TRACE_CALL( iStatus = dnvgl_get_eform_dataset_info( cpDocumentType, cpDocumentCategory, strEformID, strEformDocType, strDatasetType, &tDatasetTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			std::vector<std::string> vTableBookmarks ;
			DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_letter_bookmarks( DNVGL_COMMENT_LETTER_TABLE_BOOKMAKRS, strEformID.c_str(), vTableBookmarks ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			std::vector<std::string> vReplyData ;
			//Get replies from word file
			DNVGL_TRACE_CALL( iStatus = dnvgl_get_replies_from_comment_letter ( strWordFilePath, vTableBookmarks[0], vReplyData) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			//Create reply object for all replies exported from word file
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_replies_from_comment_letter ( vReplyData) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			//Attach comment letter revision to tech doc revision
			DNVGL_TRACE_CALL( iStatus = dnvgl_attach_comment_letter_to_tech_doc ( tCommentLetterRevTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}
	//Free memory
	DNVGL_MEM_FREE(tpTargetTags);
	DNVGL_MEM_FREE(cpOriginalFileName);
	DNVGL_MEM_FREE(cpReferenceName);
	DNVGL_MEM_FREE(tpSecondaryObjects);
	DNVGL_MEM_FREE(tpRelationObjects);
	DNVGL_MEM_FREE(cpDocumentType);
	DNVGL_MEM_FREE(cpDocumentCategory);

	//Delete the folder	
	if(bIsTempFolderCreated)
	{
		string strTempFolderDeleteCmd = "" ;

		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );	
	}

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_import_comments_from_comment_letter.cxx
* \par  Description :
This function will read all the reply from customer letter.It will call the c# method to read all the replies from customer.
* \verbatim
\endverbatim     
* \param[in]		strWordFilePath		    comment letter path
* \param[out]		vReplyData				replies vector
* \par Algorithm:
* \verbatim  
a. Create WordCppService objce twith comment letter file path.
b. Call c# method to read all the replies from customer.
c. Thorw error if any and set the exceptio nmessage returened from c# method.
d. In case of no error return status and out param vReplyData
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 05-Jan-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_get_replies_from_comment_letter(std::string strWordFilePath, std::string strCommentaryBookmark, std::vector<std::string> &vReplyData)
{	
	int		iStatus					= ITK_ok	;
	OfficeInterop::WordCppService *wordCppObj	= NULL	;
	DNVGL_TRACE_ENTER();
	try{
		DNVGL_TRACE_CALL( iStatus = dnvgl_create_wordinterop_object(wordCppObj,strWordFilePath.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		char* cpErrMessage  = NULL;
		//Calling brigde method to getting all the bookmarks present in comment letter
		iStatus = wordCppObj->ReadCommentTable(strCommentaryBookmark.c_str(), vReplyData , &cpErrMessage );

		//Need to add error msg if any present in cpErrMessage 
		if( iStatus!=0 )
		{
			//Need to add custom error
			TC_write_syslog("\n Interop Caused following error = %s",cpErrMessage);
			iStatus = ERROR_919151;
			EMH_store_error_s1(EMH_severity_error,ERROR_919151,cpErrMessage);
			DNVGL_LOG_ERROR_AND_THROW_STATUS ;
		}
	}
	catch( ... )
	{
	}

	free(wordCppObj);

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_import_comments_from_comment_letter.cxx
* \par  Description :
This function will create reply objects using create comment service operation.
* \verbatim
\endverbatim     
* \param[in]		vReplyData				replies vector
* \par Algorithm:
* \verbatim  
a. Create structre with require data(CommentChainUID, Comment type and roch text) for service operation input
b. Call service operation "dnvgl_service_operation_create_comment" for every reply.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 05-Jan-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_replies_from_comment_letter(std::vector<std::string> &vReplyData)
{	
	int			   iStatus		   = ITK_ok	 ;
	CommentInputVS inputVS					 ;
	tag_t		   tCommentObjTag  = NULLTAG ;
	DNVGL_TRACE_ENTER();
	try{
		for(int iCount =0 ; iCount<vReplyData.size(); iCount=iCount+2)
		{
			inputVS.primaryTargetVS		 	= vReplyData[iCount];
			inputVS.commentTypeVS			= COMMENT_TYPE_REPLY;
			inputVS.richTextVS				= vReplyData[iCount+1];
			inputVS.titleVS					= "Reply" ;
			inputVS.statusVS                = OPEN_STATUS;
			DNVGL_TRACE_CALL( iStatus = dnvgl_service_operation_create_comment ( inputVS, &tCommentObjTag));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		//Add sequence id to last comment
		DNVGL_TRACE_CALL( iStatus = dnvgl_create_comment_count_for_reply ( vReplyData ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_import_comments_from_comment_letter.cxx
* \par  Description :
This function will attach comment letter revision to technical document revision.
* \verbatim
\endverbatim     
* \param[in]		tCommentLetterRevTag			Comment letter revision tag
* \par Algorithm:
* \verbatim  
a. Get Comment letter tag from Comment letter revision tag.
b. Get Tech doc tag from Comment letter tag. Comment letter is attached with Tech doc by IMAN_REFERENCES relation.
c. Get latest tech doc revision from Tech doc.
d. Attach Comment letter rev with Tech doc rev by IMAN_REFERENCES relation.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 05-Jan-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_attach_comment_letter_to_tech_doc(tag_t tCommentLetterRevTag)
{	
	int			   iStatus			= ITK_ok	;
	int			   iObjectCount	    = 0			;	
	CommentInputVS inputVS						;
	tag_t		   commentObjTag	= NULLTAG   ;
	tag_t	       tStructRelTag	= NULLTAG   ;
	tag_t*		   tpRelatedTags	= {NULLTAG} ;
	DNVGL_TRACE_ENTER();
	try{
		tag_t   tCommentLetterTag	 = NULLTAG  ;
		DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tCommentLetterRevTag, &tCommentLetterTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_COMMENTLETTERRELATION , &tStructRelTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(iStatus =  GRM_list_primary_objects_only( tCommentLetterTag, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tPrimaryTypeTag = NULLTAG;  
		DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( AP4_TECH_DOCUMENT , &tPrimaryTypeTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t   tTechDocTag		 = NULLTAG  ;
		tag_t   tTechDocRevTag	 = NULLTAG  ;
		for ( int index = 0; index < iObjectCount; index++ )
		{			
			bool bIsInstance = false;
			tag_t tInputObjectType = NULLTAG;

			DNVGL_TRACE_CALL( iStatus = POM_class_of_instance(tpRelatedTags[index], &tInputObjectType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = POM_is_descendant( tPrimaryTypeTag, tInputObjectType, &bIsInstance) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( bIsInstance )
			{									
				tTechDocTag = tpRelatedTags[index];
				break;
			}			
		}

		DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tTechDocTag , &tTechDocRevTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation( tTechDocRevTag, tCommentLetterRevTag, AP4_COMMENTLETTERRELATION ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}

	//Free memory
	DNVGL_MEM_FREE(tpRelatedTags);

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}