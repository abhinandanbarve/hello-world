#include "dnvgl_workflows.h"

using namespace std;

int dnvgl_shift_schedule_based_on_start_date( EPM_action_message_t msg )
{
	int	    iStatus          = ITK_ok	;
	int 	iCount           = NULL		;
	int		iTargetCount	 = 0		;
	tag_t	tRelationType	 = NULLTAG	;
	tag_t  *tpTargetTags	 = NULL		;
	tag_t  *tSecondaryObjects= NULLTAG	;
	tag_t   tRootTaskTag     = NULLTAG  ;
	tag_t   tProjectRev      = NULLTAG  ;
	date_t  dtStartDate      = NULLDATE ;
	date_t  dtEndDate		 = NULLDATE ;
	
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task(msg.task, &tRootTaskTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		for( int i=0; i<iTargetCount; i++ )
		{
			tProjectRev = tpTargetTags[i];
	
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(tProjectRev, AP4_START_DATE, &dtStartDate) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(tProjectRev, AP4_ESTIMATED_END_DATE, &dtEndDate) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !DATE_IS_NULL( dtStartDate ) )
			{
				DNVGL_TRACE_CALL( iStatus =  GRM_find_relation_type	( AP4_PROJECT_SCHEDULE_RELATION, &tRelationType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only(tProjectRev, tRelationType, &iCount, &tSecondaryObjects ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = dnvgl_shift_schedule( *tSecondaryObjects, dtStartDate, dtEndDate ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}