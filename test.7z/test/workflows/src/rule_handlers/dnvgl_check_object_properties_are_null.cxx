/**
* \file dnvgl_upload_transmittal_without_mdr.cxx
* \par  Description :
This function will create documents in Document Register for the files present in Trasmittal document.
* \verbatim
\endverbatim     
* \param[in]		msg		    action message of document revision
* \par Algorithm:
* \verbatim  
a. Get the file list present in the zip attach to transmittal document revision
b. Check if technical document is already created for the given file
c. If already created skip that file
d. If not created ,create technical document
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 22-Sept-2016     Srushti Hanjage        Initial creation.

*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

#include "dnvgl_workflows.h"

using namespace std;

EPM_decision_t dnvgl_check_object_properties_are_null( EPM_rule_message_t msg )
{
	EPM_decision_t decision = EPM_go;
	int	    iStatus          = ITK_ok	;
	DNVGL_TRACE_ENTER();
	try
	{
		int		iTargetCount	 = NULL		;
		tag_t   tRootTaskTag     = NULLTAG  ;
		tag_t   tTargetObjTag	 = NULLTAG  ;
		tag_t*  tpTargetTags	 = NULLTAG	;
		char*	pArgValue        = NULL		;
		char*	pTypeArg         = NULL		;
		char*	pValue           = NULL		;
		char*	cpPropertyValue	 = NULL		;
	
		std::string sAttachmentType			;
		std::string sIncludeType			;
		vector<string> vProperties			;

		vector<string>::iterator it			;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;

		while( ( pArgValue = TC_next_argument( msg.arguments ) ) != NULL )
		{
			iStatus = ITK_ask_argument_named_value( pArgValue, &pTypeArg, &pValue );
			if( pValue != NULL )
			{
				if( strcmp( pTypeArg, PROPERTY ) == 0 )
				{
					vProperties.clear();
					dnvgl_split( pValue, ',', vProperties );
				}
				else if( strcmp( pTypeArg, INCLUDE_TYPE ) == 0 )
				{
					sIncludeType.assign( pValue );
				}
				else if( strcmp( pTypeArg, ATTACHMENT ) == 0 )
				{
					sAttachmentType.assign( pValue );
				}
			}
		}

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::transform( sAttachmentType.begin(), sAttachmentType.end(), sAttachmentType.begin(), ::tolower );

		if( tc_strcmp( sAttachmentType.c_str(), TARGET ) == 0 )
		{
			DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else if( tc_strcmp( sAttachmentType.c_str(), REFERENCE ) == 0 )
		{
			DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_reference_attachment, &iTargetCount, &tpTargetTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		for( int i = 0; i < iTargetCount; i++ )
		{
			tTargetObjTag = tpTargetTags[i];

			for( it = vProperties.begin(); it != vProperties.end(); it++ )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, (*it).c_str(), &cpPropertyValue ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpPropertyValue != NULL && tc_strlen(cpPropertyValue) != 0 )
				{
					decision = EPM_nogo;
					EMH_store_error_s1( EMH_severity_error, ERROR_919126, (*it).c_str() );
					iStatus = ERROR_919126;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}			
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return decision;
}