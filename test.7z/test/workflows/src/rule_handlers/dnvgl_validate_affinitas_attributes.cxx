#include "dnvgl_workflows.h"

EPM_decision_t dnvgl_validate_affinitas_attributes(EPM_rule_message_t msg)
{
	EPM_decision_t decision = EPM_go;
	int	    iStatus         = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		int		iTargetCount	 = 0		;
		char	*cpObjectType	 = NULL		;
		tag_t   tRootTaskTag     = NULLTAG  ;
		tag_t	*tpTargetTags	 = NULL		;
		tag_t   tTargetObjTag	 = NULLTAG  ;

		DNVGL_TRACE_CALL( iStatus = EMH_clear_errors() );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_root_task( msg.task, &tRootTaskTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_ask_attachments( tRootTaskTag, EPM_target_attachment, &iTargetCount, &tpTargetTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iTargetCount; i++ )
		{
			tTargetObjTag = tpTargetTags[i];

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjTag, OBJECT_TYPE, &cpObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_PROJECT_REVISION ) == 0 )
			{
				date_t dProposalSentDate = NULLDATE;

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(tTargetObjTag, AP4_PROPOSAL_SENT_DATE, &dProposalSentDate) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;


				
				char* cpSalesStage = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tTargetObjTag, AP4_SALES_STAGE, &cpSalesStage) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//  <key locale="en_US" id="LOVValue{::}AP4_SalesStages_LOV{::}1-GAVZB8" status="Approved">Opportunity In Process</key>
				//	<key locale="en_US" id="LOVValue{::}AP4_SalesStages_LOV{::}1-GAVZB9" status="Approved">Proposal Delivered</key>
				//	<key locale="en_US" id="LOVValue{::}AP4_SalesStages_LOV{::}1-GAVZBA" status="Approved">Contract Awarded</key>
				//	<key locale="en_US" id="LOVValue{::}AP4_SalesStages_LOV{::}1-GAVZBB" status="Approved">Lost Opportunity</key>
				//	<key locale="en_US" id="LOVValue{::}AP4_SalesStages_LOV{::}1-GAVZBC" status="Approved">Cancelled By DNV GL</key>
				//	<key locale="en_US" id="LOVValue{::}AP4_SalesStages_LOV{::}1-GAVZBD" status="Approved">Cancelled By Customer</key>

				if( cpSalesStage != NULL && tc_strcmp(cpSalesStage, "1-GAVZB9") == 0  )
				{
					// validating if sale stage value is "Proposal Delivered", then proposal sent date must be filled
					if( DATE_IS_NULL(dProposalSentDate) )
					{
						EMH_store_error( EMH_severity_error, ERROR_919127);
						iStatus = ERROR_919127;
						decision = EPM_nogo;

						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}
				else if(cpSalesStage != NULL && tc_strcmp(cpSalesStage, "1-GAVZB8") == 0 ) 
				{
					// validating if sale stage value is "Opportunity In Process", then proposal sent date must be empty
					if( !DATE_IS_NULL(dProposalSentDate) )
					{
						EMH_store_error( EMH_severity_error, ERROR_919136);
						iStatus = ERROR_919136;
						decision = EPM_nogo;

						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}
			}
		}
	}
	catch( ... )
	{
		decision = EPM_nogo;
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return decision;
}