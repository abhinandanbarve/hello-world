/**
* \file dnvgl_workflows.cxx
* \ingroup libAP4_dnvgl_extensions
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_ProjectStructRelation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 30-May-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_workflows.h"

/**
* \file dnvgl_ap4_project_struct_relation_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int libAP4_dnvgl_workflows_register_callbacks()
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = CUSTOM_register_exit( "libAP4_dnvgl_workflows", "USER_gs_shell_init_module", (CUSTOM_EXIT_ftn_t) dnvgl_register_handlers ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;	
}

int dnvgl_register_handlers( int* decision, va_list args )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		*decision = ALL_CUSTOMIZATIONS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-update-created-by", "DNVGL update created by attribute", (EPM_action_handler_t)dnvgl_update_created_by_attribute ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-create-eForm-dataset", "DNVGL create eForm dataset", (EPM_action_handler_t)dnvgl_create_eform_dataset ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-create-project-user", "DNVGL create project user", (EPM_action_handler_t)dnvgl_create_project_user ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-convert-to-opportunity", "DNVGL convert to opportunity", (EPM_action_handler_t)dnvgl_convert_to_opportunity ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
				
		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-create-transmittal-xml", "DNVGL create transmittal xml", (EPM_action_handler_t)dnvgl_create_transmittal_xml ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
				
		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-create-mdr-xml", "DNVGL created mdr xml", (EPM_action_handler_t)dnvgl_create_mdr_xml ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-upload-transmittal", "DNVGL upload transmittal", (EPM_action_handler_t)dnvgl_upload_transmittal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-send-opportunity-to-affinitas", "DNVGL send opportunity to affinitas", (EPM_action_handler_t)dnvgl_send_opportunity_to_affinitas ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-upload-MDR", "DNVGL upload MDR", (EPM_action_handler_t)dnvgl_upload_mdr ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
        DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-create-and-attach-invoice", "DNVGL create and attach invoice", (EPM_action_handler_t)dnvgl_create_and_attach_invoice ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
				
        DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-copy-to-invoice-folder", "DNVGL copy to invoice folder", (EPM_action_handler_t)dnvgl_copy_to_invoice_folder ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL_shift_schedule_based_on_start_date", "DNVGL shift schedule based on start date", (EPM_action_handler_t)dnvgl_shift_schedule_based_on_start_date ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-add-objects-to-workflow", "DNVGL add objects to workflow", (EPM_action_handler_t)dnvgl_add_objects_to_workflow ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-notify", "DNVGL send a notification", (EPM_action_handler_t)dnvgl_notify ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-create-comment-letter", "DNVGL create comment letter", (EPM_action_handler_t)dnvgl_create_comment_letter ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-import-comments-from-comment-letter", "DNVGL import comments from comment letter", (EPM_action_handler_t)dnvgl_import_comments_from_comment_letter ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-import-surveyor-checklist", "DNVGL import surveyor checklist", (EPM_action_handler_t)dnvgl_import_surveyor_checklist ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-external-comment-verification", "DNVGL check all external comment are verified", (EPM_action_handler_t)dnvgl_external_comment_verification ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-check-comment-added-or-updated", "DNVGL check any comment updated or added new comments", (EPM_action_handler_t)dnvgl_check_comment_added_or_updated ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-check-comment-letter-template", "DNVGL check comment letter template", (EPM_action_handler_t)dnvgl_check_comment_letter_template ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-add-signoff-user", "DNVGL add signoff user", (EPM_action_handler_t)dnvgl_add_signoff_user ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-update-contract-value", "DNVGL update contract value", (EPM_action_handler_t)dnvgl_update_contract_value ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-update-dates-of-schedule-tasks", "DNVGL update dates of schedule tasks", (EPM_action_handler_t)dnvgl_update_dates_of_tasks ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-update-current-assignee", "DNVGL update current assignee", (EPM_action_handler_t)dnvgl_update_current_assignee ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-convert-word-to-pdf", "DNVGL convert word to pdf", (EPM_action_handler_t)dnvgl_convert_word_to_pdf ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-check-surveyor-checklist-template", "DNVGL check surveyor checklist template", (EPM_action_handler_t)dnvgl_check_surveyor_checklist_template ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-create-surveyor-checklist", "DNVGL create surveyor checklist", (EPM_action_handler_t)dnvgl_create_surveyor_checklist ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-import-wvs", "DNVGL import wvs", (EPM_action_handler_t)dnvgl_import_wvs ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-create-var", "DNVGL create var", (EPM_action_handler_t)dnvgl_create_var ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		DNVGL_TRACE_CALL( iStatus = EPM_register_action_handler( "DNVGL-import-comments-from-var", "DNVGL import comments from var", (EPM_action_handler_t)dnvgl_import_comments_from_var ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		// Register Rule handlers here
		DNVGL_TRACE_CALL( iStatus = EPM_register_rule_handler( "DNVGL-validate-affinitas-attributes", "DNVGL validate Affinitas attributes", (EPM_rule_handler_t)dnvgl_validate_affinitas_attributes ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = EPM_register_rule_handler( "DNVGL-check-object-properties-are-null", "DNVGL check if object properties are null", (EPM_rule_handler_t)dnvgl_check_object_properties_are_null ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

