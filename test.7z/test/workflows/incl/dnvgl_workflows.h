/**
* \file dnvgl_workflows.h
* \ingroup libAP4_dnvgl_workflows
* \verbatim
\par Description:
Header file for all the extensions.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 30-May-2016   Vinay Kudari      Initial Creation
*--------------------------------------------------------------------------------
*/

# ifndef DNVGL_WORKFLOWS_H
# define DNVGL_WORKFLOWS_H


#include "dnvgl_common.h"


#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_tcproject_handling.h"
#include "dnvgl_schedule_handling.h"
#include "dnvgl_utils.h"


#include "dnvgl_eform_services.h"
#include "dnvgl_comment_management_service.h"
#include "dnvgl_affinitas_services.h"

#include  <fclasses\OSFile.hxx>
#include <windows.h>


#ifdef __cplusplus
extern "C" {
#endif
	

	//Extension to update TC project on creation of HasParticipant relation.
	DNVGLCOMEXP int libAP4_dnvgl_workflows_register_callbacks();

	//Extension to update TC project on deletion of HasParticipant relation.
	DNVGLCOMEXP int dnvgl_register_handlers( int* decision, va_list args );

	//Action handler to update created by attribute on AP4_ProjectRevision.
	DNVGLCOMEXP int dnvgl_update_created_by_attribute( EPM_action_message_t msg );

	//Action handler to update created by attribute on AP4_ProjectRevision.
	DNVGLCOMEXP int dnvgl_create_eform_dataset( EPM_action_message_t msg );

	//Action handler to create a project user and assign to the correct role.
	DNVGLCOMEXP int dnvgl_create_project_user( EPM_action_message_t msg );

	//Action handler to send an opportunity to affinitas.
	DNVGLCOMEXP int dnvgl_send_opportunity_to_affinitas( EPM_action_message_t msg );

	//Action handler to send an opportunity to affinitas.
	DNVGLCOMEXP int dnvgl_convert_to_opportunity( EPM_action_message_t msg );

	//Action handler to create transmittal XML.
	DNVGLCOMEXP int dnvgl_create_transmittal_xml( EPM_action_message_t msg );

	//Action handler to create MDR XML.
	DNVGLCOMEXP int dnvgl_create_mdr_xml( EPM_action_message_t msg );

	//Action handler to upload transmittal to document registry which does not have any MDR associated.
	DNVGLCOMEXP int dnvgl_upload_transmittal( EPM_action_message_t msg );

	//Action handler to upload tech doc to document registry using mdr xml
	DNVGLCOMEXP int dnvgl_upload_mdr( EPM_action_message_t msg );

    //Action handler to create and attach document revision to process
	DNVGLCOMEXP int dnvgl_create_and_attach_invoice( EPM_action_message_t msg );

	//Action handler to copy final invoice to InvoicesFolder under Governing document folder
	DNVGLCOMEXP int dnvgl_copy_to_invoice_folder( EPM_action_message_t msg );
	
	//Action handler to shift the schdule if start date is present.
	DNVGLCOMEXP int dnvgl_shift_schedule_based_on_start_date( EPM_action_message_t msg );

	//Send a notification
	DNVGLCOMEXP int dnvgl_notify( EPM_action_message_t msg );
	

	//Rule handler to validate attributes of Opportunity before sending to Affinitas
	DNVGLCOMEXP EPM_decision_t dnvgl_validate_affinitas_attributes( EPM_rule_message_t msg );

	//Rule handler to validate if attributes are not null.
	DNVGLCOMEXP EPM_decision_t dnvgl_check_object_properties_are_null( EPM_rule_message_t msg );

	DNVGLCOMEXP int dnvgl_create_latest_rev( tag_t &tpRelatedTags, char *cpTranNo, tag_t tNewRev );

	DNVGLCOMEXP int dnvgl_add_objects_to_workflow( EPM_action_message_t msg );

	//Action handler to create comment letter.
	DNVGLCOMEXP int dnvgl_create_comment_letter( EPM_action_message_t msg );

	//Action handler to to import comments from comment letter.
	DNVGLCOMEXP int dnvgl_import_comments_from_comment_letter( EPM_action_message_t msg );

	//Action handler to to import comments from comment letter.
	DNVGLCOMEXP int dnvgl_import_surveyor_checklist( EPM_action_message_t msg );

	//Action handler to check all external comment are verified.
	DNVGLCOMEXP int dnvgl_external_comment_verification( EPM_action_message_t msg );

	//Action handler to check any comment are updated or added new comments.
	DNVGLCOMEXP int dnvgl_check_comment_added_or_updated( EPM_action_message_t msg );

	//Action handler to check comment letter exists or not.
	DNVGLCOMEXP int dnvgl_check_comment_letter_template( EPM_action_message_t msg );

	//Action handler to add user for Acknowledge task or do task.
	DNVGLCOMEXP int dnvgl_add_signoff_user( EPM_action_message_t msg );

	//Action handler to update local project value on project revision.
	DNVGLCOMEXP int dnvgl_update_contract_value( EPM_action_message_t msg );

	//Action handler to finish dates of the schedule task on close of the project..
	DNVGLCOMEXP int dnvgl_update_dates_of_tasks( EPM_action_message_t msg );

	//Action handler to change current assignee
	DNVGLCOMEXP int dnvgl_update_current_assignee( EPM_action_message_t msg );

	//Action handler to convert word to pdf
	DNVGLCOMEXP int dnvgl_convert_word_to_pdf( EPM_action_message_t msg );

	//Action handler to check if surveyor checklist template exists and then set the condition task result accordingly.
	DNVGLCOMEXP int dnvgl_check_surveyor_checklist_template( EPM_action_message_t msg );

	//Action handler to create surveyor checklist
	DNVGLCOMEXP int dnvgl_create_surveyor_checklist( EPM_action_message_t msg );
	
	//Action handler to create comment letter.
	DNVGLCOMEXP int dnvgl_create_var( EPM_action_message_t msg );

	//Action handler to to import comments from comment letter.
	DNVGLCOMEXP int dnvgl_import_comments_from_var( EPM_action_message_t msg );

	//Action handler to import written verification scheme
	DNVGLCOMEXP int dnvgl_import_wvs( EPM_action_message_t msg );
	
	// helper funtions
	int populateExchangeVersion(tag_t tTargetObjTag);
	int dnvgl_create_and_attach_project_folder(tag_t tTargetObjTag, char* cpFolderType, tag_t *tGoverningDoc);

	//Create input for comment letter
	int dnvgl_get_input_for_comment_letter(std::vector<tag_t> vDocRevs, bool bIsFinal, std::string objectType, std::vector<std::vector<std::string>> &vCommentChainForInterop, std::vector<std::vector<std::string>> &vDocDataForInterop, int &iTableCount) ;
	
	//Create input for var
	int dnvgl_get_input_for_var(tag_t tActivityRev, bool bIsFinal, std::vector<std::vector<std::string>> &vCommentChainForInterop, std::vector<std::vector<std::string>> &vDocDataForInterop, int &iTableCount) ;

	//Get comment letter temaplate dataset
	int dnvgl_get_comment_template_dataset(tag_t tProjectRevTag, char** cpTemplateVesion, tag_t* tpCommentTempDatasetTag);
	
	//Get working comment letter revision
	int dnvgl_get_working_comment_letter_revision(tag_t tDocRevTag, const char	*cpVersion, tag_t* tpCommentRevLatestTag);
	
	//Update comment letter bookmarks using eform service
	int dnvgl_update_bookmarks_from_eform(std::vector<tag_t> vDocRevs, tag_t tCommLetterRev,string strEncodedWordData, string strEformWordFilePath, string strTempFolderPath, string strDrawingTableBookmark);
	
	//Get custommer replies from comment letter
	int dnvgl_get_replies_from_comment_letter(std::string strWordFilePath, std::string strCommentaryBookmark, std::vector<std::string> &vReplyData);
	
	//Create custommer replies from comment letter
	int dnvgl_create_replies_from_comment_letter( std::vector<std::string> &vReplyData );

	//Attach comment letter to tech doc revision
	int dnvgl_attach_comment_letter_to_tech_doc( tag_t tCommentLetterRevTag );

	int dnvgl_generate_pdf( tag_t* tpWordDataset, tag_t* tpPdfDataset );
	int dnvgl_attach_pdf( tag_t* tpDocRev, tag_t* tpPdfDataset );

	//Funtion to check the comment are verified or not.
	int dnvgl_check_comment_verified( tag_t &tCommentChain, logical &isVerified );

	//Method to check that comment is updated.
	int dnvgl_check_comment_updated( tag_t &tCommentChain, logical &isModified);

	//Add current assignee
	int dnvgl_update_comment_chain_current_assignee( tag_t &tCommentChain , tag_t &tCurrAssignee) ;

	//Create table node for eform xml request
	int dnvgl_create_document_table_node(std::vector<tag_t> &vDocRevs, string strDrawingTableBookmark, tinyxml2::XMLDocument &doc, tinyxml2::XMLNode **newNode);

	//Get the latest working Surveyor Checklist revision
	int dnvgl_get_working_surveyor_checklist(tag_t tSurveyorPkg,tag_t tDevieverableTmpl, tag_t* tSurveyorCheckListRev);

	//Get the surveyor template from surveyor package
	int dnvgl_get_surveyor_template( tag_t tSurveyorPkg,tag_t* tDeliverableTmpl, tag_t* tSCTmplDataset);
	
	//Attach comment letter to var
	int dnvgl_attach_comment_letter_to_var( tag_t tCommentLetterRevTag );
	
	//get wrs object using .net data
	int dnvgl_create_wrs( OfficeInterop::VerificationPlanCPP &wvsObject, tag_t tprimaryObject, tag_t tSchedule, tag_t tProjectRev );

	//create objects 
	int dnvgl_create_aba_object(std::string sItemtype, std::string sItemRevtype, std::map<std::string, std::string> &sItemAttributes, std::map<std::string, std::string> &sItemrevAttribuest, tag_t tprimaryObject, std::string relationName, tag_t &tcreatedObject );

	//Helper function to create schedule task.
	int dnvgl_create_schedule_task(tag_t tSchedule, tag_t tActivityRev, tag_t tProjectRev );
	
	//Get comment chains for TRN
	int dnvgl_comment_chains_for_trn(std::vector<std::pair<tag_t, int>> &vCommentChain );
	
#ifdef __cplusplus
}
#endif

#endif //DNVGL_WORKFLOWS_H