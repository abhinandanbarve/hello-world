/**
* \file OfficeInterop.h
* \ingroup OfficeInterop
* \verbatim
\par Description:
Header file for ExcelInterop.cpp WordInterop.cpp
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name				  Description of Change
* 15-Nov-2016   Nikhilesh Khatra      Initial Creation
  17-Apr-2017   Basha G				  Added new class C_WVS,C_SCE,C_PC,C_Activity
*--------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include <vector>
#include <set>
#include <map>
using namespace std;
#ifdef CPPSERVICE_MANAGED
#    define DECLSPECIFIER __declspec(dllexport)
#    define EXPIMP_TEMPLATE
#else
#    define DECLSPECIFIER __declspec(dllimport)
#    define EXPIMP_TEMPLATE extern
#endif

namespace OfficeInterop {

	class VerificationPlanCPP;
	class SafetyCriticalElementCPP;
	class PerformanceCriteriaCPP;
	class ActivityCPP;

	string base64_tostring(string encoded_string);

	/**
	* \file ExcelInterop.cpp
	* \ingroup OfficeInterop
	* \verbatim
	\par Description:
	Class for ExcelCppService which are called to Read or write operations on excel file 
	\par Since: Release1
	\par ENVIRONMENT : C++, ITK

	*\endverbatim
	* \par Owner:
	* Nikhilesh Khatra  
	*
	* \par History:
	*--------------------------------------------------------------------------------
	* Date         	Name			      Description of Change
	* 15-Nov-2016   Nikhilesh Khatra      Initial creation.
	*--------------------------------------------------------------------------------
	*/

	class DECLSPECIFIER ExcelCppService
	{
	public:
		ExcelCppService(const char* filepath);
		virtual ~ExcelCppService();

	public:
		void ReadCellValue(const char* sheetName, const char* cellCoordinates, bool isDateAttr);
		void UpdateCellWSharedString(const char* sheetName, const char* cellCoordinates,const char* cellValue);
		int  ProcalcUpdateCellWSharedString(const char* sheetName, const char* cellCoordinates,const char* cellValue);
		void UnprotectSheet(const char* sheetName);
		void ProtectSheet(const char* sheetName);
		void CreateMdrXml(const char* mdrConfigXmlPath, const char* mdrXmlPath,char ** cMessage);
		VerificationPlanCPP ExcelCppService::readWRS(const char* filepath,int* istaus,char** cpMessage);
		int IsOpenXmlInstalled();
	private:
		void * m_impl;
	};

	/**
	* \file OfficeInterop.cpp
	* \ingroup OfficeInterop
	* \verbatim
	\par Description:
	Class for WordCppService which will perform read, write or update operation on word file.
	\par Since: Release1
	\par ENVIRONMENT : C++, ITK

	*\endverbatim
	* \par Owner:
	* Nikhilesh Khatra  
	*
	* \par History:
	*--------------------------------------------------------------------------------
	* Date         	Name			      Description of Change
	* 30-Nov-2016   Nikhilesh Khatra      Initial creation.
	*--------------------------------------------------------------------------------
	*/
	class DECLSPECIFIER WordCppService
	{
	public:
		WordCppService(const char* filepath);
		virtual ~WordCppService();

	public:
		int CreateCommentTable(const char* cpBookMarkName,std::vector<std::vector<std::string>> &vCommentChains, std::vector<std::vector<std::string>> &vDocData, int tableCount, bool bIsFinal,char ** cpMessage);
		int ApplyDocumentProtection(const char* cpPassword,char ** cpMessage);
		int GetAllBookmarks(std::set<std::string> &sWordFileBookmarks,char ** cpMessage);
		int UpdateBookmarks(std::vector<std::vector<std::string>> &str_vec,char ** cpMessage);
		int ReadCommentTable(const char* cpBookMarkName, std::vector<std::string> &vReplyData, char ** cpMessage);
		int MakeBookmarksEditable(std::vector<std::string> &vBookmarks,char ** cpMessage);
		int GetEncodedData(std::string &strEncoadedData,char ** cpMessage);
		int SaveAsPDF(char** cpPDFFilePath, char ** cpMessage);
		int IsOpenXmlInstalled();

	private:
		void * m_impl;
	};
	
	/**
	* \file OfficeInterop.cpp
	* \ingroup OfficeInterop
	* \verbatim
	\par Description:
	Class for C_WVS which will perform setter and getter for SCE Objects
	\par Since: Release1
	\par ENVIRONMENT : C++, ITK

	*\endverbatim
	* \par Owner:
	* Basha G  
	*
	* \par History:
	*--------------------------------------------------------------------------------
	* Date         	Name			      Description of Change
	* 17-Apr-2017   Basha G					Initial creation.
	*--------------------------------------------------------------------------------
	*/
	class DECLSPECIFIER VerificationPlanCPP
	{

	private:
		std::vector<SafetyCriticalElementCPP> m_SCEs;

    public:
		void setSCES(std::vector<SafetyCriticalElementCPP>);
        std::vector<SafetyCriticalElementCPP> getSCES();

	};

	/**
	* \file OfficeInterop.cpp
	* \ingroup OfficeInterop
	* \verbatim
	\par Description:
	Class for C_SCE which will perform setter and getter for PC and item,item rev it Objects
	\par Since: Release1
	\par ENVIRONMENT : C++, ITK

	*\endverbatim
	* \par Owner:
	*  Basha G  
	*
	* \par History:
	*--------------------------------------------------------------------------------
	* Date         	Name			      Description of Change
	* 17-Apr-2017    Basha G				Initial creation.
	*--------------------------------------------------------------------------------
	*/

	class DECLSPECIFIER SafetyCriticalElementCPP
	{
	
	private:
		std::map<std::string,std::string> itemAttr;

        std::map<std::string,std::string> itemRevAttr;

        std::vector<PerformanceCriteriaCPP> m_PCs;

    public:
        void setItemAttr( std::map<std::string,std::string>);
        std::map<std::string,std::string> getItemAttr();

		void setItemRevAttr( std::map<std::string,std::string>);
        std::map<std::string,std::string> getItemRevAttr();

		void setPCList(std::vector<PerformanceCriteriaCPP>);
        std::vector<PerformanceCriteriaCPP> getPCList();

	};

	/**
	* \file OfficeInterop.cpp
	* \ingroup OfficeInterop
	* \verbatim
	\par Description:
	 Class for C_PC which will perform setter and getter for Acivity and item,item rev it Objects
	\par Since: Release1
	\par ENVIRONMENT : C++, ITK

	*\endverbatim
	* \par Owner:
	* Basha G  
	*
	* \par History:
	*--------------------------------------------------------------------------------
	* Date         	Name			      Description of Change
	* 17-Apr-2017   Basha G      Initial creation.
	*--------------------------------------------------------------------------------
	*/

	class DECLSPECIFIER PerformanceCriteriaCPP
	{

   private:
		std::map<std::string,std::string> itemAttr;

        std::map<std::string,std::string> itemRevAttr;

        std::vector<ActivityCPP> m_activities;

    public:
        void setItemAttr( std::map<std::string,std::string>);
        std::map<std::string,std::string> getItemAttr();

		void setItemRevAttr( std::map<std::string,std::string>);
        std::map<std::string,std::string> getItemRevAttr();

		void setactivity(std::vector<ActivityCPP>);
        std::vector<ActivityCPP> getactivity();
	};

	/**
	* \file OfficeInterop.cpp
	* \ingroup OfficeInterop
	* \verbatim
	\par Description:
	Class for C_Activity which will perform setter and getter for item,item rev it Objects
	\par Since: Release1
	\par ENVIRONMENT : C++, ITK

	*\endverbatim
	* \par Owner:
	* Basha G  
	*
	* \par History:
	*--------------------------------------------------------------------------------
	* Date         	Name			      Description of Change
	* 17-Apr-2017   Basha G					Initial creation.
	*--------------------------------------------------------------------------------
	*/

	class DECLSPECIFIER ActivityCPP
	{

  private:
		std::map<std::string,std::string> itemAttr;

        std::map<std::string,std::string> itemRevAttr;

    public:
        void setItemAttr( std::map<std::string,std::string>);
        std::map<std::string,std::string> getItemAttr();

		void setItemRevAttr( std::map<std::string,std::string>);
        std::map<std::string,std::string> getItemRevAttr();
	};
}


