/**
* \file dnvgl_comment_management_service.cxx
* \ingroup libAP4_dnvgl_services
* \verbatim
\par Description: Implementation code for CommentManagement SOA service operations.

\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah 
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 07-Oct-2016   Sanjay Sah   	      Initial Creation
* 13-Apr-2017   Prasmit Pansare       Fix : Req 871 Modified dnvgl_create_comment_chain()
*--------------------------------------------------------------------------------
*/

#include "dnvgl_comment_management_service.h"


/****************************************************************************
*
*  Function Name:   dnvgl_service_operation_create_comment
*
*  Description: This function creates comment object using input attributes from structure parameter. 
If target associated object is available then only go for creation of comment object.
*
*  Input
*  Parameter:      1. Structure for input attributes for Comment object
*
*  Output
*  Parameter:      1. New Comment object Tag
*		  
*--------------------------------------------------------------------------
* History
*--------------------------------------------------------------------------
* Date         	    Name              Description of Change
* Dec 2016	       Srushti Hanjage    Initial Creation 
* 
****************************************************************************/
int dnvgl_service_operation_create_comment( CommentInputVS input, tag_t *tComment )
{
	int iStatus	= ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t   tComment						= NULLTAG;
		tag_t   tTarget							= NULLTAG;
		tag_t   tUserTag						= NULLTAG;
		char    *user							= NULL;
		char cpObjectType[WSO_name_size_c+1]	= ""; /* Type of object */

		std::string puidOfPTarget			= input.primaryTargetVS ;
		std::string chainType     			= input.chainTypeVS		;
		bool internalRemark					= input.internalRemarkVS;
		std::string title     				= input.titleVS			;
		std::string section     			= input.sectionVS		;
		std::string page     				= input.pageVS			;
		std::string actionResponsible     	= input.actionResponsibleVS;
		std::string commentType     		= input.commentTypeVS	;
		std::string richText     			= input.richTextVS		;
		std::string status     				= input.statusVS		;
		std::string displine                = input.disciplineVS	;
		std::string activityUid             = input.activityUidVS   ;  
			 
		if(!(puidOfPTarget.empty()) && (puidOfPTarget.length() != 0))
		{
			//Create comment				
			DNVGL_TRACE_CALL(iStatus = dnvgl_create_comment( input, &tComment ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( puidOfPTarget.c_str(), &tTarget ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type ( tTarget, cpObjectType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tc_strcmp( AP4_TECH_DOC_REVISION, cpObjectType ) == 0 )
			{			
				//Create comment chain
				tag_t tCommentChain = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = dnvgl_create_comment_chain( input, &tCommentChain ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = dnvgl_add_comment_to_comment_chain( tComment, tCommentChain ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = dnvgl_relate_comment_chain_to_document( tTarget, tCommentChain ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}	
			else
			{
				DNVGL_TRACE_CALL( iStatus = dnvgl_add_comment_to_comment_chain( tComment, tTarget ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch(...)
	{

	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}


int dnvgl_create_comment( CommentInputVS &input, tag_t* tComment )
{
	int iStatus	= ITK_ok;
	tag_t   tCommentType				= NULLTAG;
	tag_t   tCommentInput				= NULLTAG;
	tag_t   tUserTag					= NULLTAG;
	char    *user						= NULL;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_COMMENT, AP4_COMMENT, &tCommentType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tCommentType, &tCommentInput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentInput, OBJECT_NAME, input.titleVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentInput, AP4_COMMENT_TYPE, input.commentTypeVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentInput, AP4_RICH_TEXT, input.richTextVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentInput, AP4_STATUS, input.statusVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_get_user( &user, &tUserTag ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentInput, AP4_LAST_UPDATED_BY, tUserTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* dCurrentDate = NULL;
		DNVGL_TRACE_CALL( iStatus = ITK_ask_default_date_format	( &dCurrentDate ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t dCurrDate = NULLDATE;
		logical lIsValid = false;
		DNVGL_TRACE_CALL( iStatus = DATE_string_to_date_t( dCurrentDate, &lIsValid, &dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( tCommentInput, AP4_LAST_UPDATED_ON, dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( tCommentInput, tComment ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save_with_extensions( *tComment ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{

	}
	DNVGL_TRACE_LEAVE();
	return iStatus;

}

/**
* \file dnvgl_comment_management_service.cxx
* \ingroup libAP4_dnvgl_services
* \verbatim
\par Description:

\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 03-oct-2016   Sanjay Sah     	      Initial Creation
* 13-Apr-2017   Prasmit Pansare       Modified code to set Activity on comment chain
* 28-Apr-2017	Sakshi Mathur		  Modified code to set Project on comment and comment chain
*--------------------------------------------------------------------------------
*/
 

int dnvgl_create_comment_chain( CommentInputVS &input, tag_t* tCommentChain )
{
	int iStatus	= ITK_ok;

	tag_t   tCommentChainType	= NULLTAG;
	tag_t   tCommentChainInput	= NULLTAG;
	tag_t* tProjects			= NULL;
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_COMMENT_CHAIN, AP4_COMMENT_CHAIN, &tCommentChainType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tCommentChainType, &tCommentChainInput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChainInput, OBJECT_NAME, input.titleVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_logical( tCommentChainInput, AP4_INTERNAL_REMARK, input.internalRemarkVS ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChainInput, AP4_CHAIN_TYPE, input.chainTypeVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChainInput, AP4_STATUS, input.statusVS.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChainInput, AP4_SECTION, input.sectionVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChainInput, AP4_PAGE, input.pageVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChainInput, AP4_ACTION_RESPONSIBLE, input.actionResponsibleVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tTarget = NULLTAG ;
		DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( input.primaryTargetVS.c_str(), &tTarget) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChainInput, AP4_PRIMARY_TARGET, tTarget ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tProjectRev = NULLTAG ;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tTarget, AP4_PROJECT_REVISION_ATTRIBUTE, &tProjectRev ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tProjectRev != NULLTAG )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChainInput, AP4_PROJECT_ATTRIBUTE, tProjectRev ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		tag_t tDiscipline = NULLTAG;
		DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( input.disciplineVS.c_str(), &tDiscipline ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tDiscipline != NULLTAG )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChainInput, AP4_DESCIPLINE, tDiscipline ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		tag_t tActivityRev = NULLTAG ;
		if(input.activityUidVS.c_str() != NULL && tc_strlen(input.activityUidVS.c_str())!=0)
		{
			DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( input.activityUidVS.c_str(), &tActivityRev) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			if( tActivityRev != NULLTAG )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChainInput, AP4_ACTIVITY, tActivityRev ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
		
		DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( tCommentChainInput, tCommentChain ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		//Assign tc project to the commentchain
		int iNoOfProjects		= 0;
		DNVGL_TRACE_CALL(  iStatus = AOM_ask_value_tags( tTarget, PROJECT_LIST, &iNoOfProjects, &tProjects ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(  iStatus = PROJ_assign_objects( iNoOfProjects, tProjects, 1, tCommentChain ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save_with_extensions( *tCommentChain ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{

	}

	DNVGL_MEM_FREE( tProjects );

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

/**
* \file dnvgl_comment_management_service.cxx
* Function owner : Vinay Kudari
* \par  Description :
<description of function>.
* \verbatim
*   This function will add comment to comment chain.
\endverbatim     
* \param[in]   tComment			Tag of the comment object
* \param[in]   tCommentChain	Tag of the comment chain object	
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_add_comment_to_comment_chain( tag_t tComment, tag_t tCommentChain )
{
	int iStatus				= ITK_ok;
	tag_t* tComments		= NULL;
	tag_t* tProjects		= NULL;


	char*  cpStatus    	   = NULL;


	DNVGL_TRACE_ENTER();
	try
	{		
		DNVGL_TRACE_CALL( iStatus = AOM_refresh(tCommentChain, TRUE));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;	

		int iCount ;
		DNVGL_TRACE_CALL( iStatus = AOM_get_value_tags( tCommentChain, AP4_COMMENTS, &iCount, &tComments ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t* tAllComments = new tag_t[ iCount + 1 ];
		int i = 0;
		for( i; i < iCount; i++ )
		{
			tAllComments[i] = tComments[i];
		}
		tAllComments[i] = tComment;

		//Assign tc project to the comment
		int iNoOfProjects		= 0;		
		DNVGL_TRACE_CALL(  iStatus = AOM_ask_value_tags( tCommentChain, PROJECT_LIST, &iNoOfProjects, &tProjects ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tComment, TRUE));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;	

		DNVGL_TRACE_CALL(  iStatus = PROJ_assign_objects( iNoOfProjects, tProjects, 1, &tComment ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(  iStatus = AOM_save( tComment ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tComment, FALSE));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;		

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tCommentChain, AP4_COMMENTS, iCount+1, tAllComments ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChain, AP4_LAST_COMMENT, tComment ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( iCount == 0 )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChain, AP4_FIRST_COMMENT, tComment ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		// Read ap4_status of comment and set it on comment chain - Fix for def 1370
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tComment, AP4_STATUS, &cpStatus ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string(tCommentChain,AP4_STATUS, cpStatus));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( tCommentChain ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh(tCommentChain, FALSE));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{

	}

	DNVGL_MEM_FREE( tComments );
	DNVGL_MEM_FREE( tProjects );
	DNVGL_MEM_FREE( cpStatus );

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

/**
* \file dnvgl_comment_management_service.cxx
* Function owner : Vinay Kudari
* \par  Description :
<description of function>.
* \verbatim
*   This function will related comment chain to technical document revision.
\endverbatim     
* \param[in]   tDocRev			Tag of the technical document revision
* \param[in]   tCommentChain	Tag of the comment chain object	
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_relate_comment_chain_to_document( tag_t tDocRev, tag_t tCommentChain )
{
	int iStatus	= ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tRelationType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_COMMENTCHAINRELATION, &tRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tRelation = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tDocRev, tCommentChain, tRelationType, NULLTAG, &tRelation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save_with_extensions( tRelation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{

	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}


/**
* \file dnvgl_comment_management_service.cxx
* Function owner : Sanjay Sah
* \par  Description :
<description of function>.
* \verbatim
*   This function deletes comment object based on passed puid of comment object.
\endverbatim     
* \param[in]   sPuidCommentChain			puid of comment object
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_service_operation_delete_comment( std::string sPuidCommentChain )
{
	int iStatus					= ITK_ok;
	tag_t* tpComments			= NULL;
	tag_t* tpPrimaryObjs		= NULL;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tCommentChain = NULLTAG;

		DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( sPuidCommentChain.c_str(), &tCommentChain ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tCommentChain != NULLTAG )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCommentChain, true ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			int iCount = 0;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tCommentChain, AP4_COMMENTS, &iCount, &tpComments ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tComment = NULLTAG;
			if( iCount == 1 )
			{
				tComment = tpComments[0];

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tCommentChain, AP4_COMMENTS, 0 , NULL ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChain, AP4_LAST_COMMENT, NULLTAG ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else if( iCount > 1 )
			{
				tComment = tpComments[iCount-1];
				tag_t* tAllComments = new tag_t[ iCount - 1 ];	
				int i = 0;
				for( i = 0; i < iCount-1; i++ )
				{
					tAllComments[i] = tpComments[i];
				}

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tCommentChain, AP4_COMMENTS, i , tAllComments ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChain, AP4_LAST_COMMENT, tAllComments[i-1] ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			if( tComment != NULLTAG )
			{
				tag_t tFirstComment = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tCommentChain, AP4_FIRST_COMMENT, &tFirstComment ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( tFirstComment == tComment )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChain, AP4_FIRST_COMMENT, NULLTAG ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				DNVGL_TRACE_CALL( iStatus = AOM_save( tCommentChain ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_delete( tComment ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCommentChain, false ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( iCount == 1 )
			{
				tag_t tRelationType = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_COMMENTCHAINRELATION, &tRelationType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				int iPriObjCount = 0;
				DNVGL_TRACE_CALL( iStatus = GRM_list_primary_objects_only( tCommentChain, tRelationType, &iPriObjCount, &tpPrimaryObjs ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				for( int i = 0; i < iPriObjCount; i++ )
				{
					tag_t tRelation = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = GRM_find_relation( tpPrimaryObjs[i], tCommentChain, tRelationType, &tRelation ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = GRM_delete_relation( tRelation ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				DNVGL_TRACE_CALL( iStatus = AOM_delete( tCommentChain ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch(...)
	{

	}

	DNVGL_MEM_FREE( tpComments );
	DNVGL_MEM_FREE( tpPrimaryObjs );

	DNVGL_TRACE_LEAVE();
	return iStatus;
}


/**
* \file dnvgl_comment_management_service.cxx
* \ingroup libAP4_dnvgl_services
* \verbatim
\par Description:
This function initiate internal verification workflow to the TechDocRevision object.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* Jan 2017   Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/
DNVGLCOMEXP int dnvgl_service_operation_submit_for_internal_verification( std::string targetObjPUID, std::map<std::string,std::string> internalVerifiers )
{
	int iStatus	= ITK_ok;
	tag_t*  tCommentChainObjects	= NULL;
	tag_t*  tRelationObjects		= NULL;
	bool	bIsActivity				= false		; 

	std::map<tag_t, std::vector<tag_t>> mActivityCommentChains ;  
	tag_t * tpTargetObj				= NULLTAG		;
	int    iTargetAttachCount       = 0				;
	int*		iAttachmentTypes					; 

	DNVGL_TRACE_ENTER();
	try
	{
		AM__set_application_bypass( true );
		POM_AM__set_application_bypass( true );

		tag_t   tTargetObj				= NULLTAG;
		tag_t   tInternalVerifierTag	= NULLTAG;
		char    cpObjectType[WSO_name_size_c+1]	= ""; /* Type of object */
		int     iNoOfUsers				= 0;
		tag_t   tUserTag				= NULLTAG;		
		int     iCommentObjCount		= 0;
		logical lIntComment             = true;
		tag_t   tProcessTemplate        = NULLTAG;
		char*   cpProcessName			= NULL;
		int     iAttachmentLoc			= EPM_target_attachment;
		tag_t   tNewProcess				= NULLTAG;

		if(!(targetObjPUID.empty()) && (targetObjPUID.length() != 0))
		{
			DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( targetObjPUID.c_str(), &tTargetObj ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type ( tTargetObj, cpObjectType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tc_strcmp( AP4_TECH_DOC_REVISION, cpObjectType ) == 0 || tc_strcmp( cpObjectType, AP4_ACTIVITYREVISION ) == 0 )
			{
				if(tc_strcmp( cpObjectType, AP4_ACTIVITYREVISION ) == 0)
				{
					bIsActivity = true ; 
				}
				if(internalVerifiers.size() == 1 )
				{
					// If there are no discipline assigned to the TechDocRev
					if(internalVerifiers.find("DISCIPLINE") != internalVerifiers.end())
					{
						// Get the internal verifier UID from the map. 
						std::string internalVeririerUID = internalVerifiers.at("DISCIPLINE");

						// Get the internal verifier Tag. 
						DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( internalVeririerUID.c_str(), &tInternalVerifierTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						//Get the user tag from the internal verifier Tag.
						DNVGL_TRACE_CALL( AOM_ask_value_tag( tInternalVerifierTag, FND0_ASSIGNEE_USER, &tUserTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						//Get all the external comment chains from the AP4_TechDocRevision
						if(bIsActivity)
						{
							DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_chains_for_activity( tTargetObj, &tCommentChainObjects, &iCommentObjCount, &mActivityCommentChains) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							iTargetAttachCount					 = mActivityCommentChains.size() ;
							iTargetAttachCount++ ;
							tpTargetObj							 = (tag_t*) MEM_alloc ((int)(sizeof(int)*(iTargetAttachCount)))	;
							iAttachmentTypes					 = (int*) MEM_alloc ((int)(sizeof(int)*(iTargetAttachCount)))	;

							int iCount = 0;
							//Adding object as target
							(tpTargetObj)[iCount] = tTargetObj;
							(iAttachmentTypes)[iCount] = EPM_target_attachment;
							for (std::map<tag_t, std::vector<tag_t>>::iterator it=mActivityCommentChains.begin(); it!=mActivityCommentChains.end(); ++it)
							{
								//Adding object as reference
								iCount++;							
								(tpTargetObj)[iCount] = it->first;
								(iAttachmentTypes)[iCount] = EPM_reference_attachment;							
							}
						}
						else
						{
							iTargetAttachCount					 = 1 ;
							tpTargetObj							 = (tag_t*) MEM_alloc ((int)(sizeof(int)*(iTargetAttachCount)))	;
							iAttachmentTypes					 = (int*) MEM_alloc ((int)(sizeof(int)*(iTargetAttachCount)))	;

							//Adding object as target
							(tpTargetObj)[0] = tTargetObj;
							(iAttachmentTypes)[0] = EPM_target_attachment;
							DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tTargetObj, AP4_COMMENT_CHAIN_RELATION, AP4_COMMENT_CHAIN, &tCommentChainObjects, &tRelationObjects, &iCommentObjCount ) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;
						}
						if( tCommentChainObjects != NULLTAG && iCommentObjCount > 0 )
						{
							for( int i=0; i<iCommentObjCount; i++ )
							{
								DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCommentChainObjects[i],true ));
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_logical(tCommentChainObjects[i], AP4_INTERNAL_REMARK, &lIntComment));
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								char* cpCommentStatus = NULL;
								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommentChainObjects[i] , AP4_STATUS , &cpCommentStatus) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;								

								if( tc_strcmp( cpCommentStatus, DRAFT_STATUS ) == 0 )
								{
									char* cpChainType = NULL;
									DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tCommentChainObjects[i] , AP4_CHAIN_TYPE , &cpChainType) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;

									char* cpNewCommentStatus = NULL;
									if( tc_strcmp( cpChainType, ACTION_REQUIRED ) == 0 )
									{
										cpNewCommentStatus = OPEN_STATUS;										
									}
									else if( tc_strcmp( cpChainType, IMPORTANT_NOTE ) == 0 )
									{
										cpNewCommentStatus = CLOSED_STATUS;
									}

									DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChainObjects[i] , AP4_STATUS , cpNewCommentStatus ) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;

									tag_t tComment = NULLTAG;
									DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tCommentChainObjects[i], AP4_LAST_COMMENT, &tComment ) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;

									DNVGL_TRACE_CALL( iStatus = AOM_refresh( tComment,true ));
									DNVGL_LOG_ERROR_AND_THROW_STATUS;

									DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tComment , AP4_STATUS , cpNewCommentStatus ) );
									DNVGL_LOG_ERROR_AND_THROW_STATUS;

									DNVGL_TRACE_CALL( iStatus = AOM_save_without_extensions( tComment ));
									DNVGL_LOG_ERROR_AND_THROW_STATUS

										DNVGL_TRACE_CALL( iStatus = AOM_refresh( tComment,false ));
									DNVGL_LOG_ERROR_AND_THROW_STATUS;
								}									

								if( !lIntComment )
								{
									DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tCommentChainObjects[i], AP4_CURRENT_ASSIGNEE, tUserTag ));
									DNVGL_LOG_ERROR_AND_THROW_STATUS;								
								}

								DNVGL_TRACE_CALL( iStatus = AOM_save_without_extensions( tCommentChainObjects[i] ));
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCommentChainObjects[i],false ));
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}
							//Initiate Workflow (submitForInternalVerification) to AP4_TechDocRevision 
							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tTargetObj, OBJECT_STRING, &cpProcessName));
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if( bIsActivity )
							{					
								DNVGL_TRACE_CALL( iStatus = EPM_find_process_template( INTERNAL_VERIFICATION_OF_ACTIVITY, &tProcessTemplate ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}
							else
							{	
								DNVGL_TRACE_CALL( iStatus = EPM_find_process_template( SUBMIT_FOR_INTERNAL_VERIFICATION, &tProcessTemplate ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}

							if(tProcessTemplate != NULLTAG )
							{
								DNVGL_TRACE_CALL( iStatus = EPM_create_process(cpProcessName, cpProcessName, tProcessTemplate, iTargetAttachCount, tpTargetObj, iAttachmentTypes, &tNewProcess));
								DNVGL_LOG_ERROR_AND_THROW_STATUS;								
							}
						}
					}
					else
					{
						// Disciplines are assinged to TechDocRevision
					}
				}
			}
		}
	}
	catch(...)
	{
	}

	AM__set_application_bypass( false );
	POM_AM__set_application_bypass( false );

	DNVGL_MEM_FREE( tCommentChainObjects );
	DNVGL_MEM_FREE( tRelationObjects );
	DNVGL_MEM_FREE( tpTargetObj );
	DNVGL_MEM_FREE( iAttachmentTypes );

	DNVGL_TRACE_LEAVE();
	return iStatus;
}


/**
* \file dnvgl_comment_management_service.cxx
* \ingroup libAP4_dnvgl_services
* \verbatim
\par Description:
This function initiate Quick publish workflow to commentChains objects.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* Jan 2017   Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/
int dnvgl_service_operation_submit_for_quick_publish( std::vector< std::string > puidChainObjects, std::map<std::string,std::string> internalVerifiers)
{
	int iStatus	= ITK_ok;
	tag_t*  tpCommentChains      = NULL;
	int*    iAttchTypes          = NULL;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tTargetChainObject	 = NULLTAG;
		tag_t tInternalVerifier      = NULLTAG;
		tag_t tUser                  = NULLTAG;
		tag_t tNewProcess            = NULLTAG;
		char* cpCommentType          = NULLTAG;
		char* cpProcessName          = NULLTAG;
		tag_t tProcessTemplate       = NULLTAG;
		int     iAttachmentLoc		 = EPM_target_attachment;
		logical lExtComment          = true;
		char* cpObjectType			 = NULL;

		if(puidChainObjects.size() > 0 )
		{
			tpCommentChains = (tag_t*)MEM_alloc( ( (int) puidChainObjects.size()) * (int) sizeof(tag_t) ); // Free this.
			iAttchTypes = (int*)MEM_alloc( (int) (puidChainObjects.size()) * (int) sizeof(int) ); // Free this.

			for(int i = 0; i < puidChainObjects.size(); i++)
			{

				DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( puidChainObjects.at(i).c_str(), &tTargetChainObject ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tpCommentChains[i] = tTargetChainObject;

				if(internalVerifiers.size() == 1 )
				{
					// If there are no discipline assigned to the associted TechDocRev
					if(internalVerifiers.find("DISCIPLINE") != internalVerifiers.end())
					{
						// Get the internal verifier UID from the map. 
						std::string internalVeririerUID = internalVerifiers.at("DISCIPLINE");

						// Get the internal verifier Tag. 
						DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( internalVeririerUID.c_str(), &tInternalVerifier ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						//Get the user tag from the internal verifier Tag.
						DNVGL_TRACE_CALL(iStatus = AOM_ask_value_tag( tInternalVerifier, FND0_ASSIGNEE_USER, &tUser ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_refresh(tTargetChainObject,true));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag(tTargetChainObject, AP4_CURRENT_ASSIGNEE, tUser ));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_save_without_extensions(tTargetChainObject));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = AOM_refresh(tTargetChainObject,false));
						DNVGL_LOG_ERROR_AND_THROW_STATUS
					}

					else
					{
						// Disciplines are assinged to TechDocRevision
					}
				}
			}    

			for(int i = 0; i < puidChainObjects.size(); i++)
			{
				iAttchTypes[i] = EPM_target_attachment;
			}

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tTargetChainObject, OBJECT_STRING, &cpProcessName));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = EPM_find_process_template(SUBMIT_FOR_QUICK_PUBLISH_OF_COMMENTS, &tProcessTemplate));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if(tProcessTemplate != NULLTAG )
			{
				DNVGL_TRACE_CALL( iStatus = EPM_create_process( cpProcessName, cpProcessName, tProcessTemplate, (int) puidChainObjects.size(), tpCommentChains, iAttchTypes, &tNewProcess ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}	
	}
	catch(...)
	{

	}
	DNVGL_MEM_FREE(tpCommentChains);	
	DNVGL_MEM_FREE(iAttchTypes);

	DNVGL_TRACE_LEAVE();
	return iStatus;

}


/**
* \file dnvgl_comment_management_service.cxx
* \ingroup libAP4_dnvgl_services
* \verbatim
\par Description:
This function updates attributes of comment object.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date           	Name			      Description of Change
* Dec 2016	       Srushti Hanjage            Initial Creation
* Jan 2017        Sanjay Sah	              Added attributes to be modified.
* 
*--------------------------------------------------------------------------------
*/
int dnvgl_service_operation_update_comment( CommentInputVS input, tag_t *tCommentObj )
{
	int iStatus	= ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t	tCommentChain		        = NULLTAG;
		tag_t	tComment			        = NULLTAG;
		tag_t   tUserTag					= NULLTAG;
		char    *user						= NULL;

		std::string puidOfPTarget			= input.primaryTargetVS ;
		std::string commentType     		= input.commentTypeVS	;
		std::string richText     			= input.richTextVS		;
		std::string actionResponsible       = input.actionResponsibleVS;
		if( !(puidOfPTarget.empty() ) && (puidOfPTarget.length() != 0))
		{
			DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( puidOfPTarget.c_str(), &tCommentChain ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCommentChain, TRUE ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;		

		int iNoOfComments = 0;
		tag_t* tComments = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_get_value_tags( tCommentChain, AP4_COMMENTS, &iNoOfComments, &tComments ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( iNoOfComments > 0 )
		{
			tComment = tComments[iNoOfComments-1];

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tComment, TRUE ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChain, AP4_ACTION_RESPONSIBLE, actionResponsible.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tComment, AP4_RICH_TEXT, richText.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = POM_get_user(&user, &tUserTag)) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tComment, AP4_LAST_UPDATED_BY, tUserTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char* dCurrentDate = NULL;
			DNVGL_TRACE_CALL( iStatus = ITK_ask_default_date_format	( &dCurrentDate ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			date_t dCurrDate = NULLDATE;
			logical lIsValid = false;
			DNVGL_TRACE_CALL( iStatus = DATE_string_to_date_t( dCurrentDate, &lIsValid, &dCurrDate ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( tComment, AP4_LAST_UPDATED_ON, dCurrDate ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tComment, AP4_STATUS, input.statusVS.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save_with_extensions( tComment ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			*tCommentObj = tComment;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChain, AP4_SECTION, input.sectionVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChain, AP4_PAGE, input.pageVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tCommentChain, AP4_STATUS, input.statusVS.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save_with_extensions( tCommentChain ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tCommentChain, FALSE ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;


	}
	catch(...)
	{

	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}

/****************************************************************************
*
*  Function Name:   dnvgl_service_operation_update_comment
*
*  Description: This function updates attributes of comment object.
*
*  Input
*  Parameter:      1. comment input structure
*
*  Output
*  Parameter:      1. tag of updated comment object
*		  
*--------------------------------------------------------------------------
* History
*--------------------------------------------------------------------------
* Date         	    Name              Description of Change
* Dec 2016	       Srushti Hanjage    Initial Creation
* 
****************************************************************************/
int dnvgl_service_operation_verify_comment(CommentInputVS input, tag_t *updatedCommentObjTag)
{
	int iStatus	= ITK_ok;

	std::string puidOfPTarget			= input.primaryTargetVS ;
	std::string chainType     			= input.chainTypeVS		;
	std::string verificationRemark		= input.verificationRemarkVS ;
	bool   bApproved					= input.isApprovedVS ;
	tag_t  tCurrentRole					= NULLTAG	;
	tag_t  lastComment					= NULLTAG	;
	tag_t  tTargetTag					= NULLTAG	;
	tag_t  *tComments					= NULLTAG	;
	char   *cpObjectType				= NULL		;
	int	   iCount						= NULL		;
	char   *cpRoleName					= NULL		;
	char   *cpChainType					= NULL		;

	DNVGL_TRACE_ENTER();
	try
	{
		AM__set_application_bypass( true );
		POM_AM__set_application_bypass( true );	

		if( !(puidOfPTarget.empty() ) && (puidOfPTarget.length() != 0))
		{
			DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( puidOfPTarget.c_str(), &tTargetTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetTag, OBJECT_TYPE, &cpObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_COMMENT_CHAIN ) == 0)
		{
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetTag, AP4_CHAIN_TYPE, &cpChainType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tTargetTag, AP4_COMMENTS, &iCount, &tComments ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t lastComment = tComments[ iCount-1 ];

			DNVGL_TRACE_CALL( iStatus = SA_ask_current_role( &tCurrentRole ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus =  SA_ask_role_name2( tCurrentRole, &cpRoleName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_verify_comment(&tTargetTag, &lastComment, cpRoleName, cpChainType, verificationRemark.c_str(), bApproved ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch(...)
	{

	}

	POM_AM__set_application_bypass( false );
	AM__set_application_bypass( false );

	DNVGL_MEM_FREE( tComments );
	DNVGL_MEM_FREE( cpObjectType );
	DNVGL_MEM_FREE( cpRoleName );
	DNVGL_TRACE_LEAVE();
	return iStatus;
}

/****************************************************************************
*
*  Function Name:   dnvgl_service_operation_update_comment
*
*  Description: This function updates attributes of comment object.
*
*  Input
*  Parameter:      1. comment input structure
*
*		  
*--------------------------------------------------------------------------
* History
*--------------------------------------------------------------------------
* Date         	    Name              Description of Change
* Dec 2016	       Srushti Hanjage    Initial Creation
* 
****************************************************************************/
int dnvgl_service_operation_verify_all_comments(std::string puidTechdocRev)
{
	int iStatus	= ITK_ok;

	tag_t   tTechDocRev			= NULLTAG;
	tag_t   tRelationType		= NULLTAG;
	tag_t  *tComments			= NULLTAG;
	tag_t  tUserTag				= NULLTAG;
	tag_t  *tpSecondaryObjects	= NULLTAG;
	tag_t  *tpRelationObjects	= NULLTAG;
	tag_t  tCurrentRole			= NULLTAG;
	tag_t  tLastModUser			= NULLTAG;
	tag_t  tCurrentUser			= NULLTAG;
	tag_t  tCurrAssignee		= NULLTAG;
	int		iSecondaryCount		= NULL	;
	int		iCount				= NULL	;
	char   *cpObjectType		= NULL	;
	char   *cpRoleName			= NULL	;
	char   *cpLastModUserID		= NULL	;
	char   *cpCurrentUserID		= NULL	;
	char   *cpVerificationStatus= NULL  ;
	char   *cpChainType			= NULL  ;
	char   *cpCommentStatus		= NULL	;
	char   *cpCommentType		= NULL	;
	char   *cpCurrAssigneeID	= NULL	;
	date_t *dtDate				= NULL	;

	DNVGL_TRACE_ENTER();
	try
	{
		AM__set_application_bypass( true );
		POM_AM__set_application_bypass( true );	

		if( !(puidTechdocRev.empty() ) && (puidTechdocRev.length() != 0))
		{
			DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( puidTechdocRev.c_str(), &tTechDocRev ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTechDocRev, OBJECT_TYPE, &cpObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_TECH_DOC_REVISION ) == 0 )
		{
			DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tTechDocRev , AP4_COMMENT_CHAIN_RELATION , AP4_COMMENT_CHAIN, &tpSecondaryObjects, &tpRelationObjects, &iSecondaryCount) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iSecondaryCount; index++ )
			{	
				logical  lInternalRemark		= false		;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_logical( tpSecondaryObjects[index] , AP4_INTERNAL_REMARK , &lInternalRemark) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpSecondaryObjects[index] , AP4_STATUS , &cpCommentStatus) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if(lInternalRemark || ( cpCommentStatus != NULL && tc_strcmp( cpCommentStatus, DRAFT_STATUS ) == 0 ) )
				{
					continue ;
				}		
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tpSecondaryObjects[index], AP4_COMMENTS, &iCount, &tComments ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpSecondaryObjects[index], AP4_CHAIN_TYPE, &cpChainType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				tag_t lastComment = tComments[ iCount-1 ];

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( lastComment , AP4_COMMENT_TYPE , &cpCommentType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpCommentType != NULL && tc_strcmp( cpCommentType, COMMENT_TYPE_REPLY ) == 0 )
				{
					continue ;
				}	

				DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tpSecondaryObjects[index], AP4_CURRENT_ASSIGNEE, &tCurrAssignee ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( tCurrAssignee != NULL )
				{
					DNVGL_TRACE_CALL( iStatus = POM_ask_user_name( tCurrAssignee, &cpCurrAssigneeID ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				DNVGL_TRACE_CALL( iStatus = AOM_get_value_tag( lastComment, AP4_LAST_UPDATED_BY, &tLastModUser) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = POM_get_user( &cpCurrentUserID, &tCurrentUser ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( tLastModUser != NULLTAG )
				{
					logical 	lVerdict = false;

					DNVGL_TRACE_CALL( iStatus = POM_is_loaded( tLastModUser, &lVerdict ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if(!lVerdict)
					{
						tag_t 	tClassId = NULLTAG ;
						DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( USER, &tClassId ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						DNVGL_TRACE_CALL( iStatus = POM_load_instances( 1, &tLastModUser, tClassId, POM_no_lock ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
					DNVGL_TRACE_CALL( iStatus = POM_ask_user_name(tLastModUser, &cpLastModUserID) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				if( cpLastModUserID != NULL && cpCurrentUserID != NULL && strcmp(cpLastModUserID,cpCurrentUserID)!=0 
					&& cpCurrAssigneeID != NULL && strcmp( cpCurrAssigneeID, cpCurrentUserID ) == 0 )
				{
					DNVGL_TRACE_CALL( iStatus = SA_ask_current_role( &tCurrentRole ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus =  SA_ask_role_name2( tCurrentRole, &cpRoleName ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus =AOM_ask_value_string(lastComment, AP4_INT_VERIFICATION_DONE, &cpVerificationStatus) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpRoleName != NULL && (tc_strcmp( cpRoleName, PROJECT_MANAGER ) == 0 ))
					{
						if( strcmp(cpVerificationStatus, VERIFIED_STATE ) == 0 )
						{
							DNVGL_TRACE_CALL( iStatus = dnvgl_verify_comment( &tpSecondaryObjects[index], &lastComment, cpRoleName, cpChainType, NULL, true ) ) ;
							DNVGL_LOG_ERROR_AND_THROW_STATUS;							
						}
					}
					else
					{
						if( strcmp( cpVerificationStatus,NOT_SET_STATE ) == 0 || strcmp( cpVerificationStatus,REJECTED_STATE ) == 0 )
						{
							DNVGL_TRACE_CALL( iStatus = dnvgl_verify_comment( &tpSecondaryObjects[index], &lastComment, cpRoleName, cpChainType, NULL, true ) ) ;
							DNVGL_LOG_ERROR_AND_THROW_STATUS;							
						}
					}
				}
			}
		}
	}
	catch(...)
	{

	}

	AM__set_application_bypass( false );
	POM_AM__set_application_bypass( false );	

	DNVGL_MEM_FREE( tComments );
	DNVGL_MEM_FREE( tpSecondaryObjects );
	DNVGL_MEM_FREE( tpRelationObjects );
	DNVGL_MEM_FREE( cpObjectType );
	DNVGL_MEM_FREE( cpRoleName );
	DNVGL_MEM_FREE( cpLastModUserID );
	DNVGL_MEM_FREE( cpCurrentUserID );
	DNVGL_MEM_FREE( dtDate );
	DNVGL_MEM_FREE( cpVerificationStatus );
	DNVGL_MEM_FREE( cpChainType );
	DNVGL_MEM_FREE( cpCommentStatus );
	DNVGL_MEM_FREE( cpCommentType );
	DNVGL_MEM_FREE( cpCurrAssigneeID );

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

int dnvgl_verify_comment(tag_t *tpCommentChain, tag_t *tpComment , char* cpRoleName, const char* cpChainType, const char* cpVerificationRemark, bool bApproved)
{
	int iStatus	= ITK_ok;

	tag_t  tUserTag					    = NULLTAG	;
	char   *cpUser						= NULL		;
	char   *cpCommentChainId			= NULL		;

	tag_t  *tpComments					= NULL		;
	int     iCommentCount				= 0			;
	logical lCommentChainWasLockedBefore= false		;
	std::ostringstream	commentSeqId				;
	DNVGL_TRACE_ENTER();
	try
	{
		logical lWasLockedBefore = false;
		DNVGL_TRACE_CALL( iStatus = POM_modifiable( *tpComment, &lWasLockedBefore ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( !lWasLockedBefore )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tpComment, true ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		//Get current user name and user tag
		DNVGL_TRACE_CALL( iStatus = POM_get_user(&cpUser, &tUserTag)) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* dCurrentDate = NULL;
		DNVGL_TRACE_CALL( iStatus = ITK_ask_default_date_format	( &dCurrentDate ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t dCurrDate = NULLDATE;
		logical lIsValid = false;
		DNVGL_TRACE_CALL( iStatus = DATE_string_to_date_t( dCurrentDate, &lIsValid, &dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if(bApproved)
		{
			if( cpRoleName != NULL && (tc_strcmp( cpRoleName, PROJECT_MANAGER ) == 0 ))
			{
				//For Project manager
				DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tpComment, AP4_INT_VERIFICATION_DONE, ISSUED_STATE ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS; 

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( *tpComment, AP4_PUBLISHER, tUserTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( *tpComment, AP4_PUBLISHED_DATE, dCurrDate ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				//For internal verifier				
				DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tpComment, AP4_INT_VERIFICATION_DONE, VERIFIED_STATE ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS; 

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( *tpComment, AP4_INT_VERIFIRE, tUserTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( *tpComment, AP4_VERIFICATION_DATE, dCurrDate ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				//Set comment chain id : starts
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tpCommentChain, AP4_COMMENT_ID,  &cpCommentChainId) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS; 

				if ((cpCommentChainId == NULL) || (tc_strlen(cpCommentChainId) < 1))
				{
					tag_t   tProjectRev		= NULLTAG	;
					DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( *tpCommentChain, AP4_PROJECT_ATTRIBUTE , &tProjectRev ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					std::string strCommentChainId ;
					DNVGL_TRACE_CALL( iStatus = dnvgl_get_comment_chain_count_for_project( tProjectRev, strCommentChainId ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS; 

					if( !strCommentChainId.empty() )
					{
						DNVGL_TRACE_CALL( iStatus = POM_modifiable( *tpCommentChain, &lCommentChainWasLockedBefore ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( !lCommentChainWasLockedBefore )
						{
							DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tpCommentChain, true ) ) ;
							DNVGL_LOG_ERROR_AND_THROW_STATUS;
						}
						DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tpCommentChain, AP4_COMMENT_ID,  strCommentChainId.c_str()) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS; 

						DNVGL_TRACE_CALL( iStatus = AOM_save( *tpCommentChain ) ) ;
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( !lCommentChainWasLockedBefore )
						{
							DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tpCommentChain, false ) ) ;
							DNVGL_LOG_ERROR_AND_THROW_STATUS;
						}
					}
				}

				int iCommentsCount ;

				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( *tpCommentChain, AP4_COMMENTS, &iCommentsCount, &tpComments ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				commentSeqId  << iCommentsCount;
				std::string strCommentSeq = commentSeqId.str();

				DNVGL_TRACE_CALL ( iStatus = AOM_set_value_string( *tpComment, AP4_COMMENT_SEQ_ID, strCommentSeq.c_str() ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				//Set comment chain id : ends
			}
		}
		else
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tpComment, AP4_INT_VERIFICATION_DONE, REJECTED_STATE ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		}

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( *tpComment, AP4_LAST_UPDATED_BY, tUserTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( *tpComment, AP4_LAST_UPDATED_ON, dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( cpVerificationRemark != NULL && ! ( tc_strcmp( cpVerificationRemark, "" ) == 0 ) )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tpComment, AP4_VERIFICATION_REMARK, cpVerificationRemark ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_save( *tpComment ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( !lWasLockedBefore )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tpComment, false ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch(...)
	{

	}	

	DNVGL_MEM_FREE( cpUser );
	DNVGL_MEM_FREE( tpComments );
	DNVGL_MEM_FREE( cpCommentChainId );

	DNVGL_TRACE_LEAVE();
	return iStatus;
}