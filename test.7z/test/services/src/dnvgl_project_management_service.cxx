/**
* \file dnvgl_project_management_service.cxx
* \ingroup libAP4_dnvgl_services
* \verbatim
\par Description: Implementation code for ProjectManagement SOA service operations.

\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Gouthami M 
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 24-May-2017   Gouthami M   	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_project_management_service.h"
#include "dnvgl_schedule_handling.h"
#include "dnvgl_project_handling.h"

int dnvgl_service_operation_copy_from_main_project(  CopyProjectInputVS_t copyProjectInputVS )
{
	int			iStatus						= ITK_ok;
	tag_t		tMainProject				= NULLTAG;
	tag_t		tChildProject				= NULLTAG;
	logical		lIslocked					= false;
	std::vector<DNVGL_ProjectRevisionParticipant_t> allMainProjPctInfos;
	std::vector<DNVGL_ProjectRevisionParticipant_t> allChildProjPctInfos;
	char* cpOneParticipantType[] = {AP4_BIDMANAGER,AP4_BID_RESPONSIBLE,AP4_PROJECTCONTROLLER,
				AP4_PROJECT_SPONSOR,PROPOSED_RESPONSIBLE_PARTY,NULL };	
	
	DNVGL_TRACE_ENTER();
	try
	{
		AM__set_application_bypass( true );
	    POM_AM__set_application_bypass( true );	

		DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( copyProjectInputVS.mainProjectUID.c_str(), &tMainProject ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( copyProjectInputVS.childProjectUID.c_str(), &tChildProject ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Check if object is already locked	
		DNVGL_TRACE_CALL( iStatus = POM_modifiable( tChildProject, &lIslocked ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if (!lIslocked)
		{
		// Lock the  object
		 DNVGL_TRACE_CALL (  iStatus = AOM_refresh( tChildProject, 1 ) );
	     DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		std::vector<std::string> Vproperties = copyProjectInputVS.properties;

		for( std::vector<std::string>::size_type i = 0; i != Vproperties.size(); i++ )
		{
				char* cpValType = NULL;
				PROP_value_type_t valtype;
				DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_type ( tMainProject, Vproperties[i].c_str(), &valtype, &cpValType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				/*switch case begins*/
				switch(valtype)
				{
				case PROP_untyped_relation: // only for untyped relation we have to handle differently.
					 int iRelationCnt;
					 iRelationCnt = 0;
					 tag_t*	 tpUntypedReltnTag;
					 tpUntypedReltnTag	 = NULLTAG;
				
					 //Get Relation Property from MainProject 
					 DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tMainProject, Vproperties[i].c_str(), &iRelationCnt, &tpUntypedReltnTag ) );
					 DNVGL_LOG_ERROR_AND_THROW_STATUS;
					  
					 if( tpUntypedReltnTag != NULLTAG && iRelationCnt > 0 )
					 {
					   if(Vproperties[i] == AP4_PROJECT_SCHEDULE_RELATION)
					   {	 
						   tag_t tNewScheduleTag = NULLTAG;
						   tag_t tScheduleSummaryTag = NULLTAG;
						   int	 iRefFound	 =   0 ;
						   int*  iLevelFound =  NULL;
						   char** cpReferences =  NULL;
						   tag_t* tpRefObjects = NULLTAG;
						   char* cpcheduleObjype  =  NULL ; 
						   int   iChildSchRelationCnt   = 0;
						   tag_t*	tpChildProjScheduleTag = NULLTAG;

						   DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tpUntypedReltnTag[0], FND0SUMMARYTASK, &tScheduleSummaryTag ) );
						   DNVGL_LOG_ERROR_AND_THROW_STATUS;

						   DNVGL_TRACE_CALL( iStatus = WSOM_where_referenced( tScheduleSummaryTag, 1, &iRefFound, &iLevelFound, &tpRefObjects, &cpReferences ) );
						   DNVGL_LOG_ERROR_AND_THROW_STATUS;
						   
						   //Get Relation Property from ChildProject 
						   DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tChildProject, Vproperties[i].c_str(), &iChildSchRelationCnt, &tpChildProjScheduleTag ) );
						   DNVGL_LOG_ERROR_AND_THROW_STATUS;

						//check for Main project Summary Task
						if( iRefFound >1 )
						{
						   if( tpChildProjScheduleTag != NULLTAG && iChildSchRelationCnt >0 )
						   {
							  tag_t tChildScheduleSummaryTag = NULLTAG;
							  int	 iChilRefFound	 =   0 ;
						      int*  iChildLevelFound =  NULL;
						      char** cpChildReferences =  NULL;
						      tag_t* tpChildRefObjects = NULLTAG;

						     DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tpChildProjScheduleTag[0], FND0SUMMARYTASK, &tChildScheduleSummaryTag ) );
						     DNVGL_LOG_ERROR_AND_THROW_STATUS;

						     DNVGL_TRACE_CALL( iStatus = WSOM_where_referenced( tChildScheduleSummaryTag, 1, &iChilRefFound, &iChildLevelFound, &tpChildRefObjects, &cpChildReferences ) );
						     DNVGL_LOG_ERROR_AND_THROW_STATUS;

							 //check for Schedule Task in cchild project
							 if( !( iChilRefFound >1 ) )
							 {
								 DNVGL_TRACE_CALL( iStatus = dnvgl_copy_schedule( tpUntypedReltnTag, &tNewScheduleTag ) );
								 DNVGL_LOG_ERROR_AND_THROW_STATUS;
								if( tNewScheduleTag != NULLTAG )
								{
								   char* pProjectRevObjName = NULL;
								   DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tChildProject, Vproperties[i].c_str(), 0, NULL ) );
								   DNVGL_LOG_ERROR_AND_THROW_STATUS;

								   DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tChildProject, Vproperties[i].c_str(), iRelationCnt, &tNewScheduleTag ) );
								   DNVGL_LOG_ERROR_AND_THROW_STATUS;
								}
							 }
						   }
						   else
						   {
							 DNVGL_TRACE_CALL( iStatus = dnvgl_copy_schedule( tpUntypedReltnTag, &tNewScheduleTag ) );
						     DNVGL_LOG_ERROR_AND_THROW_STATUS;
						    if( tNewScheduleTag != NULLTAG )
							{
							   char* pProjectRevObjName = NULL;
							   DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tChildProject, Vproperties[i].c_str(), 0, NULL ) );
							   DNVGL_LOG_ERROR_AND_THROW_STATUS;

							   DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tChildProject, Vproperties[i].c_str(), iRelationCnt, &tNewScheduleTag ) );
							   DNVGL_LOG_ERROR_AND_THROW_STATUS;
							}
						   }
					     }
					   }
					    else{
						  DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tChildProject, Vproperties[i].c_str(), 0, NULL ) );
						  DNVGL_LOG_ERROR_AND_THROW_STATUS;

						  DNVGL_TRACE_CALL( iStatus = AOM_set_value_tags( tChildProject, Vproperties[i].c_str(), iRelationCnt, tpUntypedReltnTag ) );
						  DNVGL_LOG_ERROR_AND_THROW_STATUS;
					     }
					 }
					  break;

				case PROP_double: // only for double we have to handle differently.
					 double  dDoubleTag;
					 dDoubleTag	 = NULL;
					 DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tMainProject, Vproperties[i].c_str(), &dDoubleTag ) );
					 DNVGL_LOG_ERROR_AND_THROW_STATUS;

					 if(dDoubleTag != NULL ){
					 DNVGL_TRACE_CALL( iStatus = AOM_set_value_double( tChildProject, Vproperties[i].c_str(), dDoubleTag ) );
					 DNVGL_LOG_ERROR_AND_THROW_STATUS;
					 }
					break;

			    case PROP_string: // only for String we have to handle differently.
					 char*   cpStringTag;
					 cpStringTag	= NULL;

					 DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tMainProject, Vproperties[i].c_str(), &cpStringTag ) );
					 DNVGL_LOG_ERROR_AND_THROW_STATUS;

					 if(cpStringTag != NULL ){
					 DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tChildProject, Vproperties[i].c_str(), cpStringTag ) );
					 DNVGL_LOG_ERROR_AND_THROW_STATUS;
					 }

					 if(Vproperties[i] == AP4_SERVICE_LINE )
					 {
					 DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tMainProject, AP4_SERVICE_CODE, &cpStringTag ) );
					 DNVGL_LOG_ERROR_AND_THROW_STATUS;

					 if(cpStringTag != NULL ){
					 DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tChildProject, AP4_SERVICE_CODE, cpStringTag ) );
					 DNVGL_LOG_ERROR_AND_THROW_STATUS;
					 }
					 }
					break;
	
                case PROP_date: // only for date we have to handle differently.
					 date_t	 dtDateTag;
					 dtDateTag	= NULLDATE;
					 DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date( tMainProject,  Vproperties[i].c_str(), &dtDateTag ) );
					 DNVGL_LOG_ERROR_AND_THROW_STATUS;

					 if( !DATE_IS_NULL(dtDateTag) ){
					 DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( tChildProject,  Vproperties[i].c_str(), dtDateTag ) );
					 DNVGL_LOG_ERROR_AND_THROW_STATUS;
					 }
					break;
					
                case PROP_untyped_reference: // only for untyped reference we have to handle differently.
					{
					tag_t tMainGroupMember;
					tMainGroupMember=NULLTAG;
					tag_t tChildGroupMember;
					tChildGroupMember=NULLTAG;
					tag_t tpartcipntTag;
					tpartcipntTag=NULLTAG;

					DNVGL_TRACE_CALL( iStatus = get_all_participants( tMainProject, allMainProjPctInfos ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					std::vector<DNVGL_ProjectRevisionParticipant_t>::iterator itrMain = allMainProjPctInfos.begin();

					while( itrMain != allMainProjPctInfos.end() )
					{
					    tMainGroupMember = itrMain->groupMember;

						std::string MpctType = itrMain->participantType;
						char * cpMainPartcpnt = new char[MpctType.size() + 1];
						std::copy(MpctType.begin(), MpctType.end(), cpMainPartcpnt);
						cpMainPartcpnt[MpctType.size()] = '\0'; // don't forget the terminating 0

						tag_t tParticipantType = NULLTAG;
						DNVGL_TRACE_CALL( iStatus = EPM_get_participanttype(  cpMainPartcpnt, &tpartcipntTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( tMainGroupMember != NULLTAG )
						{
							tag_t tRolTag = NULLTAG;
							DNVGL_TRACE_CALL( iStatus =  SA_ask_groupmember_role( tMainGroupMember , &tRolTag ) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							char* cRolName = NULL;
							DNVGL_TRACE_CALL( iStatus =  SA_ask_role_name2( tRolTag, &cRolName ) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

						
						 if( ( tc_strcmp ( cpMainPartcpnt, AP4_PROJECTMANAGER ) != 0 ) && ( tc_strcmp ( cpMainPartcpnt, AP4_SUBCONTRACTOR ) != 0 ) &&
								( tc_strcmp ( cRolName, FINANCIAL_CUSTOMER ) != 0 ) && ( tc_strcmp ( cRolName, TECHNICAL_CUSTOMER ) != 0 ) ) 			
						  {
							  	DNVGL_TRACE_CALL( iStatus = get_all_participants( tChildProject, allChildProjPctInfos ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

							  	std::vector<DNVGL_ProjectRevisionParticipant_t>::iterator itrChild = allChildProjPctInfos.begin();
								logical lSamePartcpnt = false;
								
							while( itrChild != allChildProjPctInfos.end() )
							{
								std::string CpctType = itrChild->participantType;
								char * cpChildPartcpnt = new char[CpctType.size() + 1];
								std::copy(CpctType.begin(), CpctType.end(), cpChildPartcpnt);
								cpChildPartcpnt[CpctType.size()] = '\0'; // terminating 0

							//check for Main & child project participant Type
							   if( ( tc_strcmp ( cpChildPartcpnt, cpMainPartcpnt ) == 0 ) )
							   {
								 tChildGroupMember = itrChild->groupMember;

								 if( ( tMainGroupMember != tChildGroupMember ) && ( tChildGroupMember != NULLTAG ) )
								 {
									int iOnepartcnt=0;
									while( cpOneParticipantType[iOnepartcnt] )
									{
										// check for participants with one group member
										if( ( tc_strcmp ( cpOneParticipantType [iOnepartcnt], cpChildPartcpnt ) == 0 ) )
										{
											tag_t tChildParticipantType = NULLTAG;
											tag_t*  tChildParticipantlist    = {NULLTAG} ; 
											int	  iChildParticipantCount   = 0;
											tag_t tParticipant = NULLTAG;
											DNVGL_TRACE_CALL( iStatus = EPM_get_participanttype(  cpChildPartcpnt, &tChildParticipantType ) );
											DNVGL_LOG_ERROR_AND_THROW_STATUS;

											DNVGL_TRACE_CALL ( iStatus = ITEM_rev_ask_participants( tChildProject, tChildParticipantType, &iChildParticipantCount, &tChildParticipantlist ) );
											DNVGL_LOG_ERROR_AND_THROW_STATUS;

											DNVGL_TRACE_CALL ( iStatus = ITEM_rev_remove_participant( tChildProject, tChildParticipantlist[0] ) );
											DNVGL_LOG_ERROR_AND_THROW_STATUS;

											DNVGL_TRACE_CALL( iStatus = EPM_create_participant( tMainGroupMember, tpartcipntTag, &tParticipant ) );
											DNVGL_LOG_ERROR_AND_THROW_STATUS;

										    DNVGL_TRACE_CALL( iStatus = ITEM_rev_add_participant( tChildProject, tParticipant ) );
											DNVGL_LOG_ERROR_AND_THROW_STATUS;
											lSamePartcpnt = true ;
													
											//Check if object is already locked	
											DNVGL_TRACE_CALL( iStatus = POM_modifiable( tChildProject, &lIslocked ) );
											DNVGL_LOG_ERROR_AND_THROW_STATUS;

											if (!lIslocked )
											{
											// Lock the  object
											 DNVGL_TRACE_CALL (  iStatus = AOM_refresh( tChildProject, 1 ) );
											 DNVGL_LOG_ERROR_AND_THROW_STATUS;
											}

											break;
										}
									  iOnepartcnt++;
									}
									if( lSamePartcpnt ){
										break;
									}
								}else if( tMainGroupMember == tChildGroupMember )
								{
									lSamePartcpnt = true ;
									break;
								}
								}
							  	delete[] cpChildPartcpnt;
								itrChild++;
							  }
								if(!lSamePartcpnt ){
								tag_t tParticipant = NULLTAG;
								DNVGL_TRACE_CALL( iStatus = EPM_create_participant( tMainGroupMember, tpartcipntTag, &tParticipant ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								DNVGL_TRACE_CALL( iStatus = ITEM_rev_add_participant( tChildProject, tParticipant ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;
								}
						 }
						  //  free the string after finished using it
						  delete[] cpMainPartcpnt;
						  itrMain++;
					  }
					}
					break;
				  }
				default: // for everything else, lets take display value
			
				    break;
				}//end of switch 
		 } //end of for


		// Save the  object
		DNVGL_TRACE_CALL( iStatus = AOM_save( tChildProject ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Unlock the object
		DNVGL_TRACE_CALL ( iStatus = AOM_refresh(tChildProject,0 ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	}
	catch(...)
	{

	}
    AM__set_application_bypass( false );
    POM_AM__set_application_bypass( false );	

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

