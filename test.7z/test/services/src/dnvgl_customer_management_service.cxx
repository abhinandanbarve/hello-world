/**
* \file dnvgl_customer_management_service.cxx
* \ingroup libAP4_dnvgl_services
* \verbatim
\par Description:

\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 03-Aug-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_customer_management_service.h"

int dnvgl_service_operation_find_mdm_customers( const std::map< std::string, std::string >& input,  std::vector< std::map<std::string,std::string> >& output )
{
	int iStatus	= ITK_ok;
	
	DNVGL_TRACE_ENTER();
	try
	{

	}
	catch(...)
	{

	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}
