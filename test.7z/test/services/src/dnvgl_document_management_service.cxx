/**
* \file dnvgl_customer_management_service.cxx
* \ingroup libAP4_dnvgl_services
* \verbatim
\par Description: Implementation code for DocumentManagement SOA service operations.

\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah 
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 22-Sep-2016   Sanjay Sah   	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_document_management_service.h"

int dnvgl_service_operation_createDoc( DocCreateInputVS_t docCreateInputsVS, tag_t * tDocumentRev, tag_t * tDataSet )
{
	int iStatus	= ITK_ok;

	tag_t* tpSecondaryObjects = NULL;
	tag_t* tpProjDocSecObjects = NULL;

	tag_t newDocumentItem = NULLTAG;
	tag_t newDocumentRevision = NULLTAG;
	tag_t newDataset = NULLTAG;
	tag_t tFolder = NULLTAG;

	DNVGL_TRACE_ENTER();
	try
	{
		// first lets check if the mapping preference and dataset present in database
        DNVGL_TRACE_CALL( iStatus = dnvgl_ensure_eform_preference( docCreateInputsVS ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tProjectRev = NULLTAG;
		DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( docCreateInputsVS.puidProjectRev.c_str(), &tProjectRev ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<tag_t> projFolders;
		DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type(tProjectRev, AP4_PROJECT_STRUCTURE_RELATION, docCreateInputsVS.folderType, projFolders) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// lets find out if folder exist or not
		bool bfolderFound = false;

		// lets loop thru folders to find if the input folder is
		for( std::vector<tag_t>::iterator itr = projFolders.begin(); itr != projFolders.end(); itr++)
		{
			char* cpFolderName = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *itr, OBJECT_NAME, &cpFolderName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tc_strcmp( cpFolderName, docCreateInputsVS.folderName.c_str() ) == 0 )
			{
				bfolderFound = true;
				tFolder = *itr;
				DNVGL_MEM_FREE(cpFolderName);
				break;
			}

			DNVGL_MEM_FREE(cpFolderName);
		}

		// ensuring we have the document name
		iStatus = dnvgl_ensure_document_name(docCreateInputsVS, tProjectRev);

		// check for different possibilities
		if(bfolderFound == false) // the folder itslef does not exist, create everything
		{
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_project_folder(docCreateInputsVS, tFolder) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_project_document(docCreateInputsVS, newDocumentItem, newDocumentRevision));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation(tFolder, newDocumentItem, AP4_DOCUMENT_RELATION));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation(tProjectRev, tFolder, AP4_PROJECT_STRUCTURE_RELATION));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_call_eform_service( docCreateInputsVS, newDocumentRevision, newDataset ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else if(bfolderFound && docCreateInputsVS.createIfExists ) // if folder found and create if exist
		{
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_project_document(docCreateInputsVS, newDocumentItem, newDocumentRevision));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation(tFolder, newDocumentItem, AP4_DOCUMENT_RELATION));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_call_eform_service( docCreateInputsVS, newDocumentRevision, newDataset ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

		}
		else if(bfolderFound && !docCreateInputsVS.createIfExists ) // if folder found and we dont want to create doc if it alreaday exist
		{
			DNVGL_TRACE_CALL( iStatus = dnvgl_find_or_create_document_revision(docCreateInputsVS, tFolder, newDocumentItem, newDocumentRevision, newDataset) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		// finally, lets set ouput tags
		*tDocumentRev = newDocumentRevision;
		*tDataSet = newDataset;
	}
	catch(...)
	{

	}

	DNVGL_MEM_FREE( tpSecondaryObjects );
	DNVGL_MEM_FREE( tpProjDocSecObjects );

	DNVGL_TRACE_LEAVE();
	return iStatus;
}


int dnvgl_ensure_eform_preference(DocCreateInputVS_t& docCreateInputsVS)
{
	int iStatus	= ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		if(docCreateInputsVS.documentType.compare( "AP4_CTRDocument" ) != 0 && docCreateInputsVS.documentType.compare( "AP4_ContDocument" ) != 0 ) // exclude type
		{
			tag_t tDocType = NULLTAG;
			const char* templateType = docCreateInputsVS.eFormTemplateCategory.c_str();
			const char* versionType = docCreateInputsVS.version.c_str();
			std::string cpEformID;
			std::string cpEformDocType; 
			std::string cpDatasetType; 
			tag_t tDatasetTag;

			DNVGL_TRACE_CALL( iStatus = dnvgl_get_eform_dataset_info( (char*)templateType, (char*)versionType, cpEformID, cpEformDocType, cpDatasetType, &tDatasetTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch(...)
	{
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}



int dnvgl_ensure_document_name(DocCreateInputVS_t& docCreateInputsVS, tag_t& tProjectRev)
{
	int iStatus	= ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		if(docCreateInputsVS.documentName.empty() )
		{
			tag_t tDocType = NULLTAG;
			const char* docType = docCreateInputsVS.documentType.c_str();

			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( docType, docType, &tDocType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char* displayName = NULL;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_display_name(tDocType, &displayName) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// get the project name
			char* projName = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tProjectRev, OBJECT_NAME, &projName) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// generate name
			docCreateInputsVS.documentName.assign(displayName);
			docCreateInputsVS.documentName.append(" for ");
			docCreateInputsVS.documentName.append(projName);

			DNVGL_MEM_FREE(projName);
			DNVGL_MEM_FREE(displayName);
		}
	}
	catch(...)
	{
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}


int dnvgl_create_project_document(DocCreateInputVS_t& docCreateInputsVS, tag_t& newDocItem, tag_t& newDocRevision )
{
	int iStatus = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tDocTypeTag = NULL;
		const char* docType = docCreateInputsVS.documentType.c_str();

		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( docType, docType, &tDocTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tDocTypeInputTag = NULL;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tDocTypeTag, &tDocTypeInputTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		const char* docName = docCreateInputsVS.documentName.c_str();
		std::string sDocName = "";
		if(docCreateInputsVS.documentType.compare(AP4_DELIVERABLE) == 0)
		{
			int iCount = 0;
			tag_t* tLov = NULLTAG; 
			DNVGL_TRACE_CALL( iStatus = LOV_find( "AP4_SurveyorChecklistEForm_LOV",&iCount, &tLov ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			char** cpLovValues = NULL;
			char** cpDispValues = NULL;
			int iValues = 0;
			LOV_usage_t 	usage ;
			DNVGL_TRACE_CALL( iStatus = LOV_ask_values_display_string(tLov[0], &usage, &iValues, &cpDispValues, &cpLovValues ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			char* cpLovName = NULL;
			DNVGL_TRACE_CALL( iStatus = LOV_ask_name2( tLov[0], &cpLovName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			for (int i = 0; i < iValues; i++)
			{
				if( tc_strcmp( cpLovValues[i], docCreateInputsVS.version.c_str() ) == 0 )
				{
					sDocName.append(cpDispValues[i]);
					sDocName.append(" template");
					break;
				}
			}
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tDocTypeInputTag, OBJECT_NAME, sDocName.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;			
		}
		else
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tDocTypeInputTag, OBJECT_NAME, docName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		// skipping for 
		if( (docCreateInputsVS.documentType.compare("AP4_CTRDocument") != 0)
			&& (docCreateInputsVS.documentType.compare("AP4_ContDocument") != 0 ))
		{
			const char* eFormCategory = docCreateInputsVS.eFormTemplateCategory.c_str();
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tDocTypeInputTag, AP4_TEMPLATETYPE, docCreateInputsVS.eFormTemplateCategory.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tDocTypeInputTag, AP4_VERSION, docCreateInputsVS.version.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( tDocTypeInputTag, &newDocItem ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// skipping for 
		if( (docCreateInputsVS.documentType.compare("AP4_CTRDocument") != 0)
			&& (docCreateInputsVS.documentType.compare("AP4_ContDocument") != 0 ))
		{
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( newDocItem, AP4_SERVICETYPE, docCreateInputsVS.service.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_save_with_extensions( newDocItem ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev	(newDocItem, &newDocRevision));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_create_project_folder(DocCreateInputVS_t& docCreateInputsVS, tag_t& folderTag )
{
	int iStatus = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tFolderTypeTag = NULL;
		const char* folderType = docCreateInputsVS.folderType.c_str();
		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( folderType, folderType, &tFolderTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tFolderInputTypeTag = NULL;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tFolderTypeTag, &tFolderInputTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		const char* folderName = docCreateInputsVS.folderName.c_str();
		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tFolderInputTypeTag, OBJECT_NAME, folderName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( tFolderInputTypeTag, &folderTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save_with_extensions( folderTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


int dnvgl_find_or_create_document_revision(DocCreateInputVS_t& docCreateInputsVS, tag_t& tFolder, tag_t& newDocumentItem, tag_t& newDocumentRevision, tag_t& newDataset)
{
	int iStatus	= ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t* tpProjDocSecObjects = NULL;
		std::vector<tag_t> projDocuments;
		DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type(tFolder, AP4_DOCUMENT_RELATION, docCreateInputsVS.documentType, projDocuments) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		if(projDocuments.size() > 0 && 
		     (docCreateInputsVS.documentType.compare( "AP4_CTRDocument" ) == 0 || docCreateInputsVS.documentType.compare( "AP4_ContDocument" ) == 0 ) ) // if we found CTR or Contract document
		{
			newDocumentItem = projDocuments[0];
		}
		else if(projDocuments.size() > 0)  // if we found document, lets find the doc with given eform template cat
		{
			// we now have to loop thru each document to find its eform_template type
			for( std::vector<tag_t>::iterator itr = projDocuments.begin(); itr != projDocuments.end(); itr++)
			{
				char* cpEformTemplateCat = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *itr, AP4_TEMPLATETYPE, &cpEformTemplateCat ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				char* cpVersionType = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *itr, AP4_VERSION , &cpVersionType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if(docCreateInputsVS.eFormTemplateCategory.compare(cpEformTemplateCat) == 0
					&& docCreateInputsVS.version.compare(cpVersionType) == 0)
				{
					newDocumentItem = *itr;
					DNVGL_MEM_FREE(cpEformTemplateCat);
					break;
				}

				DNVGL_MEM_FREE(cpEformTemplateCat);
			}
		}

		if(newDocumentItem == NULLTAG)  // if we dont find any document, lets create it
		{
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_project_document(docCreateInputsVS, newDocumentItem, newDocumentRevision));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation(tFolder, newDocumentItem, AP4_DOCUMENT_RELATION));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_call_eform_service(docCreateInputsVS, newDocumentRevision, newDataset ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else // lets check the dataset
		{
			DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev(newDocumentItem, &newDocumentRevision) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tTCAttachesRelation = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION, &tTCAttachesRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			int iCount = 0;
			DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( newDocumentRevision, tTCAttachesRelation, &iCount, &tpProjDocSecObjects ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( iCount == 0 )
			{
				DNVGL_TRACE_CALL( iStatus = dnvgl_call_eform_service( docCreateInputsVS, newDocumentRevision, newDataset ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				newDataset = tpProjDocSecObjects[0];
			}
			DNVGL_MEM_FREE( tpProjDocSecObjects );
		}
	}
	catch(...)
	{
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

int dnvgl_call_eform_service(DocCreateInputVS_t& docCreateInputsVS, tag_t& newDocumentRevision, tag_t& newDataset)
{
	int iStatus = ITK_ok;

	// this function will check if thegiven document revision is applicable for eform or not.
	std::set<std::string> excludeDocTypeForEform;
	excludeDocTypeForEform.insert("AP4_CTRDocument");
	excludeDocTypeForEform.insert("AP4_ContDocument");

	bool isEformApplicable = true;
	for( std::set<std::string>::iterator itr = excludeDocTypeForEform.begin(); itr != excludeDocTypeForEform.end(); itr++)
	{
		if(docCreateInputsVS.documentType.compare( *itr ) == 0 )
		{
			isEformApplicable = false;
			break;
		}
	}

	if(isEformApplicable)
	{
		iStatus = dnvgl_eform_service( newDocumentRevision, &newDataset );
	}

	return iStatus;
}

// Raju end

/**
* \file dnvgl_document_management_service.cxx
* \ingroup libAP4_dnvgl_services
* \verbatim
\par Description:
This function will query all tasks under schedule summary task and retuns leaf tasks .
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* Mar 2017   Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_service_operation_get_project_schedule_tasks(tag_t tSchedule, std::vector<tag_t> *schTasks) 
{
	int iStatus	= ITK_ok;

	char* object_type= NULL;

	const char*     enq_id = "dnvgl-get-all-schTasks" ;
	const char * attrName[] = {"puid"};
	int rows = 0;
	int cols = 0;
	void*** queryResult = NULL;
	tag_t *objs = NULL;
	DNVGL_TRACE_ENTER();
	try
	{
		/* Start POM enquery */

		// Unique identification for query
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create( enq_id ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		/* Set distinct to allow or restrict duplicate query result */
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_distinct( enq_id , TRUE ) ); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Select attributes (select puid from "ScheduleTask")
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs(enq_id, "ScheduleTask",1, attrName));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//where schedule_tag = tSchedule
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_tag_value (enq_id, "valueId1", 1, &tSchedule, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr(enq_id, "ExprId1", "ScheduleTask", "schedule_tag", POM_enquiry_equal, "valueId1"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;    

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr(enq_id, "ExprId1"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Execute the query
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute(enq_id, &rows, &cols, &queryResult));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_distinct(enq_id, false));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Extract the query result and store it in tag array 
		if(rows > 0)
		{

			objs = (tag_t *)MEM_alloc( (tag_t) ( rows) *sizeof(tag_t));

			for(int iCnt=0;iCnt<rows;iCnt++)
			{
				//Adding query result and convert puid to tag
				objs[iCnt]		= *( tag_t* )( queryResult[iCnt][0] );

				char * taskType = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(objs[iCnt], "fnd0TaskTypeString", &taskType));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if(strcmp(taskType,"T") == 0)
				{
					schTasks->push_back(objs[iCnt]);
				}					
			}

		}

		//Delete query
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete(enq_id));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete(enq_id));
	}
	DNVGL_MEM_FREE(objs);
	DNVGL_MEM_FREE(queryResult);
	DNVGL_TRACE_LEAVE();
	return iStatus;

}
/**
* \file dnvgl_document_management_service.cxx
* \par  Description :
<description of function>.
This function is used to get the FMS ticket of the download zip containing the documents related to the business objects which have been passed in the input.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]	uids			vector list of the UIDs of the BO
* \param[out]   fmsTicket		string FMS ticket
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_service_operation_downloadFiles( const std::vector<std::string> &vUids, std::string &sFMSTicket, std::string &sZipFileName ) 
{
	int   iStatus	                  = ITK_ok;
	tag_t tInputType                  = NULLTAG ;
	char* cpTransientVolume           = NULL ;
	char* cpTransientVolumeFileTicket = NULL;
	logical isFolder                  = false ;
	logical isBaseFolderCreated		  = false;
	logical lExists					  = false;
	std::string sZipFilePath          = "";
	std::string sPath                 = "";
	std::string sParentFL             = "";
	std::string sFileName             = "";
	DNVGL_TRACE_ENTER();
	try
	{		
		if( !vUids.empty() )
		{
			if( vUids.size() > 1 )
			{
				tag_t tFirst ;

				DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( vUids.front().c_str(), &tFirst ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus =  dnvgl_create_folder( tFirst, true, sParentFL, isFolder ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;			

				sZipFilePath.append(sParentFL);
				sPath.append(sParentFL);
				std::string sNewPath = "";

				for( int i = 0; i < vUids.size(); i++ )
				{
					tag_t tObj = NULLTAG;
					DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( vUids[i].c_str(), &tObj ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					DNVGL_TRACE_CALL( iStatus = dnvgl_check_if_files_exist( tObj, lExists ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( lExists )
					{
						sNewPath.assign(sPath);
						DNVGL_TRACE_CALL( iStatus = dnvgl_get_document( vUids[i], sNewPath ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}				
			}
			else 
			{
				DNVGL_TRACE_CALL( iStatus = dnvgl_get_document( vUids[0], sPath ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				sZipFilePath.append( sPath );
			}

			DNVGL_TRACE_CALL( iStatus = IMF_get_transient_volume_root_dir( 4, &cpTransientVolume ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_create_zip( sZipFilePath, cpTransientVolume, sFileName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			sZipFileName.assign( sFileName );
			std::string sTransival = cpTransientVolume ;
			sTransival.append("\\");
			sTransival.append(sFileName);

			DNVGL_TRACE_CALL( iStatus = IMF_get_transient_file_read_ticket( SS_BINARY, 4, TRUE, sTransival.c_str(), &cpTransientVolumeFileTicket) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			sFMSTicket.assign( cpTransientVolumeFileTicket );

			if( !sZipFilePath.empty() )
			{
				isBaseFolderCreated = true;
			}
		}
	}
	catch(...)
	{
	}
	DNVGL_MEM_FREE( cpTransientVolume );
	DNVGL_MEM_FREE( cpTransientVolumeFileTicket );

	if( isBaseFolderCreated )
	{
		std::string strTempFolderDeleteCmd = "" ;
		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(sZipFilePath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );	

	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}

/**
* \file dnvgl_document_management_service.cxx
* \par  Description :
<description of function>.
This function checks for the selected object contains the document or not.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]	tInput			input object
* \param[out]   lExists			true if document exists
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_check_if_files_exist(tag_t tInput, logical &lExists)
{
	int iStatus=ITK_ok;
	int    iCount = 0;		
	tag_t tFolderType   = NULLTAG ;
	tag_t tInputType    = NULLTAG ;
	logical isFolder  = false ;
	tag_t *tpSecObjs = NULLTAG;
	DNVGL_TRACE_ENTER();
	try
	{

		DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tInput, &tInputType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_PROJECT_FOLDER, AP4_PROJECT_FOLDER, &tFolderType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tInputType, tFolderType, &isFolder ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		//Check for the selection is folder or not If it is folder then check for documents with various relations 
		tag_t tRelType = NULLTAG; 
		if( isFolder )
		{
			char* cpRelationName = NULL;
			std::vector <std::string> vRelationNames;
			vRelationNames.push_back(AP4_FOLDER_DOCUMENT_RELATION);
			vRelationNames.push_back(AP4_DOCUMENT_RELATION);
			vRelationNames.push_back(AP4_SUCTEMPLATERELATION);
			vRelationNames.push_back(AP4_SURVEYOR_CHEKLST_RELATION);
			vRelationNames.push_back(AP4_PROJECT_STRUCTURE_RELATION);

			for (int index = 0; index < vRelationNames.size(); index++)
			{
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( vRelationNames[index].c_str() , &tRelType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus =  GRM_list_secondary_objects_only( tInput, tRelType, &iCount, &tpSecObjs ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( iCount > 0 )
				{
					break;
				}
			}
		}
		else
		{	
			//If tthe selection is of document type then check for Dataset attached by TC_Atttaches relation.
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION , &tRelType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;		

			DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tInput, tRelType, &iCount, &tpSecObjs ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		if( iCount > 0 )
		{
			lExists = true ;
		}
	}
	catch(...)
	{
	}
	DNVGL_MEM_FREE( tpSecObjs );

	DNVGL_TRACE_LEAVE();
	return iStatus;
}
/**
* \file dnvgl_document_management_service.cxx
* \par  Description :
<description of function>.
This function will download the dataset attached to document into system Temp directory . 
\verbatim
*   <description of function>.
\endverbatim     
* \param[in]		sUid		uid of the selected object
* \param[in/out]    sPath		path of the document (for the first time it is empty)
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_get_document( const std::string & sUid, std::string& sPath )
{
	int iStatus = ITK_ok;
	logical isFolder = false ;
	logical isMultiple = false ;
	logical isFilePresent = false ;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tInput ;
		DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( sUid.c_str(), &tInput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = dnvgl_create_folder( tInput, isMultiple, sPath, isFolder ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( isFolder )
		{
			DNVGL_TRACE_CALL( iStatus = dnvgl_download_from_folder( tInput, sPath ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;				
		}
		else 
		{
			DNVGL_TRACE_CALL( iStatus = dnvgl_download_from_document( tInput, sPath ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch(...)
	{
	}
	DNVGL_TRACE_LEAVE();
	return iStatus;

}
/**
* \file dnvgl_document_management_service.cxx
* \par  Description :
<description of function>.
This function will create a zip file of all documents from temp directory to Transient directroy. 
\verbatim
*   <description of function>.
\endverbatim     
* \param[in]		sPath					path of the temp directory
* \param[in]		cpTransVolumePath		path of the transient directory
* \param[out]       sFileName				filename of the created zip
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_create_zip( std::string &sPath, char *cpTransVolumePath, std::string &sFileName )
{
	int iStatus = ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		std::size_t found = sPath.find_last_of("/\\");
		std::string sZipFile = sPath.substr(found+1);	

		sFileName.append( sZipFile );
		sFileName.append( ".zip" );		
		const char* cpTcRootEnvVar;
		cpTcRootEnvVar = getenv( TC_ROOT_ENV_VAR );  
		std::string strBinPath = cpTcRootEnvVar;
		strBinPath.append("\\bin\\7za a");

		std::string sSystemCommand = "" ;
		sSystemCommand.append( strBinPath );
		sSystemCommand.append( " " );
		sSystemCommand.append(cpTransVolumePath);
		sSystemCommand.append("\\");
		sSystemCommand.append(sZipFile);
		sSystemCommand.append(".zip");
		sSystemCommand.append(" ");
		sSystemCommand.append(sPath);
		DNVGL_TRACE_CALL( iStatus = std::system( sSystemCommand.c_str() ) );  // System call to create the zip file in Transient volume
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{
	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}
/**
* \file dnvgl_document_management_service.cxx
* \par  Description :
<description of function>.
This function will create a system Folder inside zip file. 
\verbatim
*   <description of function>.
\endverbatim     
* \param[in]		tInput			Object type
* \param[in]		lIsMultiple		true if selection is multiple
* \param[in/out]	sPath			path of created folder
* \param[out]       lIsFolder		true if input object type is Folder
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_create_folder( tag_t &tInput, logical lIsMultiple, std::string &sPath, logical &lIsFolder )
{
	int iStatus			= ITK_ok;
	char *cpFolderName  = NULL;
	char *cpProjectName = NULL;
	char *cpTimeStamp   = NULL;
	tag_t tFolderType   = NULLTAG ;
	tag_t tInputType    = NULLTAG ;
	logical lFolderType = false ;
	logical lDocument   = false ;
	bool bMultipleDoc  = false;
	std::string strTempFolderPath = "";
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tInput, &tInputType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_PROJECT_FOLDER, AP4_PROJECT_FOLDER, &tFolderType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tInputType, tFolderType, &lIsFolder ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tParentProject = NULLTAG;
		tag_t tFolder = NULLTAG ;

		if( lIsFolder )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tInput, OBJECT_NAME , &cpFolderName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tInput, AP4_PROJECT_BACKPOINTER, &tParentProject ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tParentProject, OBJECT_NAME, &cpProjectName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			//Document revision is selected
			if( sPath.empty() )
			{
				if( !lIsMultiple )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tInput, AP4_PROJECT_FOLDER_PROP, &tFolder));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( tFolder != NULLTAG )
					{
						DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tFolder, OBJECT_NAME ,&cpFolderName ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tInput, AP4_PROJECT_NAME, &cpProjectName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				bMultipleDoc = true;
			}
		}
		if( !bMultipleDoc )
		{
			if( sPath.empty() )
			{
				char * cpTempPath = std::getenv( TEMP_ENV_VAR );
				strTempFolderPath = cpTempPath ;
			}
			else
			{
				strTempFolderPath.assign( sPath );
			}
			strTempFolderPath.append("\\");

			DNVGL_TRACE_CALL( iStatus = DNVGL_current_get_time_stamp( DATE_FORMAT_STR_FOOTER, &cpTimeStamp ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;					

			strTempFolderPath.append( cpTimeStamp );
			strTempFolderPath.append( "_" );

			std::string sProjectName = "";
			sProjectName.assign( cpProjectName );
			std::replace( sProjectName.begin(), sProjectName.end(), ' ', '_'); 

			strTempFolderPath.append( sProjectName );

			if( !lIsMultiple && cpFolderName != NULL && cpFolderName[0] != '\0') 
			{				
				std::string sFolderName = cpFolderName;				
				std::replace( sFolderName.begin(), sFolderName.end(), ' ', '_');

				strTempFolderPath.append( "_" );
				strTempFolderPath.append( sFolderName );
			}

			DNVGL_TRACE_CALL( iStatus = _mkdir( strTempFolderPath.c_str() ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			sPath = strTempFolderPath;
		}
	}
	catch(...)
	{
	}
	DNVGL_MEM_FREE( cpFolderName );
	DNVGL_MEM_FREE( cpProjectName );
	DNVGL_MEM_FREE( cpTimeStamp );

	DNVGL_TRACE_LEAVE();
	return iStatus;

}
/**
* \file dnvgl_document_management_service.cxx
* \par  Description :
<description of function>.
This function will download the document from folder. 
\verbatim
*   <description of function>.
\endverbatim     
* \param[in]		tInput			Folder tag
*  \param[in/out]	sPath			path of created folder
* 
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_download_from_folder( tag_t &tFolder, std::string &sPath )
{
	int iStatus=ITK_ok;
	int    iDocCount	= NULL;
	int    iObjectCount = NULL;
	int    iFLDocCount	= NULL;
	tag_t  tDocRelation = NULLTAG;
	tag_t  tStructRel	= NULLTAG; 
	tag_t  tFolderDocRel= NULLTAG;
	tag_t* tpDocs		= NULLTAG;
	tag_t* tpRelatedTags= NULLTAG;
	logical isFolder    = false;
	logical isMultiple  = false;

	DNVGL_TRACE_ENTER();
	try
	{
		char* cpRelationName = NULL;
		std::vector <std::string> vRelationNames;
		vRelationNames.push_back(AP4_FOLDER_DOCUMENT_RELATION);
		vRelationNames.push_back(AP4_DOCUMENT_RELATION);
		vRelationNames.push_back(AP4_SUCTEMPLATERELATION);
		vRelationNames.push_back(AP4_SURVEYOR_CHEKLST_RELATION);

		for (int index = 0; index < vRelationNames.size(); index++)
		{
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( vRelationNames[index].c_str() , &tDocRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus =  GRM_list_secondary_objects_only( tFolder, tDocRelation, &iDocCount, &tpDocs ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for( int i=0; i< iDocCount; i++ )
			{
				tag_t tDocRev = NULLTAG ;
				DNVGL_TRACE_CALL( 	iStatus =  ITEM_ask_latest_rev(	tpDocs[i], &tDocRev ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = dnvgl_download_from_document( tDocRev, sPath ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}		
		}

		//Get all the sub folders, if any.
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_STRUCTURE_RELATION , &tStructRel ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus =  GRM_list_secondary_objects_only( tFolder, tStructRel, &iObjectCount, &tpRelatedTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i< iObjectCount; i++)
		{
			std::string sFLPath = sPath;
			tag_t tFolder = tpRelatedTags[i];
			logical lExists = false;

			DNVGL_TRACE_CALL( iStatus = dnvgl_check_if_files_exist( tFolder, lExists ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( lExists )
			{
				DNVGL_TRACE_CALL( iStatus = dnvgl_create_folder( tFolder, isMultiple, sFLPath, isFolder ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = dnvgl_download_from_folder( tFolder, sFLPath ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;	
			}
		}
	}
	catch(...)
	{
	}
	DNVGL_MEM_FREE( tpDocs );
	DNVGL_MEM_FREE( tpRelatedTags );
	DNVGL_TRACE_LEAVE();
	return iStatus;
}
/**
* \file dnvgl_document_management_service.cxx
* \par  Description :
<description of function>.
This function will download the document from Document revision. 
\verbatim
*   <description of function>.
\endverbatim     
* \param[in]		tInput			Document revisiontag
*  \param[in/out]	sPath			path of created folder
* 
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_download_from_document( tag_t &tDocumentRev, std::string &sPath )
{
	int  iStatus		 = ITK_ok;
	int  iDatasetCount	 = NULL;
	char* cpTcFileName	 = NULL;
	char* reference_name = NULL ;
	tag_t referenced_object	= NULLTAG ;
	tag_t *tpDatasets		= NULLTAG;
	AE_reference_type_t reference_type ;

	DNVGL_TRACE_ENTER();
	try
	{
		char * cpDocItemId = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tDocumentRev, ITEM_ID, &cpDocItemId ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tRelType = NULLTAG; 
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_attaches_rtype , &tRelType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus =  GRM_list_secondary_objects_only( tDocumentRev, tRelType, &iDatasetCount, &tpDatasets ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i < iDatasetCount; i++ )
		{
			tag_t tDataset = tpDatasets[i];
			
			DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 (  tDataset, 0 , &reference_name , &reference_type , &referenced_object  ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			std::string strNewPath = "" ;
			strNewPath.assign(sPath);
			strNewPath.append("\\");			
			if( referenced_object != NULLTAG )
			{
				char * cpFileName = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( referenced_object, ORIGINAL_FILE_NAME, &cpFileName ));//FILE_NAME
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				strNewPath.append(cpDocItemId);
				strNewPath.append("_");
				strNewPath.append(cpFileName);

				DNVGL_TRACE_CALL( iStatus = AE_export_named_ref ( tDataset, reference_name, strNewPath.c_str() ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch(...)
	{
	}
	DNVGL_MEM_FREE( reference_name );
	DNVGL_MEM_FREE( tpDatasets );
	DNVGL_MEM_FREE( cpTcFileName );
	DNVGL_TRACE_LEAVE();
	return iStatus;
}

int dnvgl_service_operation_generateEFormDocument( GeneEFormInputVS inputStruct, tag_t * tDocumentRev, tag_t * tDataSet )
{
	int iStatus	= ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		DocCreateInputVS_t tempInput;
		tempInput.documentName = inputStruct.eformCreateIn.docName;
		tempInput.documentType = inputStruct.eformCreateIn.boType;
		tempInput.eFormTemplateCategory = inputStruct.eformCreateIn.templateType;
		tempInput.version = inputStruct.eformCreateIn.versionType;
		tempInput.service = inputStruct.eformCreateIn.service;
		tempInput.createIfExists = true;

		DNVGL_TRACE_CALL( iStatus = dnvgl_ensure_eform_preference( tempInput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t newDocumentItem = NULLTAG;
		tag_t newDocumentRevision = NULLTAG;
		tag_t newDataset = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = dnvgl_create_project_document(tempInput, newDocumentItem, newDocumentRevision) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = dnvgl_create_relation( inputStruct.targetObject, newDocumentItem, inputStruct.target2DocumentRelName.c_str() ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = dnvgl_call_eform_service( tempInput, newDocumentRevision, newDataset ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		*tDocumentRev = newDocumentRevision;
		*tDataSet = newDataset;
	}
	catch(...)
	{
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}
