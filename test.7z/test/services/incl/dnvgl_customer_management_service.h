/**
* \file dnvgl_customer_management_service.h
* \ingroup libAP4_dnvgl_services
* \verbatim
  \par Description:
    Header file for CustomerManagement SOA service operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 03-August-2016  Vinay Kudari      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_CUSTOMER_MANAGEMENT_SERVICE_H
# define DNVGL_CUSTOMER_MANAGEMENT_SERVICE_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"

#include "dnvgl_mdm_services.h"

#ifdef __cplusplus
extern "C" {
#endif

	DNVGLCOMEXP int dnvgl_service_operation_find_mdm_customers(const std::map<std::string,std::string>& input, std::vector< std::map<std::string,std::string> >& output );

#ifdef __cplusplus
}
#endif


#endif //DNVGL_CUSTOMER_MANAGEMENT_SERVICE_H