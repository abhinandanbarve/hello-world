/**
* \file dnvgl_document_management_service.h
* \ingroup libAP4_dnvgl_services
* \verbatim
  \par Description:
    Header file for DocumentManagement SOA service operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 24-May-2017  Gouthami M          Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_PROJECT_MANAGEMENT_SERVICE_H
# define DNVGL_PROJECT_MANAGEMENT_SERVICE_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_utils.h"
#include <set>

#define DNVGL_IS_STRING_EMPTY(STRING) ((STRING == NULL) || (tc_strlen(STRING) <= 0))
#ifdef __cplusplus
extern "C" {
#endif
	struct  CopyProjectInputVS
	{
		/* 
		*	PUID of MainProject 
		*/
		std::string mainProjectUID;

		/* 
		*	PUID of ChildProject  
		*/
		std::string childProjectUID;
		
		/*
		*	 vector of properties
		*/
		std:: vector <std::string> properties;
	};
	typedef struct CopyProjectInputVS CopyProjectInputVS_t;
	
	DNVGLCOMEXP int dnvgl_service_operation_copy_from_main_project( CopyProjectInputVS copyProjectInputVS );

#ifdef __cplusplus
}
#endif


#endif //DNVGL_PROJECT_MANAGEMENT_SERVICE_H