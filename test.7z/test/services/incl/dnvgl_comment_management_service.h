/**
* \file dnvgl_document_management_service.h
* \ingroup libAP4_dnvgl_services
* \verbatim
\par Description:
Header file for CommentManagement SOA service operations.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 07-Oct-2016  Sanjay Sah          Initial Creation
* 13-Apr-2017  Prasmit Pansare     Added activityUidVS parameter to struct CommentInputVS
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_COMMENT_MANAGEMENT_SERVICE_H
# define DNVGL_COMMENT_MANAGEMENT_SERVICE_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_utils.h"
#include "dnvgl_pom_enquiry_utils.h"

#ifdef __cplusplus
extern "C" {
#endif

	struct  CommentInputVS
	{
		/**
		* puid of target object i.e. AP4_TechDocRevision or AP4_CommentChain
		*/
		std::string primaryTargetVS;

		/**
		* Type of comment chain
		*/
		std::string chainTypeVS;

		/**
		* Decide internal or external comment. True means internal and False means external.
		*/
		bool internalRemarkVS;

		/**
		* Title of page
		*/
		std::string titleVS;

		/**
		* input as commentary page section
		*/
		std::string sectionVS;

		/**
		* Commentary  page number
		*/
		std::string pageVS;

		/**
		* Action Responsible
		*/
		std::string actionResponsibleVS;

		/**
		* external or internal comment type
		*/
		std::string commentTypeVS;

		/**
		* Set visibility and uses to customer based on lov values. (LOV values : Draft, Open,
		* Closed, NA) based on whether it is ActionRequired or ImportantNote
		*/
		std::string statusVS;

		/**
		* Rich text value
		*/
		std::string richTextVS;

		/**
		* puid of group member
		*/
		std::string disciplineVS;

		/**
		* Verification remark by the internal verifier.
		*/
		std::string verificationRemarkVS;

		/**
		* Boolean to hold whether the comment is approved or rejected.
		*/
		bool isApprovedVS;

		/**
		* Activity UID.
		*/
		std::string activityUidVS;
	};	

	struct CommentChain
	{
		std:: vector <tag_t> comments;
	};

	DNVGLCOMEXP int dnvgl_service_operation_create_comment( CommentInputVS input, tag_t * tComment );

	DNVGLCOMEXP int dnvgl_service_operation_update_comment( CommentInputVS input, tag_t *tComment );

	DNVGLCOMEXP int dnvgl_service_operation_delete_comment( std::string sPuidCommentChain );

	DNVGLCOMEXP int dnvgl_service_operation_verify_comment( CommentInputVS input, tag_t * tComment );

	DNVGLCOMEXP int dnvgl_service_operation_verify_all_comments( std::string sPuidTechDocRev );

	DNVGLCOMEXP int dnvgl_service_operation_submit_for_internal_verification( std::string targetObjPUID, std::map<std::string,std::string> );

	DNVGLCOMEXP int dnvgl_service_operation_submit_for_quick_publish( std::vector< std::string > puidChainObjects, std::map<std::string,std::string> internalVerifiers );
	

	//Function under the create comment SOA
	int dnvgl_create_comment( CommentInputVS &input, tag_t* tComment );

	int dnvgl_create_comment_chain( CommentInputVS &input, tag_t* tCommentChain );

	int dnvgl_add_comment_to_comment_chain( tag_t tComment, tag_t tCommentChain );

	int dnvgl_relate_comment_chain_to_document( tag_t tDocRev, tag_t tCommentChain );

	int dnvgl_verify_comment(tag_t *tpCommentChain, tag_t *tpComment , char* cpRoleName, const char* cpChainType, const char* cpVerificationRemark, bool bApproved );

#ifdef __cplusplus
}
#endif


#endif //DNVGL_COMMENT_MANAGEMENT_SERVICE_H