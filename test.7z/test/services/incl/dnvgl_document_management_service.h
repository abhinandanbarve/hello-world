/**
* \file dnvgl_document_management_service.h
* \ingroup libAP4_dnvgl_services
* \verbatim
  \par Description:
    Header file for DocumentManagement SOA service operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 22-Sep-2016  Sanjay Sah          Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_DOCUMENT_MANAGEMENT_SERVICE_H
# define DNVGL_DOCUMENT_MANAGEMENT_SERVICE_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_utils.h"
#include "dnvgl_eform_services.h"
#include <set>

#define DNVGL_IS_STRING_EMPTY(STRING) ((STRING == NULL) || (tc_strlen(STRING) <= 0))
#ifdef __cplusplus
extern "C" {
#endif
	struct  DocCreateInputVS
	{
		/* 
		*	PUID of project revision 
		*/
		std::string puidProjectRev;

		/* 
		*	Document type name 
		*/
		std::string documentType;
		
		/*
		*	Folder name
		*/
		std::string folderName;

		/*
		*	Folder type name
		*/
		std::string folderType;

		/*
		*	Name of the Document to be created
		*/
		std::string documentName;

		/*
		*	eForm template category to be used.
		*/
		std::string eFormTemplateCategory;

		/*
		*	Whether to create new document or to return exsiting one.
		*/
		bool createIfExists;

        /**
         * document service property
         */
        std::string service;
        /**
         * eform document version
         */
        std::string version;
	};
	typedef struct DocCreateInputVS DocCreateInputVS_t;

	struct  EFormDocCreateInputVS
    {
        /**
         * BO Type
         */
        std::string boType;
        /**
         * Document Name
         */
        std::string docName;
        /**
         * EForm template type
         */
        std::string templateType;
        /**
         * EForm version type
         */
        std::string versionType;
		/**
         * Service
         */
        std::string service;
        /**
         * Relation name by wichi dataset will be attached to document
         */
        std::string doc2DatasetRelName;
    };
	typedef struct EFormDocCreateInputVS EFormDocCreateInputVS_t;

    struct  GeneEFormInputVS
    {
        /**
         * Target object under which document will be attached.
         */
        tag_t targetObject;

        /**
         * Relation name by which document will be attaced under target object
         */
        std::string target2DocumentRelName;
        /**
         * eform doucment create input
         */
        EFormDocCreateInputVS_t eformCreateIn;
    };
	typedef struct GeneEFormInputVS GeneEFormInputVS_t;
	
	DNVGLCOMEXP int dnvgl_service_operation_createDoc( DocCreateInputVS docCreateInputsVS, tag_t * tDocumentRev, tag_t * tDataSet );
	DNVGLCOMEXP int dnvgl_service_operation_generateEFormDocument( GeneEFormInputVS inputStruct, tag_t * tDocumentRev, tag_t * tDataSet );
	DNVGLCOMEXP int dnvgl_service_operation_get_project_schedule_tasks(tag_t tSchedule, std::vector<tag_t> *schTasks);
	DNVGLCOMEXP int dnvgl_service_operation_downloadFiles(const std::vector<std::string> &uids,std::string &fmsTicket,std::string &sZipFileName); 
	
	// Raju : I am deliberately NOT declaring below helper function as "DNVGLCOMEXP". We should NOT export every function from dll.
	int dnvgl_ensure_eform_preference(DocCreateInputVS_t& docCreateInputsVS);
	int dnvgl_ensure_document_name(DocCreateInputVS_t& docCreateInputsVS, tag_t& tProjectRev);
	int dnvgl_create_project_document( DocCreateInputVS_t& docCreateInputsVS, tag_t& newDocItem, tag_t& newDocRevision );
	int dnvgl_create_project_folder( DocCreateInputVS_t& docCreateInputsVS, tag_t& folderTag );
	int dnvgl_find_or_create_document_revision(DocCreateInputVS_t& docCreateInputsVS, tag_t& tFolder, tag_t& newDocumentItem, tag_t& newDocumentRevision, tag_t& newDataset);
	int dnvgl_call_eform_service(DocCreateInputVS_t& docCreateInputsVS, tag_t& newDocumentRevision, tag_t&newDataset);

	//function related to downloadFiles SOA
	int dnvgl_create_zip( std::string &sPath, char *cpTransVolumePath, std::string& sFileName);
	int dnvgl_create_folder( tag_t &tInput, logical lIsMultiple, std::string &sPath, logical &lIsFolder );
	int dnvgl_download_from_folder( tag_t  &tFolder, std::string &sPath );
	int dnvgl_download_from_document( tag_t &tDocumentRev, std::string &sPath );
	int dnvgl_get_document( const std::string & sUid, std::string& sPath );
	int dnvgl_check_if_files_exist(tag_t tInput, logical &lExists);

#ifdef __cplusplus
}
#endif


#endif //DNVGL_DOCUMENT_MANAGEMENT_SERVICE_H