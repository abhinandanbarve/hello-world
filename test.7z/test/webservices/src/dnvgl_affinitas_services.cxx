/**
* \file dnvgl_mdm_services.cxx
* \ingroup libAP4_dnvgl_webservices
* \verbatim
\par Description:

\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 03-Aug-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_affinitas_services.h"
#include <amstream.h>

using namespace std;

int dnvgl_create_or_update_opportunity( tag_t* tOpportunity )
{
	int	iStatus	= ITK_ok;
	DNVGL_TRACE_ENTER();

	try
	{
		// get header and endpoint value from preference
		char* pcHeader = NULL;
		char* pcEndpoint = NULL;
		DNVGL_ITK_CALL ( PREF_ask_char_value ( "AFFINITAS_OpportunityUpsert_Service.HEADER" , 0 , &pcHeader ) ) ;
		DNVGL_ITK_CALL ( PREF_ask_char_value ( "AFFINITAS_OpportunityUpsert_Service.ENDPOINT" , 0 , &pcEndpoint ) ) ;

		//if lenth is 0, set to NULL
		if(pcHeader != NULL)
		{
			pcHeader = tc_strlen(pcHeader) == 0 ? NULL : pcHeader;
		}
		if(pcEndpoint != NULL)
		{
			pcEndpoint = tc_strlen(pcEndpoint) == 0 ? NULL : pcEndpoint;
		}


		struct soap *soap = soap_new();

		_ns10__ArrayOfOpportunityUpsertOpportunity_opportunity opportunity = _ns10__ArrayOfOpportunityUpsertOpportunity_opportunity();

		DNVGL_TRACE_CALL( iStatus = dnvgl_get_opportunity_attributes( tOpportunity, opportunity ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		_ns10__ArrayOfOpportunityUpsertOpportunityTeamUser_teamUser teamUser;
		teamUser.role = new string("Bid Manager");
		
		// set owning user information
		tag_t userTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( *tOpportunity, OWNING_USER, &userTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		Teamcenter::scoped_smptr<char> userID;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(userTag, USER_ID, &userID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		char* userID_Upper = NULL;
		tc_strupr(userID.getString(), &userID_Upper); // Converting user ID to UPPER case
		teamUser.user = new string(userID_Upper);

		vector<_ns10__ArrayOfOpportunityUpsertOpportunityTeamUser_teamUser> teamUserVector;
		teamUserVector.push_back(teamUser);

		ns10__ArrayOfOpportunityUpsertOpportunityTeamUser oppTeamUser;
		oppTeamUser.teamUser = &teamUserVector;

		opportunity.teamUserList = &oppTeamUser;

		_ns10__ArrayOfOpportunityUpsertOpportunityCustomer_customer customer;
		customer.customerDNV_USCOREGL_USCOREID = opportunity.customerDNV_USCOREGL_USCOREID;

		vector<_ns10__ArrayOfOpportunityUpsertOpportunityCustomer_customer> customerVector;
		customerVector.push_back( customer );

		ns10__ArrayOfOpportunityUpsertOpportunityCustomer customerList;
		customerList.customer = &customerVector;

		opportunity.customerList = &customerList;

		vector<_ns10__ArrayOfOpportunityUpsertOpportunity_opportunity> opportunityListVector;
		opportunityListVector.push_back( opportunity );

		ns10__ArrayOfOpportunityUpsertOpportunity upsertOpportunity;
		upsertOpportunity.opportunity = &opportunityListVector;

		_ns10__opportunityUpsert ns2OpportunityUpsert;
		ns2OpportunityUpsert.opportunityList = &upsertOpportunity;

		_ns10__opportunityUpsert_header header;
		header.targetSystemCode= new string("AFF");
		header.sourceSystemCode= new string("APS");

		ns2OpportunityUpsert.header = &header;

		_ns9__OpportunityUpsert opportunityUpsert;
		opportunityUpsert.ns10__opportunityUpsert = &ns2OpportunityUpsert;

		_ns9__OpportunityUpsertResponse oppoUpsertResponse;

		soap_init(soap);

		//Call the web service
		if (soap_call___ns9__OpportunityUpsert(soap, pcEndpoint, NULL, &opportunityUpsert, oppoUpsertResponse) == SOAP_OK) 
		{
			cout<<"Affinitas Oppourtunity Upsert has been executed successfully."<<endl;       

			vector<_ns10__ArrayOfOpportunityUpsertOpportunity_opportunity>* opportunityVector = oppoUpsertResponse.ns10__opportunityUpsert->opportunityList[0].opportunity;

			string partialError = *oppoUpsertResponse.ns10__opportunityUpsert->header->errorMessage;
			if( !partialError.empty() )
			{
				EMH_store_error( EMH_severity_warning, ERROR_919114) ;
				TC_write_syslog ( "Affinitas Opportunity Upsert webservice. Partial Error text: %s", partialError.c_str() );
				TC_write_syslog ( "Error occurred in executing Affinitas Opportunity Upsert webservice. Error text: %s", soap->buf );
				iStatus = ERROR_919114;
			}
			else
			{
				string *affinitasNumber = opportunityVector->at(0).targetSystemRecordId;
				
				DNVGL_TRACE_CALL( iStatus = AOM_load( *tOpportunity ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tOpportunity, true ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( *tOpportunity, AP4_AFFINITAS_NUMBER, affinitasNumber->c_str() ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( *tOpportunity ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tOpportunity, false ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
		else 
		{
			EMH_store_error( EMH_severity_warning, ERROR_919114) ;			
			TC_write_syslog ( "Error occurred in executing Affinitas Opportunity Upsert webservice. Error text: %s", soap->buf );
			iStatus = ERROR_919114;
		}
	}
	catch(...)
	{

	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}

std::string convertDateToRequestString(date_t inputDate)
{
	std::string dateValue = "";

	if( !DATE_IS_NULL( inputDate ) )
	{
		char buffer [11];
		sprintf (buffer, "%02d/%02d/%04d", inputDate.month + 1, inputDate.day, inputDate.year);
		buffer [10] = '\0';
		dateValue.assign(buffer);
	}

	return dateValue;
}

int dnvgl_get_opportunity_attributes( tag_t *tOpportunity, _ns10__ArrayOfOpportunityUpsertOpportunity_opportunity &opportunity )
{
	int	iStatus	= ITK_ok;
	DNVGL_TRACE_ENTER();

	try
	{
		// Get UID
		char* cSourceSystemRecordId = NULL;
		DNVGL_TRACE_CALL( iStatus = POM_tag_to_uid( *tOpportunity, &cSourceSystemRecordId ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Validate that customer is attached
		tag_t *tCustomer = NULL;
		int iNoOfCustomers = 0;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( *tOpportunity, AP4_PROJECT_CUSTOMER, &iNoOfCustomers, &tCustomer) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		// Read Customer DNVGL ID String properties
		Teamcenter::scoped_smptr<char>  sCustomerDNVID;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tCustomer[0], AP4_DNV_ID, &sCustomerDNVID));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		Teamcenter::scoped_smptr<char>  sTargetSystemServiceRecordId;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tOpportunity, AP4_SERVICE_AREA, &sTargetSystemServiceRecordId ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		Teamcenter::scoped_smptr<char>  sTargetSystemServiceLineId;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tOpportunity, AP4_SERVICE_LINE, &sTargetSystemServiceLineId ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		Teamcenter::scoped_smptr<char>  sTargetSystemSalesStageId;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tOpportunity, AP4_SALES_STAGE, &sTargetSystemSalesStageId ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		Teamcenter::scoped_smptr<char>  sName;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tOpportunity, OBJECT_NAME, &sName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		Teamcenter::scoped_smptr<char>  sCurrencyCode;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tOpportunity, AP4_CURRENCY_CODE, &sCurrencyCode ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		Teamcenter::scoped_smptr<char>  sMarketSegment;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tOpportunity, AP4_MARKET_SEGMENT, &sMarketSegment ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		Teamcenter::scoped_smptr<char> cAffinitasNumber;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tOpportunity, AP4_AFFINITAS_NUMBER, &cAffinitasNumber) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		Teamcenter::scoped_smptr<char> cExecutiveSummary;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tOpportunity, AP4_EXECUTIVE_SUMMARY, &cExecutiveSummary) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		Teamcenter::scoped_smptr<char> cLostReason;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tOpportunity, AP4_OPPORTUNITY_LOST_REASON, &cLostReason) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
			
		Teamcenter::scoped_smptr<char> cCapExOpEx;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( *tOpportunity, AP4_CAPEX_OR_OPEX, &cCapExOpEx) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		// Read Double properties
		double dLocalValue = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( *tOpportunity, AP4_LOCAL_PROJECT_VALUE, &dLocalValue) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Read Integer properties
		int iProbabilityPercent = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_int( *tOpportunity, AP4_PROBABILITY, &iProbabilityPercent ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Read Date properties
		date_t dtEstimatedClosureDate = NULLDATE;
		date_t dtProposalSentDate = NULLDATE;
		date_t dtProposalDeadline = NULLDATE;
		date_t dtStartDate = NULLDATE;		
		date_t dtEndDate = NULLDATE;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(*tOpportunity, AP4_START_DATE, &dtStartDate) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(*tOpportunity, AP4_ESTIMATED_END_DATE, &dtEndDate) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(*tOpportunity, AP4_ESTIMATED_CLOSURE_DATE, &dtEstimatedClosureDate) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(*tOpportunity, AP4_PROPOSAL_DEADLINE, &dtProposalSentDate) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_date(*tOpportunity, AP4_PROPOSAL_SENT_DATE, &dtProposalDeadline) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;


		opportunity.sourceSystemCode = new string("APS");
		opportunity.name = new string(sName.getString() );
		opportunity.sourceSystemRecordId = new string(cSourceSystemRecordId);
		opportunity.customerDNV_USCOREGL_USCOREID = new string(sCustomerDNVID.getString() );
		opportunity.targetSystemServiceRecordId = new string(sTargetSystemServiceRecordId.getString() );
		opportunity.targetSystemServiceLineId = new string(sTargetSystemServiceLineId.getString() );
		opportunity.targetSystemSalesStageId =  new string(sTargetSystemSalesStageId.getString() );
		opportunity.currencyCode = new string(sCurrencyCode.getString() );
		opportunity.marketSegment = new string(sMarketSegment.getString() );
		opportunity.targetSystemRecordId = new string( cAffinitasNumber.getString() );
		opportunity.executiveSummary = new string(cExecutiveSummary.getString());
		opportunity.lostReason = new string(cLostReason.getString());

		// This ugly looking code should be cleaned when Dama change capEx/opEx batch lov to real value.
		char* realValue = (char *)cCapExOpEx.getString();
		if(tc_strcmp(cCapExOpEx.getString(), "capEx") == 0)
		{
			realValue = "Customer Capex budget";
		}
		else if(tc_strcmp(cCapExOpEx.getString(), "opEx") == 0)
		{
			realValue = "Customer Opex budget";
		}		
		opportunity.capExOpEx = new string(realValue); // ap4_capex_or_opex
		
		int temp = (int) dLocalValue; // this conversion will trunk the decimals
		opportunity.localValue = new string( std::to_string(temp) );

		temp = iProbabilityPercent;
		opportunity.probabilityPercent = new string( std::to_string(temp) );;

		opportunity.expectedProjectStart = new string( convertDateToRequestString(dtStartDate) );
		opportunity.expectedProjectEnd = new string( convertDateToRequestString(dtEndDate) );
		opportunity.estimatedClosure = new string( convertDateToRequestString(dtEstimatedClosureDate) );
		opportunity.proposalDeadlineDate = new string( convertDateToRequestString(dtProposalSentDate) );
		opportunity.proposalSentDate = new string( convertDateToRequestString(dtProposalDeadline) );
	}
	catch(...)
	{

	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}