/**
* \file dnvgl_utils.cxx
* \ingroup libAP4_dnvgl_common
* \verbatim
\par Description:
This File  contains the utiltiy functions.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 30-May-2016   Vinay Kudari        Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_eform_services.h"

int dnvgl_eform_service_call( std::string eformDocID, std::string eformDocType, std::string cpFilePath, tinyxml2::XMLDocument & requtestXML )
{
	int iStatus = 0;
	try
	{
		CURL *curl = curl_easy_init(); 
		if(curl) 
		{ 
			char errorBuffer[CURL_ERROR_SIZE];
			std::string url = "http://onedev.dnvgl.com/EformsServices/Blender/forms/form/" + eformDocID + "/" + eformDocType;
			curl_easy_setopt(curl, CURLOPT_URL, url.c_str()); 
			struct curl_slist *slist = curl_slist_append(NULL, "Content-Type: text/xml; charset=utf-8; X-eForms-ClientId=TEST-APS-PoC");
			curl_easy_setopt(curl, CURLOPT_HTTPHEADER, slist); 

			tinyxml2::XMLPrinter printer;
			requtestXML.Print( &printer );
			std::string xmlString = printer.CStr();
			std::cout <<"calling url:-" << url << std::endl;
			TC_write_syslog("Calling E-Form URL: %s\n", url.c_str());
			TC_write_syslog("With POST data (request xml):\n%s\n", xmlString.c_str());

			xmlString.erase(std::remove(xmlString.begin(), xmlString.end(), '\n'), xmlString.end());

			curl_easy_setopt(curl, CURLOPT_POST, 1); 
			curl_easy_setopt(curl, CURLOPT_POSTFIELDS, xmlString.c_str()); 
			curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, xmlString.length()); 
			curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errorBuffer);

			FILE *fp = fopen(cpFilePath.c_str(), "wb");
			curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data_callback);
			curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);

			CURLcode respCode( CURLE_FAILED_INIT );
			respCode = curl_easy_perform(curl); 
			curl_slist_free_all(slist);
			curl_easy_cleanup(curl);
			fclose(fp);

			// check for status
			if(respCode != CURLE_OK)
			{
				long responseCode;
				curl_easy_getinfo( curl, CURLINFO_RESPONSE_CODE, &responseCode );
				std::stringstream errMsg;
				errMsg << "E-Form service return error code:" << responseCode;
				// error in eform rest service request
				std::cout << "Error exception:" << errorBuffer << std::endl;
				std::cout << "Error:" << errMsg.str().c_str()<< std::endl;

				EMH_store_error_s1( EMH_severity_error, ERROR_919113, errMsg.str().c_str() );
				TC_write_syslog ( "\nError occurred in executing E-Form webservice. Error text: %s\n",  errorBuffer );
				return ERROR_919113;
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

size_t write_data_callback(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
	size_t written = fwrite(ptr, size, nmemb, stream);
	return written;
}

int dnvgl_get_eform_dataset_info( char* cpTemplateType, char * cpVersion, std::string& cpEformID, std::string& cpEformDocType, std::string& cpDatasetType, tag_t* tDatasetTag )
{
	int iStatus = 0;
	try
	{
		int count;
		char** pszValues;
		char* pszPrefName = DNVGL_EFORM_DATASETS;
		std::string frmId,dsNm;
		std::map<std::string, std::string> mPrefVal;

		DNVGL_TRACE_ENTER();

		DNVGL_TRACE_CALL( iStatus = PREF_ask_char_values( pszPrefName, &count, &pszValues ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<std::string> vSplitVector;
		bool prefMappingFound = false;
		for( int i=0; i<count; i++ )
		{
			vSplitVector.clear();
			dnvgl_split( pszValues[i], '|', vSplitVector );
			if( vSplitVector.size() == 6 )
			{
				if( tc_strcmp( cpTemplateType, vSplitVector.at(0).c_str() ) == 0  && tc_strcmp(cpVersion, vSplitVector.at(1).c_str())== 0)
				{
					prefMappingFound = true;
					break;
				}
			}			
		}

		if( prefMappingFound )
		{
			DNVGL_TRACE_CALL( iStatus = AE_find_dataset2( vSplitVector.at(2).c_str(), tDatasetTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tDatasetTag == NULL || *tDatasetTag == NULLTAG )
			{
				iStatus = ERROR_919104;
				std::string errMsg = "EForm mapping dataset with name '" +  vSplitVector.at(2) + "' not found.";
				EMH_store_error_s1( EMH_severity_error, ERROR_919104, errMsg.c_str() );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}		
			else
			{
				cpEformID = vSplitVector.at(3);				
				cpDatasetType = vSplitVector.at(4);
				cpEformDocType = vSplitVector.at(5);
			}
		}
		else
		{
			iStatus = ERROR_919103;
			std::string errMsg = "Mapping not found in preference for '";
			errMsg.append( cpTemplateType);
			errMsg.append( "|" );
			errMsg.append( cpVersion );
			errMsg.append( "' combination" );	
			EMH_store_error_s1( EMH_severity_error, ERROR_919103, errMsg.c_str() );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}		
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_read_mapping_dataset( tag_t tDatasetTag, std::string strTempFolderPath, std::vector<std::string>  &vData )
{
	int iStatus = 0;
	char* strDatasetName = NULL;
	char* cpReferenceNm=NULL;
	char* cpDestPath = NULL ;
	try
	{
		int iInstance=0;

		std::string strTempValue;
		AE_reference_type_t reference_type;
		tag_t tRefObjectTag	;
		std::stringstream file;

		DNVGL_TRACE_CALL(iStatus=AE_find_dataset_named_ref2( tDatasetTag, iInstance, &cpReferenceNm, &reference_type, &tRefObjectTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;


		DNVGL_TRACE_CALL(iStatus=AOM_ask_value_string( tDatasetTag, OBJECT_NAME, &strDatasetName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::string strDatasetFilePath =  strTempFolderPath ;
		strDatasetFilePath.append("\\");
		strDatasetFilePath.append(strDatasetName);
		strDatasetFilePath.append(".txt");
		std::cout<<"dataset file path-"<<strDatasetFilePath<<std::endl;
		//"C:\\temp\\"<<strDatasetName<<".txt"
		file<<strDatasetFilePath;
		std::string ss=file.str();

		cpDestPath = (char*) MEM_alloc ( (int) (sizeof(char)*(ss.size()+1)) )		;
		strcpy( cpDestPath,ss.c_str() );

		struct stat buf;
		if (stat( cpDestPath, &buf ) == 0 )
		{
			remove(cpDestPath);
		}

		DNVGL_TRACE_CALL( iStatus = AE_export_named_ref( tDatasetTag, cpReferenceNm, cpDestPath ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::ifstream iFile( cpDestPath );

		if ( iFile.is_open() )
		{
			while ( getline ( iFile, strTempValue ) )
			{

				std::string validString = strTempValue;
				validString.erase( remove_if(validString.begin(), validString.end(), isspace), validString.end()); // remove all whitespace
				if (validString.size() < 1 || validString[0] == '#')
				{
					continue;
				}
				else
				{
					vData.push_back(strTempValue);
				}
			}
			iFile.close();
		}
	}
	catch( ... )
	{
	}
	MEM_free(strDatasetName);
	MEM_free(cpReferenceNm);
	MEM_free(cpDestPath);
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_eform_service( tag_t tDocrev, tag_t *datasetTag)
{
	int		iStatus			= 0			;
	std::string strTempFolderPath = "";
	boolean bIsTempFolderCreated = false ;
	try
	{
		DNVGL_TRACE_ENTER();

		tag_t tTargetObjItemTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tDocrev, &tTargetObjItemTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char * cpDocumentType = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjItemTag, AP4_TEMPLATETYPE, &cpDocumentType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char * cpDocumentCategory = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tTargetObjItemTag, AP4_VERSION, &cpDocumentCategory ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// if AP4_EFORM_TEMPLATE_CATEGORY attribute is not filled, lets replace it with NA.
		cpDocumentCategory = DNVGL_IS_STRING_EMPTY(cpDocumentCategory) ? "NA" : cpDocumentCategory;

		tag_t tDatasetTag = NULLTAG;
		std::string cpEformID;
		std::string cpEformDocType;
		std::string cpDatasetType;

		DNVGL_TRACE_CALL( iStatus = dnvgl_get_eform_dataset_info( cpDocumentType, cpDocumentCategory, cpEformID, cpEformDocType, cpDatasetType, &tDatasetTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tDatasetTag != NULL && tDatasetTag != NULLTAG )
		{
			const char* cpTempPath;
			cpTempPath = getenv (TEMP_ENV_VAR);

			std::string strDirName;
			char * timeStamp;

			DNVGL_TRACE_CALL( DNVGL_current_get_time_stamp(DATE_FORMAT_STR_FOOTER, &timeStamp) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			strDirName = timeStamp;

			strTempFolderPath = cpTempPath ;
			strTempFolderPath.append("\\");
			strTempFolderPath.append(strDirName);
			DNVGL_TRACE_CALL( iStatus = _mkdir(strTempFolderPath.c_str()));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bIsTempFolderCreated = true ;
			std::vector<std::string> vData;
			DNVGL_TRACE_CALL( iStatus = dnvgl_read_mapping_dataset( tDatasetTag ,strTempFolderPath ,vData ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			// create request xml
			tinyxml2::XMLDocument xmlRequest;

			DNVGL_TRACE_CALL( iStatus = dnvgl_get_request_xml( tDocrev, vData, xmlRequest ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char * cpObjectName = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tDocrev, OBJECT_NAME, &cpObjectName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			std::string cpFilePath = strTempFolderPath;
			cpFilePath.append("\\");
			cpFilePath.append( cpObjectName );
			cpFilePath.append( "." );
			cpFilePath.append( cpEformDocType );

			DNVGL_TRACE_CALL( iStatus = dnvgl_eform_service_call( cpEformID, cpEformDocType, cpFilePath, xmlRequest ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = dnvgl_dataset_attach( (char*) cpDatasetType.c_str(), "word", cpObjectName, (char*)cpFilePath.c_str(), tDocrev, datasetTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}
	//Delete the folder	
	if(bIsTempFolderCreated){
		std::string strTempFolderDeleteCmd = "" ;

		strTempFolderDeleteCmd.append("\"RD ");
		strTempFolderDeleteCmd.append(" /S ");
		strTempFolderDeleteCmd.append(" /Q \""); 
		strTempFolderDeleteCmd.append(strTempFolderPath);
		strTempFolderDeleteCmd.append("\"\"");

		//Delete folder
		DNVGL_TRACE_CALL( system( strTempFolderDeleteCmd.c_str() ) );
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_get_request_xml( tag_t tDocrev, std::vector<std::string> vData, tinyxml2::XMLDocument & requtestXML )
{
	int iStatus = 0;
	try
	{
		// fill header in request xml
		tinyxml2::XMLNode *pDecl = requtestXML.NewDeclaration("xml version=\"1.0\" encoding=\"utf-8\"");
		requtestXML.InsertFirstChild(pDecl);

		tinyxml2::XMLNode * pRoot = requtestXML.NewElement("Instructions");
		requtestXML.InsertEndChild(pRoot);

		tinyxml2::XMLNode * pTxtEle = requtestXML.NewElement("TextElements");
		pRoot->InsertFirstChild(pTxtEle);

		std::map<std::string,std::string> attributeMap;
		DNVGL_TRACE_CALL( iStatus = dnvgl_get_attribute_map(tDocrev, vData, attributeMap) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::map<std::string, std::string>::iterator iter = attributeMap.begin();
		for( ; iter != attributeMap.end(); iter++ )
		{	     
			std::string strBookMark = iter->first;
			std::string strValue = iter->second;

			tinyxml2::XMLNode * pTxt = requtestXML.NewElement("Text");
			pTxtEle->InsertFirstChild(pTxt);

			tinyxml2::XMLElement * pBM = requtestXML.NewElement("Bookmark");
			pBM->SetText( strBookMark.c_str() );

			tinyxml2::XMLElement * pVal = requtestXML.NewElement("Value");
			pVal->SetText( strValue.c_str() );

			pTxt->InsertFirstChild(pBM);
			pTxt->InsertEndChild(pVal);
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_get_attribute_map(tag_t tTargetObjectTag, std::vector<std::string> vMappingData, std::map<std::string,std::string> &attributeMap )
{
	int iStatus = 0;
	try
	{
		std::vector<std::string> vEqualSep;
		std::vector<std::string> vPipeSep;

		std::string vlaue = "";
		//for(vector<string>::iterator itrData = fileData.begin(); itrData != fileData.end(); itrData++)
		for(int inx = 0; inx < vMappingData.size(); inx++)
		{
			tag_t tCurrentTag = tTargetObjectTag; // initializing with document revision tag
			vlaue = "";

			vEqualSep.clear();
			dnvgl_split(vMappingData[inx], '=', vEqualSep );

			std::string bookmarkName = vEqualSep[0];
			if(vEqualSep.size() == 2) // enter only if we found 2 tokens 
			{
				vPipeSep.clear();
				dnvgl_split(vEqualSep[1] , '|', vPipeSep );
				int expressionsCount = (int) vPipeSep.size();

				int retCode = 0;
				for(int jnx = 0; jnx < (expressionsCount - 1); jnx++ ) // looping through size - 1 times coz we dont have to evaluate last expression.
				{
					retCode = resolveReferenceExpression(tCurrentTag, vPipeSep[jnx]);
					if(tCurrentTag == NULL || retCode != 0)
					{
						std::string msg("Error: expression '");
						msg.append(vPipeSep[jnx]);
						msg.append("' used in bookmark id-" );
						msg.append( vEqualSep[0] );
						msg.append(" returns NULL. Problem could be with data(like no object is attached with given relation) or mapping file.\n" );

						std::cout << msg.c_str() << std::endl;
						TC_write_syslog(msg.c_str() );
						break; // no further processing required
					}
				}

				// now lets evaluate attribute expression
				DNVGL_TRACE_CALL( iStatus = resolveAttributeExpression(tCurrentTag, vPipeSep[expressionsCount-1], vlaue));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			attributeMap[ bookmarkName ] = vlaue;
			//std::cout << inx << ". " << bookmarkName << "\t\t" << vlaue << std::endl;
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int getPrimaryObject(tag_t tCurrentTag, std::string relationName, std::string expectedBOType, tag_t& tPrimaryObjTag)
{
	int iStatus = 0;
	try
	{
		DNVGL_TRACE_ENTER();
		tag_t relationTag = NULL;
		tag_t* primObjs = NULL;
		tPrimaryObjTag = NULL; // initializing
		int count = 0;

		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type(relationName.c_str(), &relationTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus = GRM_list_primary_objects_only(tCurrentTag, relationTag, &count, &primObjs));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		bool isInstanceOf = false;
		for(int inx = 0; inx < count; inx++)
		{
			DNVGL_TRACE_CALL( iStatus = checkIsInstanceOf(primObjs[inx], expectedBOType.c_str(), isInstanceOf) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			if(isInstanceOf == true)
			{
				tPrimaryObjTag = primObjs[inx];
				break;
			}
		}

	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int resolveReferenceExpression(tag_t& tCurrentTag, std::string eachExpression)
{
	int iStatus = ITK_ok;

	try
	{
		DNVGL_TRACE_ENTER();
		tag_t otherObject = NULL;

		// remove all whitespaces in expression
		eachExpression.erase( remove_if(eachExpression.begin(), eachExpression.end(), isspace), eachExpression.end());

		std::vector<std::string> vColonSep;
		dnvgl_split(eachExpression, ':', vColonSep );

		if(vColonSep[0].compare("S2P") == 0)
		{
			std::string propName = vColonSep[1];
			std::string expectedBOType = vColonSep[2];
			DNVGL_TRACE_CALL( iStatus = getPrimaryObject(tCurrentTag, propName, expectedBOType, otherObject));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			std::string propName = vColonSep[0];
			std::string expectedBOType = vColonSep[1];

			// check if given prop is array or single value
			int maxNumElements = 0;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_max_num_elements( tCurrentTag, propName.c_str(), &maxNumElements ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( maxNumElements == 1 )
			{
				// that means its a single value attribute
				DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_tag(	tCurrentTag, propName.c_str(), &otherObject));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				tag_t* otherObjs = NULL;
				int count = 0;
				DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_tags( tCurrentTag, propName.c_str(), &count, &otherObjs));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if(count > 0) // as we dont support multiple value, hence taking whatever is there on 0th index. (could be NULL if no results found)
				{
					bool isTypeOf = false;
					checkIsInstanceOf(*otherObjs, expectedBOType.c_str(), isTypeOf);
					otherObject = isTypeOf ? *otherObjs : NULL;
				}				 
			}
		}

		tCurrentTag = otherObject;
	}
	catch( ... )
	{
		tCurrentTag = NULL;
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int resolveAttributeExpression(tag_t& tCurrentTag, std::string& eachExpression, std::string& currentValue)
{
	int iStatus = ITK_ok;
	try
	{
		DNVGL_TRACE_ENTER();
		if(tCurrentTag != NULL)
		{
			// check for comma sep values
			std::vector<std::string> vCommaSep;
			dnvgl_split(eachExpression, '+', vCommaSep );
			for(int inx = 0; inx < vCommaSep.size(); inx++)
			{
				// if start with double quotes, that means its hard coded value
				if(vCommaSep[inx].find('"') != std::string::npos) // quotes found
				{
					int first = (int) vCommaSep[inx].find_first_of('\"');
					int last = (int) vCommaSep[inx].find_last_of('\"');
					currentValue.append( vCommaSep[inx].substr( first+1, (last-first-1)) );
					continue;
				}

				char* cpValType = NULL;
				std::string propName = vCommaSep[inx];
				propName.erase( remove_if(propName.begin(), propName.end(), isspace), propName.end()); // remove all whitespaces

				PROP_value_type_t valtype;
				DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_type ( tCurrentTag, propName.c_str(), &valtype, &cpValType ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				/*switch case begins*/
				switch(valtype)
				{
				case PROP_date: // only for date we have to handler differently.
					date_t tDateTag;
					tDateTag = NULLDATE;
					DNVGL_TRACE_CALL( iStatus =  AOM_get_value_date(tCurrentTag, propName.c_str(), &tDateTag));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					char *cpDate;
					cpDate = NULL ;
					DNVGL_TRACE_CALL( iStatus =  DATE_date_to_string(tDateTag, "%Y-%m-%d %H:%M:%S", &cpDate ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					currentValue.append(cpDate);
					break;

				default: // for everything else, lets take display value
					char* value = NULL;
					DNVGL_TRACE_CALL( iStatus =   AOM_UIF_ask_value(tCurrentTag, propName.c_str(), &value));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					currentValue.append(value);
					break;
				}//end of switch 
			}
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
