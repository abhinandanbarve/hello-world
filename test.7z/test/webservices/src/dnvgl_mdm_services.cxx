/**
* \file dnvgl_mdm_services.cxx
* \ingroup libAP4_dnvgl_webservices
* \verbatim
\par Description:

\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 03-Aug-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_mdm_services.h"

int dnvgl_search_mdm_customers( const std::map< std::string, std::string >& input, std::vector< std::map<std::string,std::string> >& output )
{
	int	iStatus	= ITK_ok;
	DNVGL_TRACE_ENTER();	
	try
	{
		struct soap soap;		
		soap_init2(&soap, SOAP_C_UTFSTRING, SOAP_C_UTFSTRING);

		_ns2__customerSearchRequest_customer customer1 = _ns2__customerSearchRequest_customer();		
		customer1.city = new std::string( input.find( "ap4_addr_city" )->second );
		customer1.country = new std::string( input.find( "ap4_addr_country" )->second );
		customer1.DNV_USCOREID = new std::string( input.find( "ap4_cust_dnv_id" )->second );
		customer1.fullName = new std::string( input.find( "ap4_cust_full_name" )->second );
		customer1.sourceSystem = new std::string( "APS" );

		_ns2__customerSearchRequest request = _ns2__customerSearchRequest();
		request.customer = &customer1;

		_ns1__WS_USCORECustomerSearch customerSearch = _ns1__WS_USCORECustomerSearch();
		customerSearch.ns2__customerSearchRequest = &request;

		_ns1__WS_USCORECustomerSearchResponse customerSearchResponse1;

		// get header and endpoint value from preference
		char* pcHeader = NULL;
		char* pcEndpoint = NULL;
		DNVGL_ITK_CALL ( PREF_ask_char_value ( "MDM_CustomerSearch_Service.HEADER" , 0 , &pcHeader ) ) ;
		DNVGL_ITK_CALL ( PREF_ask_char_value ( "MDM_CustomerSearch_Service.ENDPOINT" , 0 , &pcEndpoint ) ) ;

		//if lenth is 0, set to NULL
		if(pcHeader != NULL)
		{
			pcHeader = tc_strlen(pcHeader) == 0 ? NULL : pcHeader;
		}
		if(pcEndpoint != NULL)
		{
			pcEndpoint = tc_strlen(pcEndpoint) == 0 ? NULL : pcEndpoint;
		}
		
		if( soap_call___ns1__WS_USCORECustomerSearch( &soap, pcEndpoint, NULL, &customerSearch, customerSearchResponse1 ) == SOAP_OK )
		{
			dnvgl_get_customer_attributes(&customerSearchResponse1, &output);
		}
		else
		{
			TC_write_syslog ( "\nError occurred in executing MDM Customer Search webservice. Error text: %s\n", soap.buf );
			iStatus = ERROR_919110;
		}

		soap_destroy(&soap); 
		soap_end(&soap); 
		soap_done(&soap);
	}
	catch(...)
	{
		TC_write_syslog ( "\nError occurred in executing MDM Customer Search webservice. Error text: Unhandled exception\n");
		iStatus = ERROR_919110; 
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}
/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
Thhis function will allow to add only one address against DNV ID of customer in the map
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]  mapCustomer		map of the customers, Key: DNV ID Value : Customer
* \param[in]  currCustomer		Current customer object to be checked.
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_check_unique_address( std::map <std::string,_ns2__customerSearchResponse_customer>& mapCustomer, _ns2__customerSearchResponse_customer& currCustomer )
{
	int iStatus = ITK_ok;
	std::string strAddressType; 
	std::string strMdmID;
	std::string strCurrCustAddrType;
	std::string strCurrCustMdmId;
	
	DNVGL_TRACE_ENTER();
	try
	{		
		std::map <std::string,_ns2__customerSearchResponse_customer>::iterator itrCustomer ;
		bool bCustomerFound = false;
		
		//Check wether any customer with the DNV ID is present or not in the map
		for (itrCustomer = mapCustomer.begin(); itrCustomer != mapCustomer.end(); ++itrCustomer)
		{
			if( tc_strcmp(itrCustomer->first.c_str(), currCustomer.DNV_USCOREID->c_str() ) == 0 )
			{
				bCustomerFound = true;
				break;
			}
		}
		if( bCustomerFound )
		{
			//Found the Customer in custom list 
			int iFirstAddr = 0;
			int iSecondAddr = 0;
			
			strAddressType = itrCustomer->second.addrType->c_str();
			strMdmID = itrCustomer->second.MDM_USCOREID_USCOREaddr->c_str();
			strCurrCustAddrType = currCustomer.addrType->c_str();
			int iMdmID = stoi( strMdmID );
			
			//convert the address to integer for ease of comparision
			if( tc_strcmp(OFFICE, strAddressType.c_str() ) == 0) iFirstAddr = 1;
			else if( tc_strcmp(INVOICE, strAddressType.c_str() ) == 0) iFirstAddr = 2;
			else if( tc_strcmp(POSTAL, strAddressType.c_str() ) == 0) iFirstAddr = 3;
			
			if( tc_strcmp(OFFICE, strCurrCustAddrType.c_str() ) == 0) iSecondAddr = 1;			
			else if( tc_strcmp(INVOICE, strCurrCustAddrType.c_str() ) == 0) iSecondAddr = 2;			
			else if( tc_strcmp(POSTAL, strCurrCustAddrType.c_str() ) == 0) iSecondAddr = 3;
			
			//If the number is less than current added customer address type number then address second number address type as it has higher priority
			if(iFirstAddr > iSecondAddr)
				itrCustomer->second = currCustomer;
			else if(iFirstAddr == iSecondAddr)
			{
				// Compare the MDM Id if same type of Address are present
				std::string  strCurrMdmID;
				strCurrMdmID =  currCustomer.MDM_USCOREID_USCOREaddr->c_str();
				
				if( !strCurrMdmID.empty() )
				{
					//Replace the adress which is smaller in MDM address ID
					int iCurrMdmID = stoi(strCurrMdmID);
					itrCustomer->second = iCurrMdmID < iMdmID ? currCustomer : itrCustomer->second;
				}
			}
		}
		else
		{
			//not present in the list, add directly
			mapCustomer.insert( std::pair<std::string , _ns2__customerSearchResponse_customer>( currCustomer.DNV_USCOREID->c_str(), currCustomer ) );
		}		
	}
	catch(...)
	{
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}
/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
Thhis function will call the search MDM customer web service and fetch the result.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]  mapCustomer		response object.
* \param[out] output			vector list of found customers.
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_get_customer_attributes( _ns1__WS_USCORECustomerSearchResponse* response, std::vector< std::map<std::string,std::string> >* output )
{
	int iStatus = ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		std::vector<_ns2__customerSearchResponse_customer> *customers = response->ns2__customerSearchResponse->customer;
		if( customers != NULL )
		{
			// call the web service and process the result	
			size_t iNoOfResults = customers->size();
			std::vector< std::map <std::string, std::map<std::string,std::string>>> uniqueCustomers;
			std::map <std::string,_ns2__customerSearchResponse_customer> mapCustomer;
			for( size_t i = 0; i < iNoOfResults; i++ )
			{
				dnvgl_check_unique_address( mapCustomer, customers->at(i) );				
			}
			std::map<std::string, _ns2__customerSearchResponse_customer>::iterator itrCustomer = mapCustomer.begin();
			for (itrCustomer = mapCustomer.begin(); itrCustomer != mapCustomer.end(); ++itrCustomer)
			{				
				std::map<std::string,std::string> rowData;
				rowData["DNV_USCOREID"]				= itrCustomer->second.DNV_USCOREID->c_str();
				rowData["city"]						= itrCustomer->second.city->c_str();
				rowData["MDM_USCOREID_USCOREaddr"]	= itrCustomer->second.MDM_USCOREID_USCOREaddr->c_str();
				rowData["state"]					= itrCustomer->second.state->c_str();
				rowData["dunsNumber"]				= itrCustomer->second.dunsNumber->c_str();
				rowData["fullName"]					= itrCustomer->second.fullName->c_str();
				rowData["MDM_USCOREID"]				= itrCustomer->second.MDM_USCOREID->c_str();
				rowData["country"]					= itrCustomer->second.country->c_str();
				rowData["addrLine1"]				= itrCustomer->second.addrLine1->c_str();
				rowData["MDMValidationStatus"]		= itrCustomer->second.MDMValidationStatus->c_str();
				output->push_back(rowData);						
			}		
		}
	}
	catch(...)
	{

	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

int dnvgl_retrieve_mdm_customer(std::string customerMdmID, tag_t* customerTag)
{
	int	iStatus	= ITK_ok;
	DNVGL_TRACE_ENTER();

	try
	{
		// get header and endpoint value from preference
		char* pcHeader = NULL;
		char* pcEndpoint = NULL;
		DNVGL_ITK_CALL ( PREF_ask_char_value ( "MDM_Retrieve_Service.HEADER" , 0 , &pcHeader ) ) ;
		DNVGL_ITK_CALL ( PREF_ask_char_value ( "MDM_Retrieve_Service.ENDPOINT" , 0 , &pcEndpoint ) ) ;

		//if lenth is 0, set to NULL
		if(pcHeader != NULL)
		{
			pcHeader = tc_strlen(pcHeader) == 0 ? NULL : pcHeader;
		}
		if(pcEndpoint != NULL)
		{
			pcEndpoint = tc_strlen(pcEndpoint) == 0 ? NULL : pcEndpoint;
		}

		struct soap soap;
		soap_init2(&soap, SOAP_C_UTFSTRING, SOAP_C_UTFSTRING);

		SOAP_ENV__Header header = SOAP_ENV__Header();
		header.wsa5__Action = "Retrieve";
		header.wsa5__To = pcHeader;

		soap.mustUnderstand = 1;
		soap.header = &header;

		_ns7__CustomerRetrieveId customerRetrieveID;
		customerRetrieveID.CustomerMDMId = (char*)customerMdmID.c_str();

		_ns8__APSCustomerRetrieveResponse response;
		if( soap_call___ns12__Retrieve( &soap, pcEndpoint, NULL, &customerRetrieveID, response ) == SOAP_OK )
		{
			tag_t newCustomerTag = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = dnvgl_create_customer(response.Customer, &newCustomerTag));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if(newCustomerTag != NULLTAG && iStatus == ITK_ok)
			{
				// change the ownership of new customer to infodba
				DNVGL_TRACE_CALL( iStatus = dnvgl_change_ownership( newCustomerTag, "infodba", "dba" ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;				

				// lets create addresses, below condition should always be true as we will always have atleast 1 address
				if( response.Customer.ListOfAddress != NULL )
				{
					std::vector<_ns8__APSCustomerRetrieveResponse_Customer_ListOfAddress_Addresses> *addresses = response.Customer.ListOfAddress->Addresses;

					if( addresses->size() > 0 )
					{
						// get the relation tag,
						tag_t tRelation	= NULLTAG;
						tag_t tCustAddrRelTag = NULLTAG;
						std::vector<tag_t> allAddresses;

						DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( "AP4_CustomerAddress", &tCustAddrRelTag ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						//lets create the address
						for(int inx = 0; inx < addresses->size(); inx++)
						{
							tag_t tAddressTag	= NULLTAG;
							// Ignoring errors while creating address, MDM system has bad data which may cause address creation in TC to fail.
							dnvgl_create_address( &(addresses->at(inx)), &tAddressTag);
							
							if(tAddressTag != NULLTAG)
							{
								// attache to customer
								DNVGL_TRACE_CALL( iStatus = GRM_create_relation( newCustomerTag, tAddressTag, tCustAddrRelTag, NULLTAG, &tRelation ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								//Save relation		
								DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelation ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								// change the ownership of new address to infodba
								DNVGL_TRACE_CALL( iStatus = dnvgl_change_ownership(tAddressTag, "infodba", "dba") );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								allAddresses.push_back(tAddressTag);
								tAddressTag	= NULLTAG; // reset value
							}
						}

						// create default address
						DNVGL_TRACE_CALL( iStatus = dnvgl_attach_default_address( newCustomerTag, allAddresses ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}

				// return the customer tag
				(*customerTag) = newCustomerTag;

				// lets call callback service
				char* custUid = NULL;
				DNVGL_TRACE_CALL( iStatus = POM_tag_to_uid(newCustomerTag, &custUid) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				std::string apsIdentifire(custUid);
				apsIdentifire.append("_");
				apsIdentifire.append(response.Customer.DNVGLID);

				dnvgl_update_mdm_customer( response.Customer, (char*)apsIdentifire.c_str() );

				// free the memory
				if(custUid != NULL)
				{
					MEM_free(custUid);
					custUid = NULL;
				}
			}
		}
		else
		{
			TC_write_syslog ( "\nError occurred in executing MDM Retrieve webservice. Error text: %s\n", soap.buf );
			iStatus = ERROR_919111;
		}

		soap_destroy(&soap); 
		soap_end(&soap); 
		soap_done(&soap);
	}
	catch(...)
	{
		TC_write_syslog ( "\nError occurred in executing MDM Retrieve webservice. Error text: Unhandled exception.\n" );
		iStatus = ERROR_919111;
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

int dnvgl_create_customer(_ns8__APSCustomerRetrieveResponse_Customer customer, tag_t *tNewCustomerTag)
{
	int			iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();

	try
	{
		tag_t	tCustTag			= NULLTAG;
		tag_t	tCustCreateInput	= NULLTAG;

		DNVGL_TRACE_CALL( iStatus =  TCTYPE_find_type( "AP4_MDMCustomer", "AP4_MDMCustomer", &tCustTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =   TCTYPE_construct_create_input( tCustTag, &tCustCreateInput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(tCustCreateInput, "object_name", customer.fullName.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(tCustCreateInput, "ap4_dnv_id", customer.DNVGLID.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(tCustCreateInput, "ap4_mdm_id", customer.MDMID_USCORECustomer.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( tCustCreateInput, tNewCustomerTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Set other properties
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_duns_number",customer.dunsNumber.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_legel_name", customer.legalName.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_local_name", customer.localName.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_vat", customer.vat.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_dnv_status",customer.dnvStatus.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_dnv_official_id_number", customer.DNVOfficialIdNumber.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_imo", customer.IMO.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_register_country", customer.REGISTER_USCORECOUNTRY.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_sub_category", customer.SUB_USCORECATEGORY.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_ct_legal_parent_ent_id", customer.CTLegalParentEntityDNVId.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// remove spaces from validation status
		std::string mdmValidStatus(customer.MDMValidationStatus);
		mdmValidStatus.erase( std::remove_if( mdmValidStatus.begin(), mdmValidStatus.end(), ::isspace ), mdmValidStatus.end() );
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(*tNewCustomerTag, "ap4_mdm_validation_status", mdmValidStatus.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// set validation date 
		date_t validationDate = dnvgl_get_date_from_string( customer.MDMValidationDate.c_str() );
		DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( *tNewCustomerTag, "ap4_mdm_validation_date", validationDate) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( *tNewCustomerTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	}
	catch(...)
	{

	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}


date_t dnvgl_get_date_from_string(const char* inputDateString)
{
	date_t valueDate = NULLDATE;

	// validate input string
	if(inputDateString != NULL && strlen(inputDateString) > 19 )
	{
		char year[5];
		memcpy( year, &inputDateString[0], 4 );
		year[4] = '\0';

		char month[3];
		memcpy( month, &inputDateString[5], 2 );
		month[2] = '\0';

		char day[3];
		memcpy( day, &inputDateString[8], 2 );
		day[2] = '\0';

		char hour[3];
		memcpy( hour, &inputDateString[11], 2 );
		hour[2] = '\0';

		char minute[3];
		memcpy( minute, &inputDateString[14], 2);
		minute[2] = '\0';

		char second[3];
		memcpy( second, &inputDateString[17], 2 );
		second[2] = '\0';

		valueDate.year = (short)atoi(year);
		valueDate.month = (byte)( atoi(month)-1 );
		valueDate.day = (byte)atoi(day);
		valueDate.hour = (byte)atoi(hour);
		valueDate.minute = (byte)atoi(minute);
		valueDate.second = (byte)atoi(second);

	}

	return valueDate;
}


int dnvgl_create_address( _ns8__APSCustomerRetrieveResponse_Customer_ListOfAddress_Addresses* addressStruct, tag_t* addressTagOutput )
{
	int	iStatus	= ITK_ok;
	DNVGL_TRACE_ENTER();

	try
	{
		tag_t tAddress = NULLTAG;
		tag_t tAddrCreateInput = NULLTAG;

		DNVGL_TRACE_CALL( iStatus =  TCTYPE_find_type("AP4_Address", "AP4_Address", &tAddress) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus =   TCTYPE_construct_create_input(tAddress, &tAddrCreateInput) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(tAddrCreateInput, "object_name", addressStruct->city.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(tAddrCreateInput, "ap4_city", addressStruct->city.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(tAddrCreateInput, "ap4_mdm_id_address", addressStruct->MDM_USCOREAddressId.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string(tAddrCreateInput, "ap4_mdm_id", addressStruct->MDM_USCOREAccountId.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( tAddrCreateInput, addressTagOutput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// lets set other attributes
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string( *addressTagOutput, "ap4_address_line1", addressStruct->addrLine1.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string( *addressTagOutput, "ap4_address_line2", addressStruct->addrLine2.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string( *addressTagOutput, "ap4_address_line3", addressStruct->addrLine3.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string( *addressTagOutput, "ap4_address_line4", addressStruct->addressLine4.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string( *addressTagOutput, "ap4_address_type", addressStruct->AddressType.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string( *addressTagOutput, "ap4_state", addressStruct->state.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string( *addressTagOutput, "ap4_postal_code", addressStruct->postalCode.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string( *addressTagOutput, "ap4_country", addressStruct->country.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus =  AOM_set_value_string( *addressTagOutput, "ap4_dnv_status", addressStruct->AddressStatus.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( *addressTagOutput ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{
		(*addressTagOutput) = NULLTAG;
	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}

int dnvgl_attach_default_address(tag_t& customerTag, std::vector<tag_t>& allAddress)
{
	int	iStatus	= ITK_ok;
	DNVGL_TRACE_ENTER();

	try
	{
		// 1. if only one address found, set as default
		// 2. if multiple office address, pick the one wtih smallest MDM_AddressID (as numeric value)
		// 3. if multiple postal address, pick the one wtih smallest MDM_AddressID (as numeric value)
		// 3. if multiple invoice address, pick the one wtih smallest MDM_AddressID (as numeric value)
		tag_t defautAddress = NULLTAG;
		if(allAddress.size() == 1)
		{
			defautAddress = allAddress[0];
		}
		else
		{
			tag_t officeAdr = NULLTAG;
			tag_t postalAdr = NULLTAG;
			tag_t invoiceAdr = NULLTAG;

			// check for office, postal and invoice address
			for(int inx = 0; inx < allAddress.size(); inx++)
			{
				char* addressType_str = NULL;
				char* mdmID_str = NULL;
				AOM_ask_value_string(allAddress[inx], "ap4_mdm_id_address", &mdmID_str);
				AOM_ask_value_string(allAddress[inx], "ap4_address_type", &addressType_str);

				int thisAddressID_int = atoi(mdmID_str);

				if( tc_strcmp("Office", addressType_str ) == 0)
				{
					if(officeAdr == NULLTAG)
					{
						officeAdr = allAddress[inx];
					}
					else
					{
						char* currOfcAseID = NULL;
						DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_string(officeAdr, "ap4_mdm_id_address", &currOfcAseID) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
						if(currOfcAseID != NULL && mdmID_str != NULL)
						{
							int currAddressID_int = atoi(currOfcAseID);
							officeAdr = currAddressID_int < thisAddressID_int ? officeAdr : allAddress[inx];
						}
					}
				}
				else if( tc_strcmp("Postal", addressType_str ) == 0)
				{
					if(postalAdr == NULLTAG)
					{
						postalAdr = allAddress[inx];
					}
					else
					{
						char* currAddressID = NULL;
						DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_string(postalAdr, "ap4_mdm_id_address", &currAddressID) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if(currAddressID != NULL && mdmID_str != NULL)
						{
							int currAddressID_int = atoi(currAddressID);
							postalAdr = currAddressID_int < thisAddressID_int ? postalAdr : allAddress[inx];
						}
					}
				}
				else if( tc_strcmp("Invoice", addressType_str ) == 0)
				{
					if(invoiceAdr == NULLTAG)
					{
						invoiceAdr = allAddress[inx];
					}
					else
					{
						char* currAddressID = NULL;
						DNVGL_TRACE_CALL( iStatus =  AOM_ask_value_string(invoiceAdr, "ap4_mdm_id_address", &currAddressID) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if(currAddressID != NULL && mdmID_str != NULL)
						{
							int currAddressID_int = atoi(currAddressID);
							invoiceAdr = currAddressID_int < thisAddressID_int ? invoiceAdr : allAddress[inx];
						}
					}
				}
			}

			// after we get all three address, lets assign default address
			if(officeAdr != NULLTAG) defautAddress = officeAdr;
			else if(postalAdr != NULLTAG) defautAddress = postalAdr;
			else if(invoiceAdr != NULLTAG) defautAddress = invoiceAdr;
		}

		tag_t tRelation	= NULLTAG;
		tag_t tCustAddrRelTag = NULLTAG;
		std::vector<tag_t> allAddresses;

		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( "AP4_CustomerDefaultAddress", &tCustAddrRelTag ) );
		if(defautAddress != NULLTAG)
		{
			// attache to customer
			DNVGL_TRACE_CALL( iStatus = GRM_create_relation( customerTag, defautAddress, tCustAddrRelTag, NULLTAG, &tRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Save relation		
			DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch(...)
	{

	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}

int dnvgl_update_mdm_customer( _ns8__APSCustomerRetrieveResponse_Customer retrievedCustomer, char* tcCustomerUID)
{
	int			iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();

	try
	{
		// get header and endpoint value from preference
		char* pcHeader = NULL;
		char* pcEndpoint = NULL;
		DNVGL_ITK_CALL ( PREF_ask_char_value ( "MDM_Callback_Service.HEADER" , 0 , &pcHeader ) ) ;
		DNVGL_ITK_CALL ( PREF_ask_char_value ( "MDM_Callback_Service.ENDPOINT" , 0 , &pcEndpoint ) ) ;

		//if lenth is 0, set to NULL
		if(pcHeader != NULL)
		{
			pcHeader = tc_strlen(pcHeader) == 0 ? NULL : pcHeader;
		}
		if(pcEndpoint != NULL)
		{
			pcEndpoint = tc_strlen(pcEndpoint) == 0 ? NULL : pcEndpoint;
		}

		struct soap soap;
		soap_init(&soap);	

		// set the header
		SOAP_ENV__Header header = SOAP_ENV__Header();
		header.wsa5__Action = "APSIdUpdate";
		header.wsa5__To = pcHeader;
		soap.mustUnderstand = 1;
		soap.header = &header;

		// create callback request
		_ns5__APSCustomer_Customer callbackReq_Cust = _ns5__APSCustomer_Customer();

		callbackReq_Cust.APSCustomerId		= tcCustomerUID;
		callbackReq_Cust.SourceSystem		= "APS";
		callbackReq_Cust.MDMID_USCORECustomer= retrievedCustomer.MDMID_USCORECustomer;
		callbackReq_Cust.DNVGLID			= retrievedCustomer.DNVGLID;
		callbackReq_Cust.dnvStatus			= retrievedCustomer.dnvStatus;
		callbackReq_Cust.fullName			= retrievedCustomer.fullName;
		callbackReq_Cust.DNVOfficialIdNumber = retrievedCustomer.DNVOfficialIdNumber;

		_ns5__APSCustomer callbackRequest = _ns5__APSCustomer();
		callbackRequest.Customer = callbackReq_Cust;

		_ns5__APSCustomer_Response callbackReq_Response = _ns5__APSCustomer_Response();
		callbackRequest.Response = callbackReq_Response;

		// create response object
		__ns11__APSIdUpdateResponse response = __ns11__APSIdUpdateResponse();

		if( soap_call___ns11__APSIdUpdate( &soap, pcEndpoint, NULL, &callbackRequest, response ) == SOAP_OK )
		{
			TC_write_syslog ( "\nSuccessfully called MDM callback service. Customer UID: %s\n",  tcCustomerUID);
			std::cout << "Successfully called MDM callback service. Customer UID:" << tcCustomerUID << std::endl;
		}
		else
		{
			soap_print_fault( &soap, stderr ); 
			EMH_store_error_s1(EMH_severity_error, ERROR_919112, soap.buf );
			TC_write_syslog ( "\nError occurred in executing MDM Callback webservice. Error text: %s\n", soap.buf );
			iStatus = 919112; // <error id="112">Error in executing MDM Callback webservice.</error>
		}

		soap_destroy(&soap); 
		soap_end(&soap); 
		soap_done(&soap);

	}
	catch(...)
	{
		EMH_store_error_s1(EMH_severity_error, ERROR_919112, "Unhandled exception" );
		TC_write_syslog ( "\nError occurred in executing MDM Callback webservice. Error text:Unhandled exception\n" );
		iStatus = 919112; // <error id="112">Error in executing MDM Callback webservice.</error>
	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}