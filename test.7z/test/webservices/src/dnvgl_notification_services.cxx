/**
* \file dnvgl_notification_services.cxx
* \ingroup libAP4_dnvgl_webservices
* \verbatim
\par Description: 
This service sends a SOAP Message to a middleware (see http://git.germanlloyd.org:8080/gitblit/docs/?r=PLM/MyDNVGLConnector.git) and the middleware sends a message to My DNV GL Portal.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Simon Koennecke
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 03-Aug-2016   Simon Koennecke	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_notification_services.h"


using namespace std;
using namespace mydnvgl;


int dnvgl_mydnvgl_notification( dnvgl_notification *notification )
{
	int	iStatus	= ITK_ok;
	DNVGL_TRACE_ENTER();
	
	char* pcEndpoint = NULL;
	DNVGL_ITK_CALL ( PREF_ask_char_value ( "MYDNVGL_SERVICE.SOAP_ENDPOINT" , 0 , &pcEndpoint ) ) ;

	if(pcEndpoint != NULL) {
		pcEndpoint = tc_strlen(pcEndpoint) == 0 ? NULL : pcEndpoint;
	}
	DNVGL_TRACE_DGB( ("My DNV GL SOAP Enpoint: %s", pcEndpoint) );

	try
	{
		/*
		if (!notification) {
			DNVGL_TRACE_ERRORS( ("No message defined") );
			return ERROR_919147;
		}

		if (notification->recipients.size() == 0) {
			DNVGL_TRACE_ERRORS( ("No receiver defined") );
			return ERROR_919148;
		}

		
		if (tc_strlen(notification->comment.c_str()) == 0) {
			DNVGL_TRACE_ERRORS( ("No message content defined") );
			return ERROR_919149;
		}*/
		
		//Set channel
		channel__Channel channel = channel__Channel();
		channel.channel__Id = &notification->channel_id;
		channel.channel__Title = &notification->channel_name;
		
		//Set receivers
		_msg__Message_Receivers receivers = _msg__Message_Receivers();
		receivers.msg__Receiver = notification->recipients;
		
		//Format subject and prepand to message
		if (tc_strlen(notification->subject.c_str()) > 0) {
			notification->subject.insert(0, "<strong>");
			notification->subject.append("</strong><br/>");
			notification->comment.insert(0, notification->subject);
		}

		bool urlActiveWorkspaceClient = true;
		bool urlRichClient = true; /*< TODO: urlRichClient isn't implemented */
		if (strcmp( notification->url.c_str(), "rich" ) == 0) {
			urlActiveWorkspaceClient = false;
		} else if (strcmp( notification->url.c_str(), "activeworkspace" ) == 0) {
			urlRichClient = false;
		} else if (strcmp( notification->url.c_str(), "none" ) == 0) {
			urlActiveWorkspaceClient = false;
			urlRichClient = false;
		}
		//Adding the link to active workspace
		if (urlActiveWorkspaceClient) {
			//Fetching AWC URL
			char* pcActiveWorkspaceHosting = NULL;
			DNVGL_ITK_CALL ( PREF_ask_char_value ( "ActiveWorkspaceHosting.WorkflowEmail.URL" , 0 , &pcActiveWorkspaceHosting ) ) ;

			if(tc_strlen(pcActiveWorkspaceHosting) == 0) {
				DNVGL_ITK_CALL ( PREF_ask_char_value ( "ActiveWorkspaceHosting.URL" , 0 , &pcActiveWorkspaceHosting ) );				
			}
			pcActiveWorkspaceHosting = tc_strlen(pcActiveWorkspaceHosting) == 0 ? NULL : pcActiveWorkspaceHosting;
			
			//Fetching My DNV GL Service Name
			char* pcActiveWorkspaceName = NULL;
			DNVGL_ITK_CALL ( PREF_ask_char_value ( "MYDNVGL_SERVICE.NAME" , 0 , &pcActiveWorkspaceName ) ) ;

			char* std_link_name = "Active Workspace: ";
			if (pcActiveWorkspaceName == NULL) {
				pcActiveWorkspaceName = std_link_name;
			} else {
				pcActiveWorkspaceName = tc_strlen(pcActiveWorkspaceName) == 0 ? std_link_name : pcActiveWorkspaceName;
			}
			
			try {
				//Building links and append the links to message
				if(pcActiveWorkspaceHosting != NULL && notification->links_id.size() > 0) {
					string linkActiveWorkspace = "<br/>";
					linkActiveWorkspace.append(pcActiveWorkspaceName);
					//Add more links to Email
					
					for(int i=0; i < notification->links_id.size(); i++) {
						linkActiveWorkspace.append("<a href=\"");
						linkActiveWorkspace.append(pcActiveWorkspaceHosting);
						linkActiveWorkspace.append("#com.siemens.splm.clientfx.tcui.xrt.showObject;uid=");
						linkActiveWorkspace.append(notification->links_id.at(i));
						linkActiveWorkspace.append("\">");
						linkActiveWorkspace.append(notification->links_name.at(i));
						linkActiveWorkspace.append("</a>");
						if ((i+1) < notification->links_id.size()) {
							linkActiveWorkspace.append(", ");
						}
					}
					notification->comment.append(linkActiveWorkspace);
				}
			} catch (...) {
				DNVGL_TRACE_DGB( ("The links could not be created") );
			}

			//MEM_free(pcActiveWorkspaceHosting);
			//MEM_free(pcActiveWorkspaceName);
		}
		
		//Create SOAP body and fill the needed information
		msg__Message msg = msg__Message();
		msg.msg__Content = &notification->comment;
		msg.channel__Channel_ = &channel;
		msg.msg__Receivers = &receivers;


		mydnvgl__SendNotification request = mydnvgl__SendNotification();
		request.mydnvgl__In = &msg;
		request.mydnvgl__Service =&notification->service;

		mydnvgl__SendNotificationResponse response = mydnvgl__SendNotificationResponse();
		MyDnvglServiceImplPortBindingProxy mydnvglService = MyDnvglServiceImplPortBindingProxy(pcEndpoint);
	
		DNVGL_TRACE_DGB( ("Before sending notification.") );
		if (mydnvglService.SendNotification(&request, response) == SOAP_OK){
			DNVGL_TRACE_DGB( ("Notification is sended.") );//YES dekhte hai
		} else {
			DNVGL_TRACE_DGB( ("Error appears during sending a notification: %s", mydnvglService.soap_fault_string()) ); 
			//iStatus = ERROR_919150;
		}
		mydnvglService.destroy();
		MEM_free(pcEndpoint);	
	}
	catch(...)
	{

	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}
