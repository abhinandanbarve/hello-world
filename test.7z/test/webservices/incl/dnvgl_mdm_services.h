/**
* \file dnvgl_mdm_services.h
* \ingroup libAP4_dnvgl_webservices
* \verbatim
  \par Description:
    Header file for MDM customer webservices.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 03-August-2016  Vinay Kudari      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_MDM_SERVICES_H
# define DNVGL_MDM_SERVICES_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_utils.h"

#include "stdio.h"

#ifndef _LOAD_FROM_EXTERNAL
#include "soapH.h"
#endif



#ifdef __cplusplus
extern "C" {
#endif
	
	DNVGLCOMEXP int dnvgl_search_mdm_customers( const std::map< std::string, std::string >& input, std::vector< std::map<std::string,std::string> >& output );
	DNVGLCOMEXP int dnvgl_get_customer_attributes( _ns1__WS_USCORECustomerSearchResponse* response, std::vector< std::map<std::string,std::string> >* output );

	DNVGLCOMEXP int dnvgl_retrieve_mdm_customer(std::string customerMdmID, tag_t* customerTag);
	DNVGLCOMEXP int dnvgl_create_customer(_ns8__APSCustomerRetrieveResponse_Customer customer, tag_t* tNewCustomerTag);
	DNVGLCOMEXP int dnvgl_create_address( _ns8__APSCustomerRetrieveResponse_Customer_ListOfAddress_Addresses* addressStruct, tag_t* addressTag);

	DNVGLCOMEXP int dnvgl_attach_default_address(tag_t& customerTag, std::vector<tag_t>& allAddress);

	DNVGLCOMEXP date_t dnvgl_get_date_from_string(const char* inputDateString);

	// functions for callback service
	DNVGLCOMEXP int dnvgl_update_mdm_customer( _ns8__APSCustomerRetrieveResponse_Customer retrievedCustomer, char* tcCustomerUID);
	//function to check for the unique address aginst dnvID
	DNVGLCOMEXP int dnvgl_check_unique_address(std::map <std::string,_ns2__customerSearchResponse_customer>& mapCustomer, _ns2__customerSearchResponse_customer& currCustomer);
	
#ifdef __cplusplus
}
#endif

#endif //DNVGL_MDM_SERVICES_H