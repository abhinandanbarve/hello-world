/**
* \file dnvgl_no_services.h
* \ingroup libAP4_dnvgl_webservices
* \verbatim
  \par Description:
    Header file for APS My DNV GL Connector webservices.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Simon Koennecke
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 13-12-2016  Simon Koennecke      Initial Creation
*--------------------------------------------------------------------------------
*/
#pragma once

# ifndef DNVGL_NOTIFICATION_SERVICES_H
# define DNVGL_NOTIFICATION_SERVICES_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"

#ifndef _LOAD_FROM_EXTERNAL
#include "../notify/mydnvgl.nsmap"
#include "../notify/mydnvglMyDnvglServiceImplPortBindingProxy.h"
#endif

#include "stdio.h"

#include <base_utils\ScopedSmPtr.hxx>
#include <base_utils\IFail.hxx>
#include <base_utils\TcResultStatus.hxx>


#ifdef __cplusplus
extern "C" {
#endif
	/** Data struct to send a email via My DNV Portal */
	struct dnvgl_notification {
		std::string channel_id; /**< Channel id, e.g. b736438c-50e2-4f2b-b1b8-fb935bebb134. This id is defined on My DNV GL Admin Portal. */
		std::string channel_name; /**< Channel name, is custom table not related to My DNV GL Portal to enable simple mapping from name to id. */
		std::vector<std::string> recipients; /**< vector of email addresses */
		std::string subject; /**< subject will be placed into body of message */
		std::string service; /**< service may be dafult,customer,surveyor */
		std::string comment; /**< body of the message. The name is similar to EPM_notify action handler */
		std::string url; /**< This is a enum class enum_url_type { none, activeworkspace, dhtml, rich };  see TC Workflow Doc for more information */
		std::string attachment; /**< This is currently not supported: enum class enum_attachment_type { target, process, process };   */
		std::vector<std::string> links_id; /**< UID Tag of an object, the index is related to links_name */
		std::vector<std::string> links_name; /**< Object Name of an object, the index is related to links_id */
	};

	DNVGLCOMEXP int dnvgl_mydnvgl_notification ( dnvgl_notification * tNotification );
	
#ifdef __cplusplus
}
#endif

	


#endif //DNVGL_NOTIFICATION_SERVICES_H