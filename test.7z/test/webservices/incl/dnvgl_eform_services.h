/**
* \file dnvgl_utils.h
* \ingroup libAP4_dnvgl_common
* \verbatim
  \par Description:
    Header file for utility functions.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 30-May-2016   Vinay Kudari       Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_EFORM_SERVICES_H
# define DNVGL_EFORM_SERVICES_H

#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_utils.h"

#include <curl/curl.h>

#ifdef __cplusplus
extern "C" {
#endif
	// Read eform mapping preference
	DNVGLCOMEXP int dnvgl_get_eform_dataset_info( char* cpTemplateType, char * cpVersion, std::string& cpEformID, std::string& cpEformDocType, std::string& cpDatasetType, tag_t* tDatasetTag );

	// read the mapping dataset and return each mapping line as vector of string 
	DNVGLCOMEXP int dnvgl_read_mapping_dataset( tag_t tDatasetTag, std::string strTempFolderPath, std::vector<std::string>  &vData );
	
	// create request XML by evaluationg each mappig line
	DNVGLCOMEXP int dnvgl_get_request_xml( tag_t tDocrev, std::vector<std::string> vData, tinyxml2::XMLDocument & requtestXML );
	
	// create attribute map of bookmark and value pair
	DNVGLCOMEXP int dnvgl_get_attribute_map( tag_t tTargetObjectTag, std::vector<std::string> vMappingData, std::map<std::string,std::string> &attributeMap );
	
	// call eform webserive with the request xml passed as XMLDocment.
	DNVGLCOMEXP int dnvgl_eform_service_call( std::string eformDocID, std::string eformDocType, std::string cpFilePath, tinyxml2::XMLDocument & requtestXML );

	// main API to call eform service on document revision
	DNVGLCOMEXP int dnvgl_eform_service( tag_t tDocrev, tag_t *datasetTag);	

	// Helper functions, no need to export
	size_t write_data_callback(void *ptr, size_t size, size_t nmemb, FILE *stream);
	int getPrimaryObject(tag_t tCurrentTag, std::string relationName, std::string expectedBOType, tag_t& tPrimaryObjTag);
	int resolveReferenceExpression(tag_t& tCurrentTag, std::string eachExpression);
	int resolveAttributeExpression(tag_t& tCurrentTag, std::string& eachExpression, std::string& currentValue);
	
#ifdef __cplusplus
}
#endif

#endif //DNVGL_EFORM_SERVICES_H