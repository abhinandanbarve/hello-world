/**
* \file dnvgl_mdm_services.h
* \ingroup libAP4_dnvgl_webservices
* \verbatim
  \par Description:
    Header file for MDM customer webservices.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 03-August-2016  Vinay Kudari      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AFFINITAS_SERVICES_H
# define DNVGL_AFFINITAS_SERVICES_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"

#include "stdio.h"

#ifndef _LOAD_FROM_EXTERNAL
#include "soapH.h"
#endif

#include <base_utils\ScopedSmPtr.hxx>
#include <base_utils\IFail.hxx>
#include <base_utils\TcResultStatus.hxx>

#ifdef __cplusplus
extern "C" {
#endif
	
	DNVGLCOMEXP int dnvgl_create_or_update_opportunity( tag_t* tOpportunity );

#ifndef _LOAD_FROM_EXTERNAL
	int dnvgl_get_opportunity_attributes( tag_t *tOpportunity, _ns10__ArrayOfOpportunityUpsertOpportunity_opportunity &opportunity );
#endif
	
#ifdef __cplusplus
}
#endif

	


#endif //DNVGL_AFFINITAS_SERVICES_H