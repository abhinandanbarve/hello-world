/**
* \file dnvgl_project_handling.cxx
* \ingroup libAP4_dnvgl_common
* \verbatim
\par Description:
This File  contains the Functions to copy AP4_Project, their corresponding folder structures recursively and setting project back pointers.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Chetan Kekade
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 16-May-2016   Chetan Kekade	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_project_handling.h"

/**
* \file dnvgl_project_handling.cxx
* \par  Description :
Copy the Project Folder Structure present with the relation Project structure Relation from source Project Folder to Destination Project Folder.
* \verbatim
*   Copy the Project Structure from source Project to Destination Project.
\endverbatim     
* \param[in]   projectItemTag    Tag of the Destination Project Item
* \param[in]   projectItemTag    Tag of the Source Project Item.
*
* \par Algorithm:
* \verbatim  
a. Copy the Project Structure.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_copy_project ( tag_t *tTargetProjectRevTag, tag_t *tSourceProjectRevTag, logical lIsSaveAsOperation )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Copy the project attributes from another project
		DNVGL_TRACE_CALL( iStatus = copy_project_attributes( *tTargetProjectRevTag, *tSourceProjectRevTag, lIsSaveAsOperation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Copy the folder structure with Project folder Relation
		DNVGL_TRACE_CALL( iStatus = copy_folder_structure( *tTargetProjectRevTag , *tSourceProjectRevTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_project_handling.cxx
* \par  Description :
* \verbatim
*   Copy Project folder from Destination Project Folder to Source Project Folder
\endverbatim     
* \param[in]   projectItemTag    Tag of the Destination Project Folder Item
* \param[out]  projectItemTag    Tag of Source Project Folder
*
* \par Algorithm:
* \verbatim  
a. Copy the Project Folder Structure 
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int copy_project_folder( tag_t t_dest , tag_t t_source ,tag_t* t_new)
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		char *	str_objectName		= NULL;
		tag_t	t_relation			= NULLTAG;
		tag_t	t_relation_type		= NULLTAG;

		DNVGL_TRACE_ENTER();
		//Get the name of the Source Project Folder
		DNVGL_TRACE_CALL( iStatus = WSOM_ask_name2( t_source,&str_objectName ) );

		//Create new  Project folder from existing
		DNVGL_TRACE_CALL( iStatus = WSOM_copy( t_source,str_objectName,t_new ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( *t_new ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Create Relation 
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type(AP4_PROJECT_STRUCTURE_RELATION,&t_relation_type ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = GRM_create_relation( t_dest,*t_new,t_relation_type,NULLTAG,&t_relation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Save relation		
		iStatus = GRM_save_relation( t_relation );
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );	
	return iStatus;
}


/**
* \file dnvgl_project_handling.cxx
* \par  Description :
* \verbatim
*   Copy the Excel Dataset
\endverbatim     
* \param[in]   projectItemTag    Tag of the Destination Project Folder Item
* \param[in]  projectItemTag    Tag of Source Project Folder
*
* \par Algorithm:
* \verbatim  
a. Copy the Project Folder Structure 
* \endverbatim
* \par Returns :
* int : 0/error code
*/
tag_t copy_folder_item( tag_t source,tag_t dest, tag_t* t_new )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		char *	str_RelObjectName	= "";	
		int		iObjectCount		= 0;

		tag_t	t_newRev			= NULLTAG;
		tag_t	t_relation_type		= NULLTAG;
		tag_t	tRelatedRev			= NULLTAG;
		tag_t	tRelation			= NULLTAG;


		DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( dest,&tRelatedRev ) );
		DNVGL_LOG_ERROR_AND_RETURN;

		//copy item from existing
		DNVGL_TRACE_CALL( iStatus = ITEM_copy_item( tRelatedRev,NULL,NULL,t_new,&t_newRev ) );
		DNVGL_LOG_ERROR_AND_RETURN;
		DNVGL_TRACE_CALL( iStatus = AOM_save( *t_new ) );
		DNVGL_LOG_ERROR_AND_RETURN;

		//Find and create the Project Structure relation
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_STRUCTURE_RELATION,&t_relation_type ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus=GRM_create_relation( source,*t_new,t_relation_type,NULLTAG,&tRelation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Save the relation.
		GRM_save_relation( tRelation );
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_project_handling.cxx
* \par  Description :
* \verbatim
*   Copy the Project Attributes from source Project to Destination Project.
\endverbatim     
* \param[in]   projectItemTag    Tag of the Destination Project Item
* \param[in]   projectItemTag    Tag of the Source Project Item.
*
* \par Algorithm:
* \verbatim  
a. Copy the Project Attributes.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int copy_project_attributes( tag_t tProjectRevTag , tag_t tProjectRevTemplateTag, logical lIsSaveAsOperation )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{

		// Copy project type from template.
		char* strProjectType = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRevTemplateTag, AP4_PROJECT_TYPE, &strProjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		if( !lIsSaveAsOperation )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tProjectRevTag, 1 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tProjectRevTag, AP4_PROJECT_TYPE, strProjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( tProjectRevTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( !lIsSaveAsOperation )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tProjectRevTag, 0 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_project_handling.cxx
* \par  Description :
Copy the Project Folder Structure present with the relation Project structure Relation from source Project Folder to Destination Project Folder.
* \verbatim
*   Copy the Project Structure from source Project to Destination Project.
\endverbatim     
* \param[in]   projectItemTag    Tag of the Destination Project Item
* \param[in]   projectItemTag    Tag of the Source Project Item.
*
* \par Algorithm:
* \verbatim  
a. Copy the Project Structure.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int copy_folder_structure( tag_t t_dest , tag_t t_source )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		int				iObjectCount	= 0;
		int				index			= 0;
		char *			strObjType		= NULL;
		char *			str_objectType	= NULL;
		GRM_relation_t*	t_relatedTags	= {NULLTAG};
		tag_t			t_sourceRev		= NULLTAG;
		tag_t			t_structRel		= NULLTAG;

		DNVGL_TRACE_ENTER();
		DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2( t_source,&strObjType ) );

		if( strcmp( strObjType,AP4_PROJECT ) ==0 )
		{
			DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( t_source,&t_sourceRev ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			t_source = t_sourceRev;
		}

		//Find the Secondary Related object with specific relation
		DNVGL_TRACE_CALL( GRM_find_relation_type( AP4_PROJECT_STRUCTURE_RELATION,&t_structRel ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( GRM_list_secondary_objects( t_source,t_structRel,&iObjectCount,&t_relatedTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for ( index = 0; index < iObjectCount; index++ )
		{
			tag_t t_newProjFolder = NULLTAG;

			//To copy the Project Folder
			copy_project_folder( t_dest,t_relatedTags[index].secondary ,&t_newProjFolder);

			//Set the back pointer for the copied folder.
			set_project_back_pointer( t_dest,t_newProjFolder );

			//Copy the folder structure recursively.
			copy_recursive_folder_structure( t_newProjFolder,t_relatedTags[index].secondary,t_dest );
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_project_handling.cxx
* \par  Description :
Copy the Project Folder Structure present with the relation Project structure Relation from source Project Folder to Destibanation Project Folder  
* \verbatim
*   Copy the Project  structure present from source Project to Destination Project .
\endverbatim     
* \param[in]   projectItemTag    Tag of the Destination Project Item
* \param[in]   projectItemTag    Revision Tag of the Source Project Item.
* \param[in]   rootTag			 Tag of the root Project Folder.
* \par Algorithm:
* \verbatim  
a. Copy the Project structure.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int copy_recursive_folder_structure( tag_t t_dest , tag_t t_source , tag_t t_root)
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t			t_sourceRev		= NULLTAG;
		int				iObjectCount	= 0;
		int				index			= 0;
		GRM_relation_t*	t_relatedTags	= {NULLTAG};
		char *			strObjType		= "";
		char *			strType			= NULL;
		DNVGL_TRACE_ENTER();

		DNVGL_TRACE_CALL(  iStatus = WSOM_ask_object_type2( t_source,&strObjType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( strcmp( strObjType,AP4_PROJECT )==0 )
		{
			//Get the revision tag if the item is Ap4_Project
			DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( t_source,&t_sourceRev ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			t_source = t_sourceRev;
		}

		//Finds the secondary related objects
		tag_t t_structRel = NULLTAG;
		DNVGL_TRACE_CALL( GRM_find_relation_type( AP4_PROJECT_STRUCTURE_RELATION,&t_structRel ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( GRM_list_secondary_objects( t_source,t_structRel,&iObjectCount,&t_relatedTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for (  index = 0; index < iObjectCount; index++ )
		{
			//Get the type of related object tag.
			DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2( t_relatedTags[index].secondary,&strType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t t_newProjFolder  = NULLTAG;
			copy_project_folder( t_dest,t_relatedTags[index].secondary,&t_newProjFolder );
			//set the project back pointer
			set_project_back_pointer( t_root,t_newProjFolder );

			copy_recursive_folder_structure( t_newProjFolder,t_relatedTags[index].secondary,t_root );
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_project_handling.cxx
* \par  Description :
Set the Back pointer to Project.
* \verbatim
*   Set the Back pointer to Project
\endverbatim     
* \param[in]   projectRevTag    Tag of the Root Project Revision
* \param[in]   projectItemTag    Tag of the Source Project Item.
*
* \par Algorithm:
* \verbatim  
a. Set the Back pointer to Project.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int set_project_back_pointer( tag_t primaryObjTag , tag_t secondaryObjTag )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t	t_backPoint = NULLTAG;
		tag_t	t_projRev	= NULLTAG;
		char*	str_objectType = NULL;

		DNVGL_TRACE_CALL(  iStatus = AOM_refresh( secondaryObjTag,true ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2( primaryObjTag, &str_objectType ) );

		tag_t tClassID = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( AP4_PROJECT_FOLDER, &tClassID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tPrimaryObjClassID = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = POM_class_of_instance( primaryObjTag, &tPrimaryObjClassID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		logical answer;
		DNVGL_TRACE_CALL( iStatus = POM_is_descendant( tClassID, tPrimaryObjClassID, &answer ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( strcmp( str_objectType, AP4_PROJECT_REVISION ) == 0 )
		{
			// Set the Project Back Pointer
			DNVGL_TRACE_CALL(  iStatus = AOM_assign_tag( secondaryObjTag, AP4_PROJECT_BACKPOINTER, primaryObjTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else if( answer )
		{
			DNVGL_TRACE_CALL(  iStatus = AOM_ask_value_tag( primaryObjTag, AP4_PROJECT_BACKPOINTER, &t_projRev ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( t_projRev != NULLTAG )
			{
				// Set the Project Back Pointer
				DNVGL_TRACE_CALL(  iStatus = AOM_assign_tag( secondaryObjTag, AP4_PROJECT_BACKPOINTER, t_projRev ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			// Set the Parent Folder
			DNVGL_TRACE_CALL(  iStatus = AOM_assign_tag( secondaryObjTag, AP4_PARENT_FOLDER, primaryObjTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}		

		DNVGL_TRACE_CALL(  iStatus = AOM_save( secondaryObjTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(  iStatus = AOM_refresh( secondaryObjTag,false ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_project_handling.cxx
* \par  Description :
Get all the project participant info in single call.
* \par Returns :
* int : 0/error code
*/

int get_all_participants(tag_t tProjectRev, std::vector<DNVGL_ProjectRevisionParticipant_t>& participantInfos)
{
	/*
	select ptc.puid, pc.pname, pm.puid, pm.ruseru, usr.puser_id, pm.rgroupu, grp.pname, gm.rroleu, rol.prole_name
	from tc.dbo.PIMANRELATION rel, tc.dbo.PIMANTYPE tp, tc.dbo.PPARTICIPANT ptc, tc.dbo.PPOM_MEMBER pm, tc.dbo.PGROUPMEMBER gm, tc.dbo.PPOM_CLASS pc, tc.dbo.PPOM_OBJECT po,
	     tc.dbo.PPOM_USER usr, tc.dbo.PPOM_GROUP grp, tc.dbo.PROLE rol
	where tp.ptype_name = 'HasParticipant'
	and rel.rprimary_objectu = 'wbCAQUCN6qEfMA'
	and tp.puid = rel.rrelation_typeu
	and ptc.puid = rel.rsecondary_objectu
	and pm.puid = ptc.rassigneeu
	and po.puid = rel.rsecondary_objectu
	and pc.pcpid = po.ppid
	and usr.puid = pm.ruseru
	and grp.puid = pm.rgroupu
	and gm.puid = pm.puid
	and rol.puid = gm.rroleu 	
	*/

	int iStatus = ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		int				iTotalRows			= 0;
		int				iTotalCols			= 0;
		int				iRows				= 0;
		int				iCols				= 0;
		tag_t			tItemObj			= NULLTAG;

		const char*		pcEnquiryID			= "dnvgl-get-project-participant";
		const char *	pcSelAttrsParticipant[] = {"puid"};
		const char *	pcSelAttrsGroupMember[] = {"puid", "user", "group", "role"};
		const char *	pcSelAttrsPOMClass[] = {"name"};
		const char *	pcSelAttrsUser[] = {"user_id"};
		const char *	pcSelAttrsGroup[] = {"name"};
		const char *	pcSelAttrsRole[] = {"role_name"};

		const char *	pcRelationName[] = {"HasParticipant"};

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create( pcEnquiryID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//select ptc.puid, 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, "Participant", 1, pcSelAttrsParticipant ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		//select pm.puid, pm.ruseru, pm.rgroupu, pm.rgroupu 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, "GroupMember", 4, pcSelAttrsGroupMember ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//select pc.pname 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, "POM_class", 1, pcSelAttrsPOMClass ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//select user.pname 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, "POM_user", 1, pcSelAttrsUser ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//select group.pname 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, "POM_group", 1, pcSelAttrsGroup ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//select role.pname 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, "Role", 1, pcSelAttrsRole ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_tag_value ( pcEnquiryID, "Query", 1, &tProjectRev, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// rel.primary_object = 'ssuuxxiiidduu' (some puid)
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( pcEnquiryID, "Expr1", "ImanRelation", "primary_object", POM_enquiry_equal, "Query"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (pcEnquiryID, "Query1", 1, pcRelationName, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// ty.type_name = 'HasParticipant'
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( pcEnquiryID, "Expr2", "ImanType", "type_name", POM_enquiry_in, "Query1"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// ty.puid = rel.relation_type
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr3", "ImanType", "puid", POM_enquiry_equal, "ImanRelation", "relation_type"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// ptc.puid = rel.secondary_object
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr4", "Participant", "puid", POM_enquiry_equal, "ImanRelation", "secondary_object"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//  pm.puid = ptc.rassigneeu
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr5", "GroupMember", "puid", POM_enquiry_equal, "Participant", "assignee"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//  pc.pcpid = rel.rsecondary_objectc
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr6", "POM_object", "puid", POM_enquiry_equal, "ImanRelation", "secondary_object"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//  pc.pcpid = rel.rsecondary_objectc
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr7", "POM_class", "cpid", POM_enquiry_equal, "POM_object", "pid"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// join user table
		//  pc.pcpid = rel.rsecondary_objectc
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr8", "POM_user", "puid", POM_enquiry_equal, "GroupMember", "user"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//  pc.pcpid = rel.rsecondary_objectc
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr9", "POM_group", "puid", POM_enquiry_equal, "GroupMember", "group"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//  pc.pcpid = rel.rsecondary_objectc
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr10", "Role", "puid", POM_enquiry_equal, "GroupMember", "role"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;


		// join all expressions
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.1", "Expr1", POM_enquiry_and, "Expr2"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.2", "Expr1.1", POM_enquiry_and, "Expr3"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.3", "Expr1.2", POM_enquiry_and, "Expr4"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.4", "Expr1.3", POM_enquiry_and, "Expr5"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.5", "Expr1.4", POM_enquiry_and, "Expr6"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.6", "Expr1.5", POM_enquiry_and, "Expr7"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.7", "Expr1.6", POM_enquiry_and, "Expr8"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.8", "Expr1.7", POM_enquiry_and, "Expr9"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.9", "Expr1.8", POM_enquiry_and, "Expr10"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr ( pcEnquiryID,"Expr1.9"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;


		void*** pvQueryResults = NULL;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute( pcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;		


		for(int iCnt = 0; iCnt < iTotalRows; iCnt++)
		{
			DNVGL_ProjectRevisionParticipant_t info;

			info.thisParticipant = *( tag_t* )( pvQueryResults[iCnt][0] );
			info.groupMember = *( tag_t* )( pvQueryResults[iCnt][1] );
			info.user = *( tag_t* )( pvQueryResults[iCnt][2] );
			info.group = *( tag_t* )( pvQueryResults[iCnt][3] );
			info.role = *( tag_t* )( pvQueryResults[iCnt][4] );

			char* pctName = ( char* )( pvQueryResults[iCnt][5] );
			info.participantType.assign( pctName );

			char* userID = ( char* )( pvQueryResults[iCnt][6] );
			info.userID.assign( userID );

			char* grpName = ( char* )( pvQueryResults[iCnt][7] );
			info.groupName.assign( grpName );

			char* roleName = ( char* )( pvQueryResults[iCnt][8] );
			info.roleName.assign( roleName );

			// push into vector
			participantInfos.push_back(info);
		}

		
		if(pvQueryResults != NULL)
		{
			MEM_free(pvQueryResults); // free the memory allocated by POM_Enq
		}
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete (pcEnquiryID));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;

}
