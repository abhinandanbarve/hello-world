/**
* \file dnvgl_tcproject_handling.cxx
* \ingroup libAP4_dnvgl_common
* \verbatim
\par Description:
This File  contains the Functions to Create tc project and add/remove user to the project.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 16-May-2016   Nikhilesh Khatra      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_tcproject_handling.h"

/**
* \file dnvgl_tcproject_handling.cxx
* \par  Description :
* \verbatim
*   Create Project
\endverbatim     
* \param[in]   projectItemTag    Tag of the Project Item
* \param[out]  projectTag        Tag of created project
*
* \par Algorithm:
* \verbatim  
a. Login to teamcenter
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_create_tcproject( tag_t projectItemTag, tag_t *projectTag )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tempProjectTag	=	NULLTAG;
		char* projId			=	NULL;
		char* itemID = NULL;

		DNVGL_TRACE_CALL( iStatus = ITEM_ask_id2( projectItemTag, &itemID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = PROJ_find( itemID, &tempProjectTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tempProjectTag == NULLTAG )
		{		
			DNVGL_TRACE_CALL( iStatus = PROJ_create_project( itemID, itemID, NULL, projectTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( *projectTag, 1 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( *projectTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( *projectTag, 0 ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_tcproject_handling.cxx
* \par  Description :
* \verbatim
*   Add the user to the project
\endverbatim   
* \param[in]  projectTag   Newly created or existing projectTag         
* \param[in]  userTag      UserTag of user which needs to be added in project  
* \param[in]  isAuthor     boolean for checking author rights needs to be given to user or not 
*
* \par Algorithm:
* \verbatim  
a.Add the user to the project
b.Assign privileges to the user
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_add_user_to_tcproject( tag_t projectTag, tag_t userTag, bool isPrivileged )
{   
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_TC_OBJECT( projectTag );
		DNVGL_TRACE_TC_OBJECT( userTag );

		DNVGL_TRACE_CALL( iStatus = AOM_refresh ( projectTag, 1 ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = PROJ_add_members ( projectTag, 1, &userTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( isPrivileged )
		{
			DNVGL_TRACE_CALL( iStatus = PROJ_add_author_members( projectTag, 1, &userTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}		

		DNVGL_TRACE_CALL( iStatus = AOM_save( projectTag ) );
		DNVGL_TRACE_CALL( iStatus = AOM_refresh( projectTag, 0 ) );

	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_tcproject_handling.cxx
* \par  Description :
* \verbatim
*   Remove user from the project
\endverbatim   
* \param[in]  projectTag   Newly created or existing projectTag         
* \param[in]  userTag      UserTag of user which needs to be removed from project  
*
* \par Algorithm:
* \verbatim  
a.Remove user from the project
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_remove_user_from_tcproject( tag_t projectTag, tag_t userTag )
{   
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_TC_OBJECT( projectTag );
		DNVGL_TRACE_TC_OBJECT( userTag );

		DNVGL_TRACE_CALL( iStatus = PROJ_remove_members( projectTag, 1, &userTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( projectTag ) );
		DNVGL_TRACE_CALL( iStatus = AOM_refresh( projectTag, 0 ) );

	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_get_tcproject( tag_t projectItemTag, tag_t* tcProjectTag )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{		
		char* projId			=	NULL;
		char* itemID = NULL;

		DNVGL_TRACE_CALL( iStatus = ITEM_ask_id2( projectItemTag, &itemID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = PROJ_find( itemID, tcProjectTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}