/**
* \file dnvgl_utils.cxx
* \ingroup libAP4_dnvgl_common
* \verbatim
\par Description:
This File  contains the utiltiy functions.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 30-May-2016   Vinay Kudari        Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_utils.h"
#include <openxml/OfficeInterop.h>

using namespace std;
using namespace tinyxml2;
/**
* \file dnvgl_utils.cxx
* \par  Description :
* \verbatim
*   Create Project
\endverbatim     
* \param[in]   projectItemTag    Tag of the Project Item
* \param[out]  projectTag        Tag of created project
*
* \par Algorithm:
* \verbatim  
a. Login to teamcenter
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_assign_participants(  tag_t* projectRevTag, std::vector<tag_t> *tGroupMembers )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		logical lIsProjectManager	= false;
		tag_t tProjMgrGroupTag		= NULLTAG;

		logical lIsBidManager		= false;
		tag_t tBidMgrGroupTag		= NULLTAG;

		char* cCheckForRole			= NULL;

		tag_t tGroupMemberTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = SA_ask_current_groupmember( &tGroupMemberTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tGroupTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus =  SA_ask_groupmember_group( tGroupMemberTag , &tGroupTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tParentTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus =  SA_ask_group_parent( tGroupTag , &tParentTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* cGroupName	= NULL;
		if( tParentTag != NULLTAG )
		{
			DNVGL_TRACE_CALL( iStatus =  SA_ask_group_name2( tParentTag, &cGroupName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			DNVGL_TRACE_CALL( iStatus =  SA_ask_group_name2( tGroupTag, &cGroupName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		tag_t tRoleTag		= NULLTAG;		
		DNVGL_TRACE_CALL( iStatus =  SA_ask_groupmember_role( tGroupMemberTag , &tRoleTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* cRoleName	= NULL;
		DNVGL_TRACE_CALL( iStatus =  SA_ask_role_name2( tRoleTag, &cRoleName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tc_strcmp ( cRoleName, PROJECT_MANAGER ) == 0 )
		{
			lIsProjectManager = true;
			tProjMgrGroupTag = tGroupMemberTag;
			cCheckForRole = new char[ tc_strlen( BID_MANAGER ) ];
			tc_strcpy( cCheckForRole, BID_MANAGER );
		}
		else if( tc_strcmp ( cRoleName, BID_MANAGER ) == 0 )
		{
			lIsBidManager = true;
			tBidMgrGroupTag = tGroupMemberTag;
			cCheckForRole = new char[ tc_strlen( PROJECT_MANAGER ) ];
			tc_strcpy( cCheckForRole, PROJECT_MANAGER );
		}

		tag_t   tUser				= NULLTAG;
		DNVGL_TRACE_CALL( iStatus =  SA_ask_groupmember_user( tGroupMemberTag , &tUser ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		logical lIncludeInactive		= false;
		int		iGrpCount				= 0;
		tag_t*	tGrpMemberTags			= NULLTAG;
		DNVGL_TRACE_CALL( iStatus =  SA_find_all_groupmember_by_user( tUser , lIncludeInactive , &iGrpCount , &tGrpMemberTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for (int i = 0; i < iGrpCount; i++)
		{
			tag_t tGrpTag = NULLTAG;
			DNVGL_TRACE_CALL( iStatus =  SA_ask_groupmember_group( tGrpMemberTags[i] , &tGrpTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tParTag = NULLTAG;
			DNVGL_TRACE_CALL( iStatus =  SA_ask_group_parent( tGrpTag , &tParTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char* cGrpName = NULL;
			if( tParTag != NULLTAG )
			{
				DNVGL_TRACE_CALL( iStatus =  SA_ask_group_name2( tParTag, &cGrpName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
			else
			{
				DNVGL_TRACE_CALL( iStatus =  SA_ask_group_name2( tGrpTag, &cGrpName ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			tag_t tRolTag = NULLTAG;
			DNVGL_TRACE_CALL( iStatus =  SA_ask_groupmember_role( tGrpMemberTags[i] , &tRolTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			char* cRolName = NULL;
			DNVGL_TRACE_CALL( iStatus =  SA_ask_role_name2( tRolTag, &cRolName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tc_strcmp ( cGrpName, cGroupName ) == 0 && tc_strcmp ( cRolName, cCheckForRole ) == 0 )
			{	
				if( lIsProjectManager )
				{
					lIsBidManager = true;
					tBidMgrGroupTag = tGrpMemberTags[i];					
					tGroupMembers->push_back(tBidMgrGroupTag) ;
				}
				else if( lIsBidManager )
				{
					lIsProjectManager = true;
					tProjMgrGroupTag = tGrpMemberTags[i];
					tGroupMembers->push_back(tProjMgrGroupTag) ;
					
				}
				break;
			}
		}

		//Get the Employee ID of the line manager of current logged in user
		char* cpEmoployeeId = NULL;
		DNVGL_TRACE_CALL ( iStatus = dnvgl_get_employee_number_of_line_manager( tUser, &cpEmoployeeId ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( lIsProjectManager )
		{			
			DNVGL_TRACE_CALL( iStatus = dnvgl_add_participant( *projectRevTag, tProjMgrGroupTag, AP4_PROJECTMANAGER ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpEmoployeeId != NULL )
			{
				tag_t tLineMgrProjectMgr = NULLTAG;
				DNVGL_TRACE_CALL ( iStatus = dnvgl_get_group_member_from_employee_id( cGroupName,PROJECT_MANAGER, cpEmoployeeId, &tLineMgrProjectMgr) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				// Assign group member as a Project Sponsor to the Project revision if the Line Manager is Project Manager
				if( tLineMgrProjectMgr != NULLTAG )
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_add_participant( *projectRevTag, tLineMgrProjectMgr, AP4_PROJECT_SPONSOR ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;	
					tGroupMembers->push_back(tLineMgrProjectMgr);
				}
			}			
		}

		if( lIsBidManager )
		{
			DNVGL_TRACE_CALL( iStatus = dnvgl_add_participant( *projectRevTag, tBidMgrGroupTag, AP4_BIDMANAGER) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpEmoployeeId != NULL )
			{
				tag_t tLineMgrBidMgr = NULLTAG;
				DNVGL_TRACE_CALL ( iStatus = dnvgl_get_group_member_from_employee_id( cGroupName, BID_MANAGER, cpEmoployeeId, &tLineMgrBidMgr ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				// Assign group member as a Bid Responsible to the Project revision if the Line Manager is Project Manager
				if( tLineMgrBidMgr != NULLTAG)
				{
					DNVGL_TRACE_CALL( iStatus = dnvgl_add_participant( *projectRevTag, tLineMgrBidMgr, AP4_BID_RESPONSIBLE) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					tGroupMembers->push_back(tLineMgrBidMgr);
				}
			}
		}
	
		//Add the current logged in group member as sales team member participant.
		DNVGL_TRACE_CALL( iStatus = dnvgl_add_participant( *projectRevTag, tGroupMemberTag, AP4_SALESTEAMMEMBER ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;		
		tGroupMembers->push_back(tGroupMemberTag);
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par Description:
* \verbatim
	This function adds participant to project revision
* \endverbatim

* \par Owner:
*  Chetan kekade 
* \param[in]    tag_t		tProjectRev
* \param[in]    tag_t		tGroupMember
* \param[out]   char*		cpParticipantType
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 16-Jan-2017   Chetan kekade		Initial Creation
*---------------------------------------------------------------------------------
*/
int dnvgl_add_participant( tag_t tProjectRev, tag_t tGroupMember, char* cpParticipantType )
{
	int iStatus = ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tParticipantType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = EPM_get_participanttype( cpParticipantType, &tParticipantType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tParticipant = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = EPM_create_participant( tGroupMember, tParticipantType, &tParticipant ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = ITEM_rev_add_participant( tProjectRev, tParticipant ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{
		
	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par Description:
* \verbatim
This function fetches Group Member tag of the Line Manager using POM Enquiry
* \endverbatim

* \par Owner:
*  Chetan kekade 
* \param[in]    char *		Group Name
* \param[in]    char *		Enployee Number
* \param[out]   tag_t*		Group Member tag of Line Manager
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 16-Jan-2017   Chetan kekade		Initial Creation
*---------------------------------------------------------------------------------
*/
int dnvgl_get_group_member_from_employee_id(char* cpGroupName,char* cpRoleName, char * cpEmoployeeId, tag_t * groupMemberTag)
{
	int iStatus = ITK_ok;
	const char*	pcEnquiryID			= "dnvgl-get-group-member-from-employee_number";
	void***		pvQueryResults		= NULL;

	DNVGL_TRACE_ENTER();
	try
	{
		int			i					= 0;
		int			iTotalRows			= 0;
		int			iTotalCols			= 0;
		int			iRows				= 0;
		int			iCols				= 0;
		tag_t		tItemObj			= NULLTAG;
		tag_t		itemTag				= NULLTAG;

		const char*	pcSelectAttrs[]		= {"puid"};

		int			Seq1				= 0;
		int			Seq2				= 0;
		
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create( pcEnquiryID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		/* create s  class Alias */
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create_class_alias ( pcEnquiryID, "POM_Group", 1, "t_01" ) ); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create_class_alias ( pcEnquiryID, "POM_Group", 1, "t_02" ) ); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// set distinct attribute
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_distinct ( pcEnquiryID, true ) ); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Add the Select parameters
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, "GroupMember",1,pcSelectAttrs));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
			
		/*Create the join expr PPOM_MEMBER.rgroupu = PPOM_GROUP.puid*/
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID,"auniqueExprId_1","POM_Member","group",POM_enquiry_equal,"t_01","puid" ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		/*Create the join expr  t_01.rparentu = t_02.puid*/
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID,"auniqueExprId_2","t_01","parent",POM_enquiry_equal,"t_02","puid" ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		/*Create a expression  t_02.pname = <Input  Group> .*/
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_expr ( pcEnquiryID,"auniqueExprId_3","t_02","name",POM_enquiry_equal,cpGroupName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		 
		/*Create the join expr PGROUPMEMBER.rroleu= PROLE.puid*/
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID,"auniqueExprId_4","GroupMember","role",POM_enquiry_equal,"Role","puid" ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		

		/*Create an expression PROLE.prole_name = <Input Role >*/
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_expr ( pcEnquiryID,"auniqueExprId_5","Role","role_name",POM_enquiry_equal,cpRoleName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		/*Create the join expr  PPOM_MEMBER.ruseru = PUSER.puid */
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID,"auniqueExprId_6","POM_Member","user",POM_enquiry_equal,"User","puid" ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		/*Create the join expr  PUSER.rpersonu = PPERSON.puid  */
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID,"auniqueExprId_7","User","person",POM_enquiry_equal,"person","puid") );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		/*Create a expression  PPERSON.pPA7  =   <Input Employee Id> .*/
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_expr ( pcEnquiryID,"auniqueExprId_8","Person","pa7",POM_enquiry_equal,cpEmoployeeId ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		/*Create the join expr  PPOM_MEMBER.puid = PGROUPMEMBER.puid  */
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID,"auniqueExprId_9","POM_Member","puid",POM_enquiry_equal,"GroupMember","puid" ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		/*Combine all expressions */
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.1", "auniqueExprId_1", POM_enquiry_and, "auniqueExprId_2"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.2", "Expr1.1", POM_enquiry_and, "auniqueExprId_3"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.3", "Expr1.2", POM_enquiry_and, "auniqueExprId_4"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.4", "Expr1.3", POM_enquiry_and, "auniqueExprId_5"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.5", "Expr1.4", POM_enquiry_and, "auniqueExprId_6"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.6", "Expr1.5", POM_enquiry_and, "auniqueExprId_7"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.7", "Expr1.6", POM_enquiry_and, "auniqueExprId_8"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.8", "Expr1.7", POM_enquiry_and, "auniqueExprId_9"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr ( pcEnquiryID,"Expr1.8" ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		//Execute the query
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute( pcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int iCnt=0; iCnt<iTotalRows; iCnt++ )
		{
			//Adding the Result tag to the vector for Runtime property
			tag_t tmpSecObj	= *( tag_t* )( pvQueryResults[iCnt][0] );
			*groupMemberTag = tmpSecObj;
		}

		iStatus = POM_enquiry_delete ( pcEnquiryID);
	}
	catch(...)
	{
		iStatus = POM_enquiry_delete ( pcEnquiryID);	
	}

	DNVGL_MEM_FREE( pvQueryResults );

	DNVGL_TRACE_LEAVE();

	return iStatus;
}
/**
* \file dnvgl_utils.cxx
* \par Description:
* \verbatim
This function fetches the line mamager person tag 
* \endverbatim

* \par Owner:
*  Chetan kekade 
* \param[in]    userTag		user Tag
* \param[out]   tag_t*		Line Manager Employee Number of input user tag
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 16-Jan-2017   Chetan kekade		Initial Creation
*---------------------------------------------------------------------------------
*/
int dnvgl_get_employee_id_of_line_manager( char* cpEmployeeId, tag_t orgUnitTag, char ** cpOutputManagerId )
{
	int iStatus = ITK_ok;
	char * cpManagerId = NULL;
	char * cpObjectType = NULL;
	char * cpParentManagerId = NULL;
	DNVGL_TRACE_ENTER();
	try
	{
		if( orgUnitTag != NULLTAG )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( orgUnitTag, AP4_MANAGER_ID, &cpManagerId ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			if(strcmp( cpEmployeeId, cpManagerId ) == 0)
			{
				int iCount = 0;
				tag_t childRelationTag = NULLTAG;
				tag_t* cpPrimaryTags = NULLTAG;
				tag_t primOrgUnitTag = NULLTAG;
				DNVGL_TRACE_CALL( GRM_find_relation_type( AP4_CHILD_ORG_UNIT , &childRelationTag ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = GRM_list_primary_objects_only( orgUnitTag,childRelationTag,&iCount,&cpPrimaryTags ) ); 
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				for (int i = 0; i < iCount; i++)
				{
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( cpPrimaryTags[i], OBJECT_TYPE, &cpObjectType ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_ORGANIZATION_UNIT ) == 0 )
					{
						primOrgUnitTag	=  cpPrimaryTags[i] ;
						break;
					}	
				}

				if( primOrgUnitTag != NULLTAG )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( primOrgUnitTag, AP4_MANAGER_ID, &cpParentManagerId ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
					if( strcmp( cpEmployeeId, cpParentManagerId ) == 0 )
					{
						DNVGL_TRACE_CALL( iStatus = dnvgl_get_employee_id_of_line_manager(cpEmployeeId, primOrgUnitTag,cpOutputManagerId) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
					else
					{
						DNVGL_STRCPY(*cpOutputManagerId, cpParentManagerId);
					}
				}
			}
			else
			{
				DNVGL_STRCPY(*cpOutputManagerId, cpManagerId);
			}
		}
	}
	catch(...)
	{	
	}
	DNVGL_TRACE_LEAVE();
	return iStatus;
}
/**
* \file dnvgl_utils.cxx
* \par Description:
* \verbatim
This function fetches the line mamager person tag 
* \endverbatim

* \par Owner:
*  Chetan kekade 
* \param[in]    userTag		user Tag
* \param[out]   char**		Employee Id of Line Manager of input user tag
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 16-Jan-2017   Chetan kekade		Initial Creation
*---------------------------------------------------------------------------------
*/
int dnvgl_get_employee_number_of_line_manager(tag_t userTag , char** cpLineMgrEmployeeId)
{
	int iStatus = ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tPerson = NULLTAG;
		
		// get the person tag
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( userTag, PERSON, &tPerson ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tPerson != NULLTAG )
		{
			char * cpUserName = NULL;
			char * cpObjectType = NULL;

			char * cpEmployeeId = NULL;
			tag_t relationTag = NULLTAG;
			tag_t orgUnitTag = NULLTAG;
			int iSecCount = 0;

			tag_t * tpRelatedTags =  NULLTAG;

			// get the Employee Id of the person 
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tPerson, PA7, &cpEmployeeId ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Get the eform dataset tag if already created : starts
			DNVGL_TRACE_CALL( GRM_find_relation_type( AP4_EMPLOYEE_ORG_UNIT , &relationTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tPerson, relationTag, &iSecCount, &tpRelatedTags ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			for(int index = 0; index < iSecCount ; index++)
			{
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_ORGANIZATION_UNIT ) == 0 )
				{
					orgUnitTag = tpRelatedTags[index];
					break;
				}	
			}

			char * cpManagerId = NULL;
			DNVGL_TRACE_CALL( iStatus = dnvgl_get_employee_id_of_line_manager( cpEmployeeId, orgUnitTag, &cpManagerId ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpManagerId != NULL )
			{
				DNVGL_STRCPY( *cpLineMgrEmployeeId, cpManagerId );
			}
		}
	}
	catch(...)
	{
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}


/**
* \file dnvgl_utils.cxx
* \par Description:
* \verbatim
This function reads all the arguments and returns the values of all the arguments.
* \endverbatim

* \par Owner:
*  Nikhilesh Khatra
* \param[in]    IMAN_argument_list_t*  givenArgList 
* \param[out]   char* pcGivenOptions   set of pairs (given Option, return Value) terminated by a NULL pointer.
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 05-Jul-2016   Nikhilesh Khatra    Initial Creation
*---------------------------------------------------------------------------------
*/
void dnvgl_get_handler_opts( IMAN_argument_list_t* givenArgList, char* pcGivenOptions,...)
{
	int           iArgCount = 0;
	char*         pcArgValue    = NULL;
	char*         pcOptions = pcGivenOptions;
	char*         pcEqualSign   = NULL;;
	char**        pcOptValue    = NULL;
	logical       bFound        = FALSE;
	va_list       functArgs;   

	DNVGL_TRACE_ENTER();
	iArgCount = TC_number_of_arguments( givenArgList );
	va_start( functArgs, pcGivenOptions );

	while( pcOptions )
	{
		pcOptValue = va_arg( functArgs, char** );
		bFound = FALSE;
		IMAN_init_argument_list( givenArgList );

		for( int iCounter = 0; iCounter < iArgCount && !bFound; iCounter++ )
		{
			pcArgValue = TC_next_argument( givenArgList );

			if( !strncmp( pcArgValue, pcOptions, strlen( pcOptions ) ) )
			{
				bFound = TRUE;
				pcEqualSign = strchr( pcArgValue, '=' );

				if( pcEqualSign )
				{
					*pcOptValue = pcEqualSign + 1;
				}
				else
				{
					*pcOptValue = pcArgValue;
				}
			}//if (!strncmp(pcArgValue, pcOptions, strlen(pcOptions)))
		}//end of for (int iCounter = 0;;)

		if( !bFound )
		{
			*pcOptValue = NULL;
		}

		pcOptions = va_arg( functArgs, char* );
	}//end of while loop

	va_end( functArgs );
	DNVGL_TRACE_LEAVE();
}  


int dnvgl_dataset_attach( char* cpDatasetType, char* cpRefName, char* cpFileName, char* cpFilePath, tag_t tDocumentRevTag, tag_t *opDatasetTag )
{
	int    iStatus				=  0			;
	tag_t  dataset_tag			=  NULLTAG		;
	tag_t  tStructRelTag		=  NULLTAG		;
	tag_t* tpRelatedTags		=  {NULLTAG}	;
	int	   iObjectCount			=  0			;	
	char*  cpDatasetName		=  NULL			;
	char*  cpObjectType			=  NULL			;
	bool    bIsDatasetExist		=  false		;
	DNVGL_TRACE_ENTER();
	try
	{
		// file import as dataset
		tag_t dataset_type_tag = NULLTAG ;
		DNVGL_TRACE_CALL( iStatus = AE_find_datasettype( cpDatasetType, &dataset_type_tag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tool_tag = NULLTAG ;
		DNVGL_TRACE_CALL( iStatus = AE_ask_datasettype_def_tool( dataset_type_tag, &tool_tag ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Check if dataset exists with the document revision. 

		//Get the eform dataset tag if already created : starts
		DNVGL_TRACE_CALL( GRM_find_relation_type( TC_ATTACHES_RELATION , &tStructRelTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tDocumentRevTag,tStructRelTag,&iObjectCount,&tpRelatedTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for ( int index = 0; index < iObjectCount; index++ )
		{						
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, cpDatasetType ) == 0 )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(tpRelatedTags[index], OBJECT_NAME, &cpDatasetName) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				if(strcmp(cpDatasetName, cpFileName ) == 0)
				{
					dataset_tag = tpRelatedTags[index];
					bIsDatasetExist = true ;
				}

			}	
		}
		//Get the eform dataset tag if already created : ends

		if( dataset_tag == NULLTAG )
		{
			DNVGL_TRACE_CALL( iStatus = AE_create_dataset_with_id(	dataset_type_tag, // aDatasetType
				cpFileName, // aDatasetName
				NULL, // aDatasetDescription
				NULL, // aDatasetId
				NULL, // aDatasetRev
				&dataset_tag )); // aNewDataset
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else{
			//remove old one
			char *  	reference_name =NULL;
			AE_reference_type_t   	reference_type;
			tag_t  	referenced_object ;
			DNVGL_TRACE_CALL( iStatus = AOM_lock( dataset_tag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = AE_find_dataset_named_ref2 ( dataset_tag,0,&reference_name,	&reference_type,&referenced_object));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus =  AE_remove_dataset_named_ref_by_tag2 ( dataset_tag,reference_name,referenced_object ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( dataset_tag ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		DNVGL_TRACE_CALL( iStatus = AOM_lock( dataset_tag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AE_import_named_ref(	dataset_tag, // datasetTag
			cpRefName, // referenceName
			cpFilePath, // osFullPathName
			NULL, // newFileName
			SS_BINARY ) ) ; // fileTypeFlag
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( dataset_tag ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( dataset_tag, false ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Attach to doc rev starts
		if(!bIsDatasetExist)
		{
			DNVGL_TRACE_CALL( iStatus = AOM_lock( tDocumentRevTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_lock( dataset_tag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t	tDatasetRelationTypetag		= NULLTAG;
			tag_t	tDatasetRelationTag			= NULLTAG;

			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( TC_ATTACHES_RELATION , &tDatasetRelationTypetag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tDocumentRevTag,dataset_tag,tDatasetRelationTypetag,NULLTAG,&tDatasetRelationTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Save relation		
			DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tDatasetRelationTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( dataset_tag ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			*opDatasetTag = dataset_tag;
			DNVGL_TRACE_CALL(  iStatus = AOM_save( tDocumentRevTag )) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		//Attach to doc rev ends
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE(tpRelatedTags);
	DNVGL_MEM_FREE(cpObjectType);

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}  


int dnvgl_split( std::string str, char delimiter, std::vector<std::string> &vResult ) 
{
	int iStatus = ITK_ok;

	std::stringstream ss( str ); // Turn the string into a stream.
	std::string tok;

	while( getline( ss, tok, delimiter ) )
	{
		vResult.push_back(tok);
	}

	return iStatus;
}

int dnvgl_multi_delimiter_split( std::string str, char* delimiters, std::vector<std::string> &vResult ) 
{
	int iStatus = ITK_ok;

	std::stringstream stringStream(str);
	std::string line;

	while(std::getline(stringStream, line)) 
	{
		std::size_t prev = 0, pos;
		while ((pos = line.find_first_of(delimiters, prev)) != std::string::npos)
		{
			if (pos > prev)
				vResult.push_back(line.substr(prev, pos-prev));
			prev = pos+1;
		}
		if (prev < line.length())
			vResult.push_back(line.substr(prev, std::string::npos));
	}
	return iStatus;
}

int dnvgl_dataset_attach( std::string cpDatasetType, char* cpRefName, char* cpFileName, char* cpFilePath, tag_t tDocumentRevTag )
{
	int iStatus = 0;
	try
	{
		// file import as dataset
		tag_t dataset_type_tag = NULLTAG ;
		DNVGL_TRACE_CALL( iStatus = AE_find_datasettype( cpDatasetType.c_str(), &dataset_type_tag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tool_tag = NULLTAG ;
		DNVGL_TRACE_CALL( iStatus = AE_ask_datasettype_def_tool( dataset_type_tag, &tool_tag ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Check if dataset exists with the document revision. 
		tag_t dataset_tag = NULLTAG ;
		// TODO:

		if( dataset_tag == NULLTAG )
		{
			DNVGL_TRACE_CALL( iStatus = AE_create_dataset_with_id(	dataset_type_tag, // aDatasetType
				cpFileName, // aDatasetName
				NULL, // aDatasetDescription
				NULL, // aDatasetId
				NULL, // aDatasetRev
				&dataset_tag )); // aNewDataset
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		//remove old one
		char *  	reference_name =NULL;

		DNVGL_TRACE_CALL( iStatus = AOM_lock( dataset_tag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AE_import_named_ref( dataset_tag, cpRefName, cpFilePath, NULL, SS_BINARY ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( dataset_tag ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( dataset_tag, false ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//data set attach to document revision
		tag_t	t_relation_type		= NULLTAG;
		tag_t	t_relation			= NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( "IMAN_specification", &t_relation_type ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tDocumentRevTag, dataset_tag, t_relation_type, NULLTAG, &t_relation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Save relation		
		DNVGL_TRACE_CALL( iStatus = GRM_save_relation( t_relation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_change_ownership( tag_t inputObject,const char* userName,const char* groupName )
{
	int	iStatus	= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		//find the user and group tag
		tag_t userTag = NULLTAG;
		tag_t groupTag = NULLTAG;

		DNVGL_TRACE_CALL( iStatus = SA_find_user2(userName, &userTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus = SA_find_group(groupName, &groupTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus = AOM_set_ownership(inputObject, userTag, groupTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus = AOM_save(inputObject) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{

	}
	DNVGL_TRACE_LEAVE();

	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par Description:
* \verbatim
  This function retuns current date.
* \endverbatim

* \par Owner:
*  Sanjay Sah
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 31-Mar-2017   Sanjay Sah          Initial Creation
*---------------------------------------------------------------------------------
*/
int dnvgl_get_current_date_time( date_t* dCurrDate )
{
	int iStatus = ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		char* dCurrentDate = NULL;
		DNVGL_TRACE_CALL( iStatus = ITK_ask_default_date_format	( &dCurrentDate ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		logical lIsValid = false;
		DNVGL_TRACE_CALL( iStatus = DATE_string_to_date_t( dCurrentDate, &lIsValid, dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_compare_dates(date_t targetDate, date_t inputCompareDate, logical compareDateOnly)
{
	size_t     timeDiff = 0;
	date_t  compareDate = NULLDATE;
	time_t  currentTime;
	struct  tm* current_tm = NULL;
	struct  tm compare_tm;
	struct  tm target_tm;

	if (DATE_IS_NULL(targetDate))
	{
		timeDiff = -1;
		return (int)timeDiff;
	}

	// If no compare date was input, use current local time.
	if (DATE_IS_NULL(inputCompareDate))
	{
		time(&currentTime);		
		compareDate.month = current_tm->tm_mon;
		compareDate.year = current_tm->tm_year + 1900;
		compareDate.day = current_tm->tm_mday;
		compareDate.hour = current_tm->tm_hour;
		compareDate.minute = current_tm->tm_min;
		compareDate.second = current_tm->tm_sec;
	}
	else
	{
		compareDate = inputCompareDate;
	}

	compare_tm.tm_mday = compareDate.day;
	compare_tm.tm_mon  = compareDate.month;
	compare_tm.tm_year = compareDate.year - 1900;
	compare_tm.tm_sec  = 0;
	compare_tm.tm_min  = 0;
	compare_tm.tm_hour = 0;
	compare_tm.tm_isdst= 1;
	if (!compareDateOnly)
	{
		compare_tm.tm_sec  = compareDate.second;
		compare_tm.tm_min  = compareDate.minute;
		compare_tm.tm_hour = compareDate.hour;
	}

	target_tm.tm_mday = targetDate.day;
	target_tm.tm_mon  = targetDate.month;
	target_tm.tm_year = targetDate.year - 1900;
	target_tm.tm_sec  = 0;
	target_tm.tm_min  = 0;
	target_tm.tm_hour = 0;
	target_tm.tm_isdst= 1;
	if (!compareDateOnly)
	{
		target_tm.tm_sec  = targetDate.second;
		target_tm.tm_min  = targetDate.minute;
		target_tm.tm_hour = targetDate.hour;
	}

	timeDiff = mktime(&target_tm) - mktime(&compare_tm);
	return (int)timeDiff;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will create a XML file for transmittal document present in the attached zip dataset. 
* \verbatim
\endverbatim     
* \param[in]   cpFilePath		    XML File path
* \param[in]   vFiles		        List of the files present in zip folder
* \par Algorithm:
* \verbatim  
a. Create XML document using tinyXML
b. Featch the data from the input text file 
c. Create xml tags
d. Save the XML file at the given file path in input parameter
e. Delete the temp text file
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 03-Aug-2016      Nikhilesh Khatra       Initial creation.
* 10-Aug-2016	   Nikhilesh Khatra       Reading data from text file instead of vector
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_transmittal_xml_creation_from_files(const char* cpXmlFilePath ,const char* cpTxtFilePath)
{
	int iStatus=ITK_ok;

	std::string  strFileNameWithExt		= ""	;
	std::string  strFileEachLine			= ""	;
	std::string  strFileEachLinePart1	= ""	;
	std::string  strFileEachLinePart2	= ""	;
	std::vector<std::string> vTemp ;

	//Tiny XML starts
	DNVGL_TRACE_ENTER();
	try{
		tinyxml2::XMLDocument doc;
		XMLDeclaration *declaration = doc.NewDeclaration(NULL) ;
		doc.LinkEndChild(declaration);
		XMLElement* element = doc.NewElement( "Transmittal" );
		doc.LinkEndChild( element );

		XMLText* text = doc.NewText("");
		element->LinkEndChild( text );

		ifstream infile;
		infile.open (cpTxtFilePath);
		//std::fstream infile (cpTxtFilePath, std::ios::in);	
		while (getline(infile,strFileEachLine))
		{
			// Checking for string
			if( strFileEachLine.find("....A") == std::string::npos )
				continue;

			strFileEachLinePart1 = strFileEachLine.substr (0,51); 
			strFileEachLinePart2 = strFileEachLine.substr (53); 

			while(strFileEachLinePart1.find("  ")!=std::string::npos)
			{
				strFileEachLinePart1.replace(strFileEachLinePart1.find("  "), 2, " ");
			}

			vTemp.clear();
			DNVGL_TRACE_CALL( iStatus = dnvgl_split(strFileEachLinePart1, ' ',vTemp) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			stringstream stream(strFileEachLinePart2);
			while( getline(stream, strFileNameWithExt, '\\') )
			{
				//no processing required 
			}

			std::size_t dotFound = strFileNameWithExt.find_last_of(".");
			string  strFileName			= ""	;
			if (dotFound!=std::string::npos)
			{
				strFileName = strFileNameWithExt.substr( 0 ,  dotFound );			
			}

			XMLElement* element2 = doc.NewElement( "Document" );
			XMLText* text2 = doc.NewText( "" );

			element2->SetAttribute("fileName",strFileNameWithExt.c_str());
			element2->SetAttribute("size",vTemp[3].c_str());
			element2->SetAttribute("lastModDate",(vTemp[0]+" "+vTemp[1]).c_str());
			element2->SetAttribute("documentName",strFileName.c_str());
			element->LinkEndChild( element2 );
		}	
		doc.SaveFile( cpXmlFilePath );

		infile.close();
		//Delete the temp txt file
		//std::string strFileDeleteCmd= "del /f ";
		//strFileDeleteCmd.append(cpTxtFilePath);
		////Delete xml file
		//DNVGL_TRACE_CALL( iStatus = system(strFileDeleteCmd.c_str()) );
		//DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}
	//Tiny XML ends
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_utils.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   cpExcelPath    excel file path
* \param[in]   cpXmlPath      xml file path 
*
* \par Algorithm:
* \verbatim  
a. Get the VB script path
b. Read the config file
c. Create Vb script command
d. Run the command to read the excel and create the xml file to the given loation
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_read_excel(const char* cpExcelPath,const char* cpConfigXmlPath,const char* cpMdrXmlPath)
{
	DNVGL_TRACE_ENTER();

	int iStatus				=	ITK_ok	;	

	try
	{
		int iCount				=	0		;
		char* cpVBScriptLoc		=	NULL	;
		char* cpVBLogFile		=	NULL	;
		char* cpTcRootEnvVar	=	NULL	;
		char* cpTempEnvVar		=	NULL	;

		std::string strSheetName			;
		std::string strFirstRowNo			;	
		std::string strLastRowNo			;	
		std::string strENSDoc				;	
		std::string strDocTitle				;
		std::string strRev				;

		// To get the environment variable TC_ROOT
		cpTcRootEnvVar = getenv(TC_ROOT_ENV_VAR);
		// To get the environment variable temp
		cpTempEnvVar = getenv(TEMP_ENV_VAR);

		// To generate the full path of vbscript log file
		DNVGL_TRACE_CALL( iStatus = dnvgl_generate_fullpath( cpTempEnvVar, "vbscript.log", NULL, &cpVBLogFile ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// To generate the full path of visual basic script file
		DNVGL_TRACE_CALL(iStatus = dnvgl_generate_fullpath(cpTcRootEnvVar, "custom\\ReadMDR.vbs", NULL, &cpVBScriptLoc) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//cscript <vbscript> <excel_file> <config_xml_file> <output_mdr_xml> <log_file>
		string strScriptCmd = "\"cscript ";
		strScriptCmd.append( cpVBScriptLoc );		
		strScriptCmd.append(" \"");
		strScriptCmd.append( cpExcelPath );
		strScriptCmd.append("\" \"");
		strScriptCmd.append( cpConfigXmlPath );
		strScriptCmd.append("\" ");
		strScriptCmd.append(cpMdrXmlPath);
		strScriptCmd.append(" ");
		strScriptCmd.append( cpVBLogFile );
		strScriptCmd.append("\"");	

		// This will create a process to run command line arguments 
		DNVGL_TRACE_CALL( iStatus = system( strScriptCmd.c_str() ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );

	return iStatus;
}

int dnvgl_read_config_file(const char* sConfigFilePath, string *sSheetName, string  *sFirstRowNum,  string * sLastRowNum, string  *sENSDoc,  string  *sRev,   string * sDocTitle)					
{
	DNVGL_TRACE_ENTER();
	int iStatus	=	ITK_ok	;
	tinyxml2:: XMLDocument xmlDoc;
	XMLElement * xmlSheet = NULL;
	XMLElement * xmlRow = NULL;
	XMLElement * xmlAttribute = NULL;

	vector<const char* >values;
	const char* cpSheetName	=	NULL	;	
	const char* cpFirstRowNo =	NULL	;	
	const char* cpLastRowNo	=	NULL	;	
	const char* cpENSDoc		=	NULL	;	
	const char* cpDocTitle	=	NULL	;
	const char* cpRev		=	NULL	;

	const char* cppColName;
	try
	{
		if(xmlDoc.LoadFile(sConfigFilePath) == tinyxml2::XML_NO_ERROR)
		{

			xmlAttribute = xmlDoc.FirstChildElement("excel_mapping");
			xmlSheet = xmlAttribute->FirstChildElement("sheet");
			cpSheetName= xmlSheet->Attribute("name");

			xmlRow = xmlSheet->FirstChildElement("rows");
			cpLastRowNo= xmlRow->Attribute("end");
			cpFirstRowNo = xmlRow->Attribute("start");

			for( xmlAttribute= xmlSheet->FirstChildElement("rows")->FirstChildElement("attribute"); 
				xmlAttribute; 
				xmlAttribute = xmlAttribute->NextSiblingElement())
			{
				cppColName = xmlAttribute->Attribute("column");
				values.push_back(cppColName);
			}
		}
		cpENSDoc	=values.at(0);
		cpRev		=values.at(1);
		cpDocTitle	=values.at(2);

		*sSheetName		=	cpSheetName;
		*sFirstRowNum	=	 cpFirstRowNo;
		*sLastRowNum	=	cpLastRowNo;
		*sENSDoc		=	cpENSDoc;
		*sRev			=	cpRev;
		*sDocTitle		=	cpDocTitle;

		TC_write_syslog("\n Returning from APS4_read_config_file with these values %s, %s, %s, %s, %s", sSheetName, sFirstRowNum,sLastRowNum, sENSDoc, sRev, sDocTitle);
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


int dnvgl_generate_fullpath(char* sDirName, char* sFileName, char* sCreationDate, char** sFullPath)
{
	int iStatus	=	ITK_ok	;
	DNVGL_TRACE_ENTER();
	char* sTemp = NULL;

	DNVGL_STRCPY(sTemp, sDirName);

	if (tc_strcmp(sFileName,NULL)!=0)
	{
		DNVGL_STRCAT(sTemp, "\\");
		DNVGL_STRCAT(sTemp, sFileName);
	}

	//Specially for report cases
	if (tc_strcmp(sCreationDate,NULL)!=0)
	{
		DNVGL_STRCAT(sTemp, "_");
		DNVGL_STRCAT(sTemp, sCreationDate);
		DNVGL_STRCAT(sTemp, ".txt");
	}

	DNVGL_STRCPY(*sFullPath, sTemp);
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will unzip the given zip to the given location input parameter. It will iterate in the extracted folder and 
get the file list present in the folder
* \verbatim
\endverbatim     
* \param[in]   pcZipFileNm		    Path of the exported zip dataset
* \param[in]   pcUnZipFolderNM		Path where zip need to be extracted
* \param[out]   vFiles		        List of the files present in zip folder
* \par Algorithm:
* \verbatim  
a. Unzip the given zip file
b. Iterate on the folder files and get the files name
c. Delete the given zip file
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 02-Aug-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_get_files_name_from_zip(const char* pcZipFileNm, const char * pcUnZipFolderNM,vector<string> &vFiles)

{	
	int	    iStatus  = ITK_ok	;
	size_t		iLoc				;

	DNVGL_TRACE_ENTER();
	try
	{
		const char* cpTcRootEnvVar;
		cpTcRootEnvVar = getenv( TC_ROOT_ENV_VAR );

		string strZipExePath = "\"";
		strZipExePath.append(cpTcRootEnvVar);
		strZipExePath.append("\\bin\\7za.exe e ");
		strZipExePath.append("\"");
		strZipExePath.append(pcZipFileNm);
		strZipExePath.append("\"");
		strZipExePath.append(" -o");
		strZipExePath.append("\"");
		strZipExePath.append(pcUnZipFolderNM);

		string strUnzCommand= "unzip ";
		strUnzCommand.append(pcZipFileNm);
		strUnzCommand.append(" -d "); 
		strUnzCommand.append(pcUnZipFolderNM);
		strUnzCommand.append(" "); 

		//Get only zip file name
		string strFileName = pcZipFileNm;
		iLoc = strFileName.find_last_of("/\\");
		strFileName =strFileName.substr (iLoc+1);
		iLoc= strFileName.find('.');
		strFileName =strFileName.substr(0,iLoc);

		strZipExePath.append("\\");
		strZipExePath.append(strFileName);
		strZipExePath.append("\"\"");

		DNVGL_TRACE_CALL( iStatus = system(strZipExePath.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		string strSlash="\\";
		string strDestFolderLoc = pcUnZipFolderNM +strSlash+ strFileName;

		const char* pcDestDir = strDestFolderLoc.c_str();
		FILE* pipe =  NULL;
		string strCommand = "\"dir /B /S \"" + string(pcDestDir) + "\"\"";
		char cBuffer[256];
		string strTempFilePath ;
		string  strFileNameWithExt	;
		if( NULL != (pipe = _popen(strCommand.c_str(),"rt")))
		{
			while (!feof(pipe))
			{
				if(fgets(cBuffer,256,pipe) != NULL)
				{
					strTempFilePath = cBuffer;
					strTempFilePath.erase(strTempFilePath.find_last_not_of("\n")+1);

					std::stringstream stream(strTempFilePath);
					while( getline(stream, strFileNameWithExt, '\\') )
					{
						//no processing required 
					}
					std::size_t dotFound = strFileNameWithExt.find_last_of(".");
					if (dotFound!=std::string::npos)
					{
						vFiles.push_back(string(cBuffer));
					}
				}
			}
			_pclose(pipe);
		}
		//Delete the temp zip file
		string strFileDeleteCmd= "\"del /f \"";
		strFileDeleteCmd.append(pcZipFileNm);
		strFileDeleteCmd.append("\"\"");
		//Delete zip file
		DNVGL_TRACE_CALL( iStatus = system(strFileDeleteCmd.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will read the transmittal xml and returns map of filename and document name.
* \verbatim
\endverbatim     
* \param[in]   cpXmlFilePath	Input xml file path
* \param[out]  mfileName		Result map
* \par Algorithm:
* \verbatim  
a. Parse the xml using tinyxml
b. Put the filename as key of map and document name as value of map
c. Delete the temp xml file
d. Returns the map
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 19-Aug-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_read_transmittal_xml(const char* cpXmlFilePath ,map<string,string> &mfileName)
{
	int iStatus=ITK_ok;

	string  strMapKey				= ""	;
	string  strMapValue				= ""	;

	const char *cpFileNameWithExt	= NULL	;
	const char *cpFileName			= NULL	;
	const char *cpFileSize			= NULL	;
	const char *cpFileModDate		= NULL	;

	//parsing using Tiny XML : starts
	DNVGL_TRACE_ENTER();
	try{
		tinyxml2::XMLDocument doc;
		if(doc.LoadFile(cpXmlFilePath) == tinyxml2::XML_NO_ERROR)
		{
			for( const tinyxml2::XMLElement* child = doc.FirstChildElement("Transmittal")->FirstChildElement("Document"); 
				child; 
				child = child->NextSiblingElement())
			{
				cpFileNameWithExt = child->Attribute("fileName") ;
				cpFileSize		  = child->Attribute("size") ;
				cpFileModDate	  = child->Attribute("lastModDate") ;
				cpFileName		  = child->Attribute("documentName") ;

				strMapKey = cpFileNameWithExt;
				strMapValue = cpFileName;
				mfileName.insert(std::pair<string,string>(strMapKey,strMapValue));
			}
		}

		//Delete the temp xml file
		string strFileDeleteCmd= "del /f ";
		strFileDeleteCmd.append(cpXmlFilePath);
		//Delete xml file
		DNVGL_TRACE_CALL( iStatus = system(strFileDeleteCmd.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}
	//parsing using Tiny XML : ends
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will read the mdr xml and returns the xml document tag attributes.
* \verbatim
\endverbatim     
* \param[in]   cpXmlFilePath	Input xml file path
* \param[out]  vMdrDoc			Result vector
* \par Algorithm:
* \verbatim  
a. Parse the xml using tinyxml
b. Put the attribute as key of map and attribute value as value of map
c. Put all the attributes in vetor
c. Delete the temp xml file
d. Returns the vetor
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 25-Aug-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_read_mdr_xml(const char* cpXmlFilePath ,vector<map<string,string>> &vTechDocAttr , vector<map<string,string>> &vTechDocRevAttr )
{
	int iStatus			=	ITK_ok	;
	int iPrefcount		=	0		;
	boolean bIsXmlDeleted   = false ;

	char** cpPrefValues				;
	const char* cpAttrValue = NULL ;
	string strAttrKey		= ""   ; 
	string strPrefLine		= ""   ; 
	string strAttribute     = ""   ; 
	string strType		    = ""   ; 
	map<string,string> mAttributesMap		;
	//parsing using Tiny XML : starts
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL(iStatus=PREF_ask_char_values( MDR_CONFIG_VIEW_ATTRIBUTES , &iPrefcount, &cpPrefValues ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for(int i=0;i<iPrefcount ;i++)
		{
			strPrefLine = cpPrefValues[i];
			std::stringstream stream(strPrefLine);	
			getline(stream, strType, '.') ;
			getline(stream, strAttribute, '.') ;
			mAttributesMap.insert(std::pair<string,string>(strAttribute,strType));
		}

		tinyxml2::XMLDocument doc;
		if(doc.LoadFile(cpXmlFilePath) == tinyxml2::XML_NO_ERROR)
		{
			for( const tinyxml2::XMLElement* child = doc.FirstChildElement("MDR")->FirstChildElement("Document"); 
				child; 
				child = child->NextSiblingElement())
			{
				map<string,string> mTechDocAttributesMap;
				map<string,string> mTechDocRevAttributesMap;
				for (std::map<string,string>::iterator it=mAttributesMap.begin(); it!=mAttributesMap.end(); ++it)
				{
					strAttribute = it->first.c_str();
					strType= it->second.c_str();

					cpAttrValue = child->Attribute(strAttribute.c_str()) ;
					if(cpAttrValue != NULL)
					{
						if(strType.compare( AP4_TECH_DOCUMENT ) == 0)
						{
							mTechDocAttributesMap.insert(std::pair<string,string>(strAttribute,cpAttrValue));
						}
						else if(strType.compare( AP4_TECH_DOC_REVISION ) == 0)
						{
							mTechDocRevAttributesMap.insert(std::pair<string,string>(strAttribute,cpAttrValue));
						}
					}
				}
				vTechDocAttr.push_back(mTechDocAttributesMap);
				vTechDocRevAttr.push_back(mTechDocRevAttributesMap);
			}
		}

		//Delete the temp xml file
		string strFileDeleteCmd= "del /f ";
		strFileDeleteCmd.append(cpXmlFilePath);
		//Delete xml file
		DNVGL_TRACE_CALL( iStatus = system(strFileDeleteCmd.c_str()) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		bIsXmlDeleted = true ;
	}
	catch( ... )
	{
		//Delete the temp file in case of any exception occurs and file is not deleted
		if(!bIsXmlDeleted)
		{
			string strFileDeleteCmd= "del /f ";
			strFileDeleteCmd.append(cpXmlFilePath);
			DNVGL_TRACE_CALL( iStatus = system(strFileDeleteCmd.c_str()) );
			DNVGL_LOG_ERROR;
		}
	}
	//parsing using Tiny XML : ends
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will create a techincal document input tag for the given attribute.
It is also adds attributes for technical document revision if any attributes are available to set.
* \verbatim
\endverbatim     
* \param[in]   mTechDocAttributesMap		attribute map
* \param[in]   mTechDocRevAttributesMap		attribute map
* \param[out]  tCreatedDocTag				Created doc tag
* \par Algorithm:
* \verbatim  
a. Get the attributes to create technical document input tag
b. Get the attribute for technical document rev if any attributes are present
c. Attach the tech rev input tag to tech doc input tag
d. Return the created technical document input tag
* \endverbatim
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 25-AUG-2016      Nikhilesh Khatra       Initial creation.
* 26-Sep-2016      Prasmit Pansare        Supported date properties
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_input_for_techdoc(map<string,string> mTechDocAttributesMap, map<string,string> mTechDocRevAttributesMap , tag_t * tCreatedInputTag )
{
	int	    iStatus          = ITK_ok		;

	DNVGL_TRACE_ENTER();
	try
	{
		//Document Creation starts
		tag_t tTechDocTag = NULLTAG;
		tag_t tTechDocRevTag = NULLTAG;
		tag_t tTechDocRevInputTag = NULLTAG;
		//tag_t tCreatedDocTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_TECH_DOCUMENT, AP4_TECH_DOCUMENT, &tTechDocTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tTechDocTag, tCreatedInputTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if(mTechDocRevAttributesMap.size()>0)
		{
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_TECH_DOC_REVISION , AP4_TECH_DOC_REVISION , &tTechDocRevTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tTechDocRevTag, &tTechDocRevInputTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		const char * cpPropertyValue ;
		char * cpPropertyName = NULL ;
		//Setting Document proprties
		for (std::map<string,string>::iterator it=mTechDocAttributesMap.begin(); it!=mTechDocAttributesMap.end(); ++it)
		{
			cpPropertyValue= it->second.c_str();
			cpPropertyName = (char *)it->first.c_str();
			DNVGL_TRACE_CALL( iStatus = TCTYPE_set_create_display_value(*tCreatedInputTag , cpPropertyName , 1, &cpPropertyValue) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		if(mTechDocRevAttributesMap.size()>0)
		{
			for (std::map<string,string>::iterator revIt=mTechDocRevAttributesMap.begin(); revIt!=mTechDocRevAttributesMap.end(); ++revIt)
			{
				string strDateValue;
				cpPropertyValue= revIt->second.c_str();
				cpPropertyName = (char *)revIt->first.c_str();
				bool foundDate = false;

				char*  cpPropertyType = NULL;
				PROP_value_type_t  valtype;
				tag_t propTag = NULLTAG;

				DNVGL_TRACE_CALL( iStatus  = AOM_ask_value_type(tTechDocRevInputTag, cpPropertyName, &valtype, &cpPropertyType));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				//Prasmit: Added below code to fix date issue assuming date will contain "." to be replaced with "-" (strDateValue- Manipulated)
				if(valtype == PROP_date)
				{
					string value  = revIt->second;
					size_t valLength = value.length();
					if(valLength>0)
					{
						strDateValue = revIt->second; 
						while(1)
						{
							if((strDateValue.find("."))!=std::string::npos)
							{
								replace(strDateValue.begin(), strDateValue.end(), '.','-');
								foundDate = true;
							}
							else	
								break;
						}
					}
					if(foundDate)
					{
						char* cpTempValue  = NULL;
						date_t dTempDate = NULLDATE;

						//Appending HH:MM as date from XML is in format "11-02-1984"
						strDateValue.append(" 00:00:00");
						cpTempValue=(char*) strDateValue.c_str();
						const char* cpInputDateValue = cpTempValue;
						// For "dnvgl_get_date_from_string_MDR()" Date format should be "11-02-1988 00:00:00"
						dTempDate = dnvgl_get_date_from_string_MDR(cpInputDateValue);
						DNVGL_TRACE_CALL( iStatus = AOM_set_value_date(tTechDocRevInputTag, cpPropertyName, dTempDate));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						MEM_free(cpPropertyType);
					}
				}
				else
				{
					DNVGL_TRACE_CALL( iStatus = TCTYPE_set_create_display_value( tTechDocRevInputTag, cpPropertyName , 1, &cpPropertyValue) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}

			char *tempUID  = NULL ;
			char *irCreateInputTagUid = NULL;

			DNVGL_TRACE_CALL( iStatus = AOM_tag_to_string( tTechDocRevInputTag, &tempUID ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//strcpy( irCreateInputTagUid, tempUID );
			const char * cpRevPropertyValue = tempUID;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_set_create_display_value( *tCreatedInputTag, "revision", 1, &cpRevPropertyValue ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}	

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will create all the technical document for the given techdoc input tags and attach to the given project folder
* \verbatim
\endverbatim     
* \param[in]   iNoOfObject		    Number of CreateInput objects
* \param[in]   iQuantities		    Array of number of objects to create for each CreateInput object
* \param[in]   tpInputTags		    Array of CreateInput objects
* \param[in]   tProjectFolderTag    Project Folder tag
* \par Algorithm:
* \verbatim  
a. Create the technical documents for the given input tags
b. Attach the created project documents with given project folder in input param with custom document relation
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 01-SEP-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_documents(int iNoOfObject, int * iQuantities , tag_t * tpInputTags, tag_t tDocumentRegFolder )
{
	int	    iStatus          = ITK_ok		;
	int  	iNumberOfObjectTags ; 
	tag_t *  	tpObjectTags ;
	DNVGL_TRACE_ENTER();
	try
	{
		//Create the objects in bulk.
		DNVGL_TRACE_CALL( iStatus = TCTYPE_create_objects ( iNoOfObject , iQuantities, tpInputTags, &iNumberOfObjectTags, &tpObjectTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Save the objects in bulk.
		DNVGL_TRACE_CALL( iStatus = AOM_bulk_save_instances( iNumberOfObjectTags, tpObjectTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t	tDocRelationTypeTag		= NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_DOCUMENT_RELATION, &tDocRelationTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for(int iObject = 0 ; iObject<iNumberOfObjectTags ; iObject++)
		{
			tag_t	tDocRelationTag			= NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tDocumentRegFolder, tpObjectTags[iObject], tDocRelationTypeTag, NULLTAG, &tDocRelationTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Save relation		
			DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tDocRelationTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}	

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will create a dataset based on the type of the file. Attach the file as named reference to the dataset. 
Attach the created dataset to technical document revision. 
* \verbatim
\endverbatim     
* \param[in]   cpFilePath		    File path
* \param[in]   tCreatedDocTag       Document tag
* \par Algorithm:
* \verbatim  
a. Get the file name and extension of file from the filepath 
b. From the extension using custom preference to get the dataset type
c. Create dataset and attach the file given in input parameter
d. Attach created dataset with given technical document revision
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 25-AUG-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_attach_dataset_to_techdoc( const char* cpFilePath,tag_t tCreatedDocTag )
{
	int	    iStatus          = ITK_ok		;
	int		iCount			 = 0			;

	char*	cpRefName		 = NULL	; 
	char*   cpPrefName       = "DNVGL_FormDataset" ; 
	char**  cpPrefValues	 = NULL		;	

	string  strFileExt		 = ""		;
	string  strPrefFileExt	 = ""		;
	string  cpDatasetType	 = ""		;
	string  strFileName		 = ""		;
	string  strFileNameWithExt		 = ""		;

	DNVGL_TRACE_ENTER();
	try
	{		
		string strFilePath = cpFilePath;
		stringstream stream(cpFilePath);
		while( getline(stream, strFileNameWithExt, '\\') )
		{
			//no processing required 
		}
		std::size_t dotFound = strFileNameWithExt.find_last_of(".");
		if (dotFound!=std::string::npos)
		{
			strFileName = strFileNameWithExt.substr( 0 ,  dotFound );
			strFileExt = strFileNameWithExt.substr( dotFound+1, strFileNameWithExt.length() );
		}

		size_t lastindex = strFilePath.find_last_of("."); 
		strFileExt = strFilePath.substr( lastindex+1, strFilePath.length() );

		//Preference reading starts
		DNVGL_TRACE_CALL(iStatus=PREF_ask_char_values(cpPrefName,&iCount,&cpPrefValues));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for(int i=0;i<iCount;i++)
		{
			stringstream stream(cpPrefValues[i]);
			getline(stream, strPrefFileExt, '|') ;	
			if( tc_strncasecmp( strPrefFileExt.c_str(), strFileExt.c_str(), strPrefFileExt.length() ) == 0 )			
			{
				getline(stream,cpDatasetType, '|');				
				break;
			}	
		}
		MEM_free (cpPrefValues);
		//Preference reading ends

		//Dataset creation starts
		// file import as dataset
		tag_t tDatasetTypeTag = NULLTAG ;
		/*	if(cpDatasetType == "")
		{
		return 919125;
		}*/
		DNVGL_TRACE_CALL( iStatus = AE_find_datasettype2( cpDatasetType.c_str(), &tDatasetTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char** cpRefList = NULL;
		int    iRefCount = 0   ;
		DNVGL_TRACE_CALL( iStatus = AE_ask_datasettype_refs (tDatasetTypeTag, &iRefCount, &cpRefList) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		//Setting reference name for dataset creation e.g. setting "word" for docx type fo file
		cpRefName = cpRefList[0];
		MEM_free (cpRefList);

		tag_t tDatasetTag = NULLTAG ;
		DNVGL_TRACE_CALL( iStatus = AE_create_dataset_with_id(	tDatasetTypeTag, // aDatasetType
			strFileName.c_str(), // aDatasetName
			NULL, // aDatasetDescription
			NULL, // aDatasetId
			NULL, // aDatasetRev
			&tDatasetTag )); // aNewDataset
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_lock( tDatasetTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AE_import_named_ref(	tDatasetTag, // datasetTag
			cpRefName, // referenceName
			cpFilePath, // osFullPathName
			NULL, // newFileName
			SS_BINARY ) ) ; // fileTypeFlag
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( tDatasetTag ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tDatasetTag, false ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Dataset  creation ends

		DNVGL_TRACE_CALL( iStatus = AOM_lock( tCreatedDocTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_lock( tDatasetTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t	tRelatedRevTag			= NULLTAG;
		DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( tCreatedDocTag,&tRelatedRevTag ) );
		DNVGL_LOG_ERROR_AND_RETURN;

		tag_t	tDatasetRelationTypetag		= NULLTAG;
		tag_t	tDatasetRelationTag			= NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type(TC_ATTACHES_RELATION,&tDatasetRelationTypetag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tRelatedRevTag,tDatasetTag,tDatasetRelationTypetag,NULLTAG,&tDatasetRelationTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		//Save relation		
		DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tDatasetRelationTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( tDatasetTag ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		DNVGL_TRACE_CALL(  iStatus = AOM_save( tCreatedDocTag )) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}	


/**
* \file dnvgl_utils.cxx
* \par Description :
This function will give the SubContractor Folder tag from the Document Register Folder , 
if no SubContractor Folder is present then it will create new SubContractor Folder.
* \verbatim
\endverbatim
* \param[in]	tDocRegisterTag Input Document Register Folder Tag  
* \param[out]	Folder tag
* \par Algorithm:
* \verbatim
a. Check for the SubContractor Folder
b. If present then return the SubContractor tag
c. If not present then create new SubContrsctor and return same.

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date Name Description of Change
* 26-Aug-2016 Chetan Kekade Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_get_unassignedfiles_folder( tag_t tDocRegisterTag, tag_t* tUnassignedFolderTag)
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t	tRelationTypeTag		= NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_STRUCTURE_RELATION, &tRelationTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iCount = 0;
		tag_t* tSecondaryList = NULL;
		DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tDocRegisterTag, tRelationTypeTag, &iCount, &tSecondaryList ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iCount; i++ )
		{
			char* cpFolderName = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSecondaryList[i], OBJECT_NAME, &cpFolderName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tc_strcmp( cpFolderName, UNASSIGNED_FILES ) == 0 )
			{				
				*tUnassignedFolderTag = tSecondaryList[i];
				break;
			}
		}

		if( *tUnassignedFolderTag == NULLTAG )
		{
			tag_t tSubCoTypeTag		= NULLTAG;
			tag_t tSubCoInputTag	= NULLTAG;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_UNASSIGNED_FILES, AP4_UNASSIGNED_FILES, &tSubCoTypeTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_construct_create_input( tSubCoTypeTag, &tSubCoInputTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tSubCoInputTag, OBJECT_NAME, UNASSIGNED_FILES ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_create_object( tSubCoInputTag, tUnassignedFolderTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( *tUnassignedFolderTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t	tRelationTag = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tDocRegisterTag, *tUnassignedFolderTag, tRelationTypeTag, NULLTAG, &tRelationTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelationTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will create a dataset based on the type of the file. Attach the file as named reference to the dataset. Then create a project document. 
Attach the created dataset to Folder with custom relation. 

* \verbatim
\endverbatim     
* \param[in]   cpFilePath		    File path
* \param[in]   cpDocName		    Name of the document
* \param[in]   tProjectFolderTag    Project Folder tag
* \par Algorithm:
* \verbatim  
a. Get the file name and extension of file from the filepath 
b. From the extension using custom preference to get the dataset type
c. Create dataset and attach the file given in input parameter
d. Create Project document ,attach teh created dataset with project document revision
e. Attach the created project document with given project folder in input param with custom document relation
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 26-AUG-2016      Chetan Kekade          Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_dataset( const char* cpFilePath, tag_t* tDataset )
{
	int	    iStatus          = ITK_ok		;
	int		iCount			 = 0			;

	char*	cpRefName		 = NULL	; 	
	char**  cpPrefValues	 = NULL		;	

	std::string  strFileExt		 = ""		;
	std::string  strPrefFileExt	 = ""		;
	std::string  cpDatasetType	 = ""		;
	std::string  strFileName		 = ""		;
	std::string  strFileNameWithExt		 = ""		;

	DNVGL_TRACE_ENTER();
	try
	{
		std::string strFilePath = cpFilePath;
		std::stringstream stream(cpFilePath);
		while( getline(stream, strFileNameWithExt, '\\') )
		{
			//no processing required 
		}

		//Get the filename and file extension. To get this, split the filename by last dot.
		strFileName = strFileNameWithExt.substr (0,strFileNameWithExt.find_last_of("."));
		strFileExt = strFileNameWithExt.substr (strFileNameWithExt.find_last_of(".")+1,strFileNameWithExt.size());

		//Convert the extension to lower case to avoid failure in comparison of extensions. For. eg. .pdf and .PDF are same.
		std::transform( strFileExt.begin(), strFileExt.end(), strFileExt.begin(), ::tolower );

		//Preference reading starts
		DNVGL_TRACE_CALL( iStatus = PREF_ask_char_values( DNVGL_FORMDATASET, &iCount, &cpPrefValues ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iCount; i++ )
		{
			std::stringstream stream( cpPrefValues[i] );
			getline( stream, strPrefFileExt, '|' ) ;
			if( strPrefFileExt.compare( strFileExt ) == 0 )
			{
				getline( stream, cpDatasetType, '|' );				
				break;
			}	
		}
		MEM_free (cpPrefValues);
		//Preference reading ends

		//Dataset creation starts
		// file import as dataset
		tag_t tDatasetTypeTag = NULLTAG ;
		DNVGL_TRACE_CALL( iStatus = AE_find_datasettype2( cpDatasetType.c_str(), &tDatasetTypeTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char** cpRefList = NULL;
		int    iRefCount = 0   ;
		DNVGL_TRACE_CALL( iStatus = AE_ask_datasettype_refs ( tDatasetTypeTag, &iRefCount, &cpRefList ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Setting reference name for dataset creation e.g. setting "word" for docx type fo file
		cpRefName = cpRefList[0];
		MEM_free (cpRefList);

		DNVGL_TRACE_CALL( iStatus = AE_create_dataset_with_id(	tDatasetTypeTag, // aDatasetType
			strFileName.c_str(), // aDatasetName
			NULL, // aDatasetDescription
			NULL, // aDatasetId
			NULL, // aDatasetRev
			tDataset )); // aNewDataset
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_lock( *tDataset) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AE_import_named_ref( *tDataset, // datasetTag
			cpRefName, // referenceName
			cpFilePath, // osFullPathName
			NULL, // newFileName
			SS_BINARY ) ) ; // fileTypeFlag
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( *tDataset ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( *tDataset, false ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_create_relation( tag_t tPrimaryObj, tag_t tSecondaryObj, const char* cpRelationName )
{
	int	    iStatus          = ITK_ok		;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tRelationType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( cpRelationName, &tRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tRelation = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_create_relation( tPrimaryObj, tSecondaryObj, tRelationType, NULLTAG, &tRelation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Save relation
		DNVGL_TRACE_CALL( iStatus = GRM_save_relation( tRelation ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 26-AUG-2016      Sanjay Sah             Initial creation for getting date-time stamp with specified format.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

int DNVGL_current_get_time_stamp(char* format, char** timestamp)
{
	int iStatus = ITK_ok;
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = newTime->tm_mon;
	currentTime.year = newTime->tm_year + 1900;
	currentTime.day = newTime->tm_mday;
	currentTime.hour = newTime->tm_hour;
	currentTime.minute = newTime->tm_min;
	currentTime.second = newTime->tm_sec;

	iStatus = DATE_date_to_string(currentTime, format, timestamp);

	return iStatus;
}

/*------------------------------------------------------------------------------------------------------------------------------
* History
*-------------------------------------------------------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 26-Sep-2016      Prasmit Pansare        Initial creation for getting date_t structure from input string in format "11-02-1988 00:00:00"
*-------------------------------------------------------------------------------------------------------------------------------
*
---------------------------------------------------------------------------------------------------------------------------------*/
date_t dnvgl_get_date_from_string_MDR(const char* inputDateString)
{
	date_t valueDate = NULLDATE;

	// validate input string
	if(inputDateString != NULL && strlen(inputDateString) >= 19 )
	{
		//19.02.2014 00:00:00

		char day[3];
		memcpy( day, &inputDateString[0], 2 );
		day[2] = '\0';

		char month[3];
		memcpy( month, &inputDateString[3], 2 );
		month[2] = '\0';

		char year[5];
		memcpy( year, &inputDateString[6], 4 );
		year[4] = '\0';

		char hour[3];
		memcpy( hour, &inputDateString[11], 2 );
		hour[2] = '\0';

		char minute[3];
		memcpy( minute, &inputDateString[14], 2);
		minute[2] = '\0';

		char second[3];
		memcpy( second, &inputDateString[17], 2 );
		second[2] = '\0';

		valueDate.year = (short)atoi(year);
		valueDate.month = (byte)atoi(month);
		valueDate.day = (byte)atoi(day);
		valueDate.hour = (byte)atoi(hour);
		valueDate.minute = (byte)atoi(minute);
		valueDate.second = (byte)atoi(second);

	}

	return valueDate;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will replace the special character present in the input string with Escape Sequence.
This function supports &,<,>,' and ".
* \verbatim
\endverbatim     
* \param[in]   strInput		    Input string
* \par Algorithm:
* \verbatim  
a. Replace the specail characters with Escape Sequence
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 05-OCT-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/

int dnvgl_normalize_eform_string(std::string& strInput)
{
	int	    iStatus          = ITK_ok		;
	DNVGL_TRACE_ENTER();
	try
	{
		if(! (strInput.size() == 0 || strInput.empty() ) ){
			std::map<std::string,std::string> mSpecialCharMap ;
			mSpecialCharMap.insert(std::pair<std::string,std::string>( "&","&amp;" ) );
			mSpecialCharMap.insert(std::pair<std::string,std::string>( "<","&lt;" ) );
			mSpecialCharMap.insert(std::pair<std::string,std::string>( ">","&gt;" ) );
			mSpecialCharMap.insert(std::pair<std::string,std::string>( "\"","&quot;" ) );
			mSpecialCharMap.insert(std::pair<std::string,std::string>( "'","&apos;" ) );

			size_t pos = 0;
			for (std::map<string,string>::iterator it=mSpecialCharMap.begin(); it!=mSpecialCharMap.end(); ++it)
			{
				pos = 0;
				while ((pos = strInput.find(it->first, pos)) != std::string::npos) {
					strInput.replace(pos, it->first.length(), it->second);
					pos += it->second.length();
				}
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


int dnvgl_grm_get_secondary_obj_of_type_with_relation ( tag_t tPrimaryObj, char*   pszRelationTypeName, char*   pszSecondaryObjType, tag_t** pptSecondaryObjects, tag_t** pptRelationObjects, int* piObjectCount )
{

	int     iStatus                           = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		int     iCount                          = 0;
		int     iIterator                       = 0;
		int     iSecondaryCount                 = 0;
		tag_t   tRelationType                   = NULLTAG;
		char    szObjectType[TCTYPE_name_size_c+1] = "";
		GRM_relation_t *ptSecondaryObjects      = NULL;

		/* Initializing the Out Parameter to this function. */
		(*piObjectCount) = 0;
		(*pptSecondaryObjects) = NULL;
		(*pptRelationObjects) = NULL;

		/* verify input */
		if(tPrimaryObj == NULLTAG || DNVGL_IS_STRING_EMPTY(pszSecondaryObjType))
		{
			return iStatus;
		}

		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type(pszRelationTypeName, &tRelationType)); 
		DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects(tPrimaryObj, tRelationType, &iSecondaryCount, &ptSecondaryObjects));

		for(iIterator = 0; iIterator < iSecondaryCount && iStatus == ITK_ok; iIterator++)
		{
			tag_t   tObjectType = NULLTAG;

			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type(ptSecondaryObjects[iIterator].secondary, &tObjectType) );
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_name( tObjectType, szObjectType) );

			if (tc_strcmp(szObjectType, pszSecondaryObjType) == 0)
			{
				iCount++;
				(*pptSecondaryObjects) = (tag_t*)MEM_realloc ( (*pptSecondaryObjects) , (sizeof(tag_t) * iCount) );
				(*pptSecondaryObjects)[iCount -1] = ptSecondaryObjects[iIterator].secondary;

				(*pptRelationObjects) = (tag_t*)MEM_realloc ( (*pptRelationObjects) , (sizeof(tag_t) * iCount) );
				(*pptRelationObjects)[iCount -1] = ptSecondaryObjects[iIterator].the_relation;
			}
		}

		if(iCount == 0)
		{
			TC_write_syslog("No Secondary Object associated with the %s relation to the object.\n", pszRelationTypeName);
		}
		else
		{
			(*piObjectCount ) = iCount;
		}

	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will add given number of days to the given date.
* \verbatim
\endverbatim     
* \param[in]   dInpDate		    Input date
* \param[in]   days				Number of days to be added to the input date
* \param[out]  dOutDate			New date with added days to the input date
* \par Algorithm:
* \verbatim  
a. Add days to a given date.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 09-NOV-2016      Vinay Kudari           Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvg_add_days_to_date( date_t dInpDate , int days, date_t* dOutDate )
{
	int iStatus = ITK_ok;

	struct tm date;
	date.tm_mday = dInpDate.day;
	date.tm_mon  = dInpDate.month;
	date.tm_year = dInpDate.year - 1900;
	date.tm_sec  = dInpDate.second;
	date.tm_min  = dInpDate.minute;
	date.tm_hour = dInpDate.hour;
	date.tm_isdst= 1;

	const time_t ONE_DAY = 24 * 60 * 60 ;

	// Seconds since start of epoch
	time_t date_seconds = mktime( &date ) + (days * ONE_DAY) ;

	// Update caller's date
	// Use localtime because mktime converts to UTC so may change date
	date = *localtime( &date_seconds ) ;

	char       buf[80];
	strftime( buf, sizeof(buf), "%d-%m-%Y %H:%M:%S", &date );

	iStatus = DATE_convert_formatted_string_to_date( buf, "%d-%m-%Y %H:%M:%S", false, false, dOutDate);

	return iStatus;
}


/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will get project revision from tech doc revision.
* \verbatim
\endverbatim     
* \param[in]		tTechDocRevTag		    Technical Document Revision Tag
* \param[out]		tProjectRevTag		    Project Revision Tag
* \par Algorithm:
* \verbatim  
a. Get Tech doc from Tech doc revision.
b. Get folder to which tech is attached with document relation.
c. Get Project revision from Folder using project backpointer property.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 12-Jan-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvg_get_project_rev_from_tech_doc_rev( tag_t tTechDocRevTag , tag_t *tProjectRevTag ){

	int     iStatus                 = ITK_ok	;
	int		iObjectCount			= 0			;	
	tag_t   tTechDocTag				= NULLTAG	;
	tag_t	tStructRelTag	        = NULLTAG	;
	tag_t*	tpRelatedTags	        = {NULLTAG} ;
	DNVGL_TRACE_ENTER();
	try
	{
		//Get the doc tag from doc rev
		DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tTechDocRevTag, &tTechDocTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t tPrimaryTypeTag = NULLTAG;  
		DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( AP4_PROJECT_FOLDER , &tPrimaryTypeTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_DOCUMENT_RELATION , &tStructRelTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		//Get priimary object of technical document
		DNVGL_TRACE_CALL(iStatus =  GRM_list_primary_objects_only( tTechDocTag, tStructRelTag, &iObjectCount, &tpRelatedTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		tag_t   tFolderTag	 = NULLTAG  ;
		for ( int index = 0; index < iObjectCount; index++ )
		{			
			bool bIsInstance = false;
			tag_t tInputObjectType = NULLTAG;

			DNVGL_TRACE_CALL( iStatus = POM_class_of_instance(tpRelatedTags[index], &tInputObjectType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = POM_is_descendant( tPrimaryTypeTag, tInputObjectType, &bIsInstance) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( bIsInstance )
			{									
				tFolderTag = tpRelatedTags[index];
				break;
			}			
		}
		//Get project revision from folder using AP4_PROJECT_BACKPOINTER property
		if(tFolderTag != NULLTAG)
		{
			DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_tag( tFolderTag, AP4_PROJECT_BACKPOINTER , tProjectRevTag ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else
		{
			//need to throw error that doc is not attached to any folder
			iStatus = ERROR_919137;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}	
	DNVGL_MEM_FREE(tpRelatedTags);

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


int dnvgl_grm_get_secondary_obj_of_type(tag_t tPrimaryObj, std::string sRelationTypeName, std::string sSecondaryObjType, std::vector<tag_t>& secondaryObjects)
{
	int iStatus = ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		/* verify input */
		if(tPrimaryObj == NULLTAG || sSecondaryObjType.empty() || sRelationTypeName.empty() )
		{
			return iStatus;
		}

		tag_t tRelationType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type(sRelationTypeName.c_str(), &tRelationType)); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iSecondaryCount = 0;
		tag_t* ptSecondaryObjects = NULL;
		DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tPrimaryObj, tRelationType, &iSecondaryCount, &ptSecondaryObjects ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for ( int i = 0; i < iSecondaryCount; i++ )
		{
			char* cpFolderType = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( ptSecondaryObjects[i], OBJECT_TYPE, &cpFolderType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tc_strcmp( cpFolderType, sSecondaryObjType.c_str() ) == 0 )
			{
				secondaryObjects.push_back(ptSecondaryObjects[i]);
			}
		}

		DNVGL_MEM_FREE(ptSecondaryObjects);
	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


int checkIsInstanceOf(tag_t& inputTag, const char* expectedType, bool& isTypeOf)
{
	int iStatus = 0;
	isTypeOf = false;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t tPrimaryTypeTag = NULLTAG; 
		DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( expectedType, &tPrimaryTypeTag) );
		tag_t tInputObjectType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = POM_class_of_instance(inputTag, &tInputObjectType) );
		DNVGL_TRACE_CALL( iStatus = POM_is_descendant( tPrimaryTypeTag, tInputObjectType, &isTypeOf) );
	}
	catch( ... )
	{
	}	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will get project revision from tech doc revision.
* \verbatim
\endverbatim     
* \param[in]		doc				XML
* \param[in]		newNode		    Node to add
* \param[in]		strSeach		Node to search
* \par Algorithm:
* \verbatim  
a. Move through the XML tree following these rules (basically in-order tree walk).
b. if there is one or more child element(s) visit the first one
c. if there is one or more next sibling element(s) visit the first one
d. move to the parent until there is one or more next sibling elements
e. if we reach the end break the loop
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 24-Mar-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_add_xml_element(tinyxml2::XMLDocument &doc, tinyxml2::XMLNode *newNode, string &strSeach)
{
	int		iStatus	= ITK_ok	;
	DNVGL_TRACE_ENTER()	;

	try
	{
		if ( doc.ErrorID() != tinyxml2::XML_SUCCESS )
		{
			// throw error
			iStatus = ERROR_919166;
			DNVGL_LOG_ERROR_AND_THROW_STATUS ;
		} 

		tinyxml2::XMLNode * xElem = doc.FirstChild();
		while(xElem)
		{
			if (xElem->Value() && !std::string(xElem->Value()).compare(strSeach))
			{
				break ;
			}

			if (xElem->FirstChildElement()) //(1)
			{
				xElem = xElem->FirstChildElement();
			}
			else if (xElem->NextSiblingElement())  //(2)
			{
				xElem = xElem->NextSiblingElement();
			}
			else
			{
				while(xElem->Parent() && !xElem->Parent()->NextSiblingElement()) //(3)
					xElem = xElem->Parent();
				if(xElem->Parent() && xElem->Parent()->NextSiblingElement())
					xElem = xElem->Parent()->NextSiblingElement();
				else //(4)
					break;
			}//else
		}//while

		if (xElem != nullptr)
		{
			xElem->InsertFirstChild(newNode);
		}
		else{
			iStatus = ERROR_919167;
			EMH_store_error_s1(EMH_severity_error,ERROR_919139,strSeach.c_str());
			DNVGL_LOG_ERROR_AND_THROW_STATUS ;
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will read comment letter related preference and reuturns bookmakrs based on preference and eform id.
* \verbatim
\endverbatim     
* \param[in]   cpPrefName					Preference name
* \param[in]   cpEformID					Eform ID
* \param[out]  vEditabelBookmarks			Result vector
* \par Algorithm:
* \verbatim  
a. Serach preference.
b. Iterate on preference values and serch for given eform id.
c. When matches fetch bookmarks.

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 24-Mar-2016      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_get_comment_letter_bookmarks( char* cpPrefName, const char* cpEformID, std::vector<std::string> &vEditabelBookmarks )
{
	int		iStatus = 0;
	int		iCount;
	char** cpValues;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = PREF_ask_char_values( cpPrefName, &iCount, &cpValues ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<std::string> vSplitVector;
		bool prefMappingFound = false;
		for( int i=0; i<iCount; i++ )
		{
			vSplitVector.clear();
			dnvgl_split( cpValues[i], '|', vSplitVector );

			if( tc_strcmp( cpEformID, vSplitVector.at(0).c_str() ) == 0 )
			{
				for( int bookmarkSize=1; bookmarkSize<vSplitVector.size(); bookmarkSize++ )
				{
					vEditabelBookmarks.push_back(vSplitVector[bookmarkSize]);
				}
				prefMappingFound = true;
				break;
			}			
		}

		if( !prefMappingFound )
		{
			iStatus = ERROR_919164;
			DNVGL_TRACE_CALL( EMH_store_error_s1( EMH_severity_error, ERROR_919164, cpEformID ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will create comment id for comment chain.
* \verbatim
\endverbatim     
* \param[in]   tProjectRev					Project Revision
* \param[out]  strCommentChainId			Result comment chain id
* \par Algorithm:
* \verbatim  
a. Take the old comment count based on different condition.
a. If the project is linked to an asset (through the project setup) then the numbering sequence is on asset basis (starting at 1). Comment number will have a prefix that denotes the type of service. �V� for verification, �C� for class and �A� for advisory services. This is determined from the service code in the project setup.
b. Else, if a project is just linked to a Field (not an asset) then the numbering sequence is on field basis (starting at 1). Comment number will have the prefix "F".
c. Else (no asset and no field) the numbering sequence is on project basis (starting at 1). Comment number will not have a prefix.
d. Use the prefix and old comment count to generate new comment id.
* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 05-May-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_get_comment_chain_count_for_project( tag_t &tProjectRev, string &strCommentChainId )
{
	int		iStatus					= 0			;
	int		iAssetCount				= 0			;	 
	int		iFieldCount				= 0			;
	int		iCommentId				= 0			;

	tag_t*	tpAssets				= {NULLTAG} ;
	tag_t*	tpAssetRelationObjects	= {NULLTAG} ;
	tag_t*	tpFields				= {NULLTAG} ;

	tag_t   tAsset					= NULLTAG	;
	tag_t	tField					= NULLTAG	;
	tag_t	tFieldRev				= NULLTAG	;
	tag_t	tProject				= NULLTAG	;

	char*   cpServiceArea			= NULL      ;

	string strPrefix ;
	std::ostringstream result;

	logical lWasLockedBefore		= false		;
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL(iStatus = dnvgl_grm_get_secondary_obj_of_type_with_relation( tProjectRev , AP4_ASSETRELATION , AP4_ASSETREVISION, &tpAssets, &tpAssetRelationObjects, &iAssetCount) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Check if asset is present
		if(iAssetCount>0)
		{
			DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tpAssets[0], &tAsset) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_int( tAsset, AP4_TOTAL_COMMENT_COUNT, &iCommentId ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_string( tProjectRev, AP4_SERVICE_AREA, &cpServiceArea ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpServiceArea != NULL && (tc_strcmp( cpServiceArea, SERVICEAREA_VCA ) == 0 || tc_strcmp( cpServiceArea, SERVICEAREA_VMC ) == 0 ) )
			{				
				strPrefix = "V" ;
			}
			else
			{
				strPrefix = "A" ;
			}

			iCommentId++;

			DNVGL_TRACE_CALL( iStatus = POM_modifiable( tAsset, &lWasLockedBefore ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !lWasLockedBefore )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tAsset, true ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			DNVGL_TRACE_CALL ( iStatus = AOM_set_value_int( tAsset, AP4_TOTAL_COMMENT_COUNT, iCommentId ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( tAsset ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !lWasLockedBefore )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tAsset, false ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
		//Check if field is present
		else
		{
			tag_t tPrimaryTypeTag = NULLTAG;  
			DNVGL_TRACE_CALL( iStatus = POM_class_id_of_class( AP4_FIELDREVISION , &tPrimaryTypeTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t	tStructRelTag = NULLTAG	;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_FIELDRELATION , &tStructRelTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			
			DNVGL_TRACE_CALL(iStatus =  GRM_list_secondary_objects_only( tProjectRev, tStructRelTag, &iFieldCount, &tpFields ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for ( int index = 0; index < iFieldCount; index++ )
			{			
				bool bIsInstance = false;
				tag_t tInputObjectType = NULLTAG;

				DNVGL_TRACE_CALL( iStatus = POM_class_of_instance(tpFields[index], &tInputObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = POM_is_descendant( tPrimaryTypeTag, tInputObjectType, &bIsInstance) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( bIsInstance )
				{									
					tFieldRev = tpFields[index];
					break;
				}			
			}

			if( tFieldRev != NULLTAG)
			{
				DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tFieldRev, &tField) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_int( tField, AP4_TOTAL_COMMENT_COUNT, &iCommentId ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				strPrefix = "F" ;
				iCommentId++ ;

				DNVGL_TRACE_CALL( iStatus = POM_modifiable( tField, &lWasLockedBefore ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( !lWasLockedBefore )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tField, true ) ) ;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				DNVGL_TRACE_CALL ( iStatus = AOM_set_value_int( tField, AP4_TOTAL_COMMENT_COUNT, iCommentId ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tField ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( !lWasLockedBefore )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tField, false ) ) ;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}
			else
			{
				DNVGL_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev( tProjectRev, &tProject) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL ( iStatus = AOM_ask_value_int( tProject, AP4_TOTAL_COMMENT_COUNT, &iCommentId ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
				iCommentId++ ;

				DNVGL_TRACE_CALL( iStatus = POM_modifiable( tProject, &lWasLockedBefore ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( !lWasLockedBefore )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tProject, true ) ) ;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}

				DNVGL_TRACE_CALL ( iStatus = AOM_set_value_int( tProject, AP4_TOTAL_COMMENT_COUNT, iCommentId ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				DNVGL_TRACE_CALL( iStatus = AOM_save( tProject ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( !lWasLockedBefore )
				{
					DNVGL_TRACE_CALL( iStatus = AOM_refresh( tProject, false ) ) ;
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}
		}

		if(iCommentId>0)
		{
			result << strPrefix << iCommentId;
			strCommentChainId = result.str();
		}

	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE(tpAssets);
	DNVGL_MEM_FREE(tpAssetRelationObjects);
	DNVGL_MEM_FREE(tpFields);
	DNVGL_MEM_FREE(cpServiceArea);

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will create comment sequence id for last comment of comment chain - that is newly created reply.
* \verbatim
\endverbatim     
* \param[in]   vReplyData					Reply vector
* \par Algorithm:
* \verbatim  
a. Get comment chain from input vector
b. Update last comment with comment sequence id

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 05-May-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_comment_count_for_reply( std::vector<std::string> &vReplyData ) 
{
	int		iStatus					= 0			;
	int     iCommentsCount			= 0			;
	tag_t*	tpComments				= {NULLTAG} ;
	tag_t   tCommentChain			= NULLTAG	;
	tag_t	tLastComment			= NULLTAG	;

	logical lCommentWasLockedBefore	= false		;

	DNVGL_TRACE_ENTER();
	try
	{
		for(int iCount =0 ; iCount<vReplyData.size(); iCount=iCount+2)
		{
			DNVGL_TRACE_CALL( ITK__convert_uid_to_tag( vReplyData[iCount].c_str(), &tCommentChain ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tags( tCommentChain, AP4_COMMENTS, &iCommentsCount, &tpComments ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tLastComment = tpComments[ iCommentsCount-1 ];

			std::ostringstream	commentSeqId			;
			commentSeqId  << iCommentsCount;
			std::string strCommentSeq = commentSeqId.str();

			DNVGL_TRACE_CALL( iStatus = POM_modifiable( tLastComment, &lCommentWasLockedBefore ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !lCommentWasLockedBefore )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tLastComment, true ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}

			DNVGL_TRACE_CALL ( iStatus = AOM_set_value_string( tLastComment, AP4_COMMENT_SEQ_ID, strCommentSeq.c_str() ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( tLastComment ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( !lCommentWasLockedBefore )
			{
				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tLastComment, false ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpComments );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will sort given comment chains based on page no.
* \verbatim
\endverbatim     
* \param[in]   vCommentChain		Input vector which contains all the comment chains

* \par Algorithm:
* \verbatim  
a.Sort Comment chains based on page no in ascending order.

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 22-May-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_sort_comment_chain_by_page( std::vector<std::pair<tag_t, int>> &vCommentChain ) 
{
	int		iStatus					= 0			;

	DNVGL_TRACE_ENTER();
	try
	{
		std::sort( vCommentChain.begin(), vCommentChain.end(),
			[]( const std::pair<tag_t, int> &p1, const std::pair<tag_t, int> &p2 )
		{
			return ( p1.second < p2.second);
		} );
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will create ExcelCppService object.
* \verbatim
\endverbatim     
* \param[in]   cpFilepath			File path
* \param[in]   excelServiceObj		Created object

* \par Algorithm:
* \verbatim  
a.Create object
b.Check Openxml sdk installed or not on machine

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 08-Jun-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_excelinterop_object( OfficeInterop::ExcelCppService *& excelServiceObj, const char* cpFilepath ){

	int		iStatus					= 0			;

	DNVGL_TRACE_ENTER();
	try
	{
		excelServiceObj = new OfficeInterop::ExcelCppService(cpFilepath);

		iStatus = excelServiceObj->IsOpenXmlInstalled();
		if( iStatus == 1 )
		{
			iStatus = ERROR_919176;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else if( iStatus == 2 )
		{
			iStatus = ERROR_919177;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_utils.cxx
* \par  Description :
This function will create WordCppService object.
* \verbatim
\endverbatim     
* \param[in]   cpFilepath			File path
* \param[in]   wordServiceObj		Created object

* \par Algorithm:
* \verbatim  
a.Create object
b.Check Openxml sdk installed or not on machine

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 08-Jun-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_create_wordinterop_object(  OfficeInterop::WordCppService *& wordServiceObj, const char* cpFilepath ){

	int		iStatus					= 0			;

	DNVGL_TRACE_ENTER();
	try
	{
		wordServiceObj=new OfficeInterop::WordCppService(cpFilepath);

		iStatus = wordServiceObj->IsOpenXmlInstalled();
		if( iStatus == 1 )
		{
			iStatus = ERROR_919176;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
		else if( iStatus == 2 )
		{
			iStatus = ERROR_919177;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
