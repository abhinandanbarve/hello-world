/**
* \file dnvgl_tcproject_handling.cxx
* \ingroup libAP4_dnvgl_common
* \verbatim
\par Description:
This File  contains the Functions to Create tc project and add/remove user to the project.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 16-May-2016   Nikhilesh Khatra      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_schedule_handling.h"

/**
* \file dnvgl_tcproject_handling.cxx
* \par  Description :
* \verbatim
*   Create Project
\endverbatim     
* \param[in]   projectItemTag    Tag of the Project Item
* \param[out]  projectTag        Tag of created project
*
* \par Algorithm:
* \verbatim  
a. Login to teamcenter
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_copy_schedule( tag_t *schedule, tag_t *newSchedule )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		int number_schedules_to_copy		= 1;                           
		tag_t* original_schedules			= schedule;                        
		tag_t* created_schedules			= NULL;  
		char * message						= NULL;
		char * baseName						= NULL;                       

		DNVGL_TRACE_CALL( iStatus = SCHMGT_copy_schedule( number_schedules_to_copy, schedule, &created_schedules ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( created_schedules != NULL )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( created_schedules[0], true ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_set_value_logical( created_schedules[0], IS_TEMPLATE, false ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( created_schedules[0] ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( created_schedules[0], false ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			*newSchedule = created_schedules[0];
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int dnvgl_find_schedule( const char* scheduleID, tag_t *schedule )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t queryTag = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = QRY_find( "AP4_Schedule_Query", &queryTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( queryTag != NULLTAG )
		{
			int iEntryCount = 0;
			char** cEntries = NULL;
			char** cValues = NULL;
			DNVGL_TRACE_CALL( iStatus = QRY_find_user_entries(queryTag, &iEntryCount, &cEntries, &cValues) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			int len = int( tc_strlen( scheduleID ) );
			cValues[0] = (char *)MEM_alloc( len + 1);
			tc_strcpy( cValues[0], scheduleID );

			int nFound = 0;
			tag_t* tResults = NULL;
			DNVGL_TRACE_CALL( iStatus = QRY_execute( queryTag, 1, cEntries, cValues, &nFound, &tResults) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( nFound == 1 )
			{
				*schedule = tResults[0];
			}
		}		
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


int dnvgl_shift_schedule( tag_t tSchedule, date_t dtStartDate, date_t dtEndDate )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		logical date_is_valid = false;
		logical lNewFinish = FALSE;
		int iNoOfUpdatedTasks = 0;
		tag_t* tUpdatedTasks = NULLTAG;			
		
		DNVGL_TRACE_CALL( iStatus = SCHMGT_shift_schedule_non_interactive( tSchedule, dtStartDate, lNewFinish, &iNoOfUpdatedTasks, &tUpdatedTasks ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
		for( int i=0; i<iNoOfUpdatedTasks; i++ )
		{		
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tUpdatedTasks[i], true ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save( tUpdatedTasks[i] ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tUpdatedTasks[i], false ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;					
		}

		if( iNoOfUpdatedTasks <= 1 )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tSchedule, true ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_date( tSchedule, FINISH_DATE, dtEndDate ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_save_with_extensions( tSchedule ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tSchedule, false ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
