/**
* \file dnvgl_pom_enquiry_utils.cxx
* \ingroup libAP4_dnvgl_common
* \verbatim
\par Description:
This File  contains the utiltiy functions for POM enquiry.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name					Description of Change
* 20-Apr-201    Nikhilesh KHatra        Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_pom_enquiry_utils.h"

using namespace std;

/**
* \file dnvgl_pom_enquiry_utils.cxx
* \par  Description :
 This function will featch comment chains and related tech docs for the given activity.
* \verbatim
\endverbatim     
* \param[in]    tActivityRev					Activity revision
* \param[out]   tpActivityCommentChain			Comment chains
* \param[out]   ipCommentChainCount				Comment chains count
* \param[out]   mActivityCommentChains			map of techdocs and respected comment chains
* \par Algorithm:
* \verbatim  
a. Find all the comment chains related to activity.
b. Create map of tech docs based on AP4_PRIMARY_TARGET on commment chain.

* \endverbatim
* \par Returns :
* int : 0/error code
*/
/*------------------------------------------------------------------------------
* History
*------------------------------------------------------------------------------
* Date             Name                   Description of Change
* 20-Apr-2017      Nikhilesh Khatra       Initial creation.
*------------------------------------------------------------------------------
*
------------------------------------------------------------------------------*/
int dnvgl_get_comment_chains_for_activity(tag_t tActivityRev, tag_t **tpActivityCommentChain, int* ipCommentChainCount, std::map<tag_t, vector<tag_t>> *mActivityCommentChains)
{
	int			iStatus					= ITK_ok;
	char*		argetTagToString		= NULL;
	char*		object_type				= NULL;
	tag_t*      qryTags					= NULL;
	int         qryCnt					= 0;
	const char* attrNames[]				= { "puid" };
	char*       objectType              = NULL;
	int			rows					= 0;
	int			cols					= 0;
	void***		queryResult				= NULL;
	tag_t**		tagArray				= NULL;
	const char* enq_id					= "dnvgl-get-all-comments-for-activity" ;
	int     iCount                      = 0;
	logical lInternalComment			= false ;
	DNVGL_TRACE_ENTER();
	try
	{
		// Unique identification for query
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create( enq_id ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		/* Do not allow duplicate results */
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_distinct( enq_id , TRUE ) ); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Select attributes (select puid from AP4_CommentChain)
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs( enq_id, AP4_COMMENT_CHAIN, 1, attrNames ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Create a tag value object(puidValue) and set tActivityRev value
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_tag_value (enq_id, "activityTag", 1, &tActivityRev, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_logical_value (enq_id, "internalComment", 1, &lInternalComment, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// select puid from AP4_CommentChain where ap4_activity = tActivityRev 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr(enq_id, "ExprId1", AP4_COMMENT_CHAIN , AP4_ACTIVITY, POM_enquiry_equal, "activityTag"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// select puid from AP4_CommentChain where ap4_internal_remark = false 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr(enq_id, "ExprId2", AP4_COMMENT_CHAIN , AP4_INTERNAL_REMARK, POM_enquiry_equal, "internalComment"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(enq_id, "final_expression", "ExprId1", POM_enquiry_and, "ExprId2") ); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr(enq_id, "final_expression"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute(enq_id, &rows, &cols, &queryResult));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//*tpActivityCommentChain	= (tag_t*) MEM_alloc ((int)(sizeof(int)*rows))	;
		if(ipCommentChainCount != NULL)
		{
			(*ipCommentChainCount ) = rows;
		}
		for( int iCnt=0; iCnt<rows; iCnt++ )
		{
			//Adding the Result tag to the vector
			tag_t tmpSecObj		= *( tag_t* )( queryResult[iCnt][0] );
			if( tmpSecObj != NULLTAG )
			{
				tag_t tTechDocRev = NULLTAG;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tmpSecObj, AP4_PRIMARY_TARGET, &tTechDocRev ));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( tpActivityCommentChain != NULL)
				{
					iCount++;
					(*tpActivityCommentChain) = (tag_t*)MEM_realloc ( (*tpActivityCommentChain) , (sizeof(tag_t) * iCount) );
					(*tpActivityCommentChain)[iCount -1] = tmpSecObj;
				}

				if(mActivityCommentChains != NULL){
					if ( mActivityCommentChains->find( tTechDocRev ) == mActivityCommentChains->end() )
					{
						std::vector< tag_t > vCommentChain ;
						vCommentChain.push_back(tmpSecObj);
						mActivityCommentChains->insert( std::pair<tag_t, std::vector< tag_t>>( tTechDocRev, vCommentChain ) );					
					}
					else{	
						mActivityCommentChains->at( tTechDocRev ).push_back(tmpSecObj);
					}	
				}
			}
		}

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete( enq_id ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	}
	catch(...)
	{
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete( enq_id ) );
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}