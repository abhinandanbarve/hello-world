/**
*\file dnvgl_trace_handling.cxx
* \ingroup libAP4_dnvgl_common
*\par Description:
*This file contains the functions for runtime tracing to the TOA console window,
*to the syslog file or to the journal file.

*\par Since: 
*Release1
*\par ENVIRONMENT : 
*C, ITK

*\par Owner:
*Chetan Kekade
*/
/*
*History:
-------------------------------------------------------------------------------
*Date         	Name				 Description of Change
*12-May-2016   Chetan Kekade		 Initial Creation
--------------------------------------------------------------------------------
*/
#include "dnvgl_trace_handling.h"

#pragma warning (disable : 4267)

static enum	eDNVGLTraceMethods		geDNVGLTraceMethod   = UNKNOWN_TRACE_METHOD;
static enum	eDNVGLTraceFileLines	geDNVGLTraceFileLine = UNKNOWN_TRACE_FILELINE;

static logical						gbDNVGLTraceInitialized = FALSE;

static int							gbDNVGLTraceIsOn        = 0;

static int							giDNVGLTraceIndentIncr = 0;
static int							giDNVGLTraceIndention = 0;

static char	*						gpcDNVGLTracePrefix = NULL;


/*!
*\file dnvgl_trace_handling.cxx
*\par Description:
*Initializes runtime tracing.
*A set of environment variables is asked for in order to initialize
*runtime tracing and to control the amount of output and its target.

Referenced environment variables (those in [] are optional):

DNVGL_TRACE
[DNVGL_TRACE_METHOD]    default: SYSLOG
[DNVGL_TRACE_PREFIX]    default: no prefix
[DNVGL_TRACE_INDENT]    default: 2
[P4_TRACE_FILELINE]		default: NO



*\return	logical	TRUE or FALSE signaling whether tracing has been turn on or not


*\par Owner:
*Chetan Kekade

*/
int dnvgl_trace_handling_is_on( void )
{
	if ( !gbDNVGLTraceInitialized )
	{
		int		iStatus = ITK_ok	;

		const char	cEnvSrc[] = "environment variable"	;
		const char	cPrefSrc[] = "TC preference"		;
		const char	cNoneSrc[] = ""						;

		char	* pcSrc = (char*)cNoneSrc				;
		char	* pcMethodSrc = (char*)cNoneSrc			;
		char	* pcPrefixSrc = (char*)cNoneSrc			;
		char	* pcIndentSrc = (char*)cNoneSrc			;
		char	* pcFileLineSrc = (char*)cNoneSrc		;

		char	* pcDNVGLTrace = NULL				;
		char	* pcDNVGLTraceMethod = NULL		;
		char	* pcDNVGLTraceIndent = NULL		;
		char	* pcDNVGLTraceFileLine = NULL		;
		char	* pcDNVGLTracePrefix = NULL		;

		TC_preference_search_scope_t	currPrefSearchScope = TC_preference_site;

		if ( iStatus == ITK_ok )
		{
			// Save current preference search scope
			DNVGL_ITK_CALL ( PREF_ask_search_scope ( &currPrefSearchScope ) ) ;
		}

		if ( iStatus == ITK_ok )
		{
			//Set the current search scrope to user
			DNVGL_ITK_CALL ( PREF_set_search_scope ( TC_preference_user ) ) ;	// do not forget to reset

			DNVGL_ITK_CALL ( PREF_ask_char_value ( "DNVGL_TRACE" , 0 , &pcDNVGLTrace ) ) ;
		}


		// Second look for site preference
		if ( ( iStatus != ITK_ok ) || ( pcDNVGLTrace == NULL ) || ( strlen ( pcDNVGLTrace ) <= 0 ) )
		{
			// Set the current search scrope to user
			DNVGL_ITK_CALL ( PREF_set_search_scope ( TC_preference_site ) ) ;	// do not forget to reset
			DNVGL_ITK_CALL ( PREF_ask_char_value ( "DNVGL_TRACE" , 0 , &pcDNVGLTrace ) ) ;
		}

		// Then look for environment variable DNVGL_TRACE
		if ( ( iStatus != ITK_ok ) || ( pcDNVGLTrace == NULL ) || ( strlen ( pcDNVGLTrace ) <= 0 ) )
		{
			// need to check

			size_t sz = 0;
			//pcDNVGLTrace = getenv ( "DNVGL_TRACE" ) ;
			_dupenv_s(&pcDNVGLTrace, &sz,"DNVGL_TRACE");

			pcSrc = (char*)cEnvSrc ;
		} else pcSrc = (char*)cPrefSrc ;

		if ( ( pcDNVGLTrace != NULL ) && ( strlen ( pcDNVGLTrace ) > 0 ) )
		{
			/*if ( strcmp ( pcDNVGLTrace, "OFF" ) != 0 ) 
			{
			gbDNVGLTraceIsOn = true ;
			}*/
			TC_write_syslog("Trace Option is : %s",pcDNVGLTrace);
			if ( strcmp ( pcDNVGLTrace, "0" ) == 0 ) 
				gbDNVGLTraceIsOn = 0;
			else if( strcmp ( pcDNVGLTrace, "1" ) == 0 ) 
				gbDNVGLTraceIsOn = 1;
			else if( strcmp ( pcDNVGLTrace, "2" ) == 0 ) 
				gbDNVGLTraceIsOn = 2;
			else if( strcmp ( pcDNVGLTrace, "3" ) == 0 ) 
				gbDNVGLTraceIsOn = 3;
			else if( strcmp ( pcDNVGLTrace, "ON" ) == 0 ) 
				gbDNVGLTraceIsOn = 3;

		}

		if ( gbDNVGLTraceIsOn )
		{
			// Save current preference search scope and set to user scope
			//DNVGL_ITK_CALL ( PREF_ask_search_scope ( &currPrefSearchScope ) ) ;

			if ( iStatus == ITK_ok )
			{
				// Set the current search scrope to user
				DNVGL_ITK_CALL ( PREF_set_search_scope ( TC_preference_user ) ) ;	// do not forget to reset
			}

			// First look for char preference      DNVGL_TRACE_METHOD: if not found,
			//       look for environment variable DNVGL_TRACE_METHOD
			DNVGL_ITK_CALL ( PREF_ask_char_value ( "DNVGL_TRACE_METHOD" , 0 , &pcDNVGLTraceMethod ) ) ;
			if ( ( iStatus != ITK_ok ) || ( pcDNVGLTraceMethod == NULL ) || ( strlen ( pcDNVGLTraceMethod ) <= 0 ) )
			{
				//pcDNVGLTraceMethod = TC_getenv ( "DNVGL_TRACE_METHOD" ) ;
				size_t sz = 0;
				_dupenv_s(&pcDNVGLTraceMethod, &sz,"DNVGL_TRACE_METHOD");

				pcMethodSrc = (char*)cEnvSrc ;
			} else pcMethodSrc = (char*)cPrefSrc ;
			if ( ( pcDNVGLTraceMethod != NULL ) && ( strlen ( pcDNVGLTraceMethod ) > 0 ) )
			{
				if ( strcmp ( pcDNVGLTraceMethod , "OUTSTREAM" ) == 0 ) geDNVGLTraceMethod = OUTSTREAM_TRACE_METHOD ;
				else if ( strcmp ( pcDNVGLTraceMethod , "SYSLOG"    ) == 0 ) geDNVGLTraceMethod = SYSLOG_TRACE_METHOD    ;
				else if ( strcmp ( pcDNVGLTraceMethod , "JOURNAL"   ) == 0 ) geDNVGLTraceMethod = JOURNAL_TRACE_METHOD   ;
			}
			else {
				geDNVGLTraceMethod = SYSLOG_TRACE_METHOD ; // default
				pcMethodSrc = (char*)cNoneSrc ;
			}
			if ( geDNVGLTraceMethod == UNKNOWN_TRACE_METHOD ) gbDNVGLTraceIsOn = false ; // cancel tracing


			// First look for char preference      DNVGL_TRACE_INDENT: if not found,
			//       look for environment variable DNVGL_TRACE_INDENT
			DNVGL_ITK_CALL ( PREF_ask_char_value ( "DNVGL_TRACE_INDENT" , 0 , &pcDNVGLTraceIndent ) ) ;
			if ( ( iStatus != ITK_ok ) || ( pcDNVGLTraceIndent == NULL ) || ( strlen ( pcDNVGLTraceIndent ) <= 0 ) )
			{
				//pcDNVGLTraceIndent = getenv ( "DNVGL_TRACE_INDENT" ) ;
				size_t sz = 0;
				_dupenv_s(&pcDNVGLTraceIndent, &sz,"DNVGL_TRACE_INDENT");
				pcIndentSrc = (char*)cEnvSrc ;
			} else pcIndentSrc = (char*)cPrefSrc ;
			if ( ( pcDNVGLTraceIndent != NULL ) && ( strlen ( pcDNVGLTraceIndent ) > 0 ) )
			{
				char	* pcAux = NULL	;

				giDNVGLTraceIndentIncr = strtol ( pcDNVGLTraceIndent , &pcAux , 10 ) ;
				if ( *pcAux != '\0' ) gbDNVGLTraceIsOn = false ;// cancel tracing
				else if ( giDNVGLTraceIndentIncr < 0 ) gbDNVGLTraceIsOn = false ;// cancel tracing
			}
			else {
				giDNVGLTraceIndentIncr = 2 ; // default
				pcIndentSrc = (char*)cNoneSrc ;
			}


			// First look for site char preference DNVGL_TRACE_PREFIX: if not found,
			//       look for environment variable DNVGL_TRACE_PREFIX
			DNVGL_ITK_CALL ( PREF_ask_char_value ( "DNVGL_TRACE_PREFIX" , 0 , &pcDNVGLTracePrefix ) ) ;
			if ( ( iStatus != ITK_ok ) || ( pcDNVGLTracePrefix == NULL ) || ( strlen ( pcDNVGLTracePrefix ) <= 0 ) )
			{
				//pcDNVGLTracePrefix = getenv ( "DNVGL_TRACE_PREFIX" ) ;
				size_t sz = 0;
				_dupenv_s(&pcDNVGLTracePrefix, &sz,"DNVGL_TRACE_PREFIX");
				pcPrefixSrc = (char*)cEnvSrc ;
			} else pcPrefixSrc = (char*)cPrefSrc ;
			if ( ( pcDNVGLTracePrefix != NULL ) && ( strlen ( pcDNVGLTracePrefix ) > 0 ) )
			{
				gpcDNVGLTracePrefix = (char*) MEM_alloc ( (strlen(pcDNVGLTracePrefix)+1) * sizeof(char) ) ;
				tc_strcpy ( gpcDNVGLTracePrefix , pcDNVGLTracePrefix ) ;

			}
			else {
				gpcDNVGLTracePrefix = NULL ; // default
				pcPrefixSrc = (char*)cNoneSrc ;
			}


			// First look for char preference      DNVGL_TRACE_FILELINE: if not found,
			//       look for environment variable DNVGL_TRACE_FILELINE
			DNVGL_ITK_CALL ( PREF_ask_char_value ( "DNVGL_TRACE_FILELINE" , 0 , &pcDNVGLTraceFileLine ) ) ;
			if ( ( iStatus != ITK_ok ) || ( pcDNVGLTraceFileLine == NULL )  || ( strlen ( pcDNVGLTraceFileLine ) <= 0 ) )
			{
				//pcDNVGLTraceFileLine = getenv ( "DNVGL_TRACE_FILELINE" ) ;
				size_t sz = 0;
				_dupenv_s(&pcDNVGLTraceFileLine, &sz,"DNVGL_TRACE_FILELINE");
				pcFileLineSrc = (char*)cEnvSrc ;
			} else pcFileLineSrc = (char*)cPrefSrc ;
			if ( ( pcDNVGLTraceFileLine != NULL ) && ( strlen ( pcDNVGLTraceFileLine ) > 0 ) )
			{
				if ( strcmp ( pcDNVGLTraceFileLine , "NO"    ) == 0 ) geDNVGLTraceFileLine = NO_TRACE_FILELINE    ;
				else if ( strcmp ( pcDNVGLTraceFileLine , "SHORT" ) == 0 ) geDNVGLTraceFileLine = SHORT_TRACE_FILELINE ;
				else if ( strcmp ( pcDNVGLTraceFileLine , "LONG"  ) == 0 ) geDNVGLTraceFileLine = LONG_TRACE_FILELINE  ;
			}
			else {
				geDNVGLTraceFileLine = NO_TRACE_FILELINE ; // default
				pcFileLineSrc = (char*)cNoneSrc ;
			}
			if ( geDNVGLTraceFileLine == UNKNOWN_TRACE_FILELINE ) gbDNVGLTraceIsOn = false ; // cancel tracing
		}
		gbDNVGLTraceInitialized = TRUE ;


		// Log result
		if ( gbDNVGLTraceIsOn ) 
			TC_write_syslog ( "\nDue to the following options tracing is turned ON:\n" ) ;
		else 
			TC_write_syslog ( "\nDue to the following options tracing is turned OFF:\n" ) ;

		TC_write_syslog ( "    DNVGL_TRACE          = " ) ;
		if ( pcDNVGLTrace  != NULL )          
			TC_write_syslog ( "\"%s\"" , pcDNVGLTrace ) ;
		if ( strlen ( pcSrc ) > 0 )             
			TC_write_syslog ( " (source: %s)\n" , pcSrc ) ;
		else
			TC_write_syslog ( " \"\" (default: no tracing)\n" ) ;
		TC_write_syslog ( "    DNVGL_TRACE_METHOD   = " ) ;
		if ( pcDNVGLTraceMethod != NULL )     
			TC_write_syslog ( "\"%s\"" , pcDNVGLTraceMethod ) ;
		if ( strlen ( pcMethodSrc ) > 0 )       
			TC_write_syslog ( " (source: %s)\n" , pcMethodSrc ) ;
		else                                    
			TC_write_syslog ( " \"\" (default: SYSLOG)\n" ) ;


		TC_write_syslog ( "    DNVGL_TRACE_INDENT   = " ) ;
		if ( pcDNVGLTraceIndent != NULL )     
			TC_write_syslog ( "\"%s\"" , pcDNVGLTraceIndent ) ;
		if ( strlen ( pcIndentSrc ) > 0 )       
			TC_write_syslog ( " (source: %s)\n" , pcIndentSrc ) ;
		else                                    
			TC_write_syslog ( " \"\" (default: 2)\n" ) ;


		TC_write_syslog ( "    DNVGL_TRACE_PREFIX   = " ) ;
		if ( pcDNVGLTracePrefix != NULL )     
			TC_write_syslog ( "\"%s\"" , pcDNVGLTracePrefix ) ;
		if ( strlen ( pcPrefixSrc ) > 0 )      
			TC_write_syslog ( " (source: %s)\n" , pcPrefixSrc ) ;
		else                                    
			TC_write_syslog ( " \"\" (default: no prefix)\n" ) ;


		TC_write_syslog ( "    DNVGL_TRACE_FILELINE = " ) ;
		if ( pcDNVGLTraceFileLine != NULL )   
			TC_write_syslog ( "\"%s\"" , pcDNVGLTraceFileLine ) ;
		if ( strlen ( pcFileLineSrc ) > 0 )    
			TC_write_syslog ( " (source: %s)\n" , pcFileLineSrc ) ;
		else                                   
			TC_write_syslog ( " \"\" (default: NO)\n" ) ;

		TC_write_syslog ( "(Fixed values:\n" ) ;
		TC_write_syslog ( "    DNVGL_TRACE=0,1,2,3,ON\n" ) ;
		TC_write_syslog ( "    DNVGL_TRACE_METHOD=SYSLOG,OUTSTREAM,JOURNAL\n" ) ;
		TC_write_syslog ( "   DNVGL_TRACE_FILELINE=NO,SHORT,LONG\n" ) ;
		TC_write_syslog ( " Source preference has precedence over environment variable)\n\n\n" ) ;

		// Save current preference search scope and set to default again
		DNVGL_ITK_CALL ( PREF_set_search_scope (currPrefSearchScope ) ) ;
	}
	return gbDNVGLTraceIsOn ;	
}

/*! 
*\file dnvgl_trace_handling.cxx
*\par Description:
*Writes to stdout, syslog or journal file including potential prefix
*and indention

*Based on the global variable geDNVGLTraceMethod a variable amount of arguments
*are written to stdout, to syslog or to journal file.

*Output to stdout is written straight with vfprintf, which takes a va_list type
*argument.

*Output to the syslogfile has to be written argument by argument, because
*TC_write_syslog takes a ... type argument and not a va_list type one and it is
*possible to pass a ... type argument from this function's input to TC_write_syslog.
*formatstring
*varibale number of arguments to be written


*\par Owner:
Chetan Kekade


*\param[in]	pcFmtStr	formatstring
*\param[in]	...			varibale number of arguments to be written

*/
void dnvgl_trace_args( const char	* pcFmtStr	,	... )
{
	char	cIndentFmt[32+1] = {0};
	char	cBuffer[4096+1] = {0};
	va_list pArgs	;


	if ( pcFmtStr != NULL )
	{
		sprintf_s ( cIndentFmt , "%%%ds" , giDNVGLTraceIndention ) ;

		va_start ( pArgs , pcFmtStr ) ;

		if( geDNVGLTraceMethod == UNKNOWN_TRACE_METHOD )
			geDNVGLTraceMethod = SYSLOG_TRACE_METHOD;

		switch ( geDNVGLTraceMethod )
		{
		case OUTSTREAM_TRACE_METHOD :
			if ( gpcDNVGLTracePrefix != NULL )
				fprintf ( stdout , "%s"       , gpcDNVGLTracePrefix ) ;
			fprintf ( stdout , cIndentFmt , ""                    ) ;
			vfprintf ( stdout , pcFmtStr   , pArgs                 ) ;
			break ;

		case SYSLOG_TRACE_METHOD :
			if ( gpcDNVGLTracePrefix != NULL )
				TC_write_syslog ( "%s"       , gpcDNVGLTracePrefix ) ;
			TC_write_syslog ( cIndentFmt , ""                    ) ;
			dnvgl_write_syslog ( pcFmtStr   ,        pArgs          ) ;
			break ;

		case JOURNAL_TRACE_METHOD :
			if ( gpcDNVGLTracePrefix != NULL )
			{
				sprintf_s ( cBuffer , "%s" , gpcDNVGLTracePrefix ) ;
				vsprintf ( cBuffer + strlen ( gpcDNVGLTracePrefix ) , pcFmtStr , pArgs ) ;

			}
			else
			{
				vsprintf ( cBuffer , pcFmtStr , pArgs ) ;
			}
			if ( ( strlen(cBuffer) > 0 ) && ( *(cBuffer+strlen(cBuffer)-1) == '\n' ) )
				*(cBuffer+strlen(cBuffer)-1) = '\0' ;
			JOURNAL_comment ( cBuffer ) ;
			break ;

		default : ;
		}
		va_end ( pArgs ) ;
	}
	return ;
}


/*!
*\file dnvgl_trace_handling.cxx
*\par Description:
*Get The Local Time and Date.
*write Date and Time in syslog file.

*\par Owner:
*Chetan Kekade 

*/
void dnvgl_log_local_time( void )
{
	struct timeb timebuffer ;
	ftime( &timebuffer ) ;

	time_t tt = timebuffer.time ;
	struct tm *ptm = localtime( &tt ) ;
	date_t curDate ;
	curDate.year = ptm -> tm_year + 1900 ;
	curDate.month = ptm -> tm_mon ;
	curDate.day = ptm -> tm_mday ;
	curDate.hour = ptm -> tm_hour ;
	curDate.minute = ptm -> tm_min ;
	curDate.second = ptm -> tm_sec ;

	int msec = timebuffer.millitm ;

	char *strDate = NULL ;
	DATE_date_to_string( curDate, "%Y-%m-%d %H:%M:%S", &strDate ) ;

	TC_write_syslog( "\n %s.%03d", strDate, msec );

	return;
}

/*!
*\file dnvgl_trace_handling.cxx
*\par Description:
*Writes variable number of arguments to the syslog file.
*The format string is evaluated conversion specification (%..) by conversion
*specification. For each such conversion specification an argument is fetched
*from argument list and written accordingly to syslog file.
*formatstring varibale number of arguments to be written

*\par Owner:
*Chetan Kekade

*\param[in]	pcFmtStr	formatstring
*\param[in]	pArgs		varibale number of arguments to be written

*/
void dnvgl_write_syslog ( const char	* pcFmtStr	,	va_list		pArgs )
{
	const char	cConvChars[] = "cdeEfgGinopsuxX"	; // All C onversion characters that terminate
	// conversion specifications started with %
	char	* pcFmtChr = NULL			;
	char	* pcConvChar = NULL			;
	char	cFmtStrBuff[128+1] = ""		;

	const void	* pArg = NULL	;

	if ( pcFmtStr != NULL )
	{
		for ( pcFmtChr = (char*)pcFmtStr; *pcFmtChr != '\0' ; pcFmtChr ++ )
		{
			if ( *pcFmtChr == '%' )
			{
				pcConvChar = strpbrk ( pcFmtChr + 1 , cConvChars ) ;
				if ( pcConvChar != NULL )
				{
					memset ( cFmtStrBuff , 0, sizeof(cFmtStrBuff) ) ;
					strncpy ( cFmtStrBuff , pcFmtChr , pcConvChar - pcFmtChr + 1 ) ;
					pArg = va_arg ( pArgs , const void* ) ;
					TC_write_syslog ( cFmtStrBuff , pArg ) ;

					pcFmtChr = 	pcConvChar ;
				}
			}
			else TC_write_syslog ( "%c" , *pcFmtChr ) ;
		}
	}

	return ;
}

/*!
*\file dnvgl_trace_handling.cxx
*\par Description:
*Increments or decrements the golbal variable holding the current indention depth.
*\par Owner:
*Chetan Kekade
*\param[in]	cChange		'+' : increment, '-' : decrement

*/
void dnvgl_alter_indent ( const char	cChange )
{
	if ( cChange == '+' ) giDNVGLTraceIndention = giDNVGLTraceIndention + giDNVGLTraceIndentIncr ;
	else if ( cChange == '-' ) giDNVGLTraceIndention = giDNVGLTraceIndention - giDNVGLTraceIndentIncr ;

	return ;
}

/** 
*\file dnvgl_trace_handling.cxx
*\par Description:  
Depending on the global variable geDNVGLTraceFileLine, formats
the filename and the linenumber into a string and returns it
If global variable geDNVGLTraceFileLine is LONG, the entire filename and
linenumber are formatted to output parameter, if it is SHORt only the file
name and the line number are formatted to output parameter, otherwise output
parameter is set to "".   
*\par Owner:
*Chetan Kekade

*\param[in]	pcFile		filename
*\param[in]	iLine		linenumber
*\param[out]	cFileLine	formatted filename and linenumber
*/
void dnvgl_make_fileline (	const char	* pcFile , const int	iLine ,	char	cFileLine[FILELINELENGTH+1] )
{
	char	* pcAux = NULL	;

	strcpy ( cFileLine , "" ) ;

	if ( pcFile != NULL )
	{
		switch ( geDNVGLTraceFileLine )
		{
		case LONG_TRACE_FILELINE :
			sprintf ( cFileLine , "(%s/%d)" , pcFile , iLine ) ;
			break ;

		case SHORT_TRACE_FILELINE :
#ifdef _WIN32
			pcAux = (char*)strrchr ( pcFile , '\\' ) ;
#else
			pcAux = (char*)strrchr ( pcFile , '/' ) ;
#endif
			if ( pcAux != NULL ) pcAux = pcAux + 1 ;
			else				 pcAux = (char*)pcFile ;
			sprintf ( cFileLine , "(%s/%d)" , pcAux , iLine ) ;
			break ;

		default : ;
		}
	}

	return ;
}

/*!
*\file dnvgl_trace_handling.cxx
*\par Description:
*Returns the current trace method.
*\par Owner:
*Chetan Kekade
*\param[out]	eDNVGLTraceMethods
*/
enum eDNVGLTraceMethods dnvgl_trace_method ( void )
{
	return geDNVGLTraceMethod ;
}

/*!
*\file dnvgl_trace_handling.cxx
*\par Description:
*Gets the values that control the tracing.
*\par Owner:
*Chetan Kekade
*\param[out]	ptP4TraceOptions  structure holding the various trace options.
*/
void dnvgl_trace_get_options (	dnvgl_trace_options_t		* ptDNVGLTraceOptions )
{
	ptDNVGLTraceOptions->bDNVGLTraceIsOn       = gbDNVGLTraceIsOn       ;
	ptDNVGLTraceOptions->eDNVGLTraceMethod     = geDNVGLTraceMethod     ;
	ptDNVGLTraceOptions->pcDNVGLTracePrefix    = gpcDNVGLTracePrefix    ;
	ptDNVGLTraceOptions->iDNVGLTraceIndentIncr = giDNVGLTraceIndentIncr ;
	ptDNVGLTraceOptions->iDNVGLTraceIndention  = giDNVGLTraceIndention  ;
	ptDNVGLTraceOptions->eDNVGLTraceFileLine   = geDNVGLTraceFileLine   ;

	return ;
}

/*!
*\file dnvgl_trace_handling.cxx
*\par Description:
*Sets the values that control the tracing. 
*structure holding the various trace options


*\par Owner:
*Chetan Kekade

*\param[in]	tP4TraceOptions  structure holding the various trace options

*/
void dnvgl_trace_set_options (	const dnvgl_trace_options_t	tDNVGLTraceOptions )
{
	gbDNVGLTraceIsOn        = tDNVGLTraceOptions.bDNVGLTraceIsOn       ;
	geDNVGLTraceMethod      = tDNVGLTraceOptions.eDNVGLTraceMethod     ;
	gpcDNVGLTracePrefix     = tDNVGLTraceOptions.pcDNVGLTracePrefix    ;
	giDNVGLTraceIndentIncr  = tDNVGLTraceOptions.iDNVGLTraceIndentIncr ;
	giDNVGLTraceIndention   = tDNVGLTraceOptions.iDNVGLTraceIndention  ;
	geDNVGLTraceFileLine    = tDNVGLTraceOptions.eDNVGLTraceFileLine   ;

	gbDNVGLTraceInitialized = true ;

	return ;
}

/*!
*\file dnvgl_trace_handling.cxx
*\par Description:
*Get CurrentTime.

*\par Owner:
*Chetan Kekade
*/
void dnvgl_log_current_time(void)
{
	struct timeb timebuffer ;
	ftime( &timebuffer ) ;

	time_t tt = timebuffer.time ;
	struct tm *ptm = localtime( &tt ) ;
	date_t curDate ;
	curDate.year = ptm -> tm_year + 1900 ;
	curDate.month = ptm -> tm_mon ;
	curDate.day = ptm -> tm_mday ;
	curDate.hour = ptm -> tm_hour ;
	curDate.minute = ptm -> tm_min ;
	curDate.second = ptm -> tm_sec ;

	int msec = timebuffer.millitm ;

	char *strDate = NULL ;
	DATE_date_to_string( curDate, "%Y-%m-%d %H:%M:%S", &strDate ) ;

	TC_write_syslog( "The date/time is %s.%03d -", strDate, msec );

	return;
}

char * dnvgl_TRACE_object (
	const tag_t		objectTag ) 
{
	int		iObjectTraceLength = 0	;

	tag_t			classIdTag = NULLTAG					;
	tag_t			itemTag = NULLTAG						;
	tag_t			groupTag = NULLTAG						;
	tag_t			roleTag = NULLTAG						;
	tag_t			userTag = NULLTAG						;
	tag_t			relationTypeTag = NULLTAG				;
	static tag_t	sWorkspaceObjectClassIdTag = NULLTAG	;
	static tag_t	sItemClassIdTag = NULLTAG				;
	static tag_t	sItemRevisionClassIdTag = NULLTAG		;
	static tag_t	sPersonClassIdTag = NULLTAG				;
	static tag_t	sUserClassIdTag = NULLTAG				;
	static tag_t	sGroupClassIdTag = NULLTAG				;
	static tag_t	sRoleClassIdTag = NULLTAG				;
	static tag_t	sGroupMemberClassIdTag = NULLTAG		;
	static tag_t	sImanTypeClassIdTag = NULLTAG			;
	static tag_t	sImanRelationClassIdTag = NULLTAG		;

	char	* pcClassName = NULL					;
	char	cType[WSO_name_size_c+1] = ""			;
	char	cName[WSO_name_size_c+1] = ""			;
	char	cItemId[ITEM_id_size_c+1] = ""			;
	char	cItemRevisionId[ITEM_id_size_c+1] = ""	;
	char	cPersonName[SA_name_size_c+1] = ""		; 	
	char	cUserId[SA_user_size_c+1] = ""			; 	
	char	cGroupName[SA_name_size_c+1] = ""		; 	
	char	cRoleName[SA_name_size_c+1] = ""		; 	
	char  	cTypeName[TCTYPE_name_size_c+1] = ""	;

	static char		* spcObjectTrace = NULL		;

	logical		bValidTag = false		;
	logical		bIsDescendant = false	; 



	// Initialize output
	iObjectTraceLength = 3 + WSO_name_size_c                                                   + 1 +	// [c:class]
		4 + WSO_name_size_c                                                   + 1 +	// [t:type]
		4 + WSO_name_size_c                                                   + 1 +	// [n:name]	[g:group]	
		4 + WSO_name_size_c                                                   + 1 +	// [r:role]
		4 + ((ITEM_id_size_c>SA_user_size_c)?ITEM_id_size_c:SA_user_size_c)   + 1 +	// [i:userid/itemid]
		4 + ITEM_id_size_c                                                    + 1 +	// [r:itemrevisionid]
		1 ;						                                                    // \0
	if ( spcObjectTrace == NULL ) spcObjectTrace = (char*)MEM_alloc ( iObjectTraceLength * sizeof(char) ) ;
	memset ( spcObjectTrace , 0 , iObjectTraceLength ) ; 


	// Check input integrity
	if ( objectTag == NULLTAG ) goto LEAVE_RETURN ;
	POM_is_tag_valid  ( objectTag , &bValidTag ) ;
	if ( ! bValidTag ) goto LEAVE_RETURN ;


	// Get class of given object
	POM_class_of_instance ( objectTag , &classIdTag ) ;


	// POM_object => class
	if ( classIdTag != NULLTAG )
		POM_name_of_class ( classIdTag , &pcClassName ) ;
	if ( pcClassName != NULL ) 
	{
		strncat ( spcObjectTrace , "[c:" , 3 ) ;
		strncat ( spcObjectTrace , pcClassName , WSO_name_size_c ) ;
		strncat ( spcObjectTrace , "]" , 1 ) ;
		MEM_free ( pcClassName ) ; pcClassName = NULL ;
	}


	// WorkspaceObject => type, name
	if ( sWorkspaceObjectClassIdTag == NULLTAG )
		POM_class_id_of_class ( "WorkspaceObject" , &sWorkspaceObjectClassIdTag ) ;
	POM_is_descendant ( sWorkspaceObjectClassIdTag , classIdTag , &bIsDescendant ) ;
	if ( bIsDescendant )
	{
		WSOM_ask_object_type ( objectTag , cType ) ;
		strncat ( spcObjectTrace , " [t:" , 4 ) ;
		strncat ( spcObjectTrace , cType , WSO_name_size_c ) ;
		strncat ( spcObjectTrace , "]" , 1 ) ;

		WSOM_ask_name ( objectTag , cName ) ;
		strncat ( spcObjectTrace , " [n:" , 4 ) ;
		strncat ( spcObjectTrace , cName , WSO_name_size_c ) ;
		strncat ( spcObjectTrace , "]" , 1 ) ;


		// Item => item id
		if ( sItemClassIdTag == NULLTAG )
			POM_class_id_of_class ( "Item" , &sItemClassIdTag ) ;
		POM_is_descendant ( sItemClassIdTag , classIdTag , &bIsDescendant ) ;
		if ( bIsDescendant )
		{
			strncat ( spcObjectTrace , " [i:" , 4 ) ;
			ITEM_ask_id ( objectTag , cItemId ) ;
			strncat ( spcObjectTrace , cItemId , ITEM_id_size_c ) ;
			strncat ( spcObjectTrace , "]" , 1 ) ;

		} // Item

		else {

			// ItemRevision => item id, item revision id
			if ( sItemRevisionClassIdTag == NULLTAG )
				POM_class_id_of_class ( "ItemRevision" , &sItemRevisionClassIdTag ) ;
			POM_is_descendant ( sItemRevisionClassIdTag , classIdTag , &bIsDescendant ) ;
			if ( bIsDescendant )
			{
				ITEM_ask_item_of_rev ( objectTag , &itemTag ) ;
				ITEM_ask_id ( itemTag , cItemId ) ;
				strncat ( spcObjectTrace , " [i:" , 4 ) ;
				strncat ( spcObjectTrace , cItemId , ITEM_id_size_c ) ;
				strncat ( spcObjectTrace , "]" , 1 ) ;

				ITEM_ask_rev_id ( objectTag , cItemRevisionId ) ;
				strncat ( spcObjectTrace , " [r:" , 4 ) ;
				strncat ( spcObjectTrace , cItemRevisionId , ITEM_id_size_c ) ;
				strncat ( spcObjectTrace , "]" , 1 ) ;

			} // ItemRevision
		} 
	} // WorkspaceObject

	else { 

		// Person => name
		if ( sPersonClassIdTag == NULLTAG )
			POM_class_id_of_class ( "Person" , &sPersonClassIdTag ) ;
		POM_is_descendant ( sPersonClassIdTag , classIdTag , &bIsDescendant ) ;
		if ( bIsDescendant )
		{
			SA_ask_person_name ( objectTag , cPersonName ) ;
			strncat ( spcObjectTrace , " [n:" , 4 ) ;
			strncat ( spcObjectTrace , cPersonName , SA_name_size_c ) ;
			strncat ( spcObjectTrace , "]" , 1 ) ;

		} // Person

		else {

			// User => user id
			if ( sUserClassIdTag == NULLTAG )
				POM_class_id_of_class ( "User" , &sUserClassIdTag ) ;
			POM_is_descendant ( sUserClassIdTag , classIdTag , &bIsDescendant ) ;
			if ( bIsDescendant )
			{
				SA_ask_user_identifier ( objectTag , cUserId ) ;
				strncat ( spcObjectTrace , " [i:" , 4 ) ;
				strncat ( spcObjectTrace , cUserId , SA_user_size_c ) ;
				strncat ( spcObjectTrace , "]" , 1 ) ;

			} // User

			else {

				// Group => name
				if ( sGroupClassIdTag == NULLTAG )
					POM_class_id_of_class ( "Group" , &sGroupClassIdTag ) ;
				POM_is_descendant ( sGroupClassIdTag , classIdTag , &bIsDescendant ) ;
				if ( bIsDescendant )
				{
					SA_ask_group_name ( objectTag , cGroupName ) ;
					strncat ( spcObjectTrace , " [n:" , 4 ) ;
					strncat ( spcObjectTrace , cGroupName , SA_name_size_c ) ;
					strncat ( spcObjectTrace , "]" , 1 ) ;

				} // Group

				else {

					// Role => name
					if ( sRoleClassIdTag == NULLTAG )
						POM_class_id_of_class ( "Role" , &sRoleClassIdTag ) ;
					POM_is_descendant ( sRoleClassIdTag , classIdTag , &bIsDescendant ) ;
					if ( bIsDescendant )
					{
						SA_ask_role_name ( objectTag , cRoleName ) ;
						strncat ( spcObjectTrace , " [n:" , 4 ) ;
						strncat ( spcObjectTrace , cRoleName , SA_name_size_c ) ;
						strncat ( spcObjectTrace , "]" , 1 ) ;

					} // Role

					else {

						// GroupMember => ...
						if ( sGroupMemberClassIdTag == NULLTAG )
							POM_class_id_of_class ( "GroupMember" , &sGroupMemberClassIdTag ) ;
						POM_is_descendant ( sGroupMemberClassIdTag , classIdTag , &bIsDescendant ) ;
						if ( bIsDescendant )
						{
							SA_ask_groupmember_group ( objectTag , &groupTag ) ;
							SA_ask_group_name ( groupTag , cGroupName ) ;
							strncat ( spcObjectTrace , " [g:" , 4 ) ;
							strncat ( spcObjectTrace , cGroupName , SA_name_size_c ) ;
							strncat ( spcObjectTrace , "]" , 1 ) ;

							SA_ask_groupmember_role ( objectTag , &roleTag ) ;
							SA_ask_role_name ( roleTag , cRoleName ) ;
							strncat ( spcObjectTrace , " [r:" , 4 ) ;
							strncat ( spcObjectTrace , cRoleName , SA_name_size_c ) ;
							strncat ( spcObjectTrace , "]" , 1 ) ;

							SA_ask_groupmember_user ( objectTag , &userTag ) ;
							SA_ask_user_identifier ( userTag , cUserId ) ;
							strncat ( spcObjectTrace , " [u:" , 4 ) ;
							strncat ( spcObjectTrace , cUserId , SA_user_size_c ) ;
							strncat ( spcObjectTrace , "]" , 1 ) ;

						} // GroupMember

						else {

							// ImanType => ...
							if ( sImanTypeClassIdTag == NULLTAG )
								POM_class_id_of_class ( "ImanType" , &sImanTypeClassIdTag ) ;
							POM_is_descendant ( sImanTypeClassIdTag , classIdTag , &bIsDescendant ) ;
							if ( bIsDescendant )
							{
								TCTYPE_ask_name ( objectTag , cTypeName ) ;
								strncat ( spcObjectTrace , " [n:" , 4 ) ;
								strncat ( spcObjectTrace , cTypeName , TCTYPE_name_size_c ) ;
								strncat ( spcObjectTrace , "]" , 1 ) ;

							} // ImanType

							else {

								// ImanRelation => ...
								if ( sImanRelationClassIdTag == NULLTAG )
									POM_class_id_of_class ( "ImanRelation" , &sImanRelationClassIdTag ) ;
								POM_is_descendant ( sImanRelationClassIdTag , classIdTag , &bIsDescendant ) ;
								if ( bIsDescendant )
								{
									GRM_ask_relation_type ( objectTag , &relationTypeTag ) ;
									TCTYPE_ask_name ( relationTypeTag , cTypeName ) ;
									strncat ( spcObjectTrace , " [t:" , 4 ) ;
									strncat ( spcObjectTrace , cTypeName , TCTYPE_name_size_c ) ;
									strncat ( spcObjectTrace , "]" , 1 ) ;

								} // ImanRelation
							}
						}
					}
				}
			} 
		}
	}


LEAVE_RETURN : ;
	return spcObjectTrace ;
}
