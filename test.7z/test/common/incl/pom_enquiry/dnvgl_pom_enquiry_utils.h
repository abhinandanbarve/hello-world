/**
* \file dnvgl_utils.h
* \ingroup libAP4_dnvgl_common
* \verbatim
\par Description:
Header file for utility functions.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 30-May-2016   Vinay Kudari       Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_POM_ENQUIRY_UTILS_H
# define DNVGL_POM_ENQUIRY_UTILS_H

#include "dnvgl_common.h"
#include "dnvgl_utils.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"

#ifdef __cplusplus
extern "C" {
#endif

	DNVGLCOMEXP int dnvgl_get_comment_chains_for_activity(tag_t tActivityRev, tag_t **tpActivityCommentChain, int* ipCommentChainCount ,std::map<tag_t, std::vector<tag_t>> *mActivityCommentChains);

#ifdef __cplusplus
}
#endif

#endif //DNVGL_POM_ENQUIRY_UTILS_H