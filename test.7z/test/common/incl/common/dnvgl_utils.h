/**
* \file dnvgl_utils.h
* \ingroup libAP4_dnvgl_common
* \verbatim
\par Description:
Header file for utility functions.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 30-May-2016   Vinay Kudari       Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_UTILS_H
# define DNVGL_UTILS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_tinyxml.h"
#include <openxml/OfficeInterop.h>

#ifdef __cplusplus
extern "C" {
#endif

	//Macro to free the memory
#define DNVGL_MEM_FREE(x) if(x != NULL) {MEM_free(x); x = NULL;}

	#define DNVGL_IS_STRING_EMPTY(STRING) ((STRING == NULL) || (tc_strlen(STRING) <= 0))

	//Assign logged in user as AP4_BidManager and AP4_ProjectManager participants
	
	DNVGLCOMEXP int dnvgl_assign_participants(  tag_t* , std::vector<tag_t> *);

	//This function reads all the arguments and returns the values of all the arguments.
	DNVGLCOMEXP void dnvgl_get_handler_opts( IMAN_argument_list_t* givenArgList, char* pcGivenOptions, ... );

	DNVGLCOMEXP int dnvgl_dataset_attach( char* cpDatasetType, char* cpRefName, char* cpFileName, char* cpFilePath, tag_t tDocumentRevTag, tag_t *opDatasetTag );

	//This function creates a dataset based on the type of the file. Attach the file as named reference to the dataset. Then create a Technical document. Attach the created dataset to project document revision with our custom relation. Then attach the project document to the given project folder.
	//DNVGLCOMEXP int createAndAttachDocument( const char* cpFilePath,const char* cpFileName, tag_t tProjectFolderTag );

	DNVGLCOMEXP int dnvgl_split( std::string str, char delimiter, std::vector<std::string> &vResult );

	DNVGLCOMEXP int dnvgl_multi_delimiter_split( std::string str, char* delimiters, std::vector<std::string> &vResult );

	//Change the ownership of input object to given user and group.
	DNVGLCOMEXP int dnvgl_change_ownership( tag_t inputObject, const char* userName, const char* groupName );

	//Compare dates.
	DNVGLCOMEXP int dnvgl_compare_dates( date_t targetDate, date_t inputCompareDate, logical compareDateOnly );

	//Get current date and time.
	DNVGLCOMEXP int dnvgl_get_current_date_time( date_t* valueDate );
	
	//Create transmittal XML from list of files in transmittal zip.
	DNVGLCOMEXP int dnvgl_transmittal_xml_creation_from_files( const char* cpFilePath, const char* cpTxtFilePath );

	//Read MDR excel file.
	DNVGLCOMEXP int  dnvgl_read_excel(const char* cpExcelPath,const char* cpConfigXmlPath,const char* cpMdrXmlPath);

	DNVGLCOMEXP int dnvgl_read_config_file(const char* cpConfigFilePath, std::string *strSheetName, std::string *strStartNo, std::string *strEndNo, std::string *strENSDoc, std::string *strRev, std::string *strDocTitle);

	//This function will unzip the given zip to the given location input parameter. It will iterate in the extracted folder and get the file list present in the folder.
	DNVGLCOMEXP int dnvgl_get_files_name_from_zip(const char* pcZipFileNm, const char * pcUnZipFolderNM, std::vector<std::string> &vFiles);

	DNVGLCOMEXP int dnvgl_read_transmittal_xml( const char* cpXmlFilePath, std::map<std::string,std::string> &mfileName );

	DNVGLCOMEXP int dnvgl_generate_fullpath(char* sDirName, char* sFileName, char* sCreationDate, char** sFullPath);

	DNVGLCOMEXP int dnvgl_read_mdr_xml(const char* cpXmlFilePath ,std::vector<std::map<std::string,std::string>> &vTechDocAttr , std::vector<std::map<std::string,std::string>> &vTechDocRevAttr );

	//DNVGLCOMEXP int dnvgl_create_document(std::map<std::string,std::string> mAttributeMap, tag_t tProjectFolderTag , tag_t * tCreatedDocTag );
	DNVGLCOMEXP int dnvgl_create_input_for_techdoc(std::map<std::string,std::string> mTechDocAttributesMap, std::map<std::string,std::string> mTechDocRevAttributesMap , tag_t * tCreatedInputTag );
	
	DNVGLCOMEXP int dnvgl_create_documents(int iNoOfObject, int * iQuantities , tag_t * tpInputTags, tag_t tDocumentRegFolder );

	DNVGLCOMEXP int dnvgl_attach_dataset_to_techdoc( const char* cpFilePath,tag_t tCreatedDocTag ) ; 
	
	//This function will give the SubContractor Folder tag from the Document Register Folder , if no SubContractor Folder is present then it will create new SubContractor Folder.
	DNVGLCOMEXP int dnvgl_get_unassignedfiles_folder( tag_t tDocRegisterTag, tag_t * tSubContractorTag);

	DNVGLCOMEXP int dnvgl_create_dataset( const char* cpFilePath, tag_t* tDataset );

	DNVGLCOMEXP int dnvgl_create_relation( tag_t tPrimaryObj, tag_t tDataset, const char* cpRelationName );

	DNVGLCOMEXP int DNVGL_current_get_time_stamp(char* format, char** timestamp);

	DNVGLCOMEXP date_t dnvgl_get_date_from_string_MDR(const char* timestamp);
	
	DNVGLCOMEXP int dnvgl_grm_get_secondary_obj_of_type_with_relation ( tag_t tPrimaryObj, char*   pszRelationTypeName, char*   pszSecondaryObjType, tag_t** pptSecondaryObjects, tag_t** pptRelationObjects, int* piObjectCount );

	DNVGLCOMEXP int dnvgl_normalize_eform_string(std::string& strInput) ;

	DNVGLCOMEXP int dnvg_add_days_to_date( date_t dInpDate , int days, date_t* dOutDate );
	
	DNVGLCOMEXP int dnvg_get_project_rev_from_tech_doc_rev( tag_t tTechDocRevTag , tag_t *tProjectRevTag );

	DNVGLCOMEXP int dnvgl_get_employee_number_of_line_manager(tag_t inputPersonTag ,  char** outputPersonTag);

	DNVGLCOMEXP int dnvgl_get_employee_id_of_line_manager(char * cpEmployeeId, tag_t orgUnitTag, char ** cpOutputManagerId);
	
	DNVGLCOMEXP int dnvgl_get_group_member_from_employee_id(char * cGroupName,char* cpRoleName, char * cpEmoployeeId, tag_t * groupMemberTag);

	DNVGLCOMEXP int dnvgl_add_participant( tag_t tProjectRev, tag_t tGroupMember, char* cpParticipantType );

	DNVGLCOMEXP int dnvgl_grm_get_secondary_obj_of_type(tag_t tPrimaryObj, std::string sRelationTypeName, std::string sSecondaryObjType, std::vector<tag_t>& secondaryObjects);
	DNVGLCOMEXP int checkIsInstanceOf(tag_t& inputTag, const char* expectedType, bool& isTypeOf);
	DNVGLCOMEXP int dnvgl_add_xml_element(tinyxml2::XMLDocument &doc, tinyxml2::XMLNode *newNode, std::string &strSeach);
	DNVGLCOMEXP int dnvgl_get_comment_letter_bookmarks(char* cpPrefName, const char* cpEformID, std::vector<std::string> &vEditabelBookmarks ) ;

	DNVGLCOMEXP int dnvgl_get_comment_chain_count_for_project( tag_t &tProjectRev, std::string &strCommentChainId ) ;

	DNVGLCOMEXP int dnvgl_create_comment_count_for_reply( std::vector<std::string> &vReplyData ) ;

	DNVGLCOMEXP int dnvgl_sort_comment_chain_by_page( std::vector<std::pair<tag_t, int>> &vCommentChain ) ;

	DNVGLCOMEXP int dnvgl_create_wordinterop_object( OfficeInterop::WordCppService *& wordServiceObj, const char* cpFilepath ) ;

	DNVGLCOMEXP int dnvgl_create_excelinterop_object( OfficeInterop::ExcelCppService *& excelServiceObj, const char* cpFilepath ) ;
	//macros starts
	#define DNVGL_STRCPY(destiStr,sourceStr){\
		int sourceStrLen = (int) tc_strlen(sourceStr);\
		destiStr = (char*)MEM_alloc((sourceStrLen + 1)* sizeof(char));\
		tc_strcpy(destiStr, sourceStr);\
		}

	#define DNVGL_STRCAT(destiStr,sourceStr){\
		int sourceStrLen = (int) tc_strlen(sourceStr);\
		int destiStrLen = 0;\
		if(destiStr != NULL)\
		destiStrLen = (int) tc_strlen (destiStr);\
		destiStr = (char*)MEM_realloc(destiStr, (sourceStrLen + destiStrLen + 1)* sizeof(char));\
		if(destiStrLen == 0)\
		tc_strcpy(destiStr, sourceStr);\
	else\
		tc_strcat(destiStr, sourceStr);\
		}

#ifdef __cplusplus
}
#endif

#endif //DNVGL_UTILS_H