/**
* \file dnvgl_tcproject_handling.h
* \ingroup libAP4_dnvgl_common
* \verbatim
  \par Description:
    Header file for TC project handling functions.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 12-May-2016   Nikhilesh Khatra    Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_TCPROJECT_HANDLING_H
# define DNVGL_TCPROJECT_HANDLING_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"

#ifdef __cplusplus
extern "C" {
#endif

	//Find the existing project based on project Id or creating Project with provided Id and Name
	DNVGLCOMEXP int dnvgl_create_tcproject( tag_t, tag_t* );

	//Get the TC project corresponding to AP4_Project
	DNVGLCOMEXP int dnvgl_get_tcproject( tag_t, tag_t* );

	//Adding user to project
	DNVGLCOMEXP int dnvgl_add_user_to_tcproject( tag_t, tag_t, bool );

	//Removing user from project
	DNVGLCOMEXP int dnvgl_remove_user_from_tcproject( tag_t, tag_t );

#ifdef __cplusplus
}
#endif

#endif //DNVGL_TCPROJECT_HANDLING_H