/**
* \file dnvgl_schedule_handling.h
* \ingroup libAP4_dnvgl_common
* \verbatim
  \par Description:
    Header file for AP4_Project handling functions.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 30-May-2016   Sanjay Sah      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_SCHEDULE_HANDLING_H
# define DNVGL_SCHEDULE_HANDLING_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"

#ifdef __cplusplus
extern "C" {
#endif

	//Function to copy a schedule.
	DNVGLCOMEXP int dnvgl_copy_schedule( tag_t *schedule, tag_t *newSchedule );

	//Function to find a schedule
	DNVGLCOMEXP int dnvgl_find_schedule( const char* scheduleID, tag_t *schedule );

	//Function to shift a schedule
	DNVGLCOMEXP int dnvgl_shift_schedule( tag_t tSchedule, date_t dtStartDate, date_t dtEndDate );
	

#ifdef __cplusplus
}
#endif

#endif //DNVGL_SCHEDULE_HANDLING_H