/**
* \file dnvgl_constants.h
* \ingroup libAP4_dnvgl_common
* \verbatim
* \par Description:
   Header file for constants.
* \par Since: Release1
* \par ENVIRONMENT : C++, ITK
*
*\endverbatim
* \par Owner:
* Nikhilesh Khatra
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                  Description of Change
* 12-May-2016   Nikhilesh Khatra      Initial Creation
* 16-Nov-2016   Sanjay Sah            Added comment handling constants
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_CONSTANTS_H
# define DNVGL_CONSTANTS_H

//Error Types
#define DNVGL_ERROR_MSG                         "DNVGL_ERROR_MSG"
#define DNVGL_WARNING_MSG                       "DNVGL_WARNING_MSG"
#define DNVGL_INFORMATION_MSG                   "DNVGL_INFORMATION_MSG"

//Relations
#define AP4_PROJECT_STRUCTURE_RELATION			"AP4_ProjectStructRelation"
#define AP4_PROJECT_SCHEDULE_RELATION			"AP4_ProjectScheduleRelation"
#define AP4_DOCUMENT_RELATION					"AP4_DocumentRelation"
#define AP4_FOLDER_DOCUMENT_RELATION			"AP4_FolderDocumentRelation"
#define AP4_CUSTOMER_OFFICE_ADDRESS				"AP4_CustomerOfficeAddress"
#define AP4_CUSTOMER_INVOICE_ADDRESS			"AP4_CustomerInvoiceAddress"
#define AP4_CUSTOMER_SHIPPING_ADDRESS			"AP4_CustomerShippingAddress"
#define AP4_PROJECT_CUSTOMER					"AP4_ProjectCustomer"
#define AP4_CUSTOMER_ADDRESS					"AP4_CustomerAddress"
#define AP4_DATASETS							"AP4_Datasets"
#define AP4_CUSTOMERCONTACT						"AP4_ProjectCustomerContact"
#define AP4_COMMENTCHAINRELATION				"AP4_CommentChainRelation"
#define AP4_EMPLOYEE_ORG_UNIT					"AP4_EmployeeOrgUnit"
#define AP4_CHILD_ORG_UNIT						"AP4_ChildOrgUnit"
#define AP4_IMPACTEDELEMENTS					"AP4_ImpactedElements"
#define AP4_ASSETRELATION						"AP4_AssetRelation"
#define AP4_COMMENTLETTERRELATION				"AP4_CommentLetterRelation"
#define AP4_ASSETFIELDRELATION					"AP4_AssetFieldRelation"
#define AP4_FIELDRELATION					    "AP4_FieldRelation"
#define AP4_SUCTEMPLATERELATION					"AP4_SUCTemplateRelation"
#define AP4_FOLDER_SCHEDULE_RELATION			"AP4_FolderScheduleRelation"
#define AP4_SURVEYOR_CHEKLST_RELATION			"AP4_SurveyorCheklstRelation"
#define AP4_ACTIVITYDOCRELATION					"AP4_ActivityDocRelation"
#define AP4_PROJVERIPLANRELATION				"AP4_ProjVerifPlanRelation"
#define AP4_SCERELATION							"AP4_SCERelation"
#define AP4_PERFORMANCESRANDARDS				"AP4_PerformanceStandards"
#define AP4_APPROVALACTIVITIES					"AP4_ApprovalActivities"
#define AP4_ACTIVITYTASKRELATION				"AP4_ActivityTaskRelation"
#define AP4_FRAMEAGREEMENTSRELATION				"AP4_FrameAgreementsRelation"
#define AP4_CHILDACTIVITYRELATION				"AP4_ChildActivity"
#define AP4_SCHEDULETASKEXPRELATION				"AP4_ScheduleTaskExpRelation"
#define AP4_PROJECTSECCUSTCONTACT               "AP4_ProjectSecCustContact"

//OOTB Relations
#define TC_ATTACHES_RELATION					"TC_Attaches"
#define IMAN_REFERENCE_RELATION					"IMAN_reference"

//OOTB Object Types
#define SCHEDULE							    "Schedule"
#define SCHEDULETASK							"ScheduleTask"
#define TASKTYPE_S								"S"
#define TASKTYPE_SS								"SS"

//Object types
#define AP4_TRANSMITTAL_DOC						"AP4_Transmittals"
#define AP4_DOCUMENT_REGISTER					"AP4_DocumentRegister"
#define AP4_GOVERNING_DOCUMENT					"AP4_GoverningDocuments"
#define AP4_INVOICE_FOLDER						"AP4_InvoiceFolder"
#define AP4_SUBCONTRACTORFOLDER					"AP4_SubContractorFolder"
#define AP4_PROJECT_FOLDER						"AP4_ProjectFolder"
#define AP4_PROJECT								"AP4_Project"
#define AP4_PROJECT_REVISION					"AP4_ProjectRevision"
#define AP4_INVOICE								"AP4_Invoice"
#define AP4_INVOICE_REVISION					"AP4_InvoiceRevision"
#define AP4_MDR_DOCUMENT						"AP4_MDRDocument"
#define AP4_MDR_DOCUMENT_REVISION				"AP4_MDRDocumentRevision"
#define AP4_PROJECT_DOC_REVISION				"AP4_ProjectDocRevision"
#define AP4_PROJ_DOCUMENT_REVISION				"AP4_ProjDocumentRevision"
#define AP4_TECH_DOC_REVISION					"AP4_TechDocRevision"
#define AP4_TRANSMIT_DOC_REVISION				"AP4_TransmitDocRevision"
#define AP4_DOCUMENT_REVISION					"AP4_DocumentRevision"
#define AP4_FRAMEAGREE_REVISION					"AP4_FrameAgreeRevision"
#define AP4_PROJECT_DOC							"AP4_ProjectDoc"
#define AP4_TECH_DOCUMENT					    "AP4_TechDoc"
#define AP4_REQUEST_FORM_OBJECT			        "AP4_RequestForm"
#define AP4_SUBCONTRACTOR_FOLDER			    "AP4_SubContractorFolder"
#define AP4_ZIP								    "AP4_Zip"
#define TEXT_DATASET							"Text"
#define MSEXCEL_DATASET							"MSExcel"
#define MSEXCELX_DATASET						"MSExcelX"
#define MSWORDX_DATASET                         "MSWordX"
#define PDF_DATASET								"PDF"
#define PDF_REFERENCE_NAME						"PDF_Reference"
#define DATASET                                 "Dataset"
#define AP4_UNASSIGNED_FILES					"AP4_UnassignedFiles"
#define AP4_MDMCUSTOMER				        	"AP4_MDMCustomer"
#define AP4_ADDRESS				        		"AP4_Address"
#define AP4_PROP_DOCUMENT						"AP4_PropDocument"
#define AP4_PURCHASE_ORDER_DOCUMENT				"AP4_PODocument"
#define AP4_SFA_DOCUMENT						"AP4_SFADocument"
#define AP4_CONTRACT_DOCUMENT					"AP4_ContDocument"
#define AP4_CTR_DOCUMENT						"AP4_CTRDocument"
#define AP4_COMMTEMPLATE				        "AP4_CommTemplate"
#define AP4_COMMENT								"AP4_Comment"
#define AP4_COMMENT_CHAIN						"AP4_CommentChain"
#define AP4_COMMENT_CHAIN_RELATION				"AP4_CommentChainRelation"
#define AP4_ORGANIZATION_UNIT					"AP4_OrganizationUnit"
#define AP4_SURVEYORPACKAGEFOLDER				"AP4_SurveyorPackageFolder"
#define AP4_MANAGEMENT							"AP4_Management"
#define AP4_DELIVERABLE							"AP4_Deliverable"
#define AP4_ACTIVITYREVISION					"AP4_ActivityRevision"
#define AP4_ACTIVITY_ITEM						"AP4_Activity"
#define AP4_VERIFPLAN							"AP4_VerifPlan"
#define AP4_VERIFPLANREVISION					"AP4_VerifPlanRevision"
#define AP4_SCE									"AP4_SCE"
#define AP4_PERFCRITERIAREVISION				"AP4_PerfCriteriaRevision"
#define AP4_ACTIVITYREVISION					"AP4_ActivityRevision"
#define AP4_PERFCRITERIA						"AP4_PerfCriteria"
#define AP4_SCEREVISION							"AP4_SCERevision"
#define AP4_WVSDOCREVISION						"AP4_WVSDocRevision"
#define AP4_ASSETREVISION						"AP4_AssetRevision"
#define AP4_FIELDREVISION						"AP4_FieldRevision"

#define ITEM									"Item"


//OOTB Attributes
#define OBJECT_TYPE								"object_type"
#define ITEM_ID									"item_id"
#define PRIMARY_OBJECT							"primary_object"
#define SECONDARY_OBJECT						"secondary_object"
#define ASSIGNEE								"assignee"
#define USER									"user"
#define OBJECT_NAME							    "object_name"
#define IS_TEMPLATE								"is_template"
#define IMAN_BASED_ON							"IMAN_based_on"
#define CREATION_DATE							"creation_date"
#define ORIGINAL_FILE_NAME						"original_file_name"
#define FILE_NAME								"file_name"
#define SD_PATH_NAME							"sd_path_name"
#define OWNING_USER								"owning_user"
#define USER_NAME								"user_name"
#define USER_ID								    "user_id"
#define HAS_PARTICIPANT							"HasParticipant"
#define WORKSPACE_OBJECT						"WorkspaceObject"
#define RELEASE_STATUS_LIST					 	"release_status_list"
#define PROJECT_LIST							"project_list"
#define FINISH_DATE								"finish_date"
#define FND0_ASSIGNEE_USER						"fnd0AssigneeUser"
#define FND0_ASSIGNEE_GROUP						"fnd0AssigneeGroup"
#define PA7										"PA7"
#define PERSON									"person"
#define FND0TASKTYPESTRING						"fnd0TaskTypeString"
#define FND0WORKFLOWINITIATOR					"fnd0WorkflowInitiator"
#define WORKFLOW_TEMPLATE						"workflow_template"
#define WORKFLOW_TRIGGER_TYPE					"workflow_trigger_type"
#define ITEM_ID									"item_id"
#define AP4_TEMPLATETYPE						"ap4_templatetype"
#define FND0SUMMARYTASK							"fnd0SummaryTask"
#define START_DATE								"start_date"
#define FINISH_DATE								"finish_date"

//Custom Attributes
#define AP4_PROJECT_NAME                        "ap4_project_name"
#define AP4_PARENT_FOLDER					    "ap4_parent_folder"
#define AP4_PROJECT_BACKPOINTER					"ap4_project_backpointer"
#define AP4_PROJFOLDER_BACKPOINTER			    "ap4_projfolder_backpointer"
#define AP4_START_DATE							"ap4_start_date"
#define AP4_END_DATE							"ap4_end_date"
#define AP4_ESTIMATED_END_DATE					"ap4_estimated_end_date"
#define AP4_PROJECT_TYPE						"ap4_project_type"
#define AP4_PROJECT_TEMPLATE_ID					"ap4_project_template_id"
#define AP4_SCHEDULE_TEMPLATE_ID				"ap4_schedule_template_id"
#define AP4_PROJECT_STAGE						"ap4_project_stage"
#define AP4_PROJECT_STATUS_CODE					"ap4_project_status_code"
#define AP4_LEAD_CREATED_BY						"ap4_lead_created_by"
#define AP4_LEAD_CREATION_DATE					"ap4_lead_creation_date"
#define AP4_OPPORTUNITY_CREATED_BY				"ap4_opportunity_created_by"
#define AP4_OPPORTUNITY_CREATE_DATE				"ap4_opportunity_create_date"
#define AP4_PROJECT_CREATED_BY					"ap4_project_created_by"
#define AP4_PROJECT_CREATION_DATE				"ap4_project_creation_date"
#define AP4_DOCUMENT_TYPE						"ap4_document_type"
#define AP4_REQUEST_TYPE						"ap4_request_type"
#define AP4_USER_FIRST_NAME						"ap4_user_first_name"
#define AP4_USER_LAST_NAME						"ap4_user_last_name"
#define AP4_EMAIL_ID							"ap4_email_id"
#define AP4_DNV_ID								"ap4_dnv_id"
#define AP4_SERVICE_AREA						"ap4_service_area"
#define AP4_SERVICE_LINE						"ap4_service_line"
#define AP4_SERVICE_CODE						"ap4_service_code"
#define AP4_CURRENCY_CODE						"ap4_currency_code"
#define AP4_COST_CENTER							"ap4_cost_center"
#define AP4_MARKET_SEGMENT						"ap4_market_segment"
#define AP4_LOCAL_PROJECT_VALUE					"ap4_local_project_value"
#define AP4_PROBABILITY							"ap4_probability"
#define	AP4_SALES_STAGE							"ap4_sales_stage"
#define AP4_AFFINITAS_NUMBER					"ap4_affinitas_number"
#define AP4_EXECUTIVE_SUMMARY					"ap4_executive_summary"
#define AP4_OPPORTUNITY_LOST_REASON				"ap4_opportunity_lost_reason"
#define AP4_PROPOSAL_DEADLINE					"ap4_proposal_deadline"
#define AP4_PROPOSAL_SENT_DATE					"ap4_proposal_sent_date"
#define AP4_CAPEX_OR_OPEX						"ap4_capex_or_opex"
#define AP4_ESTIMATED_CLOSURE_DATE				"ap4_estimated_closure_date"
#define AP4_CREATED_BY							"ap4_created_by"
#define AP4_RELATION_CREATION_DATE				"ap4_relation_creation_date"	
#define AP4_LAST_MOD_BY							"ap4_last_mod_by"
#define AP4_LAST_MOD_DATE						"ap4_last_mod_date"
#define AP4_ADDRESS_TYPE						"ap4_address_type"
#define AP4_CUSTOMER_POINT_OF_CONTACT			"AP4_CustomerPointOfContact"
#define AP4_PROJECT_CUSTOMER_CONTACT			"AP4_ProjectCustomerContact"
#define AP4_EXCHANGE_VERSION                    "ap4_exchange_version"
#define AP4_INVOICE_TYPE                        "ap4_invoice_type"
#define AP4_TRANSMITTAL_NO						"ap4_transmittal_no"
#define AP4_DNV_STATUS							"ap4_dnv_status"
#define AP4_COMMENT_TYPE                        "ap4_comment_type"
#define AP4_VERIFICATION_REMARK					"ap4_verification_remark"
#define AP4_INT_VERIFICATION_DONE               "ap4_int_verification_done"
#define AP4_INT_VERIFIRE						"ap4_int_verifier"
#define AP4_VERIFICATION_DATE                   "ap4_int_verification_date"
#define AP4_PUBLISHER							"ap4_publisher" 
#define AP4_PUBLISHED_DATE						"ap4_published_date" 
#define AP4_RICH_TEXT							"ap4_rich_text"
#define AP4_LAST_UPDATED_BY                     "ap4_last_updated_by"
#define AP4_LAST_UPDATED_ON						"ap4_last_updated_on"       
#define AP4_STATUS                              "ap4_status"
#define AP4_INTERNAL_REMARK						"ap4_internal_remark"
#define AP4_CHAIN_TYPE							"ap4_chain_type"
#define AP4_STATUS								"ap4_status"
#define AP4_TITLE								"ap4_title"
#define AP4_SECTION								"ap4_section"
#define AP4_PAGE								"ap4_page"
#define AP4_ACTION_RESPONSIBLE					"ap4_action_responsible"
#define AP4_PRIMARY_TARGET						"ap4_primary_target"
#define AP4_DESCIPLINE							"ap4_discipline"
#define AP4_COMMENTS							"ap4_comments"
#define AP4_LAST_COMMENT						"ap4_last_comment"
#define AP4_FIRST_COMMENT						"ap4_first_comment"
#define AP4_PROJECT_ATTRIBUTE					"ap4_project"
#define AP4_PROJECT_REVISION_ATTRIBUTE			"ap4_project_revision"
#define AP4_COMMENTS_TEXT						"ap4_comments_text"
#define AP4_CURRENT_ASSIGNEE					"ap4_current_assignee"
#define OBJECT_STRING                           "object_string" 
#define AP4_CURR_CODE_LEGAL_ENTITY				"ap4_curr_code_legal_entity"
#define AP4_COMMENT_ID							"ap4_comment_id"
#define AP4_COMMENT_SEQ_ID						"ap4_comment_seq_id"
#define AP4_ACTIVITY                             "ap4_activity"
#define AP4_IS_MAIN_PROJECCT                     "ap4_is_main_project"
#define AP4_TOTAL_COMMENT_COUNT                 "ap4_total_comment_count"
#define AP4_EXPENSES_INTERNAL_COSTS				"ap4_expenses_internal_costs"
#define AP4_DOCUMENT_STATUS                     "ap4_document_status"
#define AP4_STATUS_REMARK                       "ap4_status_remark"
#define AP4_MANAGER_ID							"ap4_manager_id"
#define AP4_MSA_TSA_RATE						"ap4_msa_tsa_rate"
#define AP4_SERVICE_CODE						"ap4_service_code"
#define AP4_LOCAL_PROJECT_VALUE					"ap4_local_project_value"
#define AP4_CURRENCYCODES_LOV					"AP4_CurrencyCodes_LOV"
#define AP4_DNV_CUSTOMER_ID                     "ap4_dnv_customer_id"
#define AP4_PROJ_MEMBERS						"ap4_proj_members"
#define AP4_SCHEDULE_TASKS						"ap4_schedule_tasks"
#define AP4_CUSTOMER_DOC_NO						"ap4_customer_doc_no"
#define AP4_CUSTOMER_DOC_REV_NO					"ap4_customer_doc_rev_no"
#define AP4_DOCUMENT_STATUS_CODE				"ap4_document_status_code"
#define AP4_TEMPLATETYPE				        "ap4_templatetype"
#define AP4_VERSION								"ap4_version"
#define AP4_SERVICETYPE				            "ap4_servicetype"
#define AP4_PROJECT_FOLDER_PROP					"ap4_project_folder"
#define AP4_FRAMEAGREEMENTNAME				    "ap4_frameagreementname"
#define AP4_FRAMEAGREEMENTNUMBER				"ap4_frameagreementnumber"
#define AP4_SCE_PROP							"ap4_sce"
#define AP4_PERF_CRITERIA						"ap4_perf_criteria"

//Custom Attributes on ScheduleTask
#define AP4_ETC									"ap4_etc"
#define AP4_ACTUAL_HOURS						"ap4_actual_hours"
#define AP4_EAC									"ap4_eac"
#define AP4_PCT_COMPLETION						"ap4_pct_completion"
#define AP4_EAC_MIN_BUDGET						"ap4_eac_min_budget"
#define AP4_WORK_EFFORT_STRING                  "fnd0WorkEffortString"
#define AP4_FEE_REVENUE_FORECAST                "ap4_fee_revenue_forecast"
#define AP4_AVG_BILL_RATE                       "ap4_avg_bill_rate"
#define AP4_LABOUR_COST_FORECAST                "ap4_labour_cost_forecast"
#define AP4_COST_RATE                           "ap4_cost_rate"
#define AP4_MSA_TSA_COST_FORECAST               "ap4_msa_tsa_cost_forecast"
#define AP4_MSA_TSA								"ap4_msa_tsa"
#define AP4_OPERATING_MARGIN_FORECAST           "ap4_operate_margin_forecast"
#define AP4_REVENUE								"ap4_revenue"
#define AP4_EXTERNAL_RATE						"ap4_external_rate"
#define AP4_RAW_COST							"ap4_raw_cost"
#define AP4_CTR_NUMBER							"ap4_ctr_number"
#define AP4_COST_RATE_RT						"ap4_cost_rate_rt"
#define AP4_REVENUE_RT							"ap4_revenue_rt"
#define AP4_RAW_COST_RT							"ap4_raw_cost_rt"
#define AP4_AVG_BILL_RATE_RT					"ap4_avg_bill_rate_rt"
#define AP4_MSA_TSA_RT							"ap4_msa_tsa_rt"
#define AP4_ACTUAL_HOURS_RT						"ap4_actual_hours_rt"
#define AP4_ETC_RT								"ap4_etc_rt"
#define AP4_EAC_RT								"ap4_eac_rt"
#define AP4_EAC_MIN_BUDGET_RT					"ap4_eac_min_budget_rt"
#define AP4_EXTERNAL_RT							"ap4_external_rate_rt"
#define AP4_SCHEDULE_TASK_TYPE					"ap4_schedule_task_type"
#define AP4_SCHEDULETASKEXPRELATION             "AP4_ScheduleTaskExpRelation"
#define AP4_EXPENSES_INTERNAL_COSTS             "ap4_expenses_internal_costs"

//Custom attribute values
#define MANA_COMMLETTERTEMPLATE					"MANA_CommLetterTemplate"
#define DELI_COMMLETTER							"DELI_CommLetter"

//Constant for Field Revision
#define AP4_DELIVERABLE                         "AP4_Deliverable"
#define AP4_TEMPLATE_TYPE                       "ap4_templatetype"
#define AP4_VALIDATION_DATE                     "ap4_validation_date"
#define AP4_DELIVERABLEREVISION                 "AP4_DeliverableRevision"


//Field Revision lov values
#define DELI_COC								"DELI_COC"
#define DELI_VCARECO                            "DELI_VCAReco"
#define DELI_VCAMEMO                            "DELI_VCAMemo"

//LOV Values
#define LEAD									"Lead"
#define OPPORTUNITY								"Opportunity"
#define BIDDING									"Bidding"
#define PROJECT									"Project"
#define ORDER									"Order"
#define ACTIVE_PROJECT							"Active Project"
#define SUBCONTRACTOR							"Sub Contractor"
#define PROPOSALDOCUMENT						"Proposal Document"
#define PURCHASEORDER							"Purchase Order"
#define SFA										"SFA"
#define CONTRACTDOCUMENT						"Contract Document"
#define ACTIVE									"Active"
#define COMMENT_TYPE_COMMENT					"Comment"
#define COMMENT_TYPE_REPLY						"Reply"
#define ACTION_REQUIRED							"Action Required"
#define IMPORTANT_NOTE							"Important Note"
#define VERIFIED_STATE							"Internally Verified"
#define REJECTED_STATE							"Rejected"
#define ISSUED_STATE							"Issued"
#define NOT_SET_STATE							"Not Set"
#define EFORM_CATEGORY_STANDARD_PROPOSAL		"Standard Proposal"
#define EFORM_CATEGORY_ADVISORY_SERVICES		"Advisory Services"
#define DRAFT_STATUS							"Draft"
#define SURVEYOR_TASK							"Surveyor Task"
#define SERVICEAREA_VCA							"1-2W2RKI"
#define SERVICEAREA_VMC							"1-8STM08"
#define TRN_TEXT								"TRN"
#define VAR_TEXT								"VAR"

//Roles
#define PROJECT_ADMINISTRATOR					"Project Administrator"
#define PROJECT_MANAGER							"Project Manager"
#define BID_MANAGER								"Bid Manager"
#define SUB_CONTRACTOR							"Sub Contractor"
#define CUSTOMER								"Customer"
#define FINANCIAL_CUSTOMER						"Financial Customer"
#define TECHNICAL_CUSTOMER						"Technical Customer"
#define BID_MANAGER								"Bid Manager"

//Groups
#define PROJECT_ADMINISTRATION					"Project Administration"
#define CUSTOMER_GROUP							"Customer.DNVGL"

//Participant Types
#define AP4_BIDMANAGER							"AP4_BidManager"
#define AP4_PROJECTMANAGER						"AP4_ProjectManager"
#define AP4_SUBCONTRACTOR						"AP4_SubContractor"
#define AP4_CUSTOMER						    "AP4_Customer"
#define AP4_SALESTEAMMEMBER						"AP4_SalesTeamMember"
#define AP4_BID_RESPONSIBLE						"AP4_BidResponsible"
#define AP4_PROJECT_SPONSOR						"AP4_ProjectSponsor"
#define AP4_DISCIPLINELEAD                      "AP4_DisciplineLead"   
#define AP4_DOCUMENTCONTROLLER                  "AP4_DocumentController"   
#define AP4_INTERNALVERIFIER                    "AP4_InternalVerifier" 
#define AP4_PROJECTTEAMMEMBER                   "AP4_ProjectTeamMember"
#define AP4_SURVEYOR                            "AP4_Surveyor"
#define AP4_PROJECTCONTROLLER					"AP4_ProjectController"
#define PROPOSED_RESPONSIBLE_PARTY				"ProposedResponsibleParty"

//Address Types
#define INVOICE									"Invoice"
#define OFFICE									"Office"
#define POSTAL									"Postal"

//Handler arguments
#define CONVERT_TO								"-convert_to"
#define PROPERTY								"property"
#define INCLUDE_TYPE							"include_type"
#define ATTACHMENT								"attachment"
#define INVOICE_TYPE							"invoice_type"
#define INVOICE_NAME							"invoice_name"
#define APPEND_COUNTER							"append_counter"
#define ATTACHMENT_TYPE							"attachment_type"
#define IS_FINAL								"IsFinal"
#define TASK_TYPE								"task_type"
#define ACKNOWLEGDE_TASK						"ack_task"
#define DO_TASK									"do_task"
#define ASSIGNEE_SET							"assignee_set"
#define ASSIGNEE_REMOVE							"assignee_remove"
#define ASSIGNEE_ROLE							"assignee_role"
#define APPROVAL_ENG_ROLE						"Approval Engineer"

//Preferences
#define DNVGL_EFORM_DATASETS					"DNVGL_eForm_Datasets"
#define MDR_CONFIG_VIEW_ATTRIBUTES				"MDR_Config_View_Attributes"
#define DNVGL_FORMDATASET						"DNVGL_FormDataset"
#define AFFINITAS_ENV							"AFFINITAS_ENV"

#define DNVGL_COMMENT_LETTER_EDITABLE_BOOKMAKRS	"DNVGL_comment_letter_editable_bookmarks"
#define DNVGL_COMMENT_LETTER_TABLE_BOOKMAKRS	"DNVGL_comment_letter_table_bookmarks"

#define AP4_MSARATE_SERVICECODE					"AP4_MSARate_ServiceCode"
#define AP4_TSARATE_SERVICECODE					"AP4_TSARate_ServiceCode"

//Release Statuses
#define AP4_ISSUED   							"AP4_Issued"
#define AP4_SURVEYED							"AP4_Surveyed"
//Others	
#define NAME_XML								"XML"
#define TEMP_ENV_VAR							"TEMP"
#define TC_ROOT_ENV_VAR							"TC_ROOT"
#define TRANSMITTAL_XML_DATASET_NAME			"Transmittals XML"
#define MDR_XML_DATASET_NAME					"MDRXML"
#define MDR_CONFIG_XML_DATASET_NAME				"MDRConfigXML.xml"
#define	UNASSIGNED_FILES						"Unassigned Files"
#define DATE_FORMAT_STR_FOOTER					"%Y-%m-%d_%H%M%S"
#define DATE_FORMAT_COMMENT_LETTER				"%Y-%m-%d"
#define TARGET									"target"
#define REFERENCE								"reference"
#define CTR_DOCUMENT_TYPE						"CTR"
#define PROPOSAL_FOR							"Proposal for "
#define PURCHASEORDER_FOR						"Purchase order for "
#define SFA_FOR									"SFA for "
#define CONTRACTDOCUMENT_FOR					"Contract document for "
#define CTR_FOR									"ProCalc for "
#define COMMENTRY_BOOKMARK					    "TableCommentary"
#define COMMENT_LETTER						    "Comment letter"
#define COMMENT_TEXT							"Comment"
#define REPLY_TEXT								"Reply"
#define COMMENT_LETTER_MAPPING_DATASET_NAME		"eForm_local_mapping_comment_letter"
#define COMMENT_LETTER_NAME						"Comment Letter"
#define TRN_NAME								"TRN"
#define VAR_NAME								"VAR"
#define TCM_RELEASED_STATUS						"TCM Released"
#define NOK										"NOK"
#define OPEN_STATUS								"Open"
#define CLOSED_STATUS							"Closed"
#define DOCUMENT_STATUS_AC                       "AC"
#define DOCUMENT_STATUS_NP                       "NP"
#define DOCUMENT_NAME							 "DocName"
#define DOCUMENT_NO			                     "DocNo"
#define DOCUMENT_REV	                         "DocRev"
#define NOT_ISSUED								 "Not Issued"
#define XLSX									 "xlsx"
#define INSTRUCTION_TAG							 "Instructions"
#define TEXTELEMENTS_TAG						 "TextElements"
#define DOCUMENT_TAG							 "Document"
#define BOOKMARK_TAG							 "Bookmark"
#define VALUE_TAG								 "Value"
#define TABLE_TAG								 "table"
#define ROW_TAG									 "row"
#define DATA_TAG								 "data"
#define TYPE_ATTRIBUTE							 "Type"
#define TABLE_ATTRIBUTE_VALUE					 "table1"
#define DELETE_TAG								 "<delete></delete>"
#define DELETE_MAPPING_VALUE					 "NEWELEMENT.DELETE"
#define	SURVEYOR								 "Surveyor"
#define SURVEYOR_CHEKLIST_NAME					 "Surveyor Checklist"
#define NA_TEXT									 "NA"
// Workflow Names
#define SUBMIT_FOR_INTERNAL_VERIFICATION		"Internal Verification Of Comment"
#define INTERNAL_VERIFICATION_OF_ACTIVITY		"Internal Verification Of Activity"
#define SUBMIT_FOR_QUICK_PUBLISH_OF_COMMENTS	"Quick Publish Of Comments"
#define SEND_TO_SURVEYOR						"Send To Surveyor"

// Special characters
#define DELIMITER								"/"

//Error Codes
#define ERROR_919101							919101
#define ERROR_919102							919102
#define ERROR_919103							919103	//eForm mapping not found for the document type.
#define ERROR_919104							919104	//eForm mapping dataset not found.
#define ERROR_919105							919105	//Customer doesnt exist for the project hence address cannot be attached.
#define ERROR_919106							919106	//Invalid address. Address being attached to the project does not belong to the customer which is attached to the project.
#define ERROR_919107							919107	//Start date cannot be empty.
#define ERROR_919108							919108	//Estimated end date cannot be empty.
#define ERROR_919109							919109	//Estimated end date should be greated than start date.
#define ERROR_919110							919110  //Error in executing MDM Customer Search webservice.    
#define ERROR_919111							919111  //Error in executing MDM Retrieve webservice.    
#define ERROR_919112							919112  //Error in executing MDM Callback webservice.    
#define ERROR_919113							919113  //Error in executing E-Form webservice.    
#define ERROR_919114							919114  //Error in executing Affinitas Opportunity Upsert webservice.    
#define ERROR_919115							919115  //Validation falied. %1$ required attributes are not filled.    
#define ERROR_919116							919116  //Validation falied. No customer is attached.
#define ERROR_919117							919117	//Transmittal XML not found. Please generate transmittal XML first.
#define ERROR_919118							919118	//Document Register folder does not exist. Please create it first.
#define ERROR_919119							919119	//MDR XML not found. Please MDR XML first.
#define ERROR_919120							919120	//Transmittal Zip not found.
#define ERROR_919121							919121	//Transmittal Zip does not contain a named reference.
#define ERROR_919122							919122	//Invalid eForm attribute mapping found. Please verify the mappings.
#define ERROR_919123							919123	//Invalid attribute type used which is not supported for mapping.
#define ERROR_919124							919124	//Transmittal Zip file is not attached.
#define ERROR_919125							919125	//No Bid manager assigned.
#define ERROR_919126							919126  //Value of %1$ should be null.
#define ERROR_919127							919127  //Proposal Sent Date can not be empty when Sales Stage is set to 'Proposal Delivered'.
#define ERROR_919128							919128  //Invalid arguments provided for handler %1$.
#define ERROR_919129                            919129  //Only active addresses are allowed to be used.
#define ERROR_919130                            919130  //Only invoice address is allowed.
#define ERROR_919131                            919131  //Only office address is allowed.
#define ERROR_919132                            919132  //Only postal address is allowed.
#define ERROR_919133                            919133  //Following error occurred in ExcelInterop during Preview MDR workflow : %1$
#define ERROR_919134                            919134  //Invalid value for the argument "attachment_type" on the workflow handler.
#define ERROR_919135                            919135  //Handler argument is missing.
#define ERROR_919136                            919136  //Send to affinitas cannot be initiated because Proposal Sent Date is set when Sales Stage is Opportunity in Process.
#define ERROR_919137							919137	//Technical document is attached to the folder.
#define ERROR_919138							919138	//Comment letter template dataset is not attached with comment template revision.
#define ERROR_919139                            919139  //Following error occurred during creating comment letter : %1$
#define ERROR_919140                            919140  //Following error occurred during protacting comment letter : %1$
#define ERROR_919141							919141	//Comment letter template is not attached with project revision.
#define ERROR_919142							919142	//Admin folder does not exist. Please create it first.
#define ERROR_919143							919143  //Following error occurred during getting bookmarks from comment letter : %1$
#define ERROR_919144							919144  //Following error occurred during updating bookmarks in comment letter : %1$
#define ERROR_919145							919145	//Comment dataset mapping not found for the comment letter id.
#define ERROR_919146							919146	//Comment letter mapping dataset not found.
#define ERROR_919147							919147  //Notification: Null Pointer
#define ERROR_919148							919148  //Notification: Receiver is missing
#define ERROR_919149							919149  //Notification: Message body is missing
#define ERROR_919150							919150  //Notification: Service Error
#define ERROR_919151							919151  //Following error occurred during importing comments from comment letter : %1$
#define ERROR_919152                            919152  //Invalid value for the argument "task_type" on the workflow handler.
#define ERROR_919153                            919153  //Invalid value for the argument "object_type" on the workflow handler.
#define ERROR_919154                            919154  //No comment chain found for the given technical document.
#define ERROR_919155                            919155  //No user found to assign task.
#define ERROR_919156                            919156  //Status Remark is mandatory for Document Status AC or NP.  
#define ERROR_919157                            919157  //Invalid value for the argument "assignee_role" on the workflow handler. 
#define ERROR_919158							919158  //Handler argument "task_type" is missing.
#define ERROR_919159                            919159  //"assignee_role" argument is missing on the workflow handler. 
#define ERROR_919160                            919160  //Following error occurred during making bookmarks editable in comment letter : %1$
#define ERROR_919161                            919161  //Transmittal number is missing on Transmittal Document.
#define ERROR_919162                            919162  //Only .xlsx files are supported for MDR. 
#define ERROR_919163                            919163  //Document is already a part %1$ project and hence cannot be used in %2$ project.
#define ERROR_919164							919164	//No mapping found for the eform id - %1$.
#define ERROR_919165							919165	//Table bookmarks missing for efrom id - %1$.
#define ERROR_919166							919166	//Issue with given xml request.
#define ERROR_919167							919167	//Given element:%1$ not found in input xml.
#define ERROR_919168                            919168  //Following error occurred during eform request creation.
#define ERROR_919169							919169  //Excel file with MDR is not attached to the MDR Document. Please attach a valid MDR Excel file!
#define ERROR_919170							919170  //Import Comment letter only applicable to Deliverable Revision.
#define ERROR_919171							919171  //Import Comment letter only applicable to template type "Comment Letter".
#define ERROR_919172							919172  //Written verification scheme excel does not exist.
#define ERROR_919173							919173  //Written verification scheme document does not belong to any project. Hence cannot be imported.
#define ERROR_919174							919174  //Please create schedule first for the project before importing written verification scheme.
#define ERROR_919175							919175  //WVS excel dataset does not contain any named reference.
#define ERROR_919176							919176  //OPENXML SDK is not installed on your mmachine. Please install OPENXML SDK first.
#define ERROR_919177							919177  //Make sure "OpenXMl.properties" file is presnet in ../tc_root/custom folder.

#endif //DNVGL_CONSTANTS_H