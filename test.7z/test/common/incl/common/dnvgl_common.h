/**
* \file dnvgl_common.h
* \ingroup libAP4_dnvgl_common
* \verbatim
  \par Description:
    Common header for all the system and teamcenter includes.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Chetan Kekade
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 12-May-2016   Chetan Kekade      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_COMMON_H
# define DNVGL_COMMON_H

/*************************************************
* Disable warnings
**************************************************/
#pragma warning(disable:4251)


/*************************************************
* System Header Files
**************************************************/
#include <algorithm>
#include <winsock2.h>
#include <Windows.h>
#include <ctype.h>
#include <fstream>
#include <iomanip>
#include <locale>
#include <map>
#include <math.h>
#include <stdlib.h>
#include <string>
#include <sys/stat.h> 
#include <sys/timeb.h>
#include <sys/types.h>
#include <time.h>
#include <vector>
#include <iostream>
#include <string>
#include <sstream>
#include <direct.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <ae/ae.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <ae/shell_util.h>
#include <ae/vm_errors.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <common/emh_const.h>
#include <constants/constants.h>
#include <ctype.h>
#include <errno.h>
#include <epm/cr.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <epm/releasestatus.h>
#include <epm/signoff.h>
#include <fclasses/tc_date.h>
#include <itk/bmf.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <me/me.h>
#include <metaframework/BusinessObjectRef.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <nls\nls.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <property/propdesc.h>
#include <property/prop_errors.h>
#include <ps/ps.h>
#include <ps/ps_tokens.h>
#include <ps/vrule.h>
#include <qry/crf.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <sa/user.h>
#include <sa/tcfile.h>
#include <sa/tcvolume.h>
#include <schmgt/schmgt_bridge_itk.h>
#include <schmgt/schmgt_itk.h>
#include <sub_mgr/standardtceventtypes.h>
#include <sub_mgr/subscription.h>
#include <sub_mgr/tceventtype.h>
#include <tc/emh.h>
#include <tc\emh_errors.h>
#include <tc/folder.h>
#include <tc/iman_arguments.h>
#include <tc/preferences.h>
#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <textsrv/textserver.h>	
#include <tccore\aom.h>
#include <tccore\aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/iman_msg.h>
#include <tccore/item.h>
#include <tccore/item_msg.h>
#include <tccore/license.h>
#include <tccore/method.h>
#include <tccore/project.h>
#include <tccore/project_errors.h>
#include <tccore/tc_msg.h>	
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h> 
#include <tccoreext/gde.h>

/*************************************************
* Custom Header Files
**************************************************/
#include "dnvgl_constants.h"
#include "dnvgl_common_exports.h"
#include <AP4_dnvgl_bmide_extensions/AP4_CustomerSearchResult.hxx>


#ifdef __cplusplus
extern "C" {
#endif

	// define this function because this is not exposed API; Basically we are cheating the Tc :)
	DNVGLCOMEXP void AM__set_application_bypass(logical setBypass);
	DNVGLCOMEXP void POM_AM__set_application_bypass(logical setBypass);

#ifdef __cplusplus
}
#endif

#endif //DNVGL_COMMON_H
