/**
* \file dnvgl_project_handling.h
* \ingroup libAP4_dnvgl_common
* \verbatim
  \par Description:
    Header file for AP4_Project handling functions.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Chetan Kekade
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 12-May-2016   Chetan Kekade      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_PROJECT_HANDLING_H
# define DNVGL_PROJECT_HANDLING_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"

#ifdef __cplusplus
extern "C" {
#endif

	// defining a structure to hold GroupMember attributes
	typedef struct S_DNVGL_ProjectRevisionParticipant
	{
		tag_t thisParticipant;
		std::string participantType;
		tag_t groupMember;
		tag_t user;
		std::string userID;
		tag_t group;
		std::string groupName;
		tag_t role;
		std::string roleName;
	}DNVGL_ProjectRevisionParticipant_t;

	//Function to copy AP4_Project from another AP4_Project
	DNVGLCOMEXP int dnvgl_copy_project( tag_t*, tag_t*, logical );

	//Function to copy the folder structure from one AP4_ProjectRevision to another AP4_ProjectRevision.
	DNVGLCOMEXP int copy_project_folder( tag_t, tag_t, tag_t* );

	//Copy the Project Folder Structure present with the relation Project structure Relation from source Project Folder to Destination Project Folder.
	DNVGLCOMEXP int copy_folder_structure( tag_t, tag_t );

	//Copy the Project Attributes from source Project to Destination Project.
	DNVGLCOMEXP int copy_project_attributes( tag_t, tag_t, logical );

	//Copy the Project  structure present from source Project to Destination Project. 
	DNVGLCOMEXP int copy_recursive_folder_structure( tag_t, tag_t, tag_t );

	//Set the Back pointer to Project.
	DNVGLCOMEXP int set_project_back_pointer( tag_t, tag_t );

	DNVGLCOMEXP int get_all_participants(tag_t tProjectRev, std::vector<DNVGL_ProjectRevisionParticipant_t>& participantInfos);

#ifdef __cplusplus
}
#endif

#endif //DNVGL_PROJECT_HANDLING_H