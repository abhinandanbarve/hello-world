/**
* \file dnvgl_common_exports.h
* \ingroup libAP4_dnvgl_common
* \verbatim
  \par Description:
    brief The header file that defines the export symbols
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Nikhilesh Khatra
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 12-May-2016   Nikhilesh Khatra      Initial Creation
*--------------------------------------------------------------------------------
*/

#ifndef DNVGL_COMMON_EXPORTS_H
#define DNVGL_COMMON_EXPORTS_H


#ifdef _WIN32
#ifdef _LOAD_FROM_EXTERNAL
#define DNVGLCOMEXP extern __declspec(dllimport)
#else
#define DNVGLCOMEXP extern __declspec(dllexport)
#endif
#ifdef _LOAD_FROM_EXTERNAL
#define DNVGLCOMEXPCLASS __declspec(dllimport)
#else
#define DNVGLCOMEXPCLASS __declspec(dllexport)
#endif
#else
#define DNVGLCOMEXP extern
#define DNVGLCOMEXPCLASS
#endif

#endif  //DNVGL_COMMON_EXPORTS_H