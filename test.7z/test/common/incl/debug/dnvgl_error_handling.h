/**
* \file dnvgl_error_handling.h
* \ingroup libAP4_dnvgl_common
* \verbatim
\par Description:
Macro definitions for error handling.
* \par Since: Release1
* \par ENVIRONMENT : C++, ITK
*
\endverbatim
* \par Owner:
* Nikhilesh Khatra
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name                Description of Change
* 12-May-2016   Nikhilesh Khatra      Initial Creation
*--------------------------------------------------------------------------------
*/
#ifndef DNVGL_ERRORHANDLING_H
#define DNVGL_ERRORHANDLING_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"

#ifdef _WIN32
/* on MS Windows ignore deprecation warnings: */ 
#define _CRT_SECURE_NO_DEPRECATE 1
#endif

#ifdef __cplusplus
extern "C"
{
#endif

	DNVGLCOMEXP void dnvgl_log_error_syslog(int  iStatus, int  ierrorType, const char * szFileName, int ilineNumber, const char* szCustomMsg);

	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the iStatus with severity warning.
	This also sets iStatus back to ITK_ok.
	*/

#define DNVGL_LOG_WARNING {\
	if (iStatus != ITK_ok) {\
	dnvgl_log_error_syslog( iStatus, EMH_severity_warning , __FILE__, __LINE__ , NULL); \
	iStatus = ITK_ok;\
	}\
	}


	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the iStatus with severity error.
	<BR>
	Example:
	\image html LogErrorExample.jpg
	*/
#define DNVGL_LOG_ERROR {\
	if (iStatus != ITK_ok) {\
	dnvgl_log_error_syslog( iStatus, EMH_severity_error , __FILE__, __LINE__ , NULL); \
	}\
	}

	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the iStatus with severity error and return iStatus/error code.
	<BR>
	Example:
	\image html LogErrorAndReturnExample.jpg
	*/
#define DNVGL_LOG_ERROR_AND_RETURN {\
	if (iStatus != ITK_ok) {\
	dnvgl_log_error_syslog( iStatus, EMH_severity_error , __FILE__, __LINE__ , NULL); \
	return iStatus;\
	}\
	}

	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the iStatus with severity error and throw the iStatus/error code.
	<BR>
	Example:
	\image html LogErrorAndThrowStatusExample.jpg
	*/
#define  DNVGL_LOG_ERROR_AND_THROW_STATUS {\
	if (iStatus != ITK_ok) {\
	dnvgl_log_error_syslog( iStatus, EMH_severity_error , __FILE__, __LINE__ , NULL); \
	throw iStatus;\
	}\
	}

	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the iStatus with severity warning for ITK method calls.
	*/ 
#define DNVGL_ITK_CALL(func) {\
	if(iStatus == ITK_ok){\
	(iStatus) = (func);\
	if (iStatus != ITK_ok) {\
	dnvgl_log_error_syslog( iStatus, EMH_severity_error , __FILE__, __LINE__ , NULL); \
	}\
	}\
	}

	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the information.
	This also sets iStatus back to ITK_ok.
	*/
#define DNVGL_LOG_INFORMATION {\
	dnvgl_log_error_syslog( iStatus, EMH_severity_information , __FILE__, __LINE__ , NULL); \
	EMH_clear_errors(); \
	iStatus = ITK_ok;\
	}


#ifdef __cplusplus
}
#endif

#endif // DNVGL_ERROR_HANDLING_H
