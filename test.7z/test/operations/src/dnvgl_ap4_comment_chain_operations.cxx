/**
* \file dnvgl_ap4_comment_chain_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_CommentChain
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 11-Jan-2017   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_comment_chain_operations.h"

/**
* \file dnvgl_ap4_comment_chain_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_comment_chain_get_all_comments_text( tag_t tCommentChain, std::vector<std::string> & values, std::vector<int> & isNull )
{
	int iStatus				= ITK_ok;
	tag_t *tComments		= NULL;
	DNVGL_TRACE_ENTER();
	try
	{
		int iCount ;
		DNVGL_TRACE_CALL( iStatus = AOM_get_value_tags( tCommentChain, AP4_COMMENTS, &iCount, &tComments ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iCount; i++ )
		{
			char* cpRichText = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tComments[i], AP4_RICH_TEXT, &cpRichText ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			std::string sCommentText;

			char* cpCommentType = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tComments[i], AP4_COMMENT_TYPE, &cpCommentType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tc_strcmp( cpCommentType, COMMENT_TYPE_COMMENT ) == 0 )
			{
				sCommentText.append( "<Comment>" );
				sCommentText.append( cpRichText );
				sCommentText.append( "</Comment>" );
			}
			else
			{
				sCommentText.append( "<Reply>" );
				sCommentText.append( cpRichText );
				sCommentText.append( "</Reply>" );
			}
			values.push_back( sCommentText );
			isNull.push_back( 0 );
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tComments );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}