/**
* \file dnvgl_ap4_folder_schedule_relation_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This file contains the implementation of operations which are overridden on AP4_FolderScheduleRelation, if any.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 10-May-2017   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_folder_schedule_relation_operations.h"

/**
* \file dnvgl_ap4_folder_schedule_relation_operations.cxx
* \par  Description :
* \verbatim
*   Set the type of schedule task to surveyor task when a surveyor package folder is attached to schedule task by AP4_FolderScheduleRelation.
\endverbatim     
* \param[in]		tPrimaryObj		Tag of schedule task.
* \param[in]		tSecondaryObj	Tag of surveyor package folder.
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns : iStatus
* int : 0/error code
*/
int dnvgl_override_ap4_folder_schedule_relation_createpostbase( tag_t tPrimaryObj, tag_t tSecondaryObj )
{
	int   iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		char* cpPriObjectType = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tPrimaryObj, OBJECT_TYPE, &cpPriObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* cpSecObjectType = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSecondaryObj, OBJECT_TYPE, &cpSecObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( cpPriObjectType != NULL && tc_strcmp( cpPriObjectType, SCHEDULETASK ) == 0 &&
			cpSecObjectType != NULL && tc_strcmp( cpSecObjectType, AP4_SURVEYORPACKAGEFOLDER ) == 0 )
		{
			char* cpTaskType = NULL;
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tPrimaryObj, AP4_SCHEDULE_TASK_TYPE, &cpTaskType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpTaskType == NULL || tc_strlen( cpTaskType ) == 0 )
			{
								
				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tPrimaryObj, true ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;			
				DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tPrimaryObj, AP4_SCHEDULE_TASK_TYPE, SURVEYOR_TASK ) );
			    DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = AOM_save( tPrimaryObj ) );
			    DNVGL_LOG_ERROR_AND_THROW_STATUS;
				DNVGL_TRACE_CALL( iStatus = AOM_refresh( tPrimaryObj, false ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_folder_schedule_relation_operations.cxx
* \par  Description :
* \verbatim
*   Clear the type of schedule task when a surveyor package folder is removed from schedule task by AP4_FolderScheduleRelation.
\endverbatim     
* \param[in]		tPrimaryObj		Tag of schedule task.
* \param[in]		tSecondaryObj	Tag of surveyor package folder.
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns : iStatus
* int : 0/error code
*/
int dnvgl_override_ap4_folder_schedule_relation_fnd0DeleteBase( tag_t tPrimaryObj, tag_t tSecondaryObj )
{
	int   iStatus			= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		char* cpPriObjectType = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tPrimaryObj, OBJECT_TYPE, &cpPriObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* cpSecObjectType = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tSecondaryObj, OBJECT_TYPE, &cpSecObjectType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( cpPriObjectType != NULL && tc_strcmp( cpPriObjectType, SCHEDULETASK ) == 0 &&
			cpSecObjectType != NULL && tc_strcmp( cpSecObjectType, AP4_SURVEYORPACKAGEFOLDER ) == 0 )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tPrimaryObj, true ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = AOM_set_value_string( tPrimaryObj, AP4_SCHEDULE_TASK_TYPE, "" ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			
			DNVGL_TRACE_CALL( iStatus = AOM_save( tPrimaryObj ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			DNVGL_TRACE_CALL( iStatus = AOM_refresh( tPrimaryObj, false ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
			
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}