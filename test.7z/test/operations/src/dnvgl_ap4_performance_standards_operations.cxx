/**
* \file dnvgl_ap4_performance_standards.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This file contains the functions which are called after overriding the operations on AP4_PerformanceStandards.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 30-May-2017   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_performance_standards_operations.h"

/**
* \file dnvgl_ap4_performance_standards.cxx
* \par  Description :
<description of function>.
* \verbatim
*   Pre action to delete all the AP4_AssetRelation between AP4_AssetRevision and AP4_ProjectRevision when the AP4_FieldRelation between given AP4_ProjectRevision and AP4_FieldRevision is deleted.
\endverbatim     
* \param[in]   tPrimaryObj		Primary object i.e. AP4_ProjectRevision
* \param[in]   tSecondaryObj    Secondary object i.e. AP4_FieldRevision
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_override_ap4_performance_standards_createPostBase( tag_t tPrimaryObj, tag_t tSecondaryObj )
{
	int iStatus				= ITK_ok;
	
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tSecondaryObj, true ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tSecondaryObj, AP4_SCE_PROP, tPrimaryObj ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( tSecondaryObj ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tSecondaryObj, false ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;		
	}
	catch( ... )
	{
	}	
	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_performance_standards.cxx
* \par  Description :
<description of function>.
* \verbatim
*   Pre action to delete all the AP4_AssetRelation between AP4_AssetRevision and AP4_ProjectRevision when the AP4_FieldRelation between given AP4_ProjectRevision and AP4_FieldRevision is deleted.
\endverbatim     
* \param[in]   tPrimaryObj		Primary object i.e. AP4_ProjectRevision
* \param[in]   tSecondaryObj    Secondary object i.e. AP4_FieldRevision
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_override_ap4_performance_standards_fnd0Delete( tag_t tPrimaryObj, tag_t tSecondaryObj )
{
	int iStatus				= ITK_ok;
	
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tSecondaryObj, true ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_set_value_tag( tSecondaryObj, AP4_SCE_PROP, NULLTAG ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_save( tSecondaryObj ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_refresh( tSecondaryObj, false ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;		
	}
	catch( ... )
	{
	}	
	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}