/**
* \file dnvgl_ap4_project_struct_relation_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_ProjectStructRelation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 30-May-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_project_struct_relation_operations.h"

/**
* \file dnvgl_ap4_project_struct_relation_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_project_struct_relation_createpostbase( tag_t primaryObjTag, tag_t secondaryObjTag )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = set_project_back_pointer( primaryObjTag, secondaryObjTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}