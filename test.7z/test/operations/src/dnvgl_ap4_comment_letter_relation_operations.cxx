/**
* \file dnvgl_ap4_comment_letter_relation_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_CommentLetterRelation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Prasmit Pansare
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* June 2017   Prasmit Pansare	       Initial Creation
*--------------------------------------------------------------------------------
*/
          
#include "dnvgl_ap4_comment_letter_relation_operations.h"

/**
* \file dnvgl_ap4_comment_letter_relation_operations.cxx
* \par  Description : This will function will perform following operations:
- Set the project backpointer on the AP4_Deliverable Item
- Get the TC project from the AP4_TechDoc or AP4_Activity and assign the same to AP4_Deliverable
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   primaryObjTag    Tag of AP4_TechDoc or AP4_Activity
* \param[in]   secondaryObjTag  Tag of AP4_Deliverable
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_comment_letter_relation_createpostbase( tag_t primaryObjTag, tag_t secondaryObjTag )
{
	int iStatus				= ITK_ok;
	tag_t tDocRev			= NULLTAG;
	tag_t tProjectRev		= NULLTAG;
	int iNoOfProjects		= 0;
	tag_t* tProjects		= NULL;

	tag_t tItemClassId        = NULLTAG;
	tag_t tPrimaryObjClassId  =NULLTAG;
	tag_t tActivityType     = NULLTAG;
	tag_t tTechDocType      = NULLTAG;

	logical lIsValidType    = false;

	DNVGL_TRACE_ENTER();
	try
	{

		  /* Find the class ID of Item */
		DNVGL_TRACE_CALL( POM_class_id_of_class(ITEM, &tItemClassId));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;


		  /* Check, if the primary object is a decendant of Item */
        DNVGL_TRACE_CALL( POM_class_of_instance(primaryObjTag, &tPrimaryObjClassId));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

        DNVGL_TRACE_CALL( POM_is_descendant(tItemClassId, tPrimaryObjClassId, &lIsValidType));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if(lIsValidType)
		{
			DNVGL_TRACE_CALL(  iStatus = AOM_ask_value_tag( primaryObjTag, AP4_PROJECT_BACKPOINTER, &tProjectRev ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(  iStatus = AOM_refresh( secondaryObjTag,true ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(  iStatus = AOM_assign_tag( secondaryObjTag, AP4_PROJECT_BACKPOINTER, tProjectRev ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(  iStatus = AOM_ask_value_tags( primaryObjTag, PROJECT_LIST, &iNoOfProjects, &tProjects ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(  iStatus = PROJ_assign_objects( iNoOfProjects, tProjects, 1, &secondaryObjTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(  iStatus = AOM_save( secondaryObjTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL(  iStatus = AOM_refresh( secondaryObjTag, false ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

		}
		
	}
	catch (const std::exception &e)
	{
		printf("Error exception:%s\n", e.what());
	}
	DNVGL_MEM_FREE(tProjects);
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
