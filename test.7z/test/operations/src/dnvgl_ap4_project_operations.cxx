/**
* \file dnvgl_ap4_project_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_Project and AP4_ProjectRevision.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 27-May-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_project_operations.h"

/**
* \file dnvgl_ap4_project_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_projectrevision_validatecreateinputbase( )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t   tUserTag				= NULLTAG;
		tag_t   tCurGrpMemberTag		= NULLTAG;
		logical lIncludeInactive		= false;
		int		iGrpCount				= 0;
		tag_t*	tGrpMemberTags			= NULLTAG;
		logical lIsProjAdministrator	= false;

		DNVGL_TRACE_CALL( iStatus =  SA_ask_current_groupmember( &tCurGrpMemberTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus =  SA_ask_groupmember_user( tCurGrpMemberTag , &tUserTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus =  SA_find_all_groupmember_by_user( tUserTag , lIncludeInactive , &iGrpCount , &tGrpMemberTags ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for (int i = 0; i < iGrpCount; i++)
		{
			tag_t tGroupTag		= NULLTAG;
			char* cGroupName	= NULL;

			tag_t tRoleTag		= NULLTAG;
			char* cRoleName	= NULL;

			DNVGL_TRACE_CALL( iStatus =  SA_ask_groupmember_group( tGrpMemberTags[i] , &tGroupTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus =  SA_ask_group_name2( tGroupTag, &cGroupName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus =  SA_ask_groupmember_role( tGrpMemberTags[i] , &tRoleTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus =  SA_ask_role_name2( tRoleTag, &cRoleName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( strcmp ( cGroupName, PROJECT_ADMINISTRATION ) == 0 && strcmp ( cRoleName, PROJECT_ADMINISTRATOR ) == 0 )
			{	
				lIsProjAdministrator = true;
				break;
			}

			if( !lIsProjAdministrator )
			{
				iStatus = 919102;
			}

		}
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_project_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_projectrevision_validatesaveasinputbase( )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{

	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_project_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_projectrevision_createpostbase( tag_t projectRevTag, const char* projectTemplateID, const char* scheduleTemplateID )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_project_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_projectrevision_saveaspostbase( tag_t targetProjectRevTag, tag_t sourceProjectRevTag )
{
	int iStatus	= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_project_operations.cxx
* Function owner : Vivek Mundada
* \par  Description :
<description of function>.
* \verbatim
*   To get all latest revision of CTR document on runtime property
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_projectrevision_ctr_document_revisionsBase(tag_t tProjectRevTag,std::vector<tag_t> & values, std::vector<int> & isNull)
{
	int				iStatus				= ITK_ok;

	DNVGL_TRACE_ENTER();
	try
	{
		tag_t           tRelationType       = NULLTAG;
		int				iSecondaryCount		= 0;
		tag_t*			ptSecondaryObjects	= NULLTAG;
		char			*cpObjectType		= NULL		;
		tag_t			tFolderTag			= NULLTAG ;

		// Get Ap4_GoverningDocuments folder from project rev tag
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECT_STRUCTURE_RELATION, &tRelationType ) ); 
		DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tProjectRevTag, tRelationType, &iSecondaryCount, &ptSecondaryObjects ) );

		// Get all CTR document items from Ap4_GoverningDocuments
		for ( int index = 0; index < iSecondaryCount; index++ )
		{						
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string(ptSecondaryObjects[index], OBJECT_TYPE, &cpObjectType) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_GOVERNING_DOCUMENT ) == 0 )
			{
				tFolderTag = ptSecondaryObjects[index];
				break;
			}	
		}

		// Get latest working rev of all CTR document item
		if( tFolderTag != NULLTAG )
		{
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_DOCUMENT_RELATION, &tRelationType ) ); 
			DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tFolderTag, tRelationType, &iSecondaryCount, &ptSecondaryObjects ) );

			for ( int index = 0; index < iSecondaryCount; index++ )
			{						
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( ptSecondaryObjects[index], OBJECT_TYPE, &cpObjectType) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( cpObjectType != NULL && tc_strcmp( cpObjectType, AP4_CTR_DOCUMENT ) == 0 )
				{
					tag_t rev = NULLTAG;
					DNVGL_TRACE_CALL( iStatus = ITEM_ask_latest_rev( ptSecondaryObjects[index], &rev) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					values.push_back( ( tag_t ) rev );
					isNull.push_back(0);
				}	
			}
		}
	}
	catch(...)
	{
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

int dnvgl_override_ap4_projectrevision_schedule_taskBase(tag_t tProjectRevTag,std::vector<tag_t> & values, std::vector<int> & isNull)
{     
	// select tsk.puid
	// from tc.dbo.PIMANRELATION rel, tc.dbo.PIMANTYPE tp, tc.dbo.PSCHEDULETASK tsk
	// where (tsk.pap4_ctr_number IS NOT NULL or tsk.ptask_type = 6)
	// and tp.ptype_name = 'AP4_ProjectScheduleRelation'
	// and tp.puid = rel.rrelation_typeu
	// and rel.rprimary_objectu = 'QrDAQUms6qEfMA'
	// and tsk.rschedule_tagu = rel.rsecondary_objectu

	int iStatus = ITK_ok;	
	const char* pcEnquiryID = "dnvgl-get-schedule-tasks-of-project-revision";

	DNVGL_TRACE_ENTER();
	try
	{
		int				iTotalRows			= 0;
		int				iTotalCols			= 0;
		int				iRows				= 0;
		int				iCols				= 0;
		tag_t			tItemObj			= NULLTAG;

		const char *	pcSelectAttrs[]		= {"puid", "ap4_ctr_number"};
		const char*		RelName[]			= {"AP4_ProjectScheduleRelation"};

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create( pcEnquiryID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, "ScheduleTask", 2, pcSelectAttrs ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( pcEnquiryID, "Expr1", "ScheduleTask", "ap4_ctr_number", POM_enquiry_is_not_null, NULL));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_int_expr(pcEnquiryID, "Expr2", "ScheduleTask", "task_type", POM_enquiry_equal, 6) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_tag_value ( pcEnquiryID, "Query", 1, &tProjectRevTag, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( pcEnquiryID, "Expr3", "ImanRelation", "primary_object", POM_enquiry_equal, "Query"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (pcEnquiryID, "Query1",1 ,RelName, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( pcEnquiryID, "Expr4", "ImanType", "type_name", POM_enquiry_in, "Query1"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr5", "ImanType", "puid", POM_enquiry_equal, "ImanRelation", "relation_type"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr6", "ScheduleTask", "schedule_tag", POM_enquiry_equal, "ImanRelation", "secondary_object"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// first join or condition expression
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.1", "Expr1", POM_enquiry_or, "Expr2"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.2", "Expr1.1", POM_enquiry_and, "Expr3"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.3", "Expr1.2", POM_enquiry_and, "Expr4"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.4", "Expr1.3", POM_enquiry_and, "Expr5"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.5", "Expr1.4", POM_enquiry_and, "Expr6"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr ( pcEnquiryID,"Expr1.5"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		void*** pvQueryResults = NULL;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute( pcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int iCnt=0; iCnt<iTotalRows; iCnt++ )
		{
			tag_t tmpSecObj = *( tag_t* )( pvQueryResults[iCnt][0] );

			values.push_back(tmpSecObj);
			isNull.push_back(0);
		}

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete (pcEnquiryID));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{
		iStatus = POM_enquiry_delete ( pcEnquiryID );
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

/**
* \file dnvgl_ap4_project_operations.cxx
* Function owner : Vinay Kudari
* \par  Description :
<description of function>.
* \verbatim
*   This function will set the ap4_affinitas_env property to affinitas link so that the current opportunity can be opened in affinitas.
\endverbatim     
* \param[in]   tProjectRevTag   Tag of the project revision
* \param[in]   value			Value which will be set
* \param[in]   isNull			
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_projectrevision_affinitas_envBase( tag_t tProjectRevTag, std::string & value, bool & isNull )
{
	int				iStatus				= ITK_ok;
	char* cpPrefValue					= NULL;
	char* cpAffinitasNumber				= NULL;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = PREF_ask_char_value( AFFINITAS_ENV, 0, &cpPrefValue ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjectRevTag, AP4_AFFINITAS_NUMBER, &cpAffinitasNumber ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( cpAffinitasNumber != NULL && tc_strlen( cpAffinitasNumber ) != 0 )
		{
			value.append( "http://" );
			value.append( cpPrefValue );
			value.append( "/affinitas_enu/start.swe?SWECmd=GotoView&SWEView=CM+All+Opportunity+List+View&SWERF=1&SWEHo=" );
			value.append( cpPrefValue );
			value.append( "&SWEBU=1&SWEApplet0=CT+All+Opportunity+List+Applet+-+Without+Calc&SWERowId0=" );
			value.append( cpAffinitasNumber );
		}

		isNull = false;
	}
	catch(...)
	{

	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

/**
\ingroup libAP4_dnvgl_operations
* \par  Description :
* \verbatim
When we delete the customer attached to project the address and contact realted to it gets deleted.
\endverbatim     
*  \param[in]   projectItemTag    Tag of the Project Item
* \param[in]    cutomerTags        Tag of the attached customer
*
* \par Algorithm:
* \verbatim
a. Find the cutomers contacts and addresses 
b. Delete them while customer removed from project
\endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_override_ap4_projectrevision_fnd0delete( tag_t tPrimaryObj )
{
	int iStatus			  = ITK_ok;
	tag_t *tpOfficeAddresses = NULLTAG;
	tag_t *tpInvoiceAddresses = NULLTAG;
	tag_t *tpShippingAddresses = NULLTAG;
	tag_t *tpPrimaryContacts = NULLTAG;
	tag_t *tpSecondaryContacts = NULLTAG;

	DNVGL_TRACE_ENTER();
	try
	{
		if( tPrimaryObj != NULLTAG )
		{			
			int iCount = 0;
			tag_t tCustOfficeRelType = NULLTAG; 
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_CUSTOMER_OFFICE_ADDRESS, &tCustOfficeRelType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tCustInvoiceRelType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_CUSTOMER_INVOICE_ADDRESS, &tCustInvoiceRelType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tCustShippingRelType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_CUSTOMER_SHIPPING_ADDRESS, &tCustShippingRelType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tCustContactRelType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_CUSTOMERCONTACT, &tCustContactRelType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tSecCustContactRelType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_PROJECTSECCUSTCONTACT, &tSecCustContactRelType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tPrimaryObj, tCustOfficeRelType, &iCount, &tpOfficeAddresses ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tCustOfficeRel = NULLTAG; 
			if( iCount > 0 && tpOfficeAddresses != NULLTAG ) 
			{  
				DNVGL_TRACE_CALL( iStatus = GRM_find_relation( tPrimaryObj, tpOfficeAddresses[0], tCustOfficeRelType, &tCustOfficeRel ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( tCustOfficeRel != NULLTAG )
				{
					DNVGL_TRACE_CALL( iStatus = GRM_delete_relation( tCustOfficeRel ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}

			tag_t tCustInvoiceRel = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tPrimaryObj, tCustInvoiceRelType, &iCount, &tpInvoiceAddresses ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( iCount > 0 && tpInvoiceAddresses != NULLTAG ) 
			{
				DNVGL_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObj, tpInvoiceAddresses[0], tCustInvoiceRelType, &tCustInvoiceRel));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if(tCustInvoiceRel != NULLTAG)
				{
					DNVGL_TRACE_CALL(iStatus = GRM_delete_relation( tCustInvoiceRel ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}

			tag_t tCustShippingRel = NULLTAG;
			DNVGL_TRACE_CALL(iStatus= GRM_list_secondary_objects_only(tPrimaryObj,tCustShippingRelType,&iCount,&tpShippingAddresses));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if(iCount > 0 && tpShippingAddresses != NULLTAG)
			{
				DNVGL_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObj, tpShippingAddresses[0], tCustShippingRelType, &tCustShippingRel));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( tCustShippingRel != NULLTAG )
				{
					DNVGL_TRACE_CALL(iStatus = GRM_delete_relation( tCustShippingRel ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}

			tag_t tCustContactRel = NULLTAG;
			DNVGL_TRACE_CALL(iStatus= GRM_list_secondary_objects_only(tPrimaryObj,tCustContactRelType,&iCount,&tpPrimaryContacts));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if(iCount > 0 && tpPrimaryContacts != NULLTAG)
			{
				DNVGL_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObj, tpPrimaryContacts[0], tCustContactRelType, &tCustContactRel));
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if(tCustContactRel != NULLTAG)
				{
					DNVGL_TRACE_CALL(iStatus = GRM_delete_relation( tCustContactRel ));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;
				}
			}

			tag_t tSecCustContactRel = NULLTAG;
			DNVGL_TRACE_CALL(iStatus= GRM_list_secondary_objects_only(tPrimaryObj, tSecCustContactRelType, &iCount, &tpSecondaryContacts));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if(iCount > 0 && tpSecondaryContacts != NULLTAG)
			{
				for ( int index = 0; index < iCount; index++ )
				{
					DNVGL_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObj, tpSecondaryContacts[index], tSecCustContactRelType, &tSecCustContactRel));
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( tSecCustContactRel != NULLTAG )
					{
						DNVGL_TRACE_CALL(iStatus = GRM_delete_relation( tSecCustContactRel ));
						DNVGL_LOG_ERROR_AND_THROW_STATUS;
					}
				}
			}
		}
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE( tpOfficeAddresses );
    DNVGL_MEM_FREE( tpInvoiceAddresses );
	DNVGL_MEM_FREE( tpShippingAddresses );
	DNVGL_MEM_FREE( tpPrimaryContacts );
	DNVGL_MEM_FREE( tpSecondaryContacts );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;



}
/**
* \file dnvgl_ap4_project_operations.cxx
* Function owner : Vinay Kudari
* \par  Description :
<description of function>.
* \verbatim
*   This function will set the ap4_affinitas_env property to affinitas link so that the current opportunity can be opened in affinitas.
\endverbatim     
* \param[in]   tProjectRevTag   Tag of the project revision
* \param[in]   value			Value which will be set
* \param[in]   isNull			
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_projectrevision_used_budgetBase( tag_t tProjectRev, int & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	int * iLevelFound		= NULL;
	tag_t * tpRefObjects	= NULL;
	char ** cpReferences	= NULL;
	DNVGL_TRACE_ENTER();
	try
	{
		std::vector<tag_t> projSchedule;
		DNVGL_TRACE_CALL( iStatus = dnvgl_grm_get_secondary_obj_of_type( tProjectRev, AP4_PROJECT_SCHEDULE_RELATION, SCHEDULE, projSchedule) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( projSchedule.size() == 1 )
		{
			tag_t tSchedule = projSchedule.at(0);

			int iRefFound = 0;
			DNVGL_TRACE_CALL( iStatus = WSOM_where_referenced( tSchedule, 1, &iRefFound, &iLevelFound, &tpRefObjects, &cpReferences ) ) ;
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tScheduleSummaryTask = NULLTAG;
			if( iRefFound != 0 )
			{
				for( int iRefCnt = 0; iRefCnt < iRefFound; iRefCnt++ )
				{
					char* cpScheduleObjType = NULL;
					DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2( tpRefObjects[iRefCnt], &cpScheduleObjType ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					if( tc_strcmp( cpScheduleObjType, SCHEDULETASK) == 0 )
					{
						char* cpTaskType = NULL;
						DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpRefObjects[iRefCnt], FND0TASKTYPESTRING, &cpTaskType) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( tc_strcmp( cpTaskType, TASKTYPE_SS ) == 0 )
						{
							tScheduleSummaryTask = tpRefObjects[iRefCnt];
							break;
						}
					}
				}

				if( tScheduleSummaryTask != NULLTAG )
				{
					// Read String property
					char* cWorkEffortString = NULL;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tScheduleSummaryTask, AP4_WORK_EFFORT_STRING, &cWorkEffortString ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					int workEffortInt = atoi( cWorkEffortString );

					double iActualHours_RT = NULL;
					DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleSummaryTask, AP4_ACTUAL_HOURS_RT, &iActualHours_RT ) );
					DNVGL_LOG_ERROR_AND_THROW_STATUS;

					value = (int) ( iActualHours_RT / workEffortInt ) * 100;
					isNull = 0;
				}
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpRefObjects );
	DNVGL_MEM_FREE( cpReferences );
	DNVGL_MEM_FREE( iLevelFound );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}