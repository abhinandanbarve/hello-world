/**
* \file dnvgl_ap4_document_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This file contains the implementation of runtime attributes on AP4_Document and AP4_DocumentRevision.
It also contains the implementation of operations which are overridden on above object types, if any.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Srushti Hanjage
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 03-Mar-2017   Srushti Hanjage	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_document_operations.h"

/**
* \file dnvgl_ap4_document_operations.cxx
* \par  Description :
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   
* \param[in]   
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_surveyor_packagesBase( tag_t tDocumentRev, std::vector< tag_t >& values, std::vector< int >& isNull )
{
	int   iStatus			= ITK_ok;
	tag_t tRelationType		= NULLTAG;
	int   iCount			= NULL;
	tag_t tDocument			= NULLTAG;
	tag_t *tpPrimaryObjects	= NULL;
	

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = ITEM_ask_item_of_rev( tDocumentRev, & tDocument ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_FOLDER_DOCUMENT_RELATION, &tRelationType) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = GRM_list_primary_objects_only( tDocument , tRelationType , &iCount, &tpPrimaryObjects ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int i = 0; i < iCount; i++ )
		{
			tag_t tObjectType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tpPrimaryObjects[i], &tObjectType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			tag_t tSurveyorPackageType = NULLTAG;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_SURVEYORPACKAGEFOLDER, AP4_SURVEYORPACKAGEFOLDER, &tSurveyorPackageType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			bool bIsValidType = false;
			DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tSurveyorPackageType, &bIsValidType ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( bIsValidType )
			{
				values.push_back( tpPrimaryObjects[i] );	
				isNull.push_back( 0 );
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpPrimaryObjects );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
