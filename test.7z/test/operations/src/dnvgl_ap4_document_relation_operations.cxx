/**
* \file dnvgl_ap4_document_relation_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_DocumentRelation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vivek Mundada
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 09-Dec-2016   Vivek Mundada	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_document_relation_operations.h"

/**
* \file dnvgl_ap4_document_relation_operations.cxx
* \par  Description : This will function will perform following operations:
- Set the project backpointer on the AP4_Document
- Set the project folder backpointer on the AP4_Document
- Get the TC project from the AP4_ProjectFolder and assign the same to AP4_Document
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   primaryObjTag    Tag of AP4_ProjectFolder
* \param[in]   secondaryObjTag  Tag of AP4_Document
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_document_relation_createpostbase( tag_t primaryObjTag, tag_t secondaryObjTag )
{
	int iStatus				= ITK_ok;
	tag_t tDocRev			= NULLTAG;
	tag_t tProjectRev		= NULLTAG;
	int iNoOfProjects		= 0;
	tag_t* tProjects		= NULL;

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL(  iStatus = AOM_refresh( secondaryObjTag,true ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(  iStatus = AOM_ask_value_tag( primaryObjTag, AP4_PROJECT_BACKPOINTER, &tProjectRev ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Set the Project Back Pointer
		DNVGL_TRACE_CALL(  iStatus = AOM_assign_tag( secondaryObjTag, AP4_PROJECT_BACKPOINTER, tProjectRev ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Set the Project Folder Back Pointer
		DNVGL_TRACE_CALL(  iStatus = AOM_assign_tag( secondaryObjTag, AP4_PROJFOLDER_BACKPOINTER, primaryObjTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Assign tc project to the AP4_Document
		DNVGL_TRACE_CALL(  iStatus = AOM_ask_value_tags( primaryObjTag, PROJECT_LIST, &iNoOfProjects, &tProjects ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(  iStatus = PROJ_assign_objects( iNoOfProjects, tProjects, 1, &secondaryObjTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(  iStatus = AOM_save( secondaryObjTag ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(  iStatus = AOM_refresh( secondaryObjTag, false ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch (const std::exception &e)
	{
		printf("Error exception:%s\n", e.what());
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_document_relation_operations.cxx
* \par  Description : This will function will perform following operations:
- Get the tc project list from AP4_ProjectFolder
- Remove those tc projects from AP4_Document as the document is being removed from the folder.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   tPrimaryObj    Tag of the primary object of AP4_DocumentRelation which would be AP4_ProjectFolder in this case.
* \param[in]   tSecondaryObj  Tag of the secondary object of AP4_DocumentRelation which would be AP4_Document in this case.
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_document_relation_fnd0delete( tag_t tPrimaryObj, tag_t tSecondaryObj )
{
	int iStatus				= ITK_ok;
	int iNoOfProjects		= 0;
	tag_t* tProjects		= NULL;

	DNVGL_TRACE_ENTER();
	try
	{		
		DNVGL_TRACE_CALL(  iStatus = AOM_ask_value_tags( tPrimaryObj, PROJECT_LIST, &iNoOfProjects, &tProjects ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(  iStatus = AOM_refresh( tSecondaryObj, true ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(  iStatus = PROJ_remove_objects( iNoOfProjects, tProjects, 1, &tSecondaryObj ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL(  iStatus = AOM_refresh( tSecondaryObj, false ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
	}
	catch (const std::exception &e)
	{
		TC_write_syslog( "Error exception in dnvgl_override_ap4_document_relation_fnd0delete() :%s\n", e.what() );
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}