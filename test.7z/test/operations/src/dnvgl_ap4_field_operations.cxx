/**
* \file dnvgl_ap4_field_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This file contains the implementation of runtime attributes on AP4_Field and AP4_FieldRevision.
It also contains the implementation of operations which are overridden on above object types, if any.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Srushti Hanjage
*
* \par History:
*--------------------------------------------------------------------------------
* Date         		Name               Description of Change
* 03-March-2017		Srushti Hanjage    Initial Creation
* 23-March-2017     Sanjay Sah         Implemented runtime properties:ap4_open_coc_count, ap4_open_rec_count and ap4_memoranda_count on AP4_FieldRevision.
* 31-March-2017     Sanjay Sah         Implemented runtime properties:ap4_coc_due_count, ap4_coc_overdue_count and ap4_rec_overdue_count on AP4_FieldRevision.
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_field_operations.h"

/**
* \file dnvgl_ap4_field_operations.cxx
* \par  Description :
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   
* \param[in]   
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_assets_countBase( tag_t tFieldRev, int & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	tag_t* tpPriObjs		= NULL;
	DNVGL_TRACE_ENTER();
	try
	{		
		tag_t tAssetFieldRelationType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_ASSETFIELDRELATION, &tAssetFieldRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iPriCount = 0;
		DNVGL_TRACE_CALL( iStatus = GRM_list_primary_objects_only( tFieldRev, tAssetFieldRelationType, &iPriCount, &tpPriObjs ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		
		value = iPriCount;
		isNull = 0;
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpPriObjs );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_field_operations.cxx
* \par  Description :
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   
* \param[in]   
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_field_ap4_projects_countBase( tag_t tFieldRev, int & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	tag_t* tpPriObjs		= NULL;
	DNVGL_TRACE_ENTER();
	try
	{		
		tag_t tFieldRelationType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_FIELDRELATION, &tFieldRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iPriCount = 0;
		DNVGL_TRACE_CALL( iStatus = GRM_list_primary_objects_only( tFieldRev, tFieldRelationType, &iPriCount, &tpPriObjs ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		
		value = iPriCount;
		isNull = 0;
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpPriObjs );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_field_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This function ........
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			         Description of Change
* Mar 2017     Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_override_ap4_coc_due_countBase( tag_t tFieldRev, int & value, bool & isNull )
{
	int iStatus = ITK_ok;
	value = 0; // default value
	isNull = false;

	DNVGL_TRACE_ENTER();
	try
	{	
		std::string lovDisplayVal = "";
		DNVGL_TRACE_CALL( iStatus = dnvgl_lov_get_display_value("AP4_Deliverab_ProjectDocType_LOV", DELI_COC, lovDisplayVal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<DocumentQueryResult_t> qryResults;
		DNVGL_TRACE_CALL( iStatus = dnvgl_query_deliverable_documents(tFieldRev,AP4_FIELDRELATION, DELI_COC, lovDisplayVal.c_str(), qryResults) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t dToday = NULLDATE;
		DNVGL_TRACE_CALL( iStatus = dnvgl_get_current_date_time( &dToday ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Get date 6 months from today (6 months = 182 day)
		date_t dSixMonthsFromToday = NULLDATE;
		DNVGL_TRACE_CALL( iStatus = dnvg_add_days_to_date(dToday, 182, &dSixMonthsFromToday ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int totalCount = qryResults.size();
		for(int inx = 0; inx < totalCount; inx++)
		{
			date_t validationDate = qryResults[inx].rev_ValidationDate;
			if(!DATE_IS_NULL(validationDate) )
			{
				int iValDateToToday = 0;
				int iValDateToSixMonthsFromToday = 0;

				POM_compare_dates(validationDate, dToday, &iValDateToToday);
				POM_compare_dates(validationDate, dSixMonthsFromToday, &iValDateToSixMonthsFromToday);

				// validation date should be later than today AND validation date should be before six months from today
				if(iValDateToToday > -1 && iValDateToSixMonthsFromToday < 0 )
				{
					value++;
				}
			}

			// debug--
			char* dateFormat = NULL;
			DATE_get_internal_date_string_format(&dateFormat);

			char* valDate = NULL;
			DATE_date_to_string(qryResults[inx].rev_ValidationDate, dateFormat, &valDate);

			char* relDate = NULL;
			DATE_date_to_string(qryResults[inx].rev_ReleaseDate, dateFormat, &relDate);

			std::string msg = qryResults[inx].item_ID + ", " + qryResults[inx].rev_ID + ", " + qryResults[inx].rev_ObjectName + ", " + valDate + ", " + relDate;
			//std::cout <<"index:" << inx << "::   " << msg << std::endl;
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_field_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This function ........
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			         Description of Change
* Mar 2017     Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_override_ap4_rec_due_countBase( tag_t tFieldRev, int & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	tag_t* tpPriObjs		= NULL;
	DNVGL_TRACE_ENTER();
	try
	{		

	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpPriObjs );

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_field_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This function ........
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			         Description of Change
* Mar 2017     Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_override_ap4_rec_overdue_countBase( tag_t tFieldRev, int & value, bool & isNull )
{
	int iStatus = ITK_ok;
	value = 0; // default value
	isNull = false;

	DNVGL_TRACE_ENTER();
	try
	{	
		std::string lovDisplayVal = "";
		DNVGL_TRACE_CALL( iStatus = dnvgl_lov_get_display_value("AP4_Deliverab_ProjectDocType_LOV", DELI_VCARECO, lovDisplayVal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<DocumentQueryResult_t> qryResults;
		DNVGL_TRACE_CALL( iStatus = dnvgl_query_deliverable_documents(tFieldRev, AP4_FIELDRELATION, DELI_VCARECO, lovDisplayVal.c_str(), qryResults) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t dCurrDate = NULLDATE;
		DNVGL_TRACE_CALL( iStatus = dnvgl_get_current_date_time( &dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int totalCount = qryResults.size();
		for(int inx = 0; inx < totalCount; inx++)
		{
			date_t validationDate = qryResults[inx].rev_ValidationDate;
			if(!DATE_IS_NULL(validationDate) )
			{
				int answer = 0;
				POM_compare_dates(dCurrDate, validationDate, &answer);

				if(answer == 1) // 1 if dCurrDate is later than validationDate
				{
					value++;
				}
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_field_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This function ........
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			         Description of Change
* Mar 2017     Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_override_ap4_coc_overdue_countBase( tag_t tFieldRev, int & value, bool & isNull )
{
	int iStatus = ITK_ok;
	value = 0; // default value
	isNull = false;

	DNVGL_TRACE_ENTER();
	try
	{	
		std::string lovDisplayVal = "";
		DNVGL_TRACE_CALL( iStatus = dnvgl_lov_get_display_value("AP4_Deliverab_ProjectDocType_LOV", DELI_COC, lovDisplayVal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<DocumentQueryResult_t> qryResults;
		DNVGL_TRACE_CALL( iStatus = dnvgl_query_deliverable_documents(tFieldRev,AP4_FIELDRELATION, DELI_COC, lovDisplayVal.c_str(), qryResults) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t dCurrDate = NULLDATE;
		DNVGL_TRACE_CALL( iStatus = dnvgl_get_current_date_time( &dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int totalCount = qryResults.size();
		for(int inx = 0; inx < totalCount; inx++)
		{
			date_t validationDate = qryResults[inx].rev_ValidationDate;
			if(!DATE_IS_NULL(validationDate) )
			{
				int answer = 0;
				POM_compare_dates(dCurrDate, validationDate, &answer);

				if(answer == 1) // 1 if dCurrDate is later than validationDate
				{
					value++;
				}
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_field_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This function ........
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			         Description of Change
* Mar 2017     Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_override_ap4_memoranda_countBase( tag_t tFieldRev, int & value, bool & isNull )
{
	int iStatus = ITK_ok;
	value = 0; // default value
	isNull = false;

	DNVGL_TRACE_ENTER();
	try
	{	
		std::string lovDisplayVal = "";
		DNVGL_TRACE_CALL( iStatus = dnvgl_lov_get_display_value("AP4_Deliverab_ProjectDocType_LOV", DELI_VCAMEMO, lovDisplayVal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<DocumentQueryResult_t> qryResults;
		DNVGL_TRACE_CALL( iStatus = dnvgl_query_deliverable_documents(tFieldRev,AP4_FIELDRELATION, DELI_VCAMEMO, lovDisplayVal.c_str(), qryResults) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		value = qryResults.size();

		//std::cout <<"\t Memoranda found: "<< value << std::endl;
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_field_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This function ........
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			         Description of Change
* Mar 2017     Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_override_ap4_open_coc_countBase( tag_t tFieldRev, int & value, bool & isNull )
{
	int iStatus = ITK_ok;
	value = 0; // default value
	isNull = false;

	DNVGL_TRACE_ENTER();
	try
	{	
		std::string lovDisplayVal = "";
		DNVGL_TRACE_CALL( iStatus = dnvgl_lov_get_display_value("AP4_Deliverab_ProjectDocType_LOV", DELI_COC, lovDisplayVal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<DocumentQueryResult_t> qryResults;

		DNVGL_TRACE_CALL( iStatus = dnvgl_query_deliverable_documents(tFieldRev,AP4_FIELDRELATION, DELI_COC, lovDisplayVal.c_str(), qryResults) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t dCurrDate = NULLDATE;
		DNVGL_TRACE_CALL( iStatus = dnvgl_get_current_date_time( &dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int totalCount = qryResults.size();
		for(int inx = 0; inx < totalCount; inx++)
		{
			date_t releaseDate = qryResults[inx].rev_ReleaseDate;

			// as of now, we are considering whether document revision is released or not. 
			//  if not released, that means its open.
			// ideally, it should consider only one perticular release status. 
			if(DATE_IS_NULL(releaseDate) )
			{
				value++;
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_field_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This function ........
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			         Description of Change
* Mar 2017     Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_override_ap4_open_rec_countBase( tag_t tFieldRev, int & value, bool & isNull )
{
	int iStatus = ITK_ok;
	value = 0; // default value
	isNull = false;

	DNVGL_TRACE_ENTER();
	try
	{	
		std::string lovDisplayVal = "";
		DNVGL_TRACE_CALL( iStatus = dnvgl_lov_get_display_value("AP4_Deliverab_ProjectDocType_LOV", DELI_VCARECO, lovDisplayVal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<DocumentQueryResult_t> qryResults;
		DNVGL_TRACE_CALL( iStatus = dnvgl_query_deliverable_documents(tFieldRev,AP4_FIELDRELATION,DELI_VCARECO, lovDisplayVal.c_str(), qryResults) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t dCurrDate = NULLDATE;
		DNVGL_TRACE_CALL( iStatus = dnvgl_get_current_date_time( &dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int totalCount = qryResults.size();
		for(int inx = 0; inx < totalCount; inx++)
		{
			date_t releaseDate = qryResults[inx].rev_ReleaseDate;

			// as of now, we are considering whether document revision is released or not. 
			//  if not released, that means its open.
			// ideally, it should consider only one perticular release status. 
			if(DATE_IS_NULL(releaseDate) )
			{
				value++;
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}



int dnvgl_lov_get_display_value(const std::string lovName, const std::string realValue, std::string& displayValue)
{
	int iStatus = ITK_ok;
	displayValue = ""; // default value

	DNVGL_TRACE_ENTER();
	try
	{
		int nLov = 0;
		tag_t* lovTag = NULL;
		DNVGL_TRACE_CALL( iStatus = LOV_find(lovName.c_str(), &nLov, &lovTag) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		if(nLov > 0)
		{
			LOV_usage_t usage;
			int nValues = 0;
			char** dispVal = NULL;
			char** realVal = NULL;

			DNVGL_TRACE_CALL( iStatus = LOV_ask_values_display_string(lovTag[0], &usage, &nValues, &dispVal, &realVal) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS; 

			for(int inx = 0; inx < nValues; inx++)
			{
				char* valDisp = dispVal[inx];
				char* valReal = realVal[inx];

				if(realValue.compare(valReal) == 0)
				{
					displayValue.assign(valDisp);
				}

				// As per LOV_ask_values_display_string API documentation, we have to release each value. Hence not breaking the loop in between
				DNVGL_MEM_FREE(valDisp); 
				DNVGL_MEM_FREE(valReal);
			}
		}
	}
	catch(...)
	{
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}


/**
* \file dnvgl_ap4_field_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This function will query deliverable documents based on given template type and retuns list of deliverable documents .
select puid from AP4_Deliverable where ap4_project_backpointer = "AP4_ProjectRevision" AND ap4_template= "DELI_COC"
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			          Description of Change
* Mar 2017     Sanjay Sah	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_query_deliverable_documents(const tag_t tItemRevision, const char* cpRelationType, const char* cpDocTemplateType, const char* cpDocTemplateTypeDisplayValue, std::vector<DocumentQueryResult_t>& qryResults)
{
	int iStatus = ITK_ok;
	const char* pcEnquiryID = "dnvgl-get-documents";
	const char* pcSelAttrsItem[] = {"puid", "item_id"};
	const char* pcSelAttrsRevision[] = {"puid", "item_revision_id", "object_name", "ap4_validation_date", "date_released", "creation_date" };

	const char* DILIVERABLE_CLASS = "AP4_Deliverable";
	const char* DILIVERABLE_REV_CLASS = "AP4_DeliverableRevision";

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create( pcEnquiryID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, DILIVERABLE_CLASS, 2, pcSelAttrsItem ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, DILIVERABLE_REV_CLASS, 6, pcSelAttrsRevision ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_expr(pcEnquiryID, "bind1", DILIVERABLE_CLASS, "ap4_templatetype", POM_enquiry_equal, cpDocTemplateTypeDisplayValue));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_expr(pcEnquiryID, "bind2", DILIVERABLE_CLASS, "ap4_templatetype", POM_enquiry_equal, cpDocTemplateType));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_expr(pcEnquiryID, "Exp1", "ImanType", "type_name", POM_enquiry_equal, cpRelationType));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr(pcEnquiryID, "Exp2", "ImanRelation", "relation_type", POM_enquiry_equal, "ImanType", "puid"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_tag_expr(pcEnquiryID, "Exp3", "ImanRelation", "secondary_object", POM_enquiry_equal, tItemRevision));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr(pcEnquiryID, "Exp4", DILIVERABLE_CLASS, "ap4_project_backpointer", POM_enquiry_equal, "ImanRelation", "primary_object" ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Exp5", DILIVERABLE_REV_CLASS, "items_tag", POM_enquiry_equal, DILIVERABLE_CLASS, "puid"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(pcEnquiryID, "Exp1.01",  "bind1", POM_enquiry_or, "bind2"));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(pcEnquiryID, "Exp1.02",  "Exp1.01", POM_enquiry_and, "Exp1"));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(pcEnquiryID, "Exp1.1",  "Exp1.02", POM_enquiry_and, "Exp2"));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(pcEnquiryID, "Exp1.2",  "Exp1.1", POM_enquiry_and, "Exp3"));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(pcEnquiryID, "Exp1.3",  "Exp1.2", POM_enquiry_and, "Exp4"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(pcEnquiryID, "Exp1.4",  "Exp1.3", POM_enquiry_and, "Exp5"));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr ( pcEnquiryID, "Exp1.4") );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_order_attr(pcEnquiryID, DILIVERABLE_CLASS, "item_id", POM_enquiry_desc_order ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_order_attr(pcEnquiryID, DILIVERABLE_REV_CLASS, "creation_date", POM_enquiry_desc_order ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		void*** pvQueryResults = NULL;
		int iTotalRows = 0;
		int	iTotalCols = 0;
		int iRows = 0;
		int iCols = 0;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute( pcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute( pcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* tempItemID = NULL;
		for(int iCnt = 0; iCnt < iTotalRows; iCnt++)
		{
			char* itemID = (char*)( pvQueryResults[iCnt][1] );

			// This if statement ensures that we always pick latest revision.
			if( (tc_strcmp(tempItemID, itemID) != 0)) // if the itemId do not match, that means we have new item
			{
				tempItemID = itemID;

				DocumentQueryResult_t row;
				row.uidItem			= *((tag_t*)( pvQueryResults[iCnt][0] ));
				row.item_ID			= (char*)( pvQueryResults[iCnt][1] );
				row.uidRevision		= *((tag_t*)( pvQueryResults[iCnt][2] ));
				row.rev_ID			= (char*)( pvQueryResults[iCnt][3] );
				row.rev_ObjectName	= (char*)( pvQueryResults[iCnt][4] );

				date_t* tmpDt = (date_t*)( pvQueryResults[iCnt][5] );
				row.rev_ValidationDate = ( tmpDt == NULL ) ? NULLDATE : *tmpDt;

				tmpDt = (date_t*)( pvQueryResults[iCnt][6] );
				row.rev_ReleaseDate = ( tmpDt == NULL ) ? NULLDATE : *tmpDt;

				qryResults.push_back( row );
			}
		}

		DNVGL_MEM_FREE(pvQueryResults);

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete (pcEnquiryID) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
	}
	catch(...)
	{
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete(pcEnquiryID) );
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}

int dnvgl_override_ap4_techDoc_countBase( tag_t tFieldRev, int & value, bool & isNull )
{
	int iStatus = ITK_ok;
	value = 0; // default value
	isNull = false;

	DNVGL_TRACE_ENTER();
	try
	{	
		std::vector<DocumentQueryResult_t> qryResults;
		DNVGL_TRACE_CALL( iStatus = dnvgl_query_tech_documents(tFieldRev, qryResults) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		value = qryResults.size();
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


int dnvgl_query_tech_documents(const tag_t tFieldRevision, std::vector<DocumentQueryResult_t>& qryResults)
{
	int iStatus = ITK_ok;
	const char* pcEnquiryID = "dnvgl-get-tech-documents";
	const char* pcSelAttrsItem[] = {"puid", "item_id"};
	const char* pcSelAttrsRevision[] = {"puid", "item_revision_id", "object_name", "ap4_validation_date", "date_released", "creation_date" };

	const char* TECHDOC_CLASS = "AP4_TechDoc";
	const char* TECHDOC_REV_CLASS = "AP4_TechDocRevision";

	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create( pcEnquiryID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, TECHDOC_CLASS, 2, pcSelAttrsItem ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, TECHDOC_REV_CLASS, 6, pcSelAttrsRevision ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_expr(pcEnquiryID, "Exp1", "ImanType", "type_name", POM_enquiry_equal, "AP4_FieldRelation"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr(pcEnquiryID, "Exp2", "ImanRelation", "relation_type", POM_enquiry_equal, "ImanType", "puid"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_tag_expr(pcEnquiryID, "Exp3", "ImanRelation", "secondary_object", POM_enquiry_equal, tFieldRevision));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr(pcEnquiryID, "Exp4", TECHDOC_CLASS, "ap4_project_backpointer", POM_enquiry_equal, "ImanRelation", "primary_object" ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Exp5", TECHDOC_REV_CLASS, "items_tag", POM_enquiry_equal, TECHDOC_CLASS, "puid"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(pcEnquiryID, "Exp1.1",  "Exp1", POM_enquiry_and, "Exp2"));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(pcEnquiryID, "Exp1.2",  "Exp1.1", POM_enquiry_and, "Exp3"));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(pcEnquiryID, "Exp1.3",  "Exp1.2", POM_enquiry_and, "Exp4"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr(pcEnquiryID, "Exp1.4",  "Exp1.3", POM_enquiry_and, "Exp5"));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr ( pcEnquiryID, "Exp1.4") );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_order_attr(pcEnquiryID, TECHDOC_CLASS, "item_id", POM_enquiry_desc_order ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_order_attr(pcEnquiryID, TECHDOC_REV_CLASS, "creation_date", POM_enquiry_desc_order ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
		void*** pvQueryResults = NULL;
		int iTotalRows = 0;
		int	iTotalCols = 0;
		int iRows = 0;
		int iCols = 0;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute( pcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute( pcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		char* tempItemID = NULL;
		for(int iCnt = 0; iCnt < iTotalRows; iCnt++)
		{
			char* itemID = (char*)( pvQueryResults[iCnt][1] );

			// This if statement ensures that we always pick latest revision.
			if( (tc_strcmp(tempItemID, itemID) != 0)) // if the itemId do not match, that means we have new item
			{
				tempItemID = itemID;

				DocumentQueryResult_t row;
				row.uidItem			= *((tag_t*)( pvQueryResults[iCnt][0] ));
				row.item_ID			= (char*)( pvQueryResults[iCnt][1] );
				row.uidRevision		= *((tag_t*)( pvQueryResults[iCnt][2] ));
				row.rev_ID			= (char*)( pvQueryResults[iCnt][3] );
				row.rev_ObjectName	= (char*)( pvQueryResults[iCnt][4] );

				date_t* tmpDt = (date_t*)( pvQueryResults[iCnt][5] );
				row.rev_ValidationDate = ( tmpDt == NULL ) ? NULLDATE : *tmpDt;

				tmpDt = (date_t*)( pvQueryResults[iCnt][6] );
				row.rev_ReleaseDate = ( tmpDt == NULL ) ? NULLDATE : *tmpDt;

				qryResults.push_back( row );
			}
		}

		DNVGL_MEM_FREE(pvQueryResults);

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete (pcEnquiryID) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS; 
	}
	catch(...)
	{
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete(pcEnquiryID) );
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}
