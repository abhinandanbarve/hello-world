/**
* \file dnvgl_ap4_assetstritem_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This file  contains the functions which are called after overriding the operations on AP4_AssetStrItem & AP4_AssetStrItemRevision.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 24-Jan-2017   Vinay Kudari       Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_assetstritem_operations.h"

/**
* \file dnvgl_ap4_assetstritem_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]	tag_t		Tag of the asset str item revision
* \param[out]   values		Vector of tag of project revisions which are related to asset str item revision	
* \param[out]   values		Vector of int which will indicate whether the values are null or not
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_assetstritem_ap4_linked_projectsBase( tag_t tAssetStrRev, std::vector<tag_t> & values, std::vector<int> & isNull )
{
	int iStatus				= ITK_ok;
	tag_t* tpPriObjs		= NULL;
	DNVGL_TRACE_ENTER();
	try
	{		
		tag_t tImpactedElementsRelationType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_IMPACTEDELEMENTS, &tImpactedElementsRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iPriCount = 0;
		DNVGL_TRACE_CALL( iStatus = GRM_list_primary_objects_only( tAssetStrRev, tImpactedElementsRelationType, &iPriCount, &tpPriObjs ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		for(int index = 0; index < iPriCount ; index++)
		{
			values.push_back( tpPriObjs[index] );
			isNull.push_back( 0 );			
		}		
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpPriObjs );
	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}