/**
* \file dnvgl_ap4_field_relation_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_FieldRelation.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 30-May-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_field_relation_operations.h"

/**
* \file dnvgl_ap4_field_relation_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   Pre action to delete all the AP4_AssetRelation between AP4_AssetRevision and AP4_ProjectRevision when the AP4_FieldRelation between given AP4_ProjectRevision and AP4_FieldRevision is deleted.
\endverbatim     
* \param[in]   tPrimaryObj		Primary object i.e. AP4_ProjectRevision
* \param[in]   tSecondaryObj    Secondary object i.e. AP4_FieldRevision
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_override_ap4_field_relation_fnd0DeleteBase( tag_t tProjectRev, tag_t tFieldRev )
{
	int iStatus				= ITK_ok;
	tag_t* tpPrimaryObjs	= NULL;
	tag_t* tpSecondaryObjs	= NULL;

	DNVGL_TRACE_ENTER();
	try
	{
		//Get the relation type tag for AP4_AssetRelation.
		tag_t tRelationType = NULLTAG;
		DNVGL_TRACE_CALL(  iStatus = GRM_find_relation_type( AP4_ASSETRELATION, &tRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Get the secondary objects related to AP4_ProjectRevision by AP4_AssetRelation.
		int iCount = 0;
		DNVGL_TRACE_CALL(  iStatus = GRM_list_secondary_objects_only( tProjectRev, tRelationType, &iCount, &tpSecondaryObjs ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Loop through all the secondary objects and delete the relation between AP4_ProjectRevision and AP4_AssetRevision
		for( int i = 0; i < iCount; i++ )
		{
			tag_t tRelation = NULLTAG;
			DNVGL_TRACE_CALL(  iStatus = GRM_find_relation( tProjectRev, tpSecondaryObjs[i], tRelationType, &tRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			if( tRelation != NULLTAG )
			{
				DNVGL_TRACE_CALL(  iStatus = GRM_delete_relation( tRelation ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;
			}
		}		
	}
	catch( ... )
	{
	}
	
	DNVGL_MEM_FREE( tpPrimaryObjs );
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}