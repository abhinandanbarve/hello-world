/**
* \file dnvgl_ap4_asset_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This file  contains the functions which are called after overriding the operations on AP4_AssetStrItem & AP4_AssetStrItemRevision.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 24-Jan-2017   Vinay Kudari       Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_asset_operations.h"
#include "dnvgl_ap4_field_operations.h"

/**
* \file dnvgl_ap4_asset_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]	tag_t		Tag of the asset str item revision
* \param[out]   values		Vector of tag of project revisions which are related to asset str item revision	
* \param[out]   values		Vector of int which will indicate whether the values are null or not
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_asset_linked_projectsBase( tag_t tAssetRev, std::vector<tag_t> & values, std::vector<int> & isNull )
{
	int iStatus				= ITK_ok;
	tag_t* tpPriObjs		= NULL;
	DNVGL_TRACE_ENTER();
	try
	{		
		tag_t tAssetRelationType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_ASSETRELATION, &tAssetRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iPriCount = 0;
		DNVGL_TRACE_CALL( iStatus = GRM_list_primary_objects_only( tAssetRev, tAssetRelationType, &iPriCount, &tpPriObjs ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for(int index = 0; index < iPriCount ; index++)
		{
			values.push_back( tpPriObjs[index] );
			isNull.push_back( 0 );			
		}		
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpPriObjs );
	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_asset_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]	tag_t		Tag of the asset str item revision
* \param[out]   values		Count of project revisions which are related to asset str item revision	
* \param[out]   values		Int which will indicate whether the values are null or not
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/

int dnvgl_override_asset_ap4_projects_countBase( tag_t tAssetRev, int & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	tag_t* tpPriObjs		= NULL;
	DNVGL_TRACE_ENTER();
	try
	{		
		tag_t tAssetRelationType = NULLTAG;
		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_ASSETRELATION, &tAssetRelationType ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iPriCount = 0;
		DNVGL_TRACE_CALL( iStatus = GRM_list_primary_objects_only( tAssetRev, tAssetRelationType, &iPriCount, &tpPriObjs ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		value = iPriCount;
		isNull = 0;
	}
	catch( ... )
	{
	}

	DNVGL_MEM_FREE( tpPriObjs );
	
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_asset_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This function ........
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			            Description of Change
* May 2017     Srinivasulu Dama	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_get_open_rec_count_on_asset( tag_t tAssetRev, int & value, bool & isNull )
{
	int iStatus = ITK_ok;
	value = 0; // default value
	isNull = false;

	DNVGL_TRACE_ENTER();
	try
	{	
		std::string lovDisplayVal = "";
		DNVGL_TRACE_CALL( iStatus = dnvgl_lov_get_display_value("AP4_Deliverab_ProjectDocType_LOV", DELI_VCARECO, lovDisplayVal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<DocumentQueryResult_t> qryResults;
		DNVGL_TRACE_CALL( iStatus = dnvgl_query_deliverable_documents(tAssetRev,AP4_ASSETRELATION,DELI_VCARECO, lovDisplayVal.c_str(), qryResults) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		date_t dCurrDate = NULLDATE;
		DNVGL_TRACE_CALL( iStatus = dnvgl_get_current_date_time( &dCurrDate ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int totalCount = qryResults.size();
		for(int inx = 0; inx < totalCount; inx++)
		{
			date_t releaseDate = qryResults[inx].rev_ReleaseDate;

			// as of now, we are considering whether document revision is released or not. 
			//  if not released, that means its open.
			// ideally, it should consider only one perticular release status. 
			if(DATE_IS_NULL(releaseDate) )
			{
				value++;
			}
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_asset_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This function ........
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Sanjay Sah
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			            Description of Change
* May 2017     Srinivasulu Dama	              Initial Creation
*--------------------------------------------------------------------------------
*/

int dnvgl_get_memoranda_count_on_asset( tag_t tAssetRev, int & value, bool & isNull )
{
	int iStatus = ITK_ok;
	value = 0; // default value
	isNull = false;

	DNVGL_TRACE_ENTER();
	try
	{	
		std::string lovDisplayVal = "";
		DNVGL_TRACE_CALL( iStatus = dnvgl_lov_get_display_value("AP4_Deliverab_ProjectDocType_LOV", DELI_VCAMEMO, lovDisplayVal ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		std::vector<DocumentQueryResult_t> qryResults;
		DNVGL_TRACE_CALL( iStatus = dnvgl_query_deliverable_documents(tAssetRev,AP4_ASSETRELATION, DELI_VCAMEMO, lovDisplayVal.c_str(), qryResults) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		value = qryResults.size();

		//std::cout <<"\t Memoranda found: "<< value << std::endl;
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
