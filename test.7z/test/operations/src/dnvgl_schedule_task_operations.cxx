/**
* \file dnvgl_schedule_task_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on ScheduleTask.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vivek Mundada
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 20-Jan-2017   Vivek Mundada	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_schedule_task_operations.h"

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_eacBase( tag_t tScheduleTaskTag, int & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Integer properties
		int iETC = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_int( tScheduleTaskTag, AP4_ETC, &iETC ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double iActualHours = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTaskTag, AP4_ACTUAL_HOURS, &iActualHours ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iEAC = (int) (iETC + iActualHours);
		value = iEAC;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_pct_completionBase( tag_t tScheduleTaskTag, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		double iActualHours_RT = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTaskTag, AP4_ACTUAL_HOURS_RT, &iActualHours_RT ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int iEAC_RT = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_int( tScheduleTaskTag, AP4_EAC_RT, &iEAC_RT ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double dPCTCompletion = NULL;

		if( iEAC_RT == 0 )
		{
			dPCTCompletion = 0;
		}
		else
		{
			double calculation = iActualHours_RT / iEAC_RT;
			dPCTCompletion = floor( calculation * 100 ) / 100;
		}

		value = dPCTCompletion;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_eac_min_budgetBase( tag_t tScheduleTaskTag, int & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Integer property
		int iEAC = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_int( tScheduleTaskTag, AP4_EAC, &iEAC ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Read String property
		char* cWorkEffortString = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tScheduleTaskTag, AP4_WORK_EFFORT_STRING, &cWorkEffortString ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int workEffortInt = atoi( cWorkEffortString );

		int dEACMinBudget = iEAC - workEffortInt;
		value = dEACMinBudget;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_fee_revenue_forecastBase( tag_t tScheduleTaskTag, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Integer property
		int iEAC_RT = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_int( tScheduleTaskTag, AP4_EAC_RT, &iEAC_RT ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Read Double property
		double iAvgBillRate_RT = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTaskTag, AP4_AVG_BILL_RATE_RT, &iAvgBillRate_RT ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double dFeeRevenueForecast = iEAC_RT * iAvgBillRate_RT;
		value = dFeeRevenueForecast;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_labour_cost_forecastBase( tag_t tScheduleTaskTag, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Integer property
		int iEAC_RT = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_int( tScheduleTaskTag, AP4_EAC_RT, &iEAC_RT ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Read Double property
		double iCostRate_RT = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTaskTag, AP4_COST_RATE_RT, &iCostRate_RT ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double dLabourCostForecast = iEAC_RT * iCostRate_RT;
		value = dLabourCostForecast;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_msa_tsa_cost_forecastBase( tag_t tScheduleTaskTag, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Double properties
		double dMsaTsa_RT = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTaskTag, AP4_MSA_TSA_RT, &dMsaTsa_RT ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double dFeeRevenueForecast = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTaskTag, AP4_FEE_REVENUE_FORECAST, &dFeeRevenueForecast ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double dRevenue_RT = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTaskTag, AP4_REVENUE_RT, &dRevenue_RT) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		//changed as per the defect 698
		double dMsaTsaCostForecast = NULL;
		if( dRevenue_RT != NULL && dRevenue_RT != 0)
		{
			dMsaTsaCostForecast = ( dMsaTsa_RT / dRevenue_RT * dFeeRevenueForecast ) ;
		}
		else
		{
			dMsaTsaCostForecast = 0;
		}
		value = dMsaTsaCostForecast;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_operating_margin_forecastBase( tag_t tScheduleTaskTag, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Double properties
		double dFeeRevenueForecast = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTaskTag, AP4_FEE_REVENUE_FORECAST, &dFeeRevenueForecast ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double dLabourCostForecast = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTaskTag, AP4_LABOUR_COST_FORECAST, &dLabourCostForecast ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double dMsaTsaCostForecast = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTaskTag, AP4_MSA_TSA_COST_FORECAST, &dMsaTsaCostForecast ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		double dOperatingMarginForecast = NULL;

		if( dFeeRevenueForecast == 0 )
		{
			dOperatingMarginForecast = 0;
		}
		else
		{
			dOperatingMarginForecast = ( ( dFeeRevenueForecast - dLabourCostForecast -  dMsaTsaCostForecast ) / dFeeRevenueForecast ) * 100;
		}

		value = dOperatingMarginForecast;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
Thhis function will calculates the value of the Schedule task attribute type for double.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]  tScheduleTask     Schedule Task tag
* \param[in]  ccpAttributeName  Schedule Task atrribute name
* \param[out] dRetValue		    Calculated return value
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_schedule_task_get_value_double(tag_t tScheduleTask,const char * ccpAttributeName, bool isSumRequired, double & dRetValue)
{
	int iStatus = ITK_ok;
	int iRefFound = 0;
	int * iLevelFound = NULL;
	int iCount = 0;
	tag_t * tpRefObjects = NULLTAG; 
	char * cpScheduleObjType = NULL;
	char * cpTaskType = NULL;
	char * cpScheduleObjectType = NULL;
	char ** cpReferences = NULL;
	double dValue = 0;
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2( tScheduleTask, &cpScheduleObjectType  ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tScheduleTask, FND0TASKTYPESTRING, &cpTaskType) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tc_strcmp( cpScheduleObjectType, SCHEDULETASK ) == 0  )
		{
			if( tc_strcmp(cpTaskType, TASKTYPE_SS) == 0 )
			{	
				// IF type is SS then get the sum of child Task attribute values	
				DNVGL_TRACE_CALL( iStatus = WSOM_where_referenced( tScheduleTask, 2, &iRefFound, &iLevelFound, &tpRefObjects, &cpReferences ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( iRefFound != 0 )
				{
					for(int iRefCnt = 0; iRefCnt < iRefFound; iRefCnt++ )
					{ 
						// get the CTR number of the child Schedule Tasks if its not null then sum the attibute value.
						DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2( tpRefObjects[iRefCnt], &cpScheduleObjType ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( tc_strcmp( cpScheduleObjType, SCHEDULETASK) == 0 )
						{									
							char * cpCtrNumber = NULL;
							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpRefObjects[iRefCnt], AP4_CTR_NUMBER, &cpCtrNumber ) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if( !DNVGL_IS_STRING_EMPTY( cpCtrNumber ) )
							{
								double dTempValue = 0;
								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tpRefObjects[iRefCnt], ccpAttributeName, &dTempValue ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								iCount++;// get the count of schedule task for calculation the avarage for some of the attributes 
								dValue = dValue + dTempValue ;
							}
						}
					}
				}
			}
			else
			{
				// If the task type is 'S' or 'T' the direct value of the attribute.
				iCount = 1;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_double( tScheduleTask, ccpAttributeName, &dValue) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;			
			}
		}
		if( isSumRequired )
		{
			dRetValue = dValue;
		}
		else 
		{
			if( iCount != 0)
			{
				dRetValue = dValue / iCount;
			}
		}
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE(tpRefObjects);
	DNVGL_MEM_FREE(cpScheduleObjType);
	DNVGL_MEM_FREE(cpTaskType);
	DNVGL_MEM_FREE(cpScheduleObjectType);
	DNVGL_MEM_FREE(cpReferences);

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
Thhis function will calculates the value of the Schedule task attribute type for int.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]  tScheduleTask     Schedule Task tag
* \param[in]  ccpAtributeName   Schedule Task atrribute name
* \param[out] iRetValue		    Calculated return value
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_schedule_task_get_value_int(tag_t tScheduleTask,const char * ccpAttributeName, int & iRetValue)
{
	int iStatus = ITK_ok;
	int iRefFound = 0;
	int * iLevelFound = NULL;
	tag_t * tpRefObjects = NULLTAG; 
	char * cpScheduleObjType = NULL;
	char * cpTaskType = NULL;
	char * cpScheduleObjectType = NULL;
	char ** cpReferences = NULL;
	int iValue = 0;
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2( tScheduleTask, &cpScheduleObjectType ) ) ;
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tScheduleTask, FND0TASKTYPESTRING, &cpTaskType) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( tc_strcmp( cpScheduleObjectType , SCHEDULETASK ) == 0  )
		{
			if( tc_strcmp(cpTaskType, TASKTYPE_SS) == 0)
			{	
				// IF type is SS then get the sum of child Task attribute values	
				DNVGL_TRACE_CALL( iStatus = WSOM_where_referenced( tScheduleTask, 2, &iRefFound, &iLevelFound, &tpRefObjects, &cpReferences ) ) ;
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				if( iRefFound != 0 )
				{
					for(int iRefCnt = 0; iRefCnt < iRefFound; iRefCnt++ )
					{
						DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2( tpRefObjects[iRefCnt], &cpScheduleObjType ) );
						DNVGL_LOG_ERROR_AND_THROW_STATUS;

						if( tc_strcmp( cpScheduleObjType, SCHEDULETASK) == 0 )
						{
							char * cpCtrNumber = NULL;
							DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tpRefObjects[iRefCnt], AP4_CTR_NUMBER, &cpCtrNumber ) );
							DNVGL_LOG_ERROR_AND_THROW_STATUS;

							if( !DNVGL_IS_STRING_EMPTY( cpCtrNumber ) )
							{
								int iTempValue = 0;
								DNVGL_TRACE_CALL( iStatus = AOM_ask_value_int( tpRefObjects[iRefCnt], ccpAttributeName, &iTempValue ) );
								DNVGL_LOG_ERROR_AND_THROW_STATUS;

								iValue = iValue + iTempValue ;
							}							
						}
					}
				}
			}
			else
			{
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_int( tScheduleTask, ccpAttributeName, &iValue) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;			
			}
		}
		iRetValue = iValue;
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE(tpRefObjects);
	DNVGL_MEM_FREE(cpScheduleObjType);
	DNVGL_MEM_FREE(cpTaskType);
	DNVGL_MEM_FREE(cpScheduleObjectType);
	DNVGL_MEM_FREE(cpReferences);

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_actual_hours_rtBase( tag_t tScheduleTask, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Double properties
		double dValue = 0;
		DNVGL_TRACE_CALL( iStatus = dnvgl_schedule_task_get_value_double( tScheduleTask, AP4_ACTUAL_HOURS, true, dValue ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		value = dValue;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_etc_rtBase( tag_t tScheduleTask, int & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read integer properties
		int iValue = 0;
		DNVGL_TRACE_CALL( iStatus = dnvgl_schedule_task_get_value_int( tScheduleTask, AP4_ETC, iValue ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		value = iValue;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_eac_rtBase( tag_t tScheduleTask, int & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read integer properties
		int iValue = 0;
		DNVGL_TRACE_CALL( iStatus = dnvgl_schedule_task_get_value_int( tScheduleTask, AP4_EAC, iValue ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		value = iValue;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_eac_min_budget_rtBase( tag_t tScheduleTask, int & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		int iValue = 0;
		// Read Integer property
		int iEAC_RT = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_int( tScheduleTask, AP4_EAC_RT, &iEAC_RT ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		// Read String property
		char* cWorkEffortString = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tScheduleTask, AP4_WORK_EFFORT_STRING, &cWorkEffortString ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		int workEffortInt = atoi( cWorkEffortString );

		int iEACMinBudgetRT = iEAC_RT - workEffortInt;
		value = iEACMinBudgetRT;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_external_rate_rtBase( tag_t tScheduleTask, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Double properties
		double dValue = 0;
		DNVGL_TRACE_CALL( iStatus = dnvgl_schedule_task_get_value_double( tScheduleTask, AP4_EXTERNAL_RATE, false, dValue ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		value = dValue;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_cost_rate_rtBase( tag_t tScheduleTask, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Double properties
		double dValue = 0;
		DNVGL_TRACE_CALL( iStatus = dnvgl_schedule_task_get_value_double( tScheduleTask, AP4_COST_RATE, false, dValue ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		value = dValue;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_revenue_rtBase( tag_t tScheduleTask, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Double properties
		double dValue = 0;
		DNVGL_TRACE_CALL( iStatus = dnvgl_schedule_task_get_value_double( tScheduleTask, AP4_REVENUE, true, dValue ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		value = dValue;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_raw_cost_rtBase( tag_t tScheduleTask, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Double properties
		double dValue = 0;
		DNVGL_TRACE_CALL( iStatus = dnvgl_schedule_task_get_value_double( tScheduleTask, AP4_RAW_COST, true, dValue ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		value = dValue;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_avg_bill_rate_rtBase( tag_t tScheduleTask, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Double properties
		double dValue = 0;
		DNVGL_TRACE_CALL( iStatus = dnvgl_schedule_task_get_value_double( tScheduleTask, AP4_AVG_BILL_RATE, false, dValue ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		value = dValue;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_msa_tsa_rtBase( tag_t tScheduleTask, double & value, bool & isNull )
{
	int iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		// Read Double properties
		double dValue = 0;
		DNVGL_TRACE_CALL( iStatus = dnvgl_schedule_task_get_value_double( tScheduleTask, AP4_MSA_TSA, true, dValue ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		value = dValue;
		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
This function will calculates the value of the ap4_ongoing_documents on Schedule task attribute type for int.
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_ongoing_documentsBase( tag_t tScheduleTask, int & value, bool & isNull )
{
	int iStatus								= ITK_ok;
	const char*     cpcEnquiryID			= "dnvgl-get-schedule-tasks-of-tech-doc-revision";
	const char*		cRelName[]				= {"secondary_object"};
	const char*		csec_name[]				= {"AP4_TechDocRevision"};
	const char*		crelation_name[]		= {"AP4_AssignedDocuments"};
	const char*		cstatusName[]			= {"ap4_document_status"};
	const char*		cstatusvalue1[]			= {"FI ( For Information )"};
	const char*		cstatusvalue2[]			= {"HO ( On Hold )"};

	DNVGL_TRACE_ENTER();
	try
	{
		int				iTotalRows			= 0;
		int				iTotalCols			= 0;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create( cpcEnquiryID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Add the Select parameters
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( cpcEnquiryID, AP4_TECH_DOC_REVISION, 1, cstatusName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( cpcEnquiryID, "ImanRelation", 1, cRelName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;


		//Set the input scheduletask Tag
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_tag_value ( cpcEnquiryID, "Query", 1, &tScheduleTask, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( cpcEnquiryID, "Expr1", "ImanRelation", PRIMARY_OBJECT, POM_enquiry_equal, "Query"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (cpcEnquiryID, "Query1",1 ,crelation_name, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( cpcEnquiryID, "Expr2", "ImanType", "type_name", POM_enquiry_equal, "Query1"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( cpcEnquiryID, "Expr3", "ImanType", "puid", POM_enquiry_equal, "ImanRelation", "relation_type"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (cpcEnquiryID, "Query2",1 ,csec_name, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( cpcEnquiryID, "Expr4", "ItemRevision", OBJECT_TYPE, POM_enquiry_equal, "Query2"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;


		//Add Join statments
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( cpcEnquiryID, "Expr5", "ItemRevision", "puid", POM_enquiry_equal, "ImanRelation", SECONDARY_OBJECT));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( cpcEnquiryID, "Expr7", AP4_TECH_DOC_REVISION, "puid", POM_enquiry_equal, "ImanRelation", SECONDARY_OBJECT));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (cpcEnquiryID, "Query3",1 ,cstatusvalue1, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (cpcEnquiryID, "Query4",1 ,cstatusvalue2, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( cpcEnquiryID, "Expr10", AP4_TECH_DOC_REVISION, AP4_DOCUMENT_STATUS, POM_enquiry_not_equal, "Query4"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( cpcEnquiryID, "Expr9",AP4_TECH_DOC_REVISION, AP4_DOCUMENT_STATUS, POM_enquiry_not_equal, "Query3"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Add the where statments
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.1", "Expr1", POM_enquiry_and, "Expr2"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.2", "Expr9", POM_enquiry_and, "Expr10"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.3", "Expr1.2", POM_enquiry_and, "Expr5"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.4", "Expr1.1", POM_enquiry_and, "Expr1.3"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.5", "Expr1.4", POM_enquiry_and, "Expr4"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.6", "Expr1.5", POM_enquiry_and, "Expr7"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		bool bcond=true;

		//remove the duplicate rows
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_distinct ( cpcEnquiryID,&bcond));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr ( cpcEnquiryID,"Expr1.6"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		void*** pvQueryResults = NULL;

		//Firing the Query
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute( cpcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int iCnt=0; iCnt<iTotalRows; iCnt++ )
		{
			value=iTotalRows;
			isNull=0;
		}

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete (cpcEnquiryID));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	}
	catch( ... )
	{
		iStatus = POM_enquiry_delete ( cpcEnquiryID );
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
This function will calculates the value of the ap4_ongoing_comments on Schedule task attribute type for int.
<description of function>.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   <param>    <description of param>
* \param[in]   <param>    <description of param>
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_ongoing_commentsBase( tag_t tScheduleTask, int & value, bool & isNull )
{
	int iStatus							    = ITK_ok;
	const char*     cpcEnquiryID			= "dnvgl-get-schedule-tasks-of-comment-chain";
	const char*		cRelName[]				= {"secondary_object"};
	const char*		csec_name1[]			= {"AP4_CommentChain"};
	const char*		crelation_name1[]		= {"AP4_CommentChainRelation"};
	const char*		cstatusvalue1[]			= {"Open"};
	const char*		cstatusvalue2[]			= {"Open-Priority"};


	DNVGL_TRACE_ENTER();
	try
	{
		int				iTotalRows			= 0;
		int				iTotalCols			= 0;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create( cpcEnquiryID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Add the Select parameters
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create_class_alias ( cpcEnquiryID, "ImanRelation", 1, "p1" ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create_class_alias ( cpcEnquiryID, "ImanRelation", 1, "p2" ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( cpcEnquiryID, "p1", 1, cRelName ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;


		//Set the input scheduletask Tag
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_tag_value ( cpcEnquiryID, "Query", 1, &tScheduleTask, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( cpcEnquiryID, "Expr1", "p2", PRIMARY_OBJECT, POM_enquiry_equal, "Query"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( cpcEnquiryID, "comExpr1", "p1", PRIMARY_OBJECT, POM_enquiry_equal, AP4_TECH_DOC_REVISION,"puid"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (cpcEnquiryID, "comQuery1",1 ,crelation_name1, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( cpcEnquiryID, "comExpr2", "ImanType", "type_name", POM_enquiry_equal, "comQuery1"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (cpcEnquiryID, "comQuery2",1 ,csec_name1, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( cpcEnquiryID, "comExpr4", "WorkspaceObject", OBJECT_TYPE, POM_enquiry_equal, "comQuery2"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Add Join statments
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( cpcEnquiryID, "comExpr5", "WorkspaceObject", "puid", POM_enquiry_equal, "p1", SECONDARY_OBJECT));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( cpcEnquiryID, "comExpr6", "WorkspaceObject", "puid", POM_enquiry_equal, AP4_COMMENT_CHAIN, "puid"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( cpcEnquiryID, "comExpr7", "p1", SECONDARY_OBJECT, POM_enquiry_equal, AP4_COMMENT_CHAIN, "puid"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (cpcEnquiryID, "Query1",1 ,cstatusvalue1, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (cpcEnquiryID, "Query2",1 ,cstatusvalue2, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( cpcEnquiryID, "Expr2", AP4_COMMENT_CHAIN, AP4_STATUS, POM_enquiry_equal, "Query1"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( cpcEnquiryID, "Expr3", AP4_COMMENT_CHAIN, AP4_STATUS, POM_enquiry_equal, "Query2"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( cpcEnquiryID, "comExpcompare", "p1", PRIMARY_OBJECT, POM_enquiry_equal, "p2", SECONDARY_OBJECT));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.6", "Expr1", POM_enquiry_and, "comExpr1"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.7", "comExpr2", POM_enquiry_and, "Expr1.6"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.2", "Expr2", POM_enquiry_or, "Expr3"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.5", "Expr1.2", POM_enquiry_and, "Expr1.7"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.8", "comExpr4", POM_enquiry_and, "comExpr5"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.4", "comExpr6", POM_enquiry_and, "comExpr7"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr1.9", "Expr1.8", POM_enquiry_and, "comExpr6"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr2.0", "Expr1.5", POM_enquiry_and, "Expr1.4"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr2.1", "Expr1.9", POM_enquiry_and, "Expr2.0"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( cpcEnquiryID, "Expr2.2", "Expr2.1", POM_enquiry_and, "comExpcompare"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr ( cpcEnquiryID,"Expr2.2"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;
		bool cond=true;

		//remove duplicate rows
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_distinct ( cpcEnquiryID,&cond));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;


		void*** pvQueryResults = NULL;

		//Firing the Query
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute( cpcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for( int iCnt=0; iCnt<iTotalRows; iCnt++ )
		{
			value=iTotalRows;
			isNull=0;
		}

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_delete (cpcEnquiryID));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

	}
	catch( ... )
	{
		iStatus = POM_enquiry_delete (cpcEnquiryID);
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}


/**
* \file dnvgl_schedule_task_operations.cxx
* \par  Description :
Calculate the total internal cost for schedule task.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   tScheduleTask    Schedule task tag.
* \param[out]   value    		Value which has to be returned. It is total internal cost.
* \param[out]   isNull    		Boolean which has to be returned. Will be true if value in null else false.
*
* \par Algorithm:
- Get the CTR number on the schedule task. If the task has schedule task, only then calculate the total internal costs.
- If CTR number is not null then get all the AP4_Expenses objects related to schedule task by AP4_ScheduleTaskExpRelation
- Iterate through all the AP4_Expenses objects and sum up the ap4_external_internal_costs.
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_schedule_task_ap4_internal_costsBase( tag_t tScheduleTask, int & value, bool & isNull )
{   
	int iStatus				= ITK_ok;
	tag_t *tpExpenses		= NULL;
	DNVGL_TRACE_ENTER();
	try
	{
	    // Read String property
		char* cpCTRnumber = NULL;
		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tScheduleTask, AP4_CTR_NUMBER, &cpCTRnumber ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( !DNVGL_IS_STRING_EMPTY( cpCTRnumber ) )
		{
			int iExpInternalCost = 0;
			int iCount ;
			DNVGL_TRACE_CALL( iStatus = AOM_get_value_tags( tScheduleTask, AP4_SCHEDULETASKEXPRELATION, &iCount, &tpExpenses ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			for( int i=0; i<iCount; i++ )
			{
				int iInternalCost = NULL;
				DNVGL_TRACE_CALL( iStatus = AOM_ask_value_int( tpExpenses[i], AP4_EXPENSES_INTERNAL_COSTS, &iInternalCost ) );
				DNVGL_LOG_ERROR_AND_THROW_STATUS;

				iExpInternalCost = iInternalCost + iExpInternalCost;
			}

			value = iExpInternalCost;
			isNull = 0;
		}
		else
		{
			value = 0;
			isNull = 1;
		}
	}
	catch( ... )
	{
	}
	DNVGL_MEM_FREE( tpExpenses );
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}