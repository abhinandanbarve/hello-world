/**
* \file dnvgl_ap4_project_operations.cxx
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
This File  contains the functions which are called after overriding the operations on AP4_Project and AP4_ProjectRevision.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name			      Description of Change
* 27-May-2016   Vinay Kudari	      Initial Creation
*--------------------------------------------------------------------------------
*/

#include "dnvgl_ap4_project_folder_operations.h"

using namespace std;

int dnvgl_override_ap4_projectfolder_get_documentrevision( tag_t tProjFolder, std::vector<tag_t> & values, std::vector<int> & isNull )
{   
    int            iStatus                = ITK_ok;
    const char*    pcEnquiryID            = "dnvgl-get-document-revisions-of-projectfolder";

	DNVGL_TRACE_ENTER();
	try
	{
		int			i					= 0;
		int			iTotalRows			= 0;
		int			iTotalCols			= 0;
		int			iRows				= 0;
		int			iCols				= 0;
		tag_t		tItemObj			= NULLTAG;
		tag_t		itemTag				= NULLTAG;

		const char*	pcSelectAttrs[]		= {"puid"};
		const char* select_attr_list1[] = {"item_id"};
		const char* select_attr_list2[] = {"puid","item_revision_id","sequence_id","items_tag"};
		void***		pvQueryResults		= NULL;

		int			Seq1				= 0;
		int			Seq2				= 0;
		tag_t*		MultiRelTag			= NULL;
		
		tag_t tObjectType = NULLTAG;
        DNVGL_TRACE_CALL( iStatus = TCTYPE_ask_object_type( tProjFolder, &tObjectType ) );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;
        tag_t tSurveyorPackageType = NULLTAG;
        DNVGL_TRACE_CALL( iStatus = TCTYPE_find_type( AP4_SURVEYORPACKAGEFOLDER, AP4_SURVEYORPACKAGEFOLDER, &tSurveyorPackageType ) );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;
        bool bIsValidType = false;
        DNVGL_TRACE_CALL( iStatus = TCTYPE_is_type_of( tObjectType, tSurveyorPackageType, &bIsValidType ) );
        DNVGL_LOG_ERROR_AND_THROW_STATUS;
		
        char*    cpRelationName            = NULL;
        if( bIsValidType )
        {
            cpRelationName = AP4_FOLDER_DOCUMENT_RELATION;
        }
        else
        {
            cpRelationName = AP4_DOCUMENT_RELATION;
        }
        const char*    RelName[]       = { cpRelationName };

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create( pcEnquiryID ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create_class_alias ( pcEnquiryID, "ImanType", 1, "IType" ) ); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create_class_alias ( pcEnquiryID,"ImanRelation", 1, "IRelation" ) ); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_create_class_alias ( pcEnquiryID,"ItemRevision", 1, "IRevision" ) ); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_distinct ( pcEnquiryID, true ) ); 
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Add the Select parameters
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, "Item",1,select_attr_list1));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, "IRevision",4,select_attr_list2));	
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Set the input Project Folder Tag
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_tag_value ( pcEnquiryID, "Query", 1, &tProjFolder, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( pcEnquiryID, "Expr1", "IRelation", "primary_object", POM_enquiry_equal, "Query"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_string_value (pcEnquiryID, "Query1",1 ,RelName, POM_enquiry_bind_value ));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_attr_expr ( pcEnquiryID, "Expr2", "IType", "type_name", POM_enquiry_equal, "Query1"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Add Join statments
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr3", "IType", "puid", POM_enquiry_equal, "IRelation", "relation_type"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr4", "Item", "puid", POM_enquiry_equal, "IRelation", "secondary_object"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_join_expr ( pcEnquiryID, "Expr5", "IRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.1", "Expr1", POM_enquiry_and, "Expr2"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.2", "Expr1.1", POM_enquiry_and, "Expr3"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.3", "Expr1.2", POM_enquiry_and, "Expr4"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_expr ( pcEnquiryID, "Expr1.4", "Expr1.3", POM_enquiry_and, "Expr5"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Add the where statments
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_order_attr ( pcEnquiryID,"Item","item_id",POM_enquiry_asc_order));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_order_attr( pcEnquiryID, "IRevision", "items_tag", POM_enquiry_desc_order ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_order_attr( pcEnquiryID, "IRevision", "creation_date", POM_enquiry_desc_order ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_set_where_expr ( pcEnquiryID,"Expr1.4"));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_order_attr ( pcEnquiryID,"IRevision","item_revision_id",POM_enquiry_asc_order));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		DNVGL_TRACE_CALL( iStatus = POM_enquiry_add_order_attr ( pcEnquiryID,"IRevision","sequence_id",POM_enquiry_asc_order));
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Firing the Query
		DNVGL_TRACE_CALL( iStatus = POM_enquiry_execute( pcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		for(int iCnt=0;iCnt<iTotalRows;iCnt++)
		{
			//Adding the Result tag to the vector for Runtime property
			tag_t tmpSecObj		= *( tag_t* )( pvQueryResults[iCnt][1] );
			tag_t tmpItemTag	= *( ( tag_t* ) pvQueryResults[iCnt][4] );

			if( tmpItemTag != itemTag )
			{
				values.push_back(tmpSecObj);
				isNull.push_back(0);
				itemTag = tmpItemTag;
			}	
		}

		iStatus = POM_enquiry_delete ( pcEnquiryID);
	}
	catch(...)
	{
		iStatus = POM_enquiry_delete ( pcEnquiryID);	
	}

	DNVGL_TRACE_LEAVE();
	return iStatus;
}


int dnvgl_override_ap4_projectfolder_set_documentrevision(tag_t tProjFolderTag,const std::vector<tag_t> & values,const std::vector<int> * isNull)
{    

	int			iStatus				= ITK_ok;
	DNVGL_TRACE_ENTER();
	try
	{
		tag_t       tItemTag = NULLTAG;
		tag_t		t_newRev			= NULLTAG;
		tag_t		t_relation_type		= NULLTAG;
		tag_t		tRelatedRev			= NULLTAG;
		tag_t		tRelation			= NULLTAG;

		char *  	item_type = NULL;
		char *  	item_rev_type = NULL;

		std::vector<tag_t>  existingValues;
		std::vector<tag_t>  newValues;
		std::vector<tag_t>  removeValues;
		std::vector<int>    existingIsNull;
		std::string         valueStr = "";		

		// Getting the exisitng doc rev in project folder
		DNVGL_TRACE_CALL( iStatus = dnvgl_override_ap4_projectfolder_get_documentrevision( tProjFolderTag, existingValues, existingIsNull ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//For validation of doc rev
		for (int i=0; i<values.size();i++)
		{
			DNVGL_TRACE_CALL( iStatus = WSOM_ask_object_type2 (values[i],&item_rev_type));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			printf("\nitem_rev_type is: %s\n",item_rev_type);	
			valueStr= item_rev_type;

			if(! ( valueStr.compare( AP4_MDR_DOCUMENT_REVISION ) == 0 || 
				   valueStr.compare( AP4_PROJECT_DOC_REVISION ) == 0 || 
				   valueStr.compare( AP4_TECH_DOC_REVISION ) == 0 || 
				   valueStr.compare( AP4_TRANSMIT_DOC_REVISION ) == 0 || 
				   valueStr.compare( AP4_DOCUMENT_REVISION ) == 0 ) )
			{
				return 919103;
			} 
		}

		// Getting the lsit of documnent revisions to be removed
		for (int i=0; i<existingValues.size();i++)
		{
			if(!( std::find( values.begin(), values.end(), existingValues[i] ) != values.end() ) )
			{
				removeValues.push_back(existingValues[i]);
			}
		}

		// Getting the lsit of documnent revisions to be added
		for (int i=0; i<values.size();i++)
		{
			if(!( std::find( existingValues.begin(), existingValues.end(), values[i] ) != existingValues.end() ) )
			{
				newValues.push_back(values[i]);
			}
		}

		DNVGL_TRACE_CALL( iStatus = GRM_find_relation_type( AP4_DOCUMENT_RELATION, &t_relation_type ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		//Removing the documents revisions and doc from proejcet folder
		for( int i=0; i < removeValues.size() ; i++ )
		{
			DNVGL_TRACE_CALL( iStatus =ITEM_ask_item_of_rev ( removeValues[i], &tItemTag ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus =ITEM_ask_type2 ( tItemTag, &item_type) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus=GRM_find_relation ( tProjFolderTag, tItemTag, t_relation_type, &tRelation) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus=GRM_delete_relation( tRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}

		//Adding the documents revisions and documnet proejcet folder by document relation
		for (int i=0; i<newValues.size();i++)
		{
			DNVGL_TRACE_CALL( iStatus =ITEM_ask_item_of_rev ( newValues[i], &tItemTag) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			//Find and create the document relation
			DNVGL_TRACE_CALL( iStatus=GRM_create_relation( tProjFolderTag,tItemTag,t_relation_type,NULLTAG,&tRelation ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			DNVGL_TRACE_CALL( iStatus=GRM_save_relation( tRelation ));
			DNVGL_LOG_ERROR_AND_THROW_STATUS;
		}
	}
	catch(...)
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_project_folder_operations.cxx
* \par  Description :
To get the folder path.
* \verbatim
*   <description of function>.
\endverbatim     
* \param[in]   tProjFolder		Selected folder or its parent folder
* \param[in]   value			To get the parent path value
* \param[in]   isNull			0
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int dnvgl_override_ap4_project_folder_ap4_folder_pathBase( tag_t tProjFolder, std::string & value, bool & isNull )
{
	int		iStatus			= ITK_ok;
	int		count			= 0;  
	DNVGL_TRACE_ENTER();
	try
	{
		DNVGL_TRACE_CALL( iStatus = getParentFolder( tProjFolder, value, count ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		isNull = 0;
	}
	catch( ... )
	{
	}
	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

/**
* \file dnvgl_ap4_project_folder_operations.cxx
* \par  Description :
<description of function>.
* \verbatim
*   To get the parent path recursively.
\endverbatim     
* \param[in]   tProjFolder		Selected folder or its parent folder
* \param[in]   path				To get the parent path
* \param[in]   count			To restrict to get parent path for first 10 level
*
* \par Algorithm:
* \verbatim  
* \endverbatim
* \par Returns :
* int : 0/error code
*/
int getParentFolder( tag_t tProjFolder, string & path, int count )
{
	int		iStatus				= ITK_ok;
	tag_t	tParentFolder		= NULLTAG;
	char*	folderName			= NULL;

	DNVGL_TRACE_ENTER();
	try
	{
		if( count == 0 )
		{
			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tProjFolder, OBJECT_NAME, &folderName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			path.append( folderName );
		}

		DNVGL_TRACE_CALL( iStatus = AOM_ask_value_tag( tProjFolder, AP4_PARENT_FOLDER, &tParentFolder ) );
		DNVGL_LOG_ERROR_AND_THROW_STATUS;

		if( count < 10 && tParentFolder != NULLTAG)
		{
			++count;

			DNVGL_TRACE_CALL( iStatus = AOM_ask_value_string( tParentFolder, OBJECT_NAME, &folderName ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS;

			string newPath = folderName;
			newPath.append( DELIMITER );
			newPath.append( path );

			path = newPath;

			// Recursive call to get the Parent Project Folder
			DNVGL_TRACE_CALL( iStatus = getParentFolder( tParentFolder, path, count ) );
			DNVGL_LOG_ERROR_AND_THROW_STATUS
		}
	}
	catch( ... )
	{
	}

	DNVGL_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}