/**
* \file dnvgl_ap4_performance_standards.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_PerformanceStandards operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 30-May-2017   Vinay Kudari      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_PERFORMANCE_STANDARDS_OPERATIONS_H
# define DNVGL_AP4_PERFORMANCE_STANDARDS_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_utils.h"

#ifdef __cplusplus
extern "C" {
#endif
	
	//This function will perform custom operations after OOTB createPostBase() operation on AP4_PerformanceStandards
	DNVGLCOMEXP int dnvgl_override_ap4_performance_standards_createPostBase( tag_t tPrimaryObj, tag_t tSecondaryObj );

	//This function will perform custom operations before OOTB fnd0DeleteBase() operation on AP4_PerformanceStandards
	DNVGLCOMEXP int dnvgl_override_ap4_performance_standards_fnd0Delete( tag_t tPrimaryObj, tag_t tSecondaryObj );

#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_PERFORMANCE_STANDARDS_OPERATIONS_H