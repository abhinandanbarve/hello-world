/**
* \file dnvgl_ap4_document_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_document_operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vivek Mundada
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 03-Mar-2017   Srushti Hanjage	      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_DOCUMENT_OPERATIONS_H
# define DNVGL_AP4_DOCUMENT_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_utils.h"

#ifdef __cplusplus
extern "C" {
#endif
	
	//this function will get vector of tags veyorPackages for given dcoumentrevision
	DNVGLCOMEXP int dnvgl_override_ap4_surveyor_packagesBase( tag_t tDocumentRev, std::vector< tag_t >& values, std::vector< int >& isNull );


#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_DOCUMENT_OPERATIONS_H