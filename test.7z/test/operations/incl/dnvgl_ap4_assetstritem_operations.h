/**
* \file dnvgl_ap4_assetstritem_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_AssetStrItem operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 24-Jan-2017   Vinay Kudari       Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_ASSETSTRITEM_OPERATIONS_H
# define DNVGL_AP4_ASSETSTRITEM_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_project_handling.h"
#include "dnvgl_utils.h"

#ifdef __cplusplus
extern "C" {
#endif

	//This function will get related project revision to the asset str item revision.
	DNVGLCOMEXP int dnvgl_override_assetstritem_ap4_linked_projectsBase( tag_t tAssetStrRev, std::vector<tag_t> & values, std::vector<int> & isNull );	

#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_ASSETSTRITEM_OPERATIONS_H