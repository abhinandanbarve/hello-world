/**
* \file dnvgl_project_folder_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_ProjectFolder operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 07-July-2016  Vinay Kudari      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_PROJECT_FOLDER_OPERATIONS_H
# define DNVGL_AP4_PROJECT_FOLDER_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"

#ifdef __cplusplus
extern "C" {
#endif

	//This function will get documents revisions for runtime property
	DNVGLCOMEXP int dnvgl_override_ap4_projectfolder_get_documentrevision( tag_t tProjFolderTag, std::vector<tag_t> & values, std::vector<int> & isNull );

	//This function will set documents revisions for runtime property
	DNVGLCOMEXP int dnvgl_override_ap4_projectfolder_set_documentrevision( tag_t tProjFolderTag, const std::vector<tag_t> & values, const std::vector<int> * isNull );

	//This function will get folder path for runtime property
	DNVGLCOMEXP int dnvgl_override_ap4_project_folder_ap4_folder_pathBase( tag_t tProjFolderTag, std::string & value, bool & isNull );

	DNVGLCOMEXP int getParentFolder( tag_t primaryObjTag, std::string & path, int count );
	
#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_PROJECT_FOLDER_OPERATIONS_H