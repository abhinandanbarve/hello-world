/**
* \file dnvgl_ap4_assetstritem_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_AssetStrItem operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 24-Jan-2017   Vinay Kudari       Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_ASSET_OPERATIONS_H
# define DNVGL_AP4_ASSET_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_project_handling.h"
#include "dnvgl_utils.h"

#ifdef __cplusplus
extern "C" {
#endif

	//This function will get related project revision to the asset revision.
	DNVGLCOMEXP int dnvgl_override_ap4_asset_linked_projectsBase( tag_t tAssetRev, std::vector<tag_t> & values, std::vector<int> & isNull );	

	//This function will get count of related project revision to the asset revision.
	DNVGLCOMEXP int dnvgl_override_asset_ap4_projects_countBase( tag_t tAssetRev, int & value, bool & isNull );

	DNVGLCOMEXP int dnvgl_get_open_rec_count_on_asset( tag_t tAssetRev, int & value, bool & isNull );
	DNVGLCOMEXP int dnvgl_get_memoranda_count_on_asset( tag_t tAssetRev, int & value, bool & isNull );

#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_ASSET_OPERATIONS_H