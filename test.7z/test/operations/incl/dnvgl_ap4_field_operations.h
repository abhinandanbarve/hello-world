/**
* \file dnvgl_ap4_field_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
\par Description:
Header file for AP4_Field and AP4_FieldRevision operations.
\par Since: Release1
\par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Srushti Hanjage
*
* \par History:
*--------------------------------------------------------------------------------
* Date         		Name               Description of Change
* 03-March-2017		Srushti Hanjage    Initial Creation
* 23-March-2017     Sanjay Sah         Implement runtime attributes on AP4_FieldRevision.
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_FIELD_OPERATIONS_H
# define DNVGL_AP4_FIELD_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_utils.h"
#include "time.h"

#ifdef __cplusplus
extern "C" {
#endif

	// structure to represent each row of query result 
	struct DocumentQueryResult_s
	{
		tag_t uidItem;
		std::string item_ID;
		tag_t uidRevision;
		std::string rev_ID;
		std::string rev_ObjectName;
		date_t rev_ValidationDate;
		date_t rev_ReleaseDate;

		// initialize members
		DocumentQueryResult_s() : uidItem(NULLTAG), item_ID(""),
			uidRevision(NULLTAG), rev_ID(""), rev_ObjectName(""),
			rev_ValidationDate(NULLDATE), rev_ReleaseDate(NULLDATE)
        {
        }
	};
	typedef struct DocumentQueryResult_s  DocumentQueryResult_t;

	//This function will get the count of assets for runtime property ap4_assets_count
	DNVGLCOMEXP int dnvgl_override_ap4_assets_countBase( tag_t tFieldRev, int & value, bool & isNull );

	//This function will get the count of projects for runtime property ap4_projects_count
	DNVGLCOMEXP int dnvgl_override_field_ap4_projects_countBase( tag_t tFieldRev, int & value, bool & isNull );

	DNVGLCOMEXP int dnvgl_override_ap4_coc_due_countBase( tag_t tFieldRev, int & value, bool & isNull );
	DNVGLCOMEXP int dnvgl_override_ap4_rec_due_countBase( tag_t tFieldRev, int & value, bool & isNull );
	DNVGLCOMEXP int dnvgl_override_ap4_rec_overdue_countBase( tag_t tFieldRev, int & value, bool & isNull );
	DNVGLCOMEXP int dnvgl_override_ap4_coc_overdue_countBase( tag_t tFieldRev, int & value, bool & isNull );
	DNVGLCOMEXP int dnvgl_override_ap4_memoranda_countBase( tag_t tFieldRev, int & value, bool & isNull );
	DNVGLCOMEXP int dnvgl_override_ap4_open_coc_countBase( tag_t tFieldRev, int & value, bool & isNull );
	DNVGLCOMEXP int dnvgl_override_ap4_open_rec_countBase( tag_t tFieldRev, int & value, bool & isNull );

	DNVGLCOMEXP int dnvgl_override_ap4_techDoc_countBase( tag_t tFieldRev, int & value, bool & isNull );
	
	int dnvgl_lov_get_display_value(std::string lovName, const std::string realValue, std::string& displayValue);
	int dnvgl_query_deliverable_documents(const tag_t tItemRevision,const char* cpRelationType, const char* cpDocTemplateType, const char* cpDocTemplateTypeDisplayValue, std::vector<DocumentQueryResult_t>& qryResults);
	int dnvgl_query_tech_documents(const tag_t tFieldRevision, std::vector<DocumentQueryResult_t>& qryResults);


#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_FIELD_OPERATIONS_H