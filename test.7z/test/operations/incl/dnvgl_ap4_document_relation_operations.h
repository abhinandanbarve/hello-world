/**
* \file dnvgl_ap4_document_relation_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_DocumentRelation operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vivek Mundada
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 09-Dec-2016   Vivek Mundada	      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_DOCUMENT_RELATION_OPERATIONS_H
# define DNVGL_AP4_DOCUMENT_RELATION_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_project_handling.h"

#ifdef __cplusplus
extern "C" {
#endif
	
	//This function will perform custom operations after OOTB createPostBase() operation on AP4_DocumentRelation
	DNVGLCOMEXP int dnvgl_override_ap4_document_relation_createpostbase( tag_t primaryObjTag, tag_t secondaryObjTag );

	//This function will perform custom operations after OOTB fnd0delete() operation on AP4_DocumentRelation
	DNVGLCOMEXP int dnvgl_override_ap4_document_relation_fnd0delete( tag_t tPrimaryObj, tag_t tSecondaryObj );

#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_DOCUMENT_RELATION_OPERATIONS_H