/**
* \file dnvgl_ap4_approval_activities.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_ApprovalActivities operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 30-May-2017   Vinay Kudari      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_APPROVAL_ACTIVITIES_OPERATIONS_H
# define DNVGL_AP4_APPROVAL_ACTIVITIES_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_utils.h"

#ifdef __cplusplus
extern "C" {
#endif
	
	//This function will perform custom operations after OOTB createPostBase() operation on AP4_ApprovalActivities
	DNVGLCOMEXP int dnvgl_override_ap4_approval_activites_createPostBase( tag_t tPrimaryObj, tag_t tSecondaryObj );

	//This function will perform custom operations before OOTB fnd0DeleteBase() operation on AP4_ApprovalActivities
	DNVGLCOMEXP int dnvgl_override_ap4_approval_activites_fnd0Delete( tag_t tPrimaryObj, tag_t tSecondaryObj );

#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_APPROVAL_ACTIVITIES_OPERATIONS_H