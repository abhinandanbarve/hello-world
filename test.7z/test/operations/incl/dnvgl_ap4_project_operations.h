/**
* \file dnvgl_project_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_Project operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 26-May-2016   Vinay Kudari      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_PROJECT_OPERATIONS_H
# define DNVGL_AP4_PROJECT_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_project_handling.h"
#include "dnvgl_utils.h"

#ifdef __cplusplus
extern "C" {
#endif

	//This function will validate the create input during creation of AP4_ProjectRevision
	DNVGLCOMEXP int dnvgl_override_ap4_projectrevision_validatecreateinputbase( );

	//This function will validate the save as input during creation of AP4_ProjectRevision
	DNVGLCOMEXP int dnvgl_override_ap4_projectrevision_validatesaveasinputbase( );

	//This function will perform custom operations after OOTB createPostBase() operation on AP4_ProjectRevision
	DNVGLCOMEXP int dnvgl_override_ap4_projectrevision_createpostbase( tag_t projectRevTag, const char* projectTemplateID, const char* scheduleTemplateID );

	//This function will perform custom operations after OOTB saveAsPostBase() operation on AP4_ProjectRevision
	DNVGLCOMEXP int dnvgl_override_ap4_projectrevision_saveaspostbase( tag_t targetProjectRevTag, tag_t sourceProjectRevTag );

	//This function will get schedule tasks for runtime property
	DNVGLCOMEXP int dnvgl_override_ap4_projectrevision_schedule_taskBase( tag_t tProjectRevTag, std::vector<tag_t> & values, std::vector<int> & isNull );

	//This function will get affinitas environment value for runtime property
	DNVGLCOMEXP int dnvgl_override_ap4_projectrevision_affinitas_envBase( tag_t tProjectRevTag, std::string & value, bool & isNull );

	//This function will get the latest ctr document revisions for runtime property
	DNVGLCOMEXP int dnvgl_override_ap4_projectrevision_ctr_document_revisionsBase( tag_t tProjectRevTag, std::vector<tag_t> & values, std::vector<int> & isNull );

	//This function will remove the addresses from the project revision when a customer is removed from the project revision
	DNVGLCOMEXP int dnvgl_override_ap4_projectrevision_fnd0delete( tag_t primaryObjTag );

	//This function will get used budget value for runtime property
	DNVGLCOMEXP int dnvgl_override_ap4_projectrevision_used_budgetBase( tag_t tProjectRev, int & value, bool & isNull );

#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_PROJECT_OPERATIONS_H