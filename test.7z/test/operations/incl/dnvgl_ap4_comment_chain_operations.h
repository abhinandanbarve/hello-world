/**
* \file dnvgl_ap4_comment_chain_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_CommentChain operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 11-Jan-2017   Vinay Kudari      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_COMMENT_CHAIN_OPERATIONS_H
# define DNVGL_AP4_COMMENT_CHAIN_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_utils.h"

#ifdef __cplusplus
extern "C" {
#endif

	//This function will get schedule tasks for runtime property
	DNVGLCOMEXP int dnvgl_override_ap4_comment_chain_get_all_comments_text( tag_t tCommentChain, std::vector<std::string> & values, std::vector<int> & isNull );

#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_COMMENT_CHAIN_OPERATIONS_H