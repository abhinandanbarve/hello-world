/**
* \file dnvgl_ap4_project_struct_relation_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_ProjectStructRelation operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 30-May-2016   Vinay Kudari      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_PROJECT_STRUCT_RELATION_OPERATIONS_H
# define DNVGL_AP4_PROJECT_STRUCT_RELATION_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_project_handling.h"

#ifdef __cplusplus
extern "C" {
#endif
	
	//This function will perform custom operations after OOTB createPostBase() operation on AP4_ProjectStructRelation
	DNVGLCOMEXP int dnvgl_override_ap4_project_struct_relation_createpostbase( tag_t primaryObjTag, tag_t secondaryObjTag );

#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_PROJECT_STRUCT_RELATION_OPERATIONS_H