/**
* \file dnvgl_schedule_task_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for ScheduleTask operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vivek Mundada
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 20-Jan-2017   Vivek Mundada      Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_SCHEDULE_TASK_OPERATIONS_H
# define DNVGL_SCHEDULE_TASK_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"
#include "dnvgl_project_handling.h"
#include "dnvgl_utils.h"

#ifdef __cplusplus
extern "C" {
#endif

	//This function will calculate the EAC
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_eacBase( tag_t tScheduleTaskTag, int & value, bool & isNull );

	//This function will calculate the PCT Completion
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_pct_completionBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate the EAC minus Budget
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_eac_min_budgetBase( tag_t tScheduleTaskTag, int & value, bool & isNull );

	//This function will calculate the Fee Revenue Forecast
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_fee_revenue_forecastBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate the Labour Cost Forecast
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_labour_cost_forecastBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate the MSA TSA Cost Forecast
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_msa_tsa_cost_forecastBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate the Operating margin Forecast
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_operating_margin_forecastBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_actual_hours_rtBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_etc_rtBase( tag_t tScheduleTaskTag, int & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_eac_rtBase( tag_t tScheduleTaskTag, int & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_eac_min_budget_rtBase( tag_t tScheduleTaskTag, int & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_external_rate_rtBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_cost_rate_rtBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_revenue_rtBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_raw_cost_rtBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_avg_bill_rate_rtBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_msa_tsa_rtBase( tag_t tScheduleTaskTag, double & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_ongoing_documentsBase( tag_t tScheduleTaskTag, int & value, bool & isNull );

	//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_ongoing_commentsBase( tag_t tScheduleTaskTag, int & value, bool & isNull );
	
		//This function will calculate
	DNVGLCOMEXP int dnvgl_override_schedule_task_ap4_internal_costsBase( tag_t tScheduleTaskTag, int & value, bool & isNull );

	DNVGLCOMEXP int dnvgl_schedule_task_get_value_double(tag_t tScheduleTask,const char * ccpAttributeName, bool isSumRequired, double & dRetValue);
	DNVGLCOMEXP int dnvgl_schedule_task_get_value_int(tag_t tScheduleTask,const char * ccpAttributeName ,int & iRetValue);

#ifdef __cplusplus
}
#endif

#endif //DNVGL_SCHEDULE_TASK_OPERATIONS_H