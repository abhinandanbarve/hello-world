/**
* \file dnvgl_ap4_folder_schedule_relation_operations.h
* \ingroup libAP4_dnvgl_operations
* \verbatim
  \par Description:
    Header file for AP4_FolderScheduleRelation operations.
  \par Since: Release1
  \par ENVIRONMENT : C++, ITK

*\endverbatim
* \par Owner:
* Vinay Kudari
*
* \par History:
*--------------------------------------------------------------------------------
* Date         	Name               Description of Change
* 10-May-2017   Vinay Kudari	   Initial Creation
*--------------------------------------------------------------------------------
*/
# ifndef DNVGL_AP4_FOLDER_SCHEDULE_RELATION_OPERATIONS_H
# define DNVGL_AP4_FOLDER_SCHEDULE_RELATION_OPERATIONS_H

#include "dnvgl_common.h"
#include "dnvgl_trace_handling.h"
#include "dnvgl_error_handling.h"

#ifdef __cplusplus
extern "C" {
#endif
	
	//This function will perform custom operations after OOTB createPostBase() operation on AP4_FolderScheduleRelation
	DNVGLCOMEXP int dnvgl_override_ap4_folder_schedule_relation_createpostbase( tag_t tPrimaryObj, tag_t tSecondaryObj );

	//This function will perform custom operations before OOTB fnd0DeleteBase() operation on AP4_FolderScheduleRelation
	DNVGLCOMEXP int dnvgl_override_ap4_folder_schedule_relation_fnd0DeleteBase( tag_t tPrimaryObj, tag_t tSecondaryObj );

#ifdef __cplusplus
}
#endif

#endif //DNVGL_AP4_FOLDER_SCHEDULE_RELATION_OPERATIONS_H